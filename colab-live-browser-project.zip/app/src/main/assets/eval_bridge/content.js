// Cau noi 1 chieu -> 2 chieu: native (Kotlin) -> content script -> eval trong
// trang -> GUI KET QUA THAT (hoac loi that) VE LAI qua port.postMessage().
// TRUOC DAY: loi bi NUOT AM THAM (catch rong), khong bao gio bao ve Kotlin -
// nghia la port connect duoc KHONG co nghia la script chay dung, chi la co
// ket noi thoi. Sua de biet chac chan.
//
// BUG NGHIEM TRONG DA SUA (phat hien khi doi chieu truc tiep code Kotlin):
// Kotlin gui field "type": "eval" nhung ban JS truoc day kiem tra sai ten
// field - dieu kien if KHONG BAO GIO dung, script CHUA TUNG duoc thuc thi
// qua cau noi nay tu truoc den gio (ke ca keepPlayingScript chong YouTube
// tu pause). Sua dung "msg.type". Them echo lai "requestId" trong ket qua
// tra ve - phia Kotlin gio dung nhieu callback dong thoi (khac 1 bien
// callback dung chung truoc day, de bi ghi de mat nhau khi co nhieu lenh
// goi evaluateJs() gan nhau).
(function () {
  // BUG THẬT (xác nhận qua đối chiếu trực tiếp manifest.json +
  // GeckoViewEngine.kt::evaluateJsForTab — không phải đoán): manifest.json
  // khai "all_frames": true, nghĩa là content script này chạy trong MỌI
  // iframe của trang, không chỉ frame chính. Ở phía Kotlin,
  // `evaluateJsForTab()` gửi lệnh eval tới TẤT CẢ port khớp `tabId` —
  // `portTabId[port] == targetTabId` — nhưng port của MỌI iframe trong
  // cùng 1 tab đều được gán CHUNG 1 tabId (tabId gắn theo session/tab,
  // không phân biệt theo frame). Kết quả: khi 1 tab có iframe (quảng cáo,
  // nhúng cross-origin...), MỌI frame (kể cả iframe) đều nhận lệnh eval và
  // có thể trả lời — vì `evalCallbacks` chỉ giữ 1 callback theo requestId,
  // AI TRẢ LỜI TRƯỚC sẽ thắng (race condition). Với favicon cụ thể: script
  // fetchFavicon tìm <link rel="icon">, nếu không có sẽ fallback về
  // `location.origin + '/favicon.ico'` — nếu 1 iframe cross-origin trả lời
  // trước frame chính, favicon hiện ra là của domain HOÀN TOÀN KHÁC (vd
  // iframe quảng cáo), không phải trang người dùng đang xem — đúng khớp
  // triệu chứng "favicon không đúng như trên trang web".
  //
  // Sửa: chỉ frame TRÊN CÙNG (window === window.top) mới connect port và
  // xử lý lệnh eval chung (favicon, zoom, video diagnostic, outerHTML...).
  // Các tính năng hiện có (keepPlayingScript chống YouTube tự pause, v.v.)
  // đều nhắm vào trang top-level (youtube.com chạy ở frame chính, không
  // phải iframe), nên giới hạn này an toàn với toàn bộ tính năng đang có.
  // Nếu SAU NÀY có tính năng thật sự cần eval bên trong iframe cụ thể, cần
  // thiết kế kênh riêng có định danh frame rõ ràng — không dùng lại cầu
  // nối chung này để tránh lặp lại đúng bug này.
  if (window !== window.top) {
    return;
  }
  try {
    var port = browser.runtime.connectNative("browser");
    port.onMessage.addListener(function (msg) {
      if (msg && msg.type === "eval" && typeof msg.script === "string") {
        try {
          // FIX: new Function(script)() chỉ trả về giá trị nếu script có
          // "return" ở cấp cao nhất. Script dạng (function(){...return x;})()
          // là expression-statement — kết quả IIFE tính ra nhưng không được
          // return ra ngoài new Function() → value luôn undefined → log "OK".
          // Sửa: bọc "return <expr>" — nhưng phải trim dấu ";" trailing
          // trước (script Kotlin thường kết thúc bằng ";") để tránh lỗi
          // cú pháp "return (expr;)" không hợp lệ.
          var trimmed = msg.script.trim().replace(/;+$/, "");
          var value = (new Function("return (" + trimmed + ")"))();
          port.postMessage({
            result: "OK" + (value !== undefined ? (": " + String(value)) : ""),
            requestId: msg.requestId
          });
        } catch (e) {
          port.postMessage({
            result: "LOI: " + (e && e.message ? e.message : String(e)),
            requestId: msg.requestId
          });
        }
      }
    });
  } catch (e) {
    // Truong hop hiem trang chan native messaging - bo qua an toan
  }
})();
