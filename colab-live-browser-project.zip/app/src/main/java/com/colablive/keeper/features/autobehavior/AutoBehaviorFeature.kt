
package com.colablive.keeper.features.autobehavior

import com.colablive.keeper.core.BrowserFeature
import com.colablive.keeper.core.SlotManager
import android.content.Context
import android.view.View
import android.widget.*
import android.os.Handler
import android.os.Looper
import android.util.Log
import kotlin.random.Random

class AutoBehaviorFeature : BrowserFeature {
    override val id: String = "auto_behavior"
    override val name: String = "Auto Behavior (Simulate User)"
    private var enabled = false
    private val handler = Handler(Looper.getMainLooper())
    private var runnable: Runnable? = null
    private var currentSlot = 0

    fun setCurrentSlot(slot: Int) { currentSlot = slot }

    override fun isEnabled() = enabled
    override fun setEnabled(enabled: Boolean) {
        this.enabled = enabled
        if (enabled) startSimulation() else stopSimulation()
    }

    private fun startSimulation() {
        runnable = Runnable {
            if (enabled) {
                val session = SlotManager.getSession(currentSlot)
                session?.let {
                    val js = """
                        window.scrollTo(0, ${Random.nextInt(0, 500)});
                        const el = document.elementFromPoint(${Random.nextInt(0, 300)}, ${Random.nextInt(0, 500)});
                        if (el) el.click();
                    """.trimIndent()
                    it.evaluateJS(js) { _, ex ->
                        if (ex != null) Log.e("AutoBehavior", "JS error", ex)
                    }
                }
                handler.postDelayed(runnable!!, Random.nextLong(5000, 15000))
            }
        }
        handler.post(runnable!!)
    }

    private fun stopSimulation() {
        runnable?.let { handler.removeCallbacks(it) }
        runnable = null
    }

    override fun buildSettingsView(context: Context): View? {
        val layout = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
        val sw = Switch(context).apply {
            text = "Enable Auto Behavior"
            setOnCheckedChangeListener { _, isChecked -> setEnabled(isChecked) }
        }
        layout.addView(sw)
        layout.addView(TextView(context).apply { text = "Random scroll & click every 5-15 sec" })
        return layout
    }
}
