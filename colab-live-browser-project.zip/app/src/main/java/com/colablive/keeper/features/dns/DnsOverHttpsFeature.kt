
package com.colablive.keeper.features.dns

import com.colablive.keeper.core.BrowserFeature
import android.content.Context
import android.view.View
import android.widget.*
import android.util.Log

class DnsOverHttpsFeature : BrowserFeature {
    override val id: String = "dns_over_https"
    override val name: String = "DNS over HTTPS"
    private var enabled = false
    var dnsProvider = "https://dns.google/dns-query"

    override fun isEnabled() = enabled
    override fun setEnabled(enabled: Boolean) {
        this.enabled = enabled
        if (enabled) Log.d("DNS", "DoH set to: $dnsProvider")
    }

    override fun buildSettingsView(context: Context): View? {
        val layout = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
        val input = EditText(context).apply { hint = "DNS over HTTPS URL" }
        val btn = Button(context).apply { text = "Set DNS" }
        btn.setOnClickListener {
            dnsProvider = input.text.toString()
            setEnabled(true)
        }
        layout.addView(input)
        layout.addView(btn)
        return layout
    }
}
