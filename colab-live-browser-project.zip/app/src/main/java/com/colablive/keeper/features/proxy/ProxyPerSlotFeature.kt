
package com.colablive.keeper.features.proxy

import com.colablive.keeper.core.BrowserFeature
import com.colablive.keeper.core.SlotManager
import android.content.Context
import android.view.View
import android.widget.*
import android.util.Log
import org.mozilla.geckoview.GeckoRuntimeSettings.ProxyConfig

class ProxyPerSlotFeature : BrowserFeature {
    override val id: String = "proxy_per_slot"
    override val name: String = "Proxy per Slot"
    private var enabled = false
    var proxyHost = ""
    var proxyPort = 8080
    var proxyType = "HTTP"
    private var currentSlot = 0

    fun setCurrentSlot(slot: Int) { currentSlot = slot }

    override fun isEnabled() = enabled
    override fun setEnabled(enabled: Boolean) {
        this.enabled = enabled
        if (enabled && proxyHost.isNotBlank()) applyProxy()
    }

    private fun applyProxy() {
        val runtime = SlotManager.getRuntime(currentSlot)
        runtime?.let {
            it.settings.proxyConfig = ProxyConfig(proxyHost, proxyPort, proxyType)
            Log.d("Proxy", "Proxy set on slot $currentSlot: $proxyHost:$proxyPort")
        } ?: Log.e("Proxy", "No runtime for slot $currentSlot")
    }

    override fun buildSettingsView(context: Context): View? {
        val layout = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
        val hostInput = EditText(context).apply { hint = "Proxy Host" }
        val portInput = EditText(context).apply { hint = "Proxy Port" }
        val typeSpinner = Spinner(context).apply {
            adapter = ArrayAdapter(context, android.R.layout.simple_spinner_item, listOf("HTTP", "SOCKS5"))
        }
        val saveBtn = Button(context).apply { text = "Save & Apply" }
        saveBtn.setOnClickListener {
            proxyHost = hostInput.text.toString()
            proxyPort = portInput.text.toString().toIntOrNull() ?: 8080
            proxyType = typeSpinner.selectedItem.toString()
            setEnabled(true)
        }
        layout.addView(hostInput)
        layout.addView(portInput)
        layout.addView(typeSpinner)
        layout.addView(saveBtn)
        return layout
    }
}
