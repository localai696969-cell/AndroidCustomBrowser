
package com.colablive.keeper.features.timezone

import com.colablive.keeper.core.BrowserFeature
import android.content.Context
import android.view.View
import android.widget.*
import android.util.Log
import java.util.TimeZone

class TimezoneSyncFeature : BrowserFeature {
    override val id: String = "timezone_sync"
    override val name: String = "Timezone Sync"
    private var enabled = false
    private var currentTimezone = TimeZone.getDefault().id

    override fun isEnabled() = enabled
    override fun setEnabled(enabled: Boolean) {
        this.enabled = enabled
        if (enabled) Log.d("Timezone", "Synced to: $currentTimezone")
    }

    override fun buildSettingsView(context: Context): View? {
        val layout = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
        val tv = TextView(context).apply { text = "System timezone: $currentTimezone" }
        val btn = Button(context).apply { text = "Sync now" }
        btn.setOnClickListener {
            currentTimezone = TimeZone.getDefault().id
            setEnabled(true)
        }
        layout.addView(tv)
        layout.addView(btn)
        return layout
    }
}
