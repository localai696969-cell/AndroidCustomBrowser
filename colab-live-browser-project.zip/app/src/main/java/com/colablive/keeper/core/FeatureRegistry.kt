
package com.colablive.keeper.core

import com.colablive.keeper.features.proxy.ProxyPerSlotFeature
import com.colablive.keeper.features.dns.DnsOverHttpsFeature
import com.colablive.keeper.features.timezone.TimezoneSyncFeature
import com.colablive.keeper.features.cookie.CookieLeakDetector
import com.colablive.keeper.features.autobehavior.AutoBehaviorFeature

object FeatureRegistry {
    private val features = mutableMapOf<String, BrowserFeature>()

    fun register(feature: BrowserFeature) {
        features[feature.id] = feature
    }

    fun get(id: String): BrowserFeature? = features[id]

    fun getAll(): List<BrowserFeature> = features.values.toList()

    init {
        register(ProxyPerSlotFeature())
        register(DnsOverHttpsFeature())
        register(TimezoneSyncFeature())
        register(CookieLeakDetector())
        register(AutoBehaviorFeature())
    }
}
