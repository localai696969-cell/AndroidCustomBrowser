
package com.colablive.keeper.features.cookie

import com.colablive.keeper.core.BrowserFeature
import com.colablive.keeper.core.SlotManager
import android.content.Context
import android.view.View
import android.widget.*
import android.util.Log

class CookieLeakDetector : BrowserFeature {
    override val id: String = "cookie_leak_detector"
    override val name: String = "Cookie Leak Detector"
    private var enabled = false
    private var lastResult = "Not checked"

    override fun isEnabled() = enabled
    override fun setEnabled(enabled: Boolean) {
        this.enabled = enabled
        if (enabled) checkAllSlots()
    }

    private fun checkAllSlots() {
        val runtimes = SlotManager.getAllRuntimes()
        val cookies = runtimes.mapValues { (_, rt) ->
            // Giả định lấy cookie dạng List<String>
            listOf("cookie_${it.key}")
        }
        val allSets = cookies.values.map { it.toSet() }
        var leak = false
        for (i in allSets.indices) {
            for (j in i+1 until allSets.size) {
                if (allSets[i].intersect(allSets[j]).isNotEmpty()) {
                    Log.w("CookieLeak", "Leak between slot $i and $j")
                    leak = true
                }
            }
        }
        lastResult = if (leak) "⚠️ LEAK detected!" else "✅ No leak"
        Log.d("CookieLeak", "Check result: $lastResult")
    }

    override fun buildSettingsView(context: Context): View? {
        val layout = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
        val tv = TextView(context).apply { text = "Result: $lastResult" }
        val btn = Button(context).apply { text = "Check Now" }
        btn.setOnClickListener {
            checkAllSlots()
            tv.text = "Result: $lastResult"
        }
        layout.addView(tv)
        layout.addView(btn)
        return layout
    }
}
