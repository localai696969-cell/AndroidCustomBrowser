
package com.colablive.keeper.features.colablive

import com.colablive.keeper.core.BrowserFeature
import android.content.Context
import android.view.View
import android.net.Uri

class ColabLiveKeeperFeature : BrowserFeature {
    override val id: String = "colab_live_keeper"
    override val name: String = "Colab Live Keeper"
    private var enabled = false

    override fun isEnabled() = enabled
    override fun setEnabled(enabled: Boolean) { this.enabled = enabled }
    override fun buildSettingsView(context: Context): View? = null

    override fun onPageLoaded(url: String) { /* handle page load */ }
    override fun onPageLoadError(url: String, error: String) { /* handle error */ }
    override fun onDropFile(uri: Uri) { /* handle drop */ }
}
