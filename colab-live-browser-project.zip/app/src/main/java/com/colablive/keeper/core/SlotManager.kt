
package com.colablive.keeper.core

import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.GeckoSession

object SlotManager {
    private val runtimes = mutableMapOf<Int, GeckoRuntime>()
    private val sessions = mutableMapOf<Int, GeckoSession>()

    fun registerRuntime(slot: Int, runtime: GeckoRuntime) {
        runtimes[slot] = runtime
    }
    fun getRuntime(slot: Int): GeckoRuntime? = runtimes[slot]
    fun registerSession(slot: Int, session: GeckoSession) {
        sessions[slot] = session
    }
    fun getSession(slot: Int): GeckoSession? = sessions[slot]
    fun getAllRuntimes(): Map<Int, GeckoRuntime> = runtimes
}
