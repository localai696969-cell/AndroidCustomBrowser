# TÀI LIỆU KỸ THUẬT - COLAB LIVE BROWSER
## Phiên bản: 5.0-CLEAN | Cập nhật: 2026-07-19

---

## 1. TỔNG QUAN DỰ ÁN

**Mục tiêu:** App trình duyệt Android tự build, có khả năng giữ phiên Colab sống khi chuyển app/tắt màn hình, hỗ trợ multi-profile với fingerprint spoof và addon extension.

**Ràng buộc:**
- Không có PC, chỉ dùng điện thoại Android + trình duyệt mobile
- Build APK qua GitHub Actions (free)
- Máy chưa root

---

## 2. CÔNG NGHỆ SỬ DỤNG

| Thành phần | Công nghệ | Chi tiết |
|-----------|-----------|---------|
| Browser Engine | GeckoView (Mozilla Firefox) | nightly channel, arm64-v8a |
| Language | Kotlin | AGP 9.0 built-in support |
| Build System | Gradle 9.5.1 | wrapper included |
| CI/CD | GitHub Actions | Build APK tự động |
| Min SDK | 26 | Android 8.0+ |
| Target SDK | 34 | |
| Compile SDK | 36 | |
| GeckoView Version | 150.0.20260511200624 | nightly-arm64-v8a |
| Repository Mozilla | https://maven.mozilla.org/maven2/ | BẮT BUỘC thêm vào settings.gradle |

---

## 3. KIẾN TRÚC MULTI-PROFILE

```
┌─────────────────────────────────────────┐
│         MainActivity (UI chính)          │
│  - Toolbar: Back/Forward/Reload/Omnibox  │
│  - Tab bar (1 tab per slot)              │
│  - Menu: Settings, Debug Log, Features   │
└─────────────────────────────────────────┘
                    │
    ┌───────────────┼───────────────┐
    ▼               ▼               ▼
┌───────┐     ┌───────┐     ┌───────┐
│Slot 0 │     │Slot 1 │     │Slot 2 │     │Slot 3 │
│Main   │     │:slot1 │     │:slot2 │     │:slot3 │
│Process│     │Process│     │Process│     │Process│
│Runtime│     │Runtime│     │Runtime│     │Runtime│
│Cookie │     │Cookie │     │Cookie │     │Cookie │
│tương  │     │tương  │     │tương  │     │tương  │
│đối    │     │đối    │     │đối    │     │đối    │
│lập    │     │lập    │     │lập    │     │lập    │
└───────┘     └───────┘     └───────┘     └───────┘
```

**Quy tắc:**
- Chỉ 1 slot active tại 1 thờ điểm (chuyển slot = đóng slot cũ)
- Mỗi slot có GeckoRuntime instance riêng
- Cookie cô lập TƯƠNG ĐỐI (không 100%, xem phần 7)
- Fingerprint riêng mỗi slot (seed theo slotIndex)

---

## 4. CẤU TRÚC SOURCE CODE

```
colab-live-browser/
├── .github/workflows/build.yml          # GitHub Actions CI
├── app/build.gradle                       # Module config + dependencies
├── app/src/main/AndroidManifest.xml       # 4 activity-alias cho 4 slot
├── app/src/main/assets/
│   ├── eval_bridge/                       # WebExtension nội bộ
│   │   ├── manifest.json
│   │   └── content.js                   # Bridge eval JS
│   └── fingerprint_spoof/               # WebExtension spoof
│       ├── manifest.json
│       └── content.js                     # Canvas, WebGL, Audio, Font spoof
├── app/src/main/java/com/colablive/keeper/
│   ├── MainActivity.kt                    # Activity chính + UI
│   ├── LiveBrowserApp.kt                  # Application class
│   ├── KeepAliveService.kt                # ForegroundService + WakeLock
│   ├── AutoClickAccessibilityService.kt   # Accessibility tap
│   ├── ProfilePickerActivity.kt           # Chọn profile slot
│   ├── SettingsActivity.kt                # Danh sách feature
│   ├── FeatureSettingsActivity.kt         # Cấu hình từng feature
│   ├── DebugLogActivity.kt                # Xem log debug
│   ├── core/                              # Engine + hạ tầng
│   │   ├── BrowserEngine.kt               # Interface engine
│   │   ├── GeckoViewEngine.kt             # GeckoView implementation
│   │   ├── GeckoRuntimeProvider.kt        # Multi-runtime per slot + DNS + Timezone
│   │   ├── BrowserFeature.kt              # Interface feature
│   │   ├── FeatureRegistry.kt             # Đăng ký feature
│   │   ├── ProfileSlots.kt                # Quản lý 4 slot
│   │   ├── AppPrefs.kt                    # SharedPreferences helper
│   │   ├── ForegroundState.kt             # Broadcast liên-process
│   │   ├── DebugLog.kt                    # Ring buffer log
│   │   ├── CookieLeakDetector.kt          # Auto test cookie leak
│   │   └── BuildMarker.kt                 # Version marker
│   ├── features/
│   │   ├── colablives/
│   │   │   └── ColabLiveKeeperFeature.kt  # Giữ Colab sống
│   │   ├── downloads/
│   │   │   ├── DownloadManagerFeature.kt  # Tải file (DownloadManager hệ thống)
│   │   │   ├── DownloadLocationPicker.kt  # Chọn vị trí lưu
│   │   │   ├── DownloadPolicy.kt          # Policy download
│   │   │   └── DownloadModels.kt          # Data class
│   │   ├── fingerprint/
│   │   │   ├── FingerprintSpoofFeature.kt # Giả fingerprint + Proxy config
│   │   │   └── DeviceProfiles.kt          # 20 hardware + 20 locale presets
│   │   └── autobehavior/
│   │       └── AutoBehaviorFeature.kt     # Giả lập hành vi ngườ dùng
│   └── models/
│       └── DownloadModels.kt              # Data class download
└── res/                                   # Layout, strings, drawable
```

---

## 5. TÍNH NĂNG ĐÃ HOÀN THÀNH (22/25)

| # | Tính năng | File | Mô tả | Trạng thái |
|---|-----------|------|-------|------------|
| 1 | Colab Live Keeper | `ColabLiveKeeperFeature.kt` | DOM polling detect dialog + Accessibility tap giữ sống | ✅ |
| 2 | KeepAliveService | `KeepAliveService.kt` | ForegroundService + PARTIAL_WAKE_LOCK | ✅ |
| 3 | AutoClickAccessibility | `AutoClickAccessibilityService.kt` | Tự động tap element theo text target | ✅ |
| 4 | Multi-profile (4 slot) | `ProfileSlots.kt` | 4 slot, mỗi slot process riêng | ✅ |
| 5 | GeckoRuntime riêng/slot | `GeckoRuntimeProvider.kt` | Mỗi slot có runtime instance riêng | ✅ |
| 6 | Fingerprint Spoof UI | `FingerprintSpoofFeature.kt` | Chọn Hardware Profile + Locale Profile | ✅ |
| 7 | Fingerprint inject JS | `fingerprint_spoof/content.js` | Canvas, WebGL, AudioContext, Font, WebRTC | ✅ |
| 8 | Eval Bridge | `eval_bridge/content.js` | Inject JS từ Android sang web page | ✅ |
| 9 | Download Manager (cơ bản) | `DownloadManagerFeature.kt` | Dùng DownloadManager hệ thống Android | ✅ |
| 10 | Debug Log | `DebugLog.kt` | Ring buffer 200 dòng, xem trong DebugLogActivity | ✅ |
| 11 | UI Chrome-like | `MainActivity.kt` | Toolbar, omnibox, navigation buttons | ✅ |
| 12 | Tab bar | `MainActivity.kt` | Hiển thị slot hiện tại | ✅ |
| 13 | File upload fix | `GeckoViewEngine.kt` | mimeType `*/*` cho file upload | ✅ |
| 14 | Drag & Drop | `MainActivity.kt` + `GeckoViewEngine.kt` | Kéo thả file từ file manager | ✅ |
| 15 | Proxy per slot | `FingerprintSpoofFeature.kt` | HTTP/SOCKS5 proxy config cho mỗi slot | ✅ |
| 16 | Auto Behavior | `AutoBehaviorFeature.kt` | Giả lập scroll, click ngẫu nhiên | ✅ |
| 17 | Cookie Leak Detector | `CookieLeakDetector.kt` | Auto test cookie leak giữa các slot | ✅ |
| 18 | DNS over HTTPS | `GeckoRuntimeProvider.kt` | Cloudflare DNS, chống DNS leak | ✅ |
| 19 | Timezone Sync | `GeckoRuntimeProvider.kt` | Đồng bộ timezone với proxy IP | ✅ |
| 20 | Download Location Picker | `DownloadLocationPicker.kt` | Chọn vị trí lưu file | ✅ |
| 21 | Download Policy | `DownloadPolicy.kt` | Policy cơ bản cho download | ✅ |
| 22 | GitHub Actions Build | `.github/workflows/build.yml` | Build APK tự động | ✅ |

---

## 6. TÍNH NĂNG BỊ BỎ QUA (3/25)

| # | Tính năng | Lý do bỏ | Có thể thêm lại? |
|---|-----------|----------|------------------|
| 1 | DownloadEngine custom (multi-thread, pause/resume) | `okhttp3` không có dependency, `TRY_CALL` lỗi | Có - cần thêm dependency |
| 2 | YouTube Download (NewPipeExtractor) | Dependency resolve lỗi từ JitPack | Có - cần fix JitPack hoặc thay thư viện |
| 3 | Stream Sniffer | File hỏng syntax, regex error | Có - viết lại từ đầu |

## 6.1 TÍNH NĂNG PHỤ BỊ XÓA (KHÔNG ẢNH HƯỞNG CORE)

| # | Tính năng | Lý do xóa |
|---|-----------|-----------|
| 1 | WebArchiver | Regex syntax error, `jsoup` dependency |
| 2 | PageConverter (PDF/EPUB/TXT) | Phụ thuộc WebArchiver |
| 3 | WebArchiveDialog | Phụ thuộc WebArchiver |
| 4 | IDMDownloadDialog | Phụ thuộc DownloadEngine custom |
| 5 | SaveLocationDialog | Tính năng phụ |
| 6 | DownloadPolicyManager | Tính năng phụ |

---

## 7. VẤN ĐỀ CHƯA GIẢI QUYẾT (QUAN TRỌNG)

### 7.1 Cookie cô lập 100% - CHƯA ĐẠT

**Thực trạng:**
- GeckoView không có `setDataDirectorySuffix()` như WebView
- `contextId` trong `GeckoSessionSettings` được báo cáo không hoạt động đúng
- Nhiều `GeckoRuntime` instance = cô lập tương đối, không hoàn toàn

**Giải pháp đã thử:**
- Nhiều GeckoRuntime per slot ✅ (đã implement)
- contextId ✅ (đã implement nhưng không đảm bảo)
- Private mode (usePrivateMode=true) - mất login

**Giải pháp thay thế:**
- WebView + `setDataDirectorySuffix()` = cô lập 100% NHƯNG mất addon support
- Root máy + network namespace = hoàn hảo NHƯNG cần root

**Quyết định:** Giữ GeckoView, chấp nhận cô lập tương đối. Test thực tế trên device.

### 7.2 Extension VPN per slot - CHƯA TEST

**Thực trạng:**
- GeckoView hỗ trợ WebExtension API nhưng là subset của Firefox desktop
- Extension VPN thường dùng `browser.proxy` API, chưa chắc GeckoView hỗ trợ
- Chưa test thực tế extension nào chạy được

**Giải pháp thay thế:**
- Proxy trực tiếp trong code (HTTP/SOCKS5) ✅ ĐÃ THÊM
- VPN app hệ thống + đổi server theo slot (chỉ 1 VPN active)

### 7.3 Nhiều IP đồng thờ - KHÔNG THỂ (không root)

**Thực trạng:**
- Android OS chỉ cho 1 VPN active tại 1 thờ điểm
- Không root = không tạo network interface riêng
- Proxy per app không đổi IP toàn hệ thống

**Giải pháp thay thế:**
- Chạy luân phiên: Slot 1 → Proxy 1 → chạy xong → đổi Proxy → Slot 2
- Dùng nhiều điện thoại
- Dùng cloud VPS (mỗi VM = 1 IP)

---

## 8. CẤU HÌNH BUILD QUAN TRỌNG

### 8.1 settings.gradle - BẮT BUỘC thêm repository Mozilla

```gradle
dependencyResolutionManagement {
    repositories {
        maven { url "https://maven.mozilla.org/maven2/" }
        google()
        mavenCentral()
        // maven { url 'https://jitpack.io' } // Cho NewPipeExtractor nếu cần
    }
}
```

### 8.2 app/build.gradle - GeckoView dependency

```gradle
android {
    compileSdk 36
    namespace 'com.colablive.keeper'

    defaultConfig {
        applicationId "com.colablive.keeper"
        minSdk 26
        targetSdk 34
        versionCode 5
        versionName "5.0-CLEAN"
    }
}

ext {
    geckoviewChannel = "nightly"
    geckoviewVersion = "150.0.20260511200624" // Latest May 2026
}

dependencies {
    implementation 'androidx.core:core-ktx:1.13.1'
    implementation 'androidx.appcompat:appcompat:1.7.0'
    implementation 'com.google.android.material:material:1.12.0'

    // GeckoView - BẮT BUỘC có repository Mozilla
    implementation "org.mozilla.geckoview:geckoview-${geckoviewChannel}-arm64-v8a:${geckoviewVersion}"

    // NewPipeExtractor - Comment nếu build lỗi
    // implementation 'com.github.TeamNewPipe:NewPipeExtractor:v0.24.6'

    // jsoup - Comment nếu không dùng WebArchiver
    // implementation 'org.jsoup:jsoup:1.17.2'
}
```

### 8.3 AndroidManifest.xml - 4 slot + Services

```xml
<manifest>
    <application
        android:name=".LiveBrowserApp"
        android:usesCleartextTraffic="true">

        <!-- Main Activity (Slot 0) -->
        <activity android:name=".MainActivity"
            android:exported="true"
            android:launchMode="singleTask"
            android:configChanges="orientation|screenSize">
            <intent-filter>
                <action android:name="android.intent.action.MAIN"/>
                <category android:name="android.intent.category.LAUNCHER"/>
            </intent-filter>
        </activity>

        <!-- Slot 1-3 -->
        <activity-alias android:name=".MainActivity$$slot1"
            android:targetActivity=".MainActivity"
            android:process=":slot1"/>
        <activity-alias android:name=".MainActivity$$slot2"
            android:targetActivity=".MainActivity"
            android:process=":slot2"/>
        <activity-alias android:name=".MainActivity$$slot3"
            android:targetActivity=".MainActivity"
            android:process=":slot3"/>

        <!-- Services -->
        <service android:name=".KeepAliveService"
            android:foregroundServiceType="dataSync"/>

        <service android:name=".AutoClickAccessibilityService"
            android:permission="android.permission.BIND_ACCESSIBILITY_SERVICE"
            android:exported="true">
            <intent-filter>
                <action android:name="android.accessibilityservice.AccessibilityService"/>
            </intent-filter>
        </service>
    </application>
</manifest>
```

---

## 9. LỖI BUILD ĐÃ GẶP VÀ CÁCH FIX

### 9.1 Lỗi: Could not find geckoview:xxx

**Nguyên nhân:** Thiếu repository Mozilla Maven trong `settings.gradle`
**Fix:** Thêm `maven { url "https://maven.mozilla.org/maven2/" }`

### 9.2 Lỗi: Unresolved reference 'name', 'description'

**Nguyên nhân:** `FingerprintSpoofFeature.kt` dùng tên biến không có trong `BrowserFeature` interface
**Fix:** Đổi `name` → `id`, `description` → xóa, `createSettingsView` → `buildSettingsView`

### 9.3 Lỗi: Regex syntax error

**Nguyên nhân:** `WebArchiver.kt` dùng `"` trong string không escape đúng
**Fix:** Xóa file WebArchiver.kt (không thể fix nhanh)

### 9.4 Lỗi: TRY_CALL null error

**Nguyên nhân:** `DownloadEngine.kt` dùng generic type inference sai
**Fix:** Xóa file DownloadEngine.kt (cần viết lại từ đầu)

### 9.5 Lỗi: NewPipeExtractor resolve failed

**Nguyên nhân:** JitPack repository thiếu hoặc version không tồn tại
**Fix:** Comment dependency tạm thờ

### 9.6 Lỗi: Interface method mismatch

**Nguyên nhân:** `ColabLiveKeeperFeature.kt` có hàm không có trong `BrowserFeature`
**Fix:** Thêm `onPageLoaded`, `onPageLoadError`, `onDropFile`; xóa `description`, `intervalMinutes`, `matchesUrl`

---

## 10. QUY TRÌNH BUILD APK

### Bước 1: Upload ZIP lên GitHub
1. Tạo repo mới trên github.com/new
2. Upload file ZIP vào gốc repo
3. Commit

### Bước 2: Chạy GitHub Actions
1. Tab Actions → "Build APK" workflow
2. "Run workflow" → Run
3. Chờ ~5-10 phút

### Bước 3: Tải APK
1. Tab Actions → click workflow vừa chạy
2. Kéo xuống Artifacts
3. Tải `colab-live-browser-debug-apk`
4. Giải nén → cài APK

---

## 11. TEST CHECKLIST

### Trước khi release:
- [ ] Build thành công trên GitHub Actions
- [ ] Cài APK trên device
- [ ] Mở app, load google.com
- [ ] Login Google account trên Slot 1
- [ ] Chuyển Slot 2, vào google.com
- [ ] **KIỂM TRA:** Slot 2 có tự động login account Slot 1 không?
- [ ] Nếu KHÔNG → Cookie cô lập hoạt động ✅
- [ ] Nếu CÓ → Cookie leak ❌ (cần fix)
- [ ] Test Colab Live Keeper: Mở Colab, đợi 90 phút
- [ ] Test KeepAlive: Tắt màn hình, đợi 10 phút, mở lại
- [ ] Test Fingerprint: Vào browserleaks.com, kiểm tra canvas/WebGL
- [ ] Test Proxy: Cấu hình proxy trong Settings, kiểm tra IP
- [ ] Test Auto Behavior: Bật feature, kiểm tra scroll/click tự động
- [ ] Test Cookie Leak Detector: Menu → Test Cookie Leak

---

## 12. GIỚI HẠN BIẾT TRƯỚC

| Giới hạn | Mô tả | Ảnh hưởng |
|----------|-------|-----------|
| Cookie không cô lập 100% | GeckoView hạn chế | Có thể bị Google liên kết account |
| Chỉ 1 VPN active | Android OS giới hạn | Tất cả slot cùng IP nếu dùng VPN app |
| Extension VPN chưa test | GeckoView WebExtension API subset | Chưa chắc addon VPN chạy được |
| Build Chromium không khả thi | Resource quá lớn | Phải dùng GeckoView hoặc pre-built |
| RAM 4GB giới hạn | Nhiều GeckoRuntime tốn RAM | Có thể bị Android kill app |

---

## 13. ROADMAP TƯƠNG LAI

| Ưu tiên | Tính năng | Ghi chú |
|---------|-----------|---------|
| 1 | DownloadEngine custom | Multi-thread + pause/resume, cần okhttp3 |
| 2 | YouTube Download | NewPipeExtractor hoặc thay thế |
| 3 | StreamSniffer | Viết lại từ đầu |
| 4 | Extension VPN test | Kiểm tra addon nào chạy được trên GeckoView |
| 5 | WebArchiver | Viết lại từ đầu, không dùng jsoup |

---

## 14. LỊCH SỬ PHIÊN BẢN

| Version | Ngày | Thay đổi |
|---------|------|----------|
| 1.0 | - | Source gốc từ file .doc |
| 2.0 | - | Thêm multi-tab, UI Chrome-like, fix omnibox |
| 3.0 | - | Thêm DownloadEngine, KeepAlive JobScheduler |
| 4.0 | - | Thêm proxy per profile, data directory riêng |
| 4.1 | - | Thêm auto behavior, DNS over HTTPS, timezone sync |
| 4.2 | - | Thêm WebArchiver, PageConverter |
| 4.3 | - | Thêm Download Policy, Save Location dialog |
| 5.0-FINAL | 2026-07-19 | Clean build, fix tất cả lỗi syntax |
| 5.0-CLEAN | 2026-07-19 | Xóa file lỗi, thêm AutoBehavior, CookieLeakDetector, Proxy, DNS, Timezone |

---

## 15. TÀI LIỆU THAM KHẢO

- GeckoView Docs: https://mozilla.github.io/geckoview/
- Maven Mozilla: https://maven.mozilla.org/
- GitHub Actions: https://docs.github.com/en/actions
- Android WebExtension: https://developer.mozilla.org/en-US/docs/Mozilla/Add-ons/WebExtension

---

**Ngườ viết:** Kimi AI (Moonshot AI)
**Phiên bản tài liệu:** 2.0
**Ngày cập nhật:** 2026-07-19
