# Live Browser (colab-live-browser) — Tài liệu trạng thái dự án

> File này là nguồn sự thật duy nhất về tiến độ dự án. Đọc file này TRƯỚC
> khi tiếp tục code — không cần đọc lại lịch sử chat để hiểu bối cảnh.
> Cập nhật file này SAU MỖI PHIÊN làm việc tiếp theo, không để nó lỗi thời.

## 1. Mục đích dự án là gì

Ban đầu chỉ là 1 addon Firefox để giữ phiên Google Colab không bị ngắt khi
chuyển sang app khác/tắt màn hình. Sau khi phát hiện addon Firefox không đủ
quyền hệ thống để làm việc này, dự án chuyển thành **1 app trình duyệt
Android tự build từ đầu**, với Colab Live Keeper chỉ là 1 tính năng trong số
nhiều tính năng dự kiến (download, multi-profile, addon...).

**Ràng buộc quan trọng cần nhớ**: người dùng **không có PC**, chỉ có điện
thoại Android + trình duyệt di động (Chrome). Toàn bộ việc build APK diễn ra
qua **GitHub Actions** (miễn phí), code được viết ở đây rồi đóng gói thành
`.zip`, người dùng upload lên GitHub qua giao diện web mobile.

## 2. Kiến trúc kỹ thuật hiện tại

### 2.1. Engine trình duyệt: GeckoView (không dùng WebView)

- **Lý do đổi từ WebView sang GeckoView**: WebView (Chromium hệ thống)
  không hỗ trợ load WebExtension/addon thật. GeckoView (engine của Firefox,
  Mozilla phân phối dạng thư viện nhúng qua Maven) có hỗ trợ WebExtension
  API thật cho ứng dụng nhúng — mục tiêu dài hạn là load được addon thật.
- **Đã cân nhắc và loại bỏ**: tự fork Chromium (kiểu Kiwi Browser) — không
  khả thi vì cần build từ source (~40GB, nhiều giờ build), vượt xa giới hạn
  GitHub Actions free tier (6h/job, ~14GB đĩa).
- Dependency: `org.mozilla.geckoview:geckoview:${geckoviewVersion}` (xem
  `app/build.gradle`). **LƯU Ý**: tên artifact đúng là `geckoview` (KHÔNG
  phải `geckoview-release` — đã build lỗi thật với tên sai này, xem mục 5).
  Version hiện tại: `145.0.20251124145406` — **cần xác nhận lại số mới nhất**
  tại https://mvnrepository.com/artifact/org.mozilla.geckoview/geckoview/versions
  trước khi build nếu đã lâu không cập nhật.
- **CHƯA XÁC NHẬN**: artifact `geckoview` (không suffix) có phải bản đầy đủ
  hay bản "lite" thiếu tài nguyên runtime (cần `geckoview-omni` thay thế)?
  Build qua được nhưng nếu app crash lúc khởi tạo `GeckoRuntime`, đây là nghi
  phạm đầu tiên cần thử.

### 2.2. Kiến trúc "tiện ích" (Feature system) — điểm mạnh nhất của dự án

Không hardcode tính năng vào `MainActivity`. Mọi tiện ích implement interface
`BrowserFeature` (`core/BrowserFeature.kt`), đăng ký vào `FeatureRegistry`
(`core/FeatureRegistry.kt`). Thêm tiện ích mới = viết 1 class mới + thêm 1
dòng vào registry — **không đụng** `MainActivity`, `AutoClickAccessibilityService`,
hay `SettingsActivity`.

Feature hiện có:
- `features/colablive/ColabLiveKeeperFeature.kt` — giữ Colab sống.
- `features/downloads/DownloadManagerFeature.kt` — tải file media thường
  (KHÔNG hỗ trợ YouTube, xem mục 6).

### 2.3. `BrowserEngine` — lớp trừu tượng tách feature khỏi engine cụ thể

`core/BrowserEngine.kt` (interface) + `core/GeckoViewEngine.kt` (implementation
hiện tại, bọc GeckoView). Mọi feature chỉ biết tới `BrowserEngine`, không biết
gì về GeckoView hay WebView cụ thể. **Đây là quyết định kiến trúc đúng nhất
của dự án** — khi chuyển từ WebView sang GeckoView, `ColabLiveKeeperFeature`
và `DownloadManagerFeature` **không cần sửa 1 dòng nào**, chỉ cần viết
`GeckoViewEngine` mới. Nếu sau này đổi engine lần nữa, chỉ cần viết thêm 1
class engine mới.

### 2.4. Hệ thống "khe" (Profile Slots) — trình duyệt con độc lập

`core/ProfileSlots.kt` + khai báo `activity-alias` trong `AndroidManifest.xml`
(hiện tại: `SLOT_COUNT = 4`, tức 5 khe tổng cộng tính cả khe 0/chính).

- Mỗi khe = 1 **tiến trình Android riêng** (`android:process=":slotN"`),
  đây là ràng buộc nền tảng của Android (không tạo process tuỳ ý lúc runtime
  được, phải khai báo tĩnh trong Manifest).
- Gán profile (tên tự đặt, không giới hạn số lượng) vào khe (số lượng cố
  định) — đổi gán = khởi động lại đúng 1 khe đó qua `ProfilePickerActivity`.
- **CHƯA HOÀN THÀNH**: cô lập dữ liệu `GeckoRuntime` thật theo từng khe.
  Trước đây dùng `WebView.setDataDirectorySuffix()` cho việc này (khi còn
  dùng WebView) — GeckoView có cơ chế tương đương nhưng **CHƯA tra cứu API
  chính xác** (xem `LiveBrowserApp.kt`, có TODO ghi rõ). **Hệ quả hiện tại:
  mọi khe đang dùng chung 1 GeckoRuntime data — cookie/session KHÔNG cô lập
  thật giữa các khe.** Đây là việc ưu tiên cao cần làm tiếp.

### 2.5. Cấu hình theo từng khe (`AppPrefs`)

`core/AppPrefs.kt` — mọi cấu hình feature (bật/tắt, interval...) namespace
theo `slotIndex` tường minh (file SharedPreferences riêng: `browser_prefs_slotN`).
**Đã sửa 1 bug thật**: ban đầu cấu hình dùng chung toàn app (bật Colab ở khe
1 thì khe khác cũng bật theo) — đã sửa để mỗi khe độc lập hoàn toàn. Interface
`BrowserFeature` bắt buộc mọi hàm nhận `slotIndex` tường minh để tránh tái
phạm lỗi này khi thêm feature mới.

### 2.6. Cơ chế giữ Colab sống (2 chế độ song song)

Trong `ColabLiveKeeperFeature.kt`, người dùng chọn 1 trong 2 (cấu hình qua
Settings UI):

- **Chế độ DOM**: JS giả lập (`mousemove`, click nút Connect) qua "eval
  bridge" (xem mục 2.7). Không cần bật màn hình. **`isTrusted` của event
  KHÔNG đảm bảo = true** — nếu Colab kiểm tra cờ này, cách này thất bại.
  Chưa kiểm chứng thực tế Colab có check hay không.
- **Chế độ Accessibility**: `AutoClickAccessibilityService.kt` dùng
  `dispatchGesture()` — tap thật ở tầng input Android, gần như chắc chắn
  `isTrusted = true`. Đánh đổi: cần bật màn hình + đưa app lên foreground
  mỗi chu kỳ (mặc định 20 phút, dưới ngưỡng idle-timeout ~90 phút của Colab)
  để tap trúng đúng chỗ.
- Cả 2 chế độ đều **CHƯA được test thực tế** trên thiết bị (do các lỗi build
  chặn trước đó) — xem mục 4 "Việc cần làm tiếp theo", đây là việc ưu tiên
  SỐ 1 cần làm ngay khi app chạy ổn định.

### 2.7. "Eval bridge" — cách chạy JS trong GeckoView

GeckoView không có API kiểu `WebView.evaluateJavascript()`. Giải pháp: 1
WebExtension nội bộ tự đóng gói trong `assets/eval_bridge/` (`manifest.json`
+ `content.js`) — **KHÔNG PHẢI addon thật cho người dùng cài**, chỉ là hạ
tầng nội bộ. Cơ chế: content script mở `Port` qua
`browser.runtime.connectNative("browser")`, native side (`GeckoViewEngine.kt`)
nhận qua `session.webExtensionController.setMessageDelegate()`, gửi lệnh eval
qua `port.postMessage()`. **1 CHIỀU** (native → trang), không có giá trị trả
về thật — `evaluateJs()` trong `BrowserEngine` luôn callback `null`.

Cơ chế này giờ còn dùng thêm để **giả fingerprint** (xem mục 2.8) — phần
spoof canvas/WebGL nằm TĨNH trực tiếp trong `content.js` (chạy ngay lúc
`document_start`, không qua round-trip native vì cần chạy SỚM hơn cả lúc
trang kịp đọc giá trị thật).

### 2.8. `FingerprintSpoofFeature` — hồ sơ thiết bị TRỌN GÓI (đảm bảo nhất quán)

Bản đầu cho chọn từng thông số rời (WebGL/CPU/RAM độc lập) — rủi ro tự tạo
ra tổ hợp vô lý (vd platform Windows nhưng WebGL renderer của Apple), còn
dễ bị phát hiện hơn cả không giả gì. Đã sửa: `DeviceProfiles.kt` định nghĩa
**hồ sơ trọn gói tự nhất quán bên trong**:
- `HardwareProfile`: platform + WebGL vendor/renderer + hardwareConcurrency +
  deviceMemory đi CÙNG NHAU (5 preset: Windows-Intel, Windows-NVIDIA,
  Windows-AMD, MacBook-M1, Chromebook-Intel).
- `LocaleProfile`: timezone + ngôn ngữ đi CÙNG NHAU (5 preset: VN, Singapore,
  Nhật, Mỹ, Anh).

Random/Manual đều chọn CẢ hồ sơ (không chỉnh từng thông số) — loại bỏ khả
năng tạo tổ hợp không nhất quán **ngay từ thiết kế**, thay vì phải validate
rồi báo lỗi sau (cách này chắc chắn hơn, không có logic kiểm tra nào có thể
viết sai).

**Đã làm** (mặc định BẬT toàn bộ):
- Toggle riêng theo NHÓM: canvas / Hardware Profile / Locale Profile /
  chặn WebRTC (không còn per-signal rời như bản đầu).
- 2 chế độ: Random (seed bền theo `slotIndex`, mỗi khe ra hồ sơ khác nhau,
  ổn định qua các lần mở lại) hoặc Chỉ định (chọn hẳn 1 hồ sơ từ Spinner).
- Cơ chế truyền cấu hình: giống bản đầu (port riêng, đẩy config lúc
  content script connect, có fallback mặc định an toàn tại `document_start`).
- **Mới thêm so với bản đầu**: giả `navigator.platform`, giả
  `Date.prototype.getTimezoneOffset()` + `Intl.DateTimeFormat` (timezone),
  giả `navigator.language`/`languages`, và **chặn hẳn WebRTC**
  (`RTCPeerConnection`/`webkitRTCPeerConnection`/`RTCDataChannel` = undefined)
  để tránh rò IP thật qua ICE candidate.

**CHƯA làm** (liệt kê rõ để không quên):
- Audio fingerprint (`AudioContext` fingerprinting).
- Liệt kê font cài sẵn trên máy.
- User-Agent string chi tiết đồng bộ với Hardware Profile đã chọn (hiện
  "Chế độ máy tính" trong menu là cơ chế RIÊNG, độc lập, đổi
  `GeckoSessionSettings.userAgentMode`/`viewportMode` — CHƯA liên kết với
  platform/hồ sơ đã chọn trong Fingerprint Spoof, có thể gây KHÔNG NHẤT
  QUÁN nếu bật cả 2 cùng lúc theo hướng khác nhau — cần hợp nhất sau).
- Chỉ có 5 preset mỗi loại (Hardware/Locale) — chưa phải "sinh ngẫu nhiên
  không giới hạn" như trình duyệt antidetect thương mại thật.
- **QUAN TRỌNG HƠN CẢ VIỆC THÊM FINGERPRINT**: cookie/storage vẫn CHƯA cô
  lập thật giữa các khe (xem mục 2.4 — GeckoRuntime data chưa tách theo
  slot). Giả fingerprint mà cookie vẫn dùng chung thì các "tài khoản khác
  nhau" vẫn liên kết được qua cookie/session, fingerprint chỉ là 1 lớp bảo
  vệ bổ sung, KHÔNG thay thế được việc cô lập storage thật — ưu tiên sửa
  mục 2.4 trước khi đầu tư thêm vào fingerprint.
- Không có cách nào giả IP thật (proxy theo từng khe) — đây là biện pháp
  chống liên kết MẠNH NHẤT trong thực tế (IP trùng là tín hiệu liên kết
  đáng tin cậy hơn mọi fingerprint JS cộng lại), nhưng nằm ngoài phạm vi
  JS/WebExtension hoàn toàn — cần cấu hình proxy ở tầng network
  (GeckoRuntimeSettings hoặc tương đương), chưa khảo sát API.
- Đây KHÔNG phải giải pháp toàn diện kiểu trình duyệt "antidetect" thương
  mại (Multilogin, GoLogin, AdsPower) — những sản phẩm đó là dự án riêng quy
  mô lớn với hàng chục vector fingerprint + hạ tầng proxy, không kỳ vọng đạt
  được mức đó chỉ qua vài file JS này.

### 2.9. Foreground Service + WakeLock

`KeepAliveService.kt` — Foreground Service thật (khác Firefox addon, không
cần mượn qua media session) + `PARTIAL_WAKE_LOCK` giữ CPU chạy khi màn hình
tắt. Chạy chung 1 instance cho toàn app (Android tự gộp, không tạo nhiều
service dù nhiều khe cùng gọi `startForegroundService`).

### 2.10. Broadcast liên-process (`ForegroundState`)

`core/ForegroundState.kt` — mỗi khe là 1 process riêng, Kotlin `object`
singleton (như `CurrentBrowserState` cũ) **KHÔNG chia sẻ được giữa các
process khác nhau**. Đã sửa bằng broadcast Intent thật
(`setPackage(packageName)` giới hạn nội bộ app) để `AutoClickAccessibilityService`
(luôn chạy ở khe 0) biết được khe nào đang thực sự active + URL của khe đó,
và bật ĐÚNG khe đó lên khi cần tap (trước đây có bug: luôn bật nhầm khe 0).

### 2.11. UI Settings — mỗi feature 1 màn hình riêng (không còn dồn chung)

Trước đây `SettingsActivity` nhồi UI của MỌI feature vào 1 màn hình cuộn dài
— dễ loãng khi thêm feature mới. Đã tách:
- `SettingsActivity.kt` — chỉ còn là DANH SÁCH tên feature (nút bấm điều
  hướng), không tự vẽ UI chi tiết nào.
- `FeatureSettingsActivity.kt` (mới) — nhận `feature_id` + `slot_index` qua
  Intent, tìm đúng feature trong `FeatureRegistry`, hiển thị
  `buildSettingsView()` của riêng feature đó chiếm toàn màn hình.
- Thêm feature mới **không cần sửa** `SettingsActivity`/`FeatureSettingsActivity`
  — tự động xuất hiện trong danh sách nhờ `FeatureRegistry`.

### 2.12. Debug Log — thay Toast thoáng qua

`core/DebugLog.kt` (ring buffer trong bộ nhớ, tối đa 300 dòng, có timestamp)
+ `DebugLogActivity.kt` (xem lại được, có nút Làm mới/Xoá log). Mọi chẩn
đoán trước đây dùng Toast (dễ mất, khó chụp màn hình kịp) giờ ghi vào đây:
`onLoadError`, `onPopupRequested`, `onNavigationAttempt`, `onFilePrompt`.
Truy cập qua menu 3 chấm → 🐞 Debug Log, hoặc từ danh sách Tiện ích.

## 3. Đã hoàn thành (tính năng)

- [x] Kiến trúc feature module mở rộng được (`BrowserFeature`/`FeatureRegistry`)
- [x] `ColabLiveKeeperFeature` — 2 chế độ DOM/Accessibility, cấu hình được
      chu kỳ, cấu hình riêng theo từng khe
- [x] `DownloadManagerFeature` — bắt download file thường qua
      `DownloadManager` hệ thống (không phải engine đa luồng riêng)
- [x] Hệ thống khe/profile (`ProfileSlots`) — cô lập process thật, gán linh
      hoạt qua `ProfilePickerActivity`
- [x] Chuyển engine từ WebView sang GeckoView hoàn toàn
- [x] Eval bridge — chạy JS trong GeckoView
- [x] Navigation: Back/Forward, Reload, báo lỗi tải trang (`onLoadError`)
- [x] Xử lý popup OAuth cơ bản (`onNewSession` → điều hướng tab hiện tại)
- [x] Upload file cơ bản (`onFilePrompt` → `ACTION_OPEN_DOCUMENT` → copy
      `content://` thành `file://` thật, né giới hạn GeckoView)
- [x] UI giống Chrome cơ bản: omnibox bo tròn, icon vector back/forward/refresh,
      overflow menu 3 chấm
- [x] Chế độ máy tính (Desktop mode) — đổi User-Agent + viewport
- [x] Giả fingerprint — `FingerprintSpoofFeature` riêng biệt, toggle từng
      tín hiệu (canvas/WebGL/hardwareConcurrency/deviceMemory), chế độ
      Random (seed riêng bền vững theo khe) hoặc Chỉ định (chọn preset),
      cần khởi động lại khe để áp dụng (xem mục 2.8)
- [x] UI Settings tách riêng từng feature (`FeatureSettingsActivity`) thay
      vì dồn chung 1 màn hình cuộn dài (xem mục 2.11)
- [x] Debug Log bền vững (`DebugLogActivity`) thay Toast thoáng qua khó
      chụp màn hình kịp (xem mục 2.12)
- [x] Xin quyền `POST_NOTIFICATIONS` đúng cách (runtime, Android 13+)
- [x] CI build qua GitHub Actions (`build.yml`) — build được, có ABI split
      (nghi vấn hiệu quả thật, xem mục 5)

## 4. Việc cần làm tiếp theo (ưu tiên từ cao xuống thấp)

1. **Test thực tế Colab Live Keeper có giữ được phiên Colab hay không** — MỤC
   TIÊU GỐC của cả dự án. **ĐĂNG NHẬP GOOGLE ĐÃ XÁC NHẬN THÀNH CÔNG** (log
   19/07 cho thấy luồng OAuth hoàn chỉnh: ServiceLogin → InteractiveLogin →
   CheckCookie → SetSID) — vậy phần điều hướng/popup không còn là rào cản.
   Vẫn CHƯA test được việc giữ phiên qua idle-timeout thật (~90 phút) do các
   lỗi khác chen ngang. Đây vẫn là việc quan trọng nhất.
2. **Cô lập dữ liệu `GeckoRuntime` thật theo từng khe (mục 2.4)** — NÂNG ƯU
   TIÊN lên vị trí 2 (trước đây ở vị trí 3): quan trọng hơn cả việc tiếp tục
   đầu tư vào Fingerprint Spoof, vì cookie/session hiện vẫn dùng CHUNG giữa
   các khe — fingerprint giả tốt tới đâu cũng vô nghĩa nếu cookie vẫn liên
   kết được các "tài khoản khác nhau" lại với nhau.
3. Xác nhận nguyên nhân file upload thực sự thất bại — đã thêm log chi tiết
   ở `onActivityResult` (resultCode, data, lỗi copy file) thay vì chỉ có
   Toast ở `onFilePrompt` như trước; log thực tế (14 lần gọi liên tiếp trong
   7 giây) cho thấy picker fail NGAY LẬP TỨC mỗi lần — đang chờ log mới từ
   `onActivityResult` để biết chính xác nguyên nhân (resultCode gì, hay
   `ACTION_OPEN_DOCUMENT` vẫn không có app nào xử lý được trên máy CAT S52).
4. Xác nhận artifact GeckoView đúng là `geckoview` hay cần `geckoview-omni`
   (mục 2.1).
5. Xác nhận ABI split có thực sự giảm size APK không (mục 5 — nghi ngờ AGP 9
   đổi cú pháp splits).
6. Hợp nhất "Chế độ máy tính" (đổi UA/viewport, cơ chế riêng trong menu) với
   Hardware Profile của Fingerprint Spoof — hiện 2 cơ chế độc lập, bật cả 2
   theo hướng khác nhau có thể gây KHÔNG NHẤT QUÁN (vd chọn platform Mac
   trong Fingerprint Spoof nhưng "Chế độ máy tính" lại set UA Windows).
7. Multi-tab (nhiều tab trong 1 khe) — xác nhận là dự án riêng, quy mô lớn,
   làm SAU khi Colab chạy ổn định.
8. Tích hợp YouTube downloader (NewPipeExtractor) — đã dừng ở bước khảo sát,
   chưa viết code (mục 6).
9. Migrate sang tải addon WebExtension THẬT (không phải eval bridge nội bộ)
   — đây là lý do gốc để đổi sang GeckoView, chưa bắt đầu.
10. Proxy riêng theo từng khe (chống liên kết qua IP — biện pháp mạnh nhất,
    nằm ngoài phạm vi JS hoàn toàn, xem mục 2.8 "CHƯA làm").
11. Audio fingerprint spoof, font enumeration spoof nếu cần mức ẩn danh cao
    hơn nữa (mức độ ưu tiên thấp, chỉ làm nếu 1-10 đã ổn).

## 5. Kỹ thuật đã THẤT BẠI / SAI — để không lặp lại

| Vấn đề | Sai lầm cụ thể | Bài học |
|---|---|---|
| Fork Chromium (Kiwi-style) | Cân nhắc rồi loại bỏ — không khả thi trên GitHub Actions free (build từ source quá nặng) | Không thử lại hướng này trừ khi có hạ tầng build riêng |
| Tên artifact GeckoView | Dùng `geckoview-release` — build lỗi "Could not find". Tên đúng: `geckoview` (không suffix) | Luôn tra Maven thật trước khi đoán tên artifact |
| Version GeckoView | Đoán `150.0` (số ngắn) — sai định dạng, version thật có timestamp dài | Version GeckoView luôn có định dạng `xxx.0.yyyymmddhhmmss` |
| `GeckoView.session = ...` | Gán property trực tiếp — lỗi "'val' cannot be reassigned" vì GeckoView chỉ có `setSession()`, không có setter property chuẩn Kotlin | Luôn dùng `geckoView.setSession(session)` (gọi hàm), không gán property |
| Theme Activity | Khai `@android:style/Theme.Material.Light.NoActionBar` (theme gốc Android) cho `AppCompatActivity` — crash `IllegalStateException: You need to use a Theme.AppCompat theme` | `AppCompatActivity` bắt buộc theme dòng `Theme.AppCompat.*` hoặc `Theme.MaterialComponents.*` |
| Sed hàng loạt sửa `slotIndex` | Dùng `sed` để thêm tham số `slotIndex` vào nhiều lời gọi hàm cùng lúc — sót 1 chỗ (`setIntervalMinutes` trong `ColabLiveKeeperFeature.kt`), gây lỗi build `No value passed for parameter 'minutes'` | Sau khi sed hàng loạt, LUÔN `grep` lại toàn bộ để xác nhận không sót, không tin sed 100% |
| Kotlin shadowing `id` trong `.apply{}` | `FingerprintSpoofFeature.buildSettingsView()` gọi `AppPrefs.getBoolean(context, slotIndex, id, ...)` trực tiếp BÊN TRONG `Switch(context).apply { ... }` — `id` ở đó bị Kotlin hiểu nhầm thành `View.id` (Int, thuộc tính có sẵn của Android View) do `apply` đổi receiver, không phải `FingerprintSpoofFeature.id` (String) như ý muốn → lỗi build "Argument type mismatch: actual type is 'Int', but 'String' was expected" hàng loạt. `ColabLiveKeeperFeature`/`DownloadManagerFeature` KHÔNG dính lỗi này vì chúng gọi qua hàm bọc `isEnabled()/setEnabled()` thay vì gọi `AppPrefs` trực tiếp trong `.apply{}` | Khi viết feature mới có `buildSettingsView()`: (1) không bao giờ dùng bare `id`/`context` mơ hồ bên trong `.apply{}` của bất kỳ `View` con nào (Switch/Button/Spinner/RadioButton đều có thuộc tính `id: Int` kế thừa từ View, sẽ shadow); (2) luôn gán `val featureId = id` ra biến riêng ở đầu hàm rồi dùng biến đó xuyên suốt, hoặc gọi qua hàm bọc như 2 feature kia đã làm đúng từ đầu |
| Upload code lên GitHub | Hiểu nhầm ban đầu: tưởng không up được thư mục qua mobile browser nên định bắt tạo tay từng file — thực ra chỉ cần upload 1 file `.zip` duy nhất (chọn file đơn lẻ hoạt động bình thường trên mobile), rồi để `build.yml` tự `unzip` trong CI | Đừng phức tạp hoá quá mức khi chưa thử cách đơn giản trước |
| `build.yml` không tự cập nhật | Nhiều lần user chỉ upload lại file `.zip` mới nhưng KHÔNG sửa `build.yml` thật trong repo — Actions vẫn chạy bản `build.yml` CŨ, gây lỗi lặp lại y hệt dù code đã sửa | `.zip` và `.github/workflows/build.yml` là 2 thứ ĐỘC LẬP — sửa 1 cái không tự cập nhật cái kia. Chỉ cần nói rõ "lượt này CÓ/KHÔNG đổi build.yml" mỗi lần, đừng nhắc chung chung gây rối |
| Đường dẫn Artifact trong `build.yml` | Hardcode `app/build/outputs/apk/debug/app-debug.apk` — khi bật ABI split, tên file đổi thành `app-arm64-v8a-debug.apk`, gây lỗi "No files were found" | Dùng glob pattern (`**/*.apk`) thay vì đường dẫn cứng, kèm bước `find` chẩn đoán trước khi upload artifact |
| `ACTION_GET_CONTENT` cho file upload | Dùng để mở file picker — nghi ngờ không đáng tin cậy trên 1 số dòng máy (CAT S52) do phụ thuộc app nào có đăng ký intent-filter. Đã đổi sang `ACTION_OPEN_DOCUMENT` (đảm bảo có sẵn qua DocumentsUI hệ thống) — **CHƯA XÁC NHẬN fix có thực sự giải quyết được không**, đang chờ test |
| Quyền `POST_NOTIFICATIONS` | Chỉ khai trong Manifest, KHÔNG xin runtime — trên Android 13+, đây là quyền nguy hiểm bắt buộc xin lúc chạy, khai Manifest không đủ. App chạy được nhưng notification của Foreground Service âm thầm không hiện | Với quyền "dangerous" (list đầy đủ trong docs Android), luôn cần `ActivityCompat.requestPermissions()`, không chỉ khai Manifest |
| Play Protect chặn cài | App dùng `AccessibilityService` → bị Play Protect heuristic chặn cài (mọi APK sideload xin quyền này đều bị nghi ngờ, không phải lỗi code) | Cần tắt tạm "Scan apps with Play Protect" hoặc bật "Install unknown apps" đúng nguồn trước khi cài loại app này |
| Ước lượng % code phụ thuộc WebView | Ước đoán "~30-40%" lúc chưa đo — sau khi đo thật (`grep`) chỉ ~18% file, thấp hơn nhiều. Số liệu đoán trước khi có `BrowserEngine` bị coi là lỗi thời sau khi đã trừu tượng hoá | Luôn đo bằng `grep`/`wc` thật thay vì ước lượng khi bàn về mức độ ảnh hưởng của 1 thay đổi kiến trúc |

## 6. Việc CỐ TÌNH CHƯA làm (và lý do)

- **YouTube video/playlist downloader**: dừng ở mức khảo sát. Không tự viết
  phần giải mã cipher YouTube (đây là việc reverse-engineer liên tục, YouTube
  chủ động chống, và vi phạm ToS trực tiếp — khác bản chất với việc "lách
  timeout" của Colab). Hướng đề xuất: dùng thư viện có sẵn
  **NewPipeExtractor** (Kotlin/Java thuần, nhẹ hơn yt-dlp+Python nhiều, NewPipe
  app dùng chính thư viện này) — coordinate Maven qua JitPack:
  `com.github.TeamNewPipe:NewPipeExtractor:v0.24.6` (kiểm tra version mới
  nhất). **CHƯA viết code wrapper cụ thể** vì chưa tra kỹ API chính xác
  (tên class `StreamExtractor`/`PlaylistExtractor`...), tránh đưa code sai.
- **Fork Chromium để load Chrome extension thật (kiểu Kiwi Browser)**: loại
  bỏ hẳn, không khả thi với hạ tầng build hiện có (mục 5).
- **Multi-tab thật**: xác nhận là tính năng lớn, để sau khi Colab chạy ổn
  định (theo đúng yêu cầu người dùng ưu tiên).
- **Load addon WebExtension thật** (không phải eval bridge nội bộ): đây là
  MỤC TIÊU CUỐI của việc đổi sang GeckoView, nhưng chưa bắt đầu implement —
  cần nghiên cứu thêm API cài đặt addon từ file `.xpi`/URL bên ngoài (khác
  với `ensureBuiltIn()` dùng cho eval bridge, vốn chỉ load resource đóng gói
  sẵn trong APK).

## 7. Quy trình build/deploy (nhắc lại cho người tiếp theo)

1. Sửa code trong dự án này.
2. Đóng gói `zip -r colab-live-browser-project.zip colab-live-browser`.
3. Upload `.zip` này vào **gốc repo GitHub** (Add file → Upload files, chọn
   1 file, hoạt động bình thường trên mobile).
4. **CHỈ KHI có sửa `.github/workflows/build.yml`**: phải sửa TAY file đó
   thật trong repo (Edit trực tiếp trên GitHub), zip không tự cập nhật nó.
5. Tab Actions tự chạy (push) hoặc bấm "Run workflow" thủ công
   (`workflow_dispatch`).
6. Tải APK từ mục Artifacts sau khi build xong.
7. Cài trên điện thoại — có thể cần tắt tạm Play Protect / bật "Install
   unknown apps" (mục 5).

## 8. Thông tin thiết bị test

- Asus Zenfone 8 (ZenUI, gần Android gốc)
- Sharp/CAT S52 (Bullitt Group, rugged, gần Android gốc, đôi khi thiếu 1 số
  app Google mặc định — có thể là nguyên nhân file picker không đáng tin cậy)

## 9. Ghi chú pháp lý/đạo đức đã bàn (không lặp lại cảnh báo dài dòng)

- Việc giữ phiên Colab "sống" khi không thực sự tính toán có thể vi phạm ToS
  của Google Colab (họ có thể hạn chế quota GPU/TPU miễn phí nếu phát hiện).
  Người dùng đã được thông báo, tự quyết định rủi ro.
- Google chủ động chặn đăng nhập từ trình duyệt nhúng "lạ" (embedded browser
  detection) — đây là biện pháp bảo mật thật của Google, không phải bug của
  app này, không có cách nào đảm bảo vượt qua được 100%.
