# Live Browser (colab-live-browser) — Tài liệu trạng thái dự án

> File này là nguồn sự thật duy nhất về tiến độ dự án. Đọc file này TRƯỚC
> khi tiếp tục code — không cần đọc lại lịch sử chat để hiểu bối cảnh.
> Cập nhật file này SAU MỖI PHIÊN làm việc tiếp theo, không để nó lỗi thời.

## 1. Mục đích dự án là gì

Ban đầu chỉ là 1 addon Firefox để giữ phiên Google Colab không bị ngắt khi
chuyển sang app khác/tắt màn hình. Sau khi phát hiện addon Firefox không đủ
quyền hệ thống để làm việc này, dự án chuyển thành **1 app trình duyệt
Android tự build từ đầu**, với Colab Live Keeper chỉ là 1 tính năng trong số
nhiều tính năng dự kiến (download, multi-profile, addon...).

**Ràng buộc quan trọng cần nhớ**: người dùng **không có PC**, chỉ có điện
thoại Android + trình duyệt di động (Chrome). Toàn bộ việc build APK diễn ra
qua **GitHub Actions** (miễn phí), code được viết ở đây rồi đóng gói thành
`.zip`, người dùng upload lên GitHub qua giao diện web mobile.

## 2. Kiến trúc kỹ thuật hiện tại

### 2.1. Engine trình duyệt: GeckoView (không dùng WebView)

- **Lý do đổi từ WebView sang GeckoView**: WebView (Chromium hệ thống)
  không hỗ trợ load WebExtension/addon thật. GeckoView (engine của Firefox,
  Mozilla phân phối dạng thư viện nhúng qua Maven) có hỗ trợ WebExtension
  API thật cho ứng dụng nhúng — mục tiêu dài hạn là load được addon thật.
- **Đã cân nhắc và loại bỏ**: tự fork Chromium (kiểu Kiwi Browser) — không
  khả thi vì cần build từ source (~40GB, nhiều giờ build), vượt xa giới hạn
  GitHub Actions free tier (6h/job, ~14GB đĩa).
- Dependency: `org.mozilla.geckoview:geckoview:${geckoviewVersion}` (xem
  `app/build.gradle`). **LƯU Ý**: tên artifact đúng là `geckoview` (KHÔNG
  phải `geckoview-release` — đã build lỗi thật với tên sai này, xem mục 5).
  Version hiện tại: `145.0.20251124145406` — **cần xác nhận lại số mới nhất**
  tại https://mvnrepository.com/artifact/org.mozilla.geckoview/geckoview/versions
  trước khi build nếu đã lâu không cập nhật.
- **CHƯA XÁC NHẬN**: artifact `geckoview` (không suffix) có phải bản đầy đủ
  hay bản "lite" thiếu tài nguyên runtime (cần `geckoview-omni` thay thế)?
  Build qua được nhưng nếu app crash lúc khởi tạo `GeckoRuntime`, đây là nghi
  phạm đầu tiên cần thử.

### 2.2. Kiến trúc "tiện ích" (Feature system) — điểm mạnh nhất của dự án

Không hardcode tính năng vào `MainActivity`. Mọi tiện ích implement interface
`BrowserFeature` (`core/BrowserFeature.kt`), đăng ký vào `FeatureRegistry`
(`core/FeatureRegistry.kt`). Thêm tiện ích mới = viết 1 class mới + thêm 1
dòng vào registry — **không đụng** `MainActivity`, `AutoClickAccessibilityService`,
hay `SettingsActivity`.

Feature hiện có:
- `features/colablive/ColabLiveKeeperFeature.kt` — giữ Colab sống.
- `features/downloads/DownloadManagerFeature.kt` — tải file media thường
  (KHÔNG hỗ trợ YouTube, xem mục 6).

### 2.3. `BrowserEngine` — lớp trừu tượng tách feature khỏi engine cụ thể

`core/BrowserEngine.kt` (interface) + `core/GeckoViewEngine.kt` (implementation
hiện tại, bọc GeckoView). Mọi feature chỉ biết tới `BrowserEngine`, không biết
gì về GeckoView hay WebView cụ thể. **Đây là quyết định kiến trúc đúng nhất
của dự án** — khi chuyển từ WebView sang GeckoView, `ColabLiveKeeperFeature`
và `DownloadManagerFeature` **không cần sửa 1 dòng nào**, chỉ cần viết
`GeckoViewEngine` mới. Nếu sau này đổi engine lần nữa, chỉ cần viết thêm 1
class engine mới.

### 2.4. Hệ thống "khe" (Profile Slots) — trình duyệt con độc lập

`core/ProfileSlots.kt` + khai báo `activity-alias` trong `AndroidManifest.xml`
(hiện tại: `SLOT_COUNT = 4`, tức 5 khe tổng cộng tính cả khe 0/chính).

- Mỗi khe = 1 **tiến trình Android riêng** (`android:process=":slotN"`),
  đây là ràng buộc nền tảng của Android (không tạo process tuỳ ý lúc runtime
  được, phải khai báo tĩnh trong Manifest).
- Gán profile (tên tự đặt, không giới hạn số lượng) vào khe (số lượng cố
  định) — đổi gán = khởi động lại đúng 1 khe đó qua `ProfilePickerActivity`.
- **CHƯA HOÀN THÀNH**: cô lập dữ liệu `GeckoRuntime` thật theo từng khe.
  Trước đây dùng `WebView.setDataDirectorySuffix()` cho việc này (khi còn
  dùng WebView) — GeckoView có cơ chế tương đương nhưng **CHƯA tra cứu API
  chính xác** (xem `LiveBrowserApp.kt`, có TODO ghi rõ). **Hệ quả hiện tại:
  mọi khe đang dùng chung 1 GeckoRuntime data — cookie/session KHÔNG cô lập
  thật giữa các khe.** Đây là việc ưu tiên cao cần làm tiếp.

### 2.5. Cấu hình theo từng khe (`AppPrefs`)

`core/AppPrefs.kt` — mọi cấu hình feature (bật/tắt, interval...) namespace
theo `slotIndex` tường minh (file SharedPreferences riêng: `browser_prefs_slotN`).
**Đã sửa 1 bug thật**: ban đầu cấu hình dùng chung toàn app (bật Colab ở khe
1 thì khe khác cũng bật theo) — đã sửa để mỗi khe độc lập hoàn toàn. Interface
`BrowserFeature` bắt buộc mọi hàm nhận `slotIndex` tường minh để tránh tái
phạm lỗi này khi thêm feature mới.

### 2.6. Cơ chế giữ Colab sống (2 chế độ song song)

Trong `ColabLiveKeeperFeature.kt`, người dùng chọn 1 trong 2 (cấu hình qua
Settings UI):

- **Chế độ DOM**: JS giả lập (`mousemove`, click nút Connect) qua "eval
  bridge" (xem mục 2.7). Không cần bật màn hình. **`isTrusted` của event
  KHÔNG đảm bảo = true** — nếu Colab kiểm tra cờ này, cách này thất bại.
  Chưa kiểm chứng thực tế Colab có check hay không.
- **Chế độ Accessibility**: `AutoClickAccessibilityService.kt` dùng
  `dispatchGesture()` — tap thật ở tầng input Android, gần như chắc chắn
  `isTrusted = true`. Đánh đổi: cần bật màn hình + đưa app lên foreground
  mỗi chu kỳ (mặc định 20 phút, dưới ngưỡng idle-timeout ~90 phút của Colab)
  để tap trúng đúng chỗ.
- Cả 2 chế độ đều **CHƯA được test thực tế** trên thiết bị (do các lỗi build
  chặn trước đó) — xem mục 4 "Việc cần làm tiếp theo", đây là việc ưu tiên
  SỐ 1 cần làm ngay khi app chạy ổn định.

### 2.7. "Eval bridge" — cách chạy JS trong GeckoView

GeckoView không có API kiểu `WebView.evaluateJavascript()`. Giải pháp: 1
WebExtension nội bộ tự đóng gói trong `assets/eval_bridge/` (`manifest.json`
+ `content.js`) — **KHÔNG PHẢI addon thật cho người dùng cài**, chỉ là hạ
tầng nội bộ. Cơ chế: content script mở `Port` qua
`browser.runtime.connectNative("browser")`, native side (`GeckoViewEngine.kt`)
nhận qua `session.webExtensionController.setMessageDelegate()`, gửi lệnh eval
qua `port.postMessage()`. **1 CHIỀU** (native → trang), không có giá trị trả
về thật — `evaluateJs()` trong `BrowserEngine` luôn callback `null`.

Cơ chế này giờ còn dùng thêm để **giả fingerprint** (xem mục 2.8) — phần
spoof canvas/WebGL nằm TĨNH trực tiếp trong `content.js` (chạy ngay lúc
`document_start`, không qua round-trip native vì cần chạy SỚM hơn cả lúc
trang kịp đọc giá trị thật).

### 2.8. `FingerprintSpoofFeature` — feature riêng, ngang hàng ColabLiveKeeperFeature

Ban đầu code fingerprint nằm gộp trong `eval_bridge/content.js` (không tắt
được độc lập). Đã tách thành **1 `BrowserFeature` riêng** —
`features/fingerprint/FingerprintSpoofFeature.kt` — với WebExtension riêng
biệt hoàn toàn (`assets/fingerprint_spoof/`), có Settings UI + toggle
bật/tắt theo từng khe như mọi feature khác.

**Khác biệt kiến trúc quan trọng so với ColabLiveKeeperFeature**: việc
bật/tắt KHÔNG áp dụng ngay giữa phiên — vì script bảo vệ phải chạy ở
`document_start` (sớm hơn cả lúc app kịp hỏi Kotlin có nên chạy hay không).
Cách duy nhất để bảo vệ đáng tin cậy: `GeckoRuntimeProvider.get(context,
slotIndex)` chỉ **đăng ký (hoặc không đăng ký)** WebExtension này 1 LẦN lúc
`GeckoRuntime` được tạo (tức lúc khe khởi động). Đổi cài đặt → cần đóng hẳn
app và mở lại đúng khe đó mới có hiệu lực. Đã ghi rõ trong UI Settings (dòng
cảnh báo ⚠) và trong code comment.

Lý do: chạy nhiều profile/khe nhưng nếu canvas/WebGL/hardwareConcurrency
giống hệt nhau, nền tảng có thể liên kết các "tài khoản khác nhau" về cùng
1 thiết bị vật lý dù cookie/IP đã tách riêng.

**Đã làm** (mặc định BẬT, `assets/fingerprint_spoof/content.js`):
- Canvas fingerprint: thêm nhiễu ngẫu nhiên nhỏ vào `toDataURL()`.
- WebGL: giả `UNMASKED_VENDOR_WEBGL`/`UNMASKED_RENDERER_WEBGL` thành
  "Intel Inc." / "Intel Iris OpenGL Engine".
- `navigator.hardwareConcurrency` → giả cố định = 4.
- `navigator.deviceMemory` → giả cố định = 8.

**CHƯA làm** (liệt kê rõ để không quên):
- Rò IP thật qua WebRTC (`RTCPeerConnection` local candidate leak).
- Audio fingerprint (`AudioContext` fingerprinting).
- Liệt kê font cài sẵn trên máy.
- Timezone/locale tự động khớp với vị trí thật.
- User-Agent chi tiết (đã có "Chế độ máy tính" riêng qua menu, đổi
  `GeckoSessionSettings.userAgentMode`/`viewportMode`, không phải fake sâu).
- Tất cả các giá trị giả hiện tại là **CỐ ĐỊNH GIỐNG NHAU** cho mọi khe —
  nghĩa là dù giả được, mọi profile vẫn lộ ra "giống hệt nhau" nếu so sánh
  chéo giữa các khe (thực ra vẫn dễ bị liên kết theo cách khác). Muốn đúng
  nghĩa "mỗi profile 1 fingerprint riêng biệt, ngẫu nhiên nhưng ổn định qua
  các lần mở lại", cần thêm cơ chế sinh seed ngẫu nhiên **theo từng
  slotIndex**, lưu lại, và dùng seed đó để sinh giá trị giả nhất quán — CHƯA
  làm, đây là việc tiếp theo nếu muốn làm đúng bài toán multi-account thật.
- Đây KHÔNG phải giải pháp toàn diện kiểu trình duyệt "antidetect" thương
  mại (Multilogin, GoLogin, AdsPower) — những sản phẩm đó là dự án riêng quy
  mô lớn với hàng chục vector fingerprint, không kỳ vọng đạt được mức đó chỉ
  qua vài dòng JS này.

### 2.9. Foreground Service + WakeLock

`KeepAliveService.kt` — Foreground Service thật (khác Firefox addon, không
cần mượn qua media session) + `PARTIAL_WAKE_LOCK` giữ CPU chạy khi màn hình
tắt. Chạy chung 1 instance cho toàn app (Android tự gộp, không tạo nhiều
service dù nhiều khe cùng gọi `startForegroundService`).

### 2.10. Broadcast liên-process (`ForegroundState`)

`core/ForegroundState.kt` — mỗi khe là 1 process riêng, Kotlin `object`
singleton (như `CurrentBrowserState` cũ) **KHÔNG chia sẻ được giữa các
process khác nhau**. Đã sửa bằng broadcast Intent thật
(`setPackage(packageName)` giới hạn nội bộ app) để `AutoClickAccessibilityService`
(luôn chạy ở khe 0) biết được khe nào đang thực sự active + URL của khe đó,
và bật ĐÚNG khe đó lên khi cần tap (trước đây có bug: luôn bật nhầm khe 0).

## 3. Đã hoàn thành (tính năng)

- [x] Kiến trúc feature module mở rộng được (`BrowserFeature`/`FeatureRegistry`)
- [x] `ColabLiveKeeperFeature` — 2 chế độ DOM/Accessibility, cấu hình được
      chu kỳ, cấu hình riêng theo từng khe
- [x] `DownloadManagerFeature` — bắt download file thường qua
      `DownloadManager` hệ thống (không phải engine đa luồng riêng)
- [x] Hệ thống khe/profile (`ProfileSlots`) — cô lập process thật, gán linh
      hoạt qua `ProfilePickerActivity`
- [x] Chuyển engine từ WebView sang GeckoView hoàn toàn
- [x] Eval bridge — chạy JS trong GeckoView
- [x] Navigation: Back/Forward, Reload, báo lỗi tải trang (`onLoadError`)
- [x] Xử lý popup OAuth cơ bản (`onNewSession` → điều hướng tab hiện tại)
- [x] Upload file cơ bản (`onFilePrompt` → `ACTION_OPEN_DOCUMENT` → copy
      `content://` thành `file://` thật, né giới hạn GeckoView)
- [x] UI giống Chrome cơ bản: omnibox bo tròn, icon vector back/forward/refresh,
      overflow menu 3 chấm
- [x] Chế độ máy tính (Desktop mode) — đổi User-Agent + viewport
- [x] Giả fingerprint — giờ là `FingerprintSpoofFeature` riêng biệt, ngang
      hàng `ColabLiveKeeperFeature`, có toggle Settings theo từng khe (cần
      khởi động lại khe để áp dụng, xem mục 2.8)
- [x] Xin quyền `POST_NOTIFICATIONS` đúng cách (runtime, Android 13+)
- [x] CI build qua GitHub Actions (`build.yml`) — build được, có ABI split
      (nghi vấn hiệu quả thật, xem mục 5)

## 4. Việc cần làm tiếp theo (ưu tiên từ cao xuống thấp)

1. **Test thực tế Colab Live Keeper có giữ được phiên Colab hay không** — MỤC
   TIÊU GỐC của cả dự án, tới giờ vẫn CHƯA kiểm chứng được vì các lỗi build/
   crash chặn trước đó. Đây là việc quan trọng nhất, làm trước mọi thứ khác.
2. Xác nhận nguyên nhân file upload thực sự không phản ứng (đã thêm Toast
   chẩn đoán ở `onFilePrompt`, đang chờ kết quả test).
3. Cô lập dữ liệu `GeckoRuntime` thật theo từng khe (mục 2.4) — hiện các khe
   đang dùng chung data, sai với mục đích ban đầu của tính năng "trình duyệt
   con".
4. Xác nhận artifact GeckoView đúng là `geckoview` hay cần `geckoview-omni`
   (mục 2.1).
5. Xác nhận ABI split có thực sự giảm size APK không (mục 5 — nghi ngờ AGP 9
   đổi cú pháp splits).
6. Multi-tab (nhiều tab trong 1 khe) — xác nhận là dự án riêng, quy mô lớn,
   làm SAU khi Colab chạy ổn định.
7. Tích hợp YouTube downloader (NewPipeExtractor) — đã dừng ở bước khảo sát,
   chưa viết code (mục 6).
8. Migrate sang tải addon WebExtension THẬT (không phải eval bridge nội bộ)
   — đây là lý do gốc để đổi sang GeckoView, chưa bắt đầu.
9. Fingerprint theo seed riêng từng khe (mục 2.8) thay vì giá trị cố định
   chung cho mọi khe.
10. Cân nhắc thêm WebRTC IP leak protection, audio fingerprint spoof nếu
    thực sự cần mức độ ẩn danh cao hơn.

## 5. Kỹ thuật đã THẤT BẠI / SAI — để không lặp lại

| Vấn đề | Sai lầm cụ thể | Bài học |
|---|---|---|
| Fork Chromium (Kiwi-style) | Cân nhắc rồi loại bỏ — không khả thi trên GitHub Actions free (build từ source quá nặng) | Không thử lại hướng này trừ khi có hạ tầng build riêng |
| Tên artifact GeckoView | Dùng `geckoview-release` — build lỗi "Could not find". Tên đúng: `geckoview` (không suffix) | Luôn tra Maven thật trước khi đoán tên artifact |
| Version GeckoView | Đoán `150.0` (số ngắn) — sai định dạng, version thật có timestamp dài | Version GeckoView luôn có định dạng `xxx.0.yyyymmddhhmmss` |
| `GeckoView.session = ...` | Gán property trực tiếp — lỗi "'val' cannot be reassigned" vì GeckoView chỉ có `setSession()`, không có setter property chuẩn Kotlin | Luôn dùng `geckoView.setSession(session)` (gọi hàm), không gán property |
| Theme Activity | Khai `@android:style/Theme.Material.Light.NoActionBar` (theme gốc Android) cho `AppCompatActivity` — crash `IllegalStateException: You need to use a Theme.AppCompat theme` | `AppCompatActivity` bắt buộc theme dòng `Theme.AppCompat.*` hoặc `Theme.MaterialComponents.*` |
| Sed hàng loạt sửa `slotIndex` | Dùng `sed` để thêm tham số `slotIndex` vào nhiều lời gọi hàm cùng lúc — sót 1 chỗ (`setIntervalMinutes` trong `ColabLiveKeeperFeature.kt`), gây lỗi build `No value passed for parameter 'minutes'` | Sau khi sed hàng loạt, LUÔN `grep` lại toàn bộ để xác nhận không sót, không tin sed 100% |
| Upload code lên GitHub | Hiểu nhầm ban đầu: tưởng không up được thư mục qua mobile browser nên định bắt tạo tay từng file — thực ra chỉ cần upload 1 file `.zip` duy nhất (chọn file đơn lẻ hoạt động bình thường trên mobile), rồi để `build.yml` tự `unzip` trong CI | Đừng phức tạp hoá quá mức khi chưa thử cách đơn giản trước |
| `build.yml` không tự cập nhật | Nhiều lần user chỉ upload lại file `.zip` mới nhưng KHÔNG sửa `build.yml` thật trong repo — Actions vẫn chạy bản `build.yml` CŨ, gây lỗi lặp lại y hệt dù code đã sửa | `.zip` và `.github/workflows/build.yml` là 2 thứ ĐỘC LẬP — sửa 1 cái không tự cập nhật cái kia. Chỉ cần nói rõ "lượt này CÓ/KHÔNG đổi build.yml" mỗi lần, đừng nhắc chung chung gây rối |
| Đường dẫn Artifact trong `build.yml` | Hardcode `app/build/outputs/apk/debug/app-debug.apk` — khi bật ABI split, tên file đổi thành `app-arm64-v8a-debug.apk`, gây lỗi "No files were found" | Dùng glob pattern (`**/*.apk`) thay vì đường dẫn cứng, kèm bước `find` chẩn đoán trước khi upload artifact |
| `ACTION_GET_CONTENT` cho file upload | Dùng để mở file picker — nghi ngờ không đáng tin cậy trên 1 số dòng máy (CAT S52) do phụ thuộc app nào có đăng ký intent-filter. Đã đổi sang `ACTION_OPEN_DOCUMENT` (đảm bảo có sẵn qua DocumentsUI hệ thống) — **CHƯA XÁC NHẬN fix có thực sự giải quyết được không**, đang chờ test |
| Quyền `POST_NOTIFICATIONS` | Chỉ khai trong Manifest, KHÔNG xin runtime — trên Android 13+, đây là quyền nguy hiểm bắt buộc xin lúc chạy, khai Manifest không đủ. App chạy được nhưng notification của Foreground Service âm thầm không hiện | Với quyền "dangerous" (list đầy đủ trong docs Android), luôn cần `ActivityCompat.requestPermissions()`, không chỉ khai Manifest |
| Play Protect chặn cài | App dùng `AccessibilityService` → bị Play Protect heuristic chặn cài (mọi APK sideload xin quyền này đều bị nghi ngờ, không phải lỗi code) | Cần tắt tạm "Scan apps with Play Protect" hoặc bật "Install unknown apps" đúng nguồn trước khi cài loại app này |
| Ước lượng % code phụ thuộc WebView | Ước đoán "~30-40%" lúc chưa đo — sau khi đo thật (`grep`) chỉ ~18% file, thấp hơn nhiều. Số liệu đoán trước khi có `BrowserEngine` bị coi là lỗi thời sau khi đã trừu tượng hoá | Luôn đo bằng `grep`/`wc` thật thay vì ước lượng khi bàn về mức độ ảnh hưởng của 1 thay đổi kiến trúc |

## 6. Việc CỐ TÌNH CHƯA làm (và lý do)

- **YouTube video/playlist downloader**: dừng ở mức khảo sát. Không tự viết
  phần giải mã cipher YouTube (đây là việc reverse-engineer liên tục, YouTube
  chủ động chống, và vi phạm ToS trực tiếp — khác bản chất với việc "lách
  timeout" của Colab). Hướng đề xuất: dùng thư viện có sẵn
  **NewPipeExtractor** (Kotlin/Java thuần, nhẹ hơn yt-dlp+Python nhiều, NewPipe
  app dùng chính thư viện này) — coordinate Maven qua JitPack:
  `com.github.TeamNewPipe:NewPipeExtractor:v0.24.6` (kiểm tra version mới
  nhất). **CHƯA viết code wrapper cụ thể** vì chưa tra kỹ API chính xác
  (tên class `StreamExtractor`/`PlaylistExtractor`...), tránh đưa code sai.
- **Fork Chromium để load Chrome extension thật (kiểu Kiwi Browser)**: loại
  bỏ hẳn, không khả thi với hạ tầng build hiện có (mục 5).
- **Multi-tab thật**: xác nhận là tính năng lớn, để sau khi Colab chạy ổn
  định (theo đúng yêu cầu người dùng ưu tiên).
- **Load addon WebExtension thật** (không phải eval bridge nội bộ): đây là
  MỤC TIÊU CUỐI của việc đổi sang GeckoView, nhưng chưa bắt đầu implement —
  cần nghiên cứu thêm API cài đặt addon từ file `.xpi`/URL bên ngoài (khác
  với `ensureBuiltIn()` dùng cho eval bridge, vốn chỉ load resource đóng gói
  sẵn trong APK).

## 7. Quy trình build/deploy (nhắc lại cho người tiếp theo)

1. Sửa code trong dự án này.
2. Đóng gói `zip -r colab-live-browser-project.zip colab-live-browser`.
3. Upload `.zip` này vào **gốc repo GitHub** (Add file → Upload files, chọn
   1 file, hoạt động bình thường trên mobile).
4. **CHỈ KHI có sửa `.github/workflows/build.yml`**: phải sửa TAY file đó
   thật trong repo (Edit trực tiếp trên GitHub), zip không tự cập nhật nó.
5. Tab Actions tự chạy (push) hoặc bấm "Run workflow" thủ công
   (`workflow_dispatch`).
6. Tải APK từ mục Artifacts sau khi build xong.
7. Cài trên điện thoại — có thể cần tắt tạm Play Protect / bật "Install
   unknown apps" (mục 5).

## 8. Thông tin thiết bị test

- Asus Zenfone 8 (ZenUI, gần Android gốc)
- Sharp/CAT S52 (Bullitt Group, rugged, gần Android gốc, đôi khi thiếu 1 số
  app Google mặc định — có thể là nguyên nhân file picker không đáng tin cậy)

## 9. Ghi chú pháp lý/đạo đức đã bàn (không lặp lại cảnh báo dài dòng)

- Việc giữ phiên Colab "sống" khi không thực sự tính toán có thể vi phạm ToS
  của Google Colab (họ có thể hạn chế quota GPU/TPU miễn phí nếu phát hiện).
  Người dùng đã được thông báo, tự quyết định rủi ro.
- Google chủ động chặn đăng nhập từ trình duyệt nhúng "lạ" (embedded browser
  detection) — đây là biện pháp bảo mật thật của Google, không phải bug của
  app này, không có cách nào đảm bảo vượt qua được 100%.
