# Live Browser (colab-live-browser) — Tài liệu trạng thái dự án

> File này là nguồn sự thật duy nhất về tiến độ dự án. Đọc file này TRƯỚC
> khi tiếp tục code — không cần đọc lại lịch sử chat để hiểu bối cảnh.
> Cập nhật file này SAU MỖI PHIÊN làm việc tiếp theo, không để nó lỗi thời.

## 0. ⚠️ CHANGELOG — Phiên audit 2 lượt (2025 — trước khi build lần đầu)

**Bối cảnh phát hiện được**: dự án đã trải qua nhiều phiên/fork khác nhau.
Code thật trong zip đã đi XA HƠN những gì các mục bên dưới (1-7, viết từ
phiên cũ hơn) mô tả — ví dụ YouTube downloader và multi-tab **đã có code**
dù mục 6/9 nói "chưa bắt đầu". Nhưng đồng thời code có **hàng loạt lỗi build
thật** khiến app **CHƯA TỪNG BUILD ĐƯỢC**, vì các phần được viết trong các
phiên/fork khác nhau không khớp interface với nhau. 2 lượt audit vừa rồi
tập trung dò và sửa các lỗi này — đọc kỹ mục này trước khi tin bất kỳ mục
nào bên dưới có mâu thuẫn.

### Lượt 1 — tập trung IDM / YouTube download / multi-tab

- **`MainActivity.kt`**: `showSniffDialog()` bị hỏng cấu trúc nghiêm trọng —
  2 hàm khác (`showWebArchiveDialog`, `showDownloadPolicySettings`) từng bị
  dán nhầm vào BÊN TRONG lambda của nó. Đã tách lại đúng 3 hàm riêng.
- **`DownloadManagerFeature.kt`**: thiếu 4 import (`File`, `FeatureRegistry`,
  `GeckoViewEngine`, `CookieLeakDetector`); thiếu hẳn hàm `startDownload(context,
  url, fileName)` dù bị gọi ở 3 nơi; regex đổi tên file MP3 hở dấu `"` giữa
  chuỗi.
- **`DownloadPolicy.kt`**: `getRules()` là `private` nhưng bị gọi từ ngoài
  class → đổi thành public.
- **`StreamSniffer.kt`**: TOÀN BỘ 10 regex bắt link video/audio bị hỏng —
  dùng `\s` (Kotlin không có escape này, phải viết `\\s`) và dấu `"` không
  escape cắt đứt chuỗi giữa chừng → chắc chắn không compile. Viết lại đúng
  cú pháp cho cả `videoPatterns`, `audioPatterns`, `jsonPattern`,
  `streamPattern`, `ogVideoPattern`.
- **`WebArchiver.kt` + `WebArchiveDialog.kt`**: cùng lỗi regex hở dấu `"`
  khi làm sạch tên file (3 chỗ).
- **Multi-tab UI**: `tabContainer`/`tabViews` được khai báo nhưng KHÔNG BAO
  GIỜ có view nào thêm vào — tạo tab mới trước đây không hiện gì, không bấm
  chuyển được (logic tạo/switch/close session ở `GeckoViewEngine` thì đã có
  và đúng). Đã viết `refreshTabBar()` + `createTabChip()` (chip có tiêu đề +
  nút đóng, tô sáng tab active, bấm để chuyển) và nối vào mọi nơi tab thay
  đổi (`createTab`, `closeTab`, `switchToTab`, đổi tiêu đề). Thêm
  `GeckoViewEngine.onTabSwitchedListener` để UI biết khi nào tab active đổi.

### Lượt 2 — tập trung cookie leak / fingerprint / proxy (hệ sinh thái antidetect)

Phát hiện lớn nhất: **`BrowserFeature.kt` (interface) và CẢ BA feature hiện
có (`ColabLiveKeeperFeature`, `DownloadManagerFeature`, `FingerprintSpoofFeature`)
không khớp nhau** — rõ ràng dấu vết của merge nhánh không trọn vẹn. Interface
cũ chỉ có 8 member, nhưng `ColabLiveKeeperFeature`/`AutoClickAccessibilityService`
cần thêm `description`, `matchesUrl`, `onPageFinished`, `onTick`,
`accessibilityTargetTexts`, `intervalMinutes` — đã bổ sung vào interface
(có default an toàn để feature nào không cần thì khỏi override).

- **`FingerprintSpoofFeature.kt`**: hoàn toàn KHÔNG implement đúng
  `BrowserFeature` — dùng `name`/`description`/`createSettingsView`/
  `onSlotActivate`/`onSlotDeactivate`, không cái nào tồn tại trong interface
  thật. Viết lại dùng đúng `id`/`displayName`/`isEnabled`/`setEnabled`/
  `buildSettingsView`. Đồng thời sửa nút bật/tắt trong UI trước đây ghi vào
  key `"fp_enabled"` riêng biệt, KHÔNG PHẢI key mà `isEnabled()` đọc — bấm
  công tắc trước đây không có tác dụng gì với việc feature có chạy hay
  không. Đã hợp nhất về 1 key.
- **`DownloadManagerFeature.kt` + `FingerprintSpoofFeature.kt`**: đổi từ
  `class` sang `object` — `FeatureRegistry.features` tham chiếu chúng như
  giá trị trần (singleton), chỉ hợp lệ với `object`; hàng chục chỗ gọi
  `FeatureRegistry.all().filterIsInstance<...>().firstOrNull()` khắp app
  dựa vào đúng 1 instance dùng chung tồn tại trong registry.
- **`FeatureRegistry.kt`**: thêm `fun all() = features` — rất nhiều nơi gọi
  `.all()` nhưng hàm này trước đây không tồn tại (chỉ có `.features`).
- **`AppPrefs.kt`**: `ColabLiveKeeperFeature` gọi `AppPrefs.getBoolean(context,
  slotIndex, id, key, default)` (5 tham số, có `featureId` để namespace) —
  AppPrefs trước đây chỉ có bản 4 tham số. Thêm overload 5 tham số cho cả
  get/set Boolean/String/Int (gộp `featureId:key` vào key, không đổi hành vi
  của bản 4 tham số hiện có).
- **Colab Live Keeper chế độ DOM chưa từng chạy**: `onTick`/`onPageFinished`
  được viết đầy đủ nhưng KHÔNG CÓ GÌ TRONG `MainActivity` GỌI TỚI — chỉ chế
  độ Accessibility (qua `AutoClickAccessibilityService`, chạy độc lập) là
  thật sự hoạt động. Đã thêm vòng lặp tick 60s/lần + gọi `onPageFinished` khi
  trang load xong trong `MainActivity.kt`.
- **Fingerprint spoof chưa từng có tác dụng**: `setupFingerprintExtension()`
  trong `GeckoViewEngine.kt` chỉ load WebExtension `fingerprint_spoof`, KHÔNG
  BAO GIỜ gửi config xuống — `content.js` mặc định `enabled: false` nên luôn
  return sớm. Đã viết `buildFingerprintConfigMessage()` đọc đúng lựa chọn của
  người dùng (`fp_hw_idx`/`fp_locale_idx`/`fp_fresh`) và đẩy xuống qua
  `MessageDelegate.onConnect` (giống hệt cách `proxy_config` đã làm đúng).
  Đồng thời sửa 1 bug thật trong `content.js`: object literal có key `locale`
  bị khai báo 2 LẦN (1 lần làm cờ bật/tắt boolean, 1 lần làm chuỗi định danh
  locale) — JS chỉ giữ lại key sau cùng nên cờ bật/tắt thực chất luôn là 1
  chuỗi non-empty = luôn truthy. Đổi tên cờ boolean thành `spoofLocale`.
- **Cookie leak detector không thể phát hiện leak thật**: `markers` là 1
  `Map` TRONG BỘ NHỚ của 1 instance `CookieLeakDetector` — nhưng mỗi khe
  chạy TIẾN TRÌNH RIÊNG (`android:process=":slotN"`), nên map này không bao
  giờ thấy được marker do khe khác (tiến trình khác) set → `checkLeak()`
  trước đây LUÔN trả về "chưa có slot khác để so sánh", không thể phát hiện
  leak thật kể cả khi có leak. Đổi sang lưu marker vào 1 file JSON dùng
  chung trong `context.filesDir` (mọi tiến trình cùng app/UID đọc/ghi được).
- **Comment/log về proxy bị sai lệch**: `GeckoViewEngine.setupProxy()` và
  dialog Proxy trong `MainActivity` trước đây khẳng định "GeckoView không hỗ
  trợ proxy theo session, IP thật không được che" — ĐIỀU NÀY KHÔNG CÒN ĐÚNG,
  `GeckoRuntimeProvider.registerProxyExtensionIfConfigured()` đã đăng ký
  WebExtension `proxy_config` (dùng `browser.proxy.onRequest`) thật ngay khi
  tạo runtime, đọc từ `AppPrefs`. Đã cập nhật comment/log cho đúng thực tế:
  proxy có hoạt động, chỉ cần khởi động lại khe sau khi đổi cấu hình (vì
  runtime đã tạo trong tiến trình thì không đăng ký lại extension được).
- Thêm import thiếu `org.json.JSONObject`/`JSONArray` trong `GeckoViewEngine.kt`
  (dùng trong `setupEvalBridge` từ trước nhưng chưa từng import — lẽ ra cũng
  không compile được).

### Lượt 4 — Trả lời thẳng: cấu hình fingerprint/UA có nhất quán không?

Người dùng hỏi đúng trọng tâm: **các profile TỰ nó có nhất quán nội bộ
không, có cảnh báo/ngăn tổ hợp vô lý không, và random có tạo ra cấu hình
hợp lý không**. Trả lời thành thật sau khi đọc lại toàn bộ `DeviceProfiles.kt`
+ `content.js`:

**Cái ĐÃ đúng từ trước**: mỗi `HardwareProfile` là 1 object TRỌN GÓI —
platform+UA+GPU vendor/renderer+CPU/RAM+độ phân giải đi cùng nhau, không rời
rạc từng field. Ví dụ chọn "iPhone 15 Pro Max" thì platform="iPhone", UA là
UA Safari iOS thật, GPU="Apple GPU" — không có chuyện random ra iPhone+GPU
NVIDIA. Trong PHẠM VI 1 profile, không có "râu ông nọ cắm cằm bà kia". Locale
độc lập với hardware (vd Mỹ dùng iPhone + múi giờ Nga) — cái này KHÔNG phải
lỗi, người dùng thật cũng vậy (đi công tác, mua máy nước khác).

**Cái SAI thật, đã sửa lượt này**:

1. **Nghiêm trọng nhất — UA header HTTP thật KHÔNG khớp `navigator.userAgent`
   JS giả**: code cũ chỉ override `navigator.userAgent` bằng JS
   (`Object.defineProperty`) — đây là cách LÀM ĐƯỢC cho fingerprint JS đọc,
   nhưng KHÔNG đổi được header `User-Agent` thật mà GeckoView gửi trong MỌI
   request HTTP. Hệ quả: server nhận header nói "GeckoView/Firefox Android"
   thật, còn `navigator.userAgent` JS lại nói "Chrome/126 Windows" giả — đây
   là kiểu mismatch RẤT NHIỀU hệ thống anti-bot/anti-fraud kiểm tra trực
   tiếp (so khớp UA header với navigator.userAgent cùng 1 request), và khi
   phát hiện thì **còn đáng ngờ hơn cả không giả gì cả**. Đã thêm
   `GeckoSessionSettings.Builder().userAgentOverride(...)` (API thật của
   GeckoView, đổi header HTTP thật) — dùng CHUNG 1 profile đã chọn với JS
   override (cache 1 lần/engine qua `resolveProfile()`) để 2 bên LUÔN khớp
   nhau tuyệt đối, kể cả ở chế độ random "fresh".
   ⚠️ Có bug lịch sử công khai của chính GeckoView (bugzilla 1629921,
   1511281) là `userAgentOverride` từng gây CORS preflight thừa hoặc không
   áp dụng cho request con (subresource) ở vài bản cũ — CẦN kiểm tra thật
   trên thiết bị (mở DevTools/proxy bắt gói xem header UA thực tế gửi đi có
   đúng không), không thể chỉ tin code là xong.
2. **`maxTouchPoints` chưa từng được set theo profile**: `HardwareProfile`
   trước đây KHÔNG có field này — chọn hồ sơ "Windows desktop" trên chính
   điện thoại Android (luôn có cảm ứng thật) thì `maxTouchPoints` vẫn là số
   thật (vd 5), mâu thuẫn với 1 PC Windows thật (gần như luôn = 0, không
   cảm ứng). Đã thêm field, set 0 cho mọi hồ sơ desktop, 5 cho mobile.
3. **KHÔNG có cảnh báo/ngăn chặn tổ hợp vô lý — đã tìm ra tổ hợp CHẮC CHẮN
   VÔ LÝ mà UI cũ cho phép**: công tắc "Đồng bộ User-Agent" tách rời khỏi
   "Hardware Profile" — tắt riêng nó trong khi vẫn bật hardware spoof tạo ra
   platform/GPU giả (vd Win32) nhưng UA thật (Android) — KHÔNG CÓ tổ hợp
   nào hợp lý khi tách 2 cái này. Thay vì chỉ cảnh báo, đã BỎ HẲN công tắc
   rời này — UA giờ LUÔN đi cùng hardware spoof, không thể tách ra tạo mâu
   thuẫn được nữa (đúng như người dùng hỏi: "có ngăn chặn không" → giờ có,
   bằng cách xoá bỏ khả năng tạo ra tổ hợp sai, không phải chỉ cảnh báo).

**Giới hạn THẬT, không sửa được bằng code (đã ghi rõ trong UI, không giấu)**:

- **Không thể giả "là Chrome" ở tầng sâu**: toàn bộ UA đều claim
  "Chrome/126.0.0.0" nhưng JS engine thật chạy dưới là SpiderMonkey (Gecko),
  không phải V8 (Chrome thật). Bất kỳ kiểm tra nào dựa vào hành vi
  engine-specific (`window.chrome` object, format `Error().stack`,
  `Function.prototype.toString`, quirk CSS -webkit-, bug riêng của
  V8/ANGLE...) đều CÓ THỂ phát hiện đây không phải Chrome thật, dù UA/JS
  property đã khớp hết. Đây là giới hạn của việc "giả UA" nói chung (mọi
  antidetect browser dựa trên 1 engine để giả engine khác đều gặp vấn đề
  này ở mức độ nào đó), không phải lỗi riêng của app này.
- **Không thể giả kích thước màn hình thật**: `screen.width/height` đổi
  được ở JS, nhưng vùng hiển thị thật (CSS render, `@media` query, layout
  responsive) vẫn theo màn hình vật lý thật của điện thoại. Chọn hồ sơ
  desktop 1920x1080 trên điện thoại thì trang vẫn HIỂN THỊ layout mobile,
  trong khi `screen.width` JS báo 1920 — 1 script kiểm tra chéo (so
  `screen.width` với `window.matchMedia('(max-width:768px)').matches`) vẫn
  phát hiện được. Đã ghi cảnh báo trực tiếp trong UI Settings.
- **Chế độ "fresh" (random mỗi lần mở khe) tự nó là tín hiệu đáng ngờ**:
  đã cảnh báo sẵn trong UI từ trước, không phải phát hiện mới — nhắc lại vì
  liên quan trực tiếp câu hỏi "random có hợp lý không": HỢP LÝ về mặt profile
  (không lộn xộn field), nhưng KHÔNG hợp lý về mặt hành vi nếu đổi liên tục
  trong 1 phiên — không có thiết bị thật nào tự đổi CPU/GPU giữa chừng.



1. **Chưa build thử qua GitHub Actions** — mọi thứ trên là audit đọc code +
   kiểm tra cân bằng ngoặc/quote thủ công, chưa có trình biên dịch Kotlin
   thật xác nhận. Đây là việc ưu tiên SỐ 1 tiếp theo.
2. `DownloadEngine.startDownload()` luôn lưu vào 1 thư mục cố định
   (`getExternalFilesDir/downloads`), bỏ qua thư mục người dùng chọn ở
   `SaveLocationDialog` (Pictures/Movies/Music/tuỳ chỉnh) — IDM báo lưu ở A
   nhưng file luôn nằm ở B.
3. Chưa test trên thiết bị thật (ưu tiên gốc trong mục 4 cũ bên dưới).

### Lượt 3 — Cô lập hồ sơ thật theo khe + kỹ thuật giả lập riêng lẻ

Người dùng chỉ ra đúng: 2 việc để "chưa làm" ở lượt 2 KHÔNG PHẢI việc phụ —
đây chính là phần lõi của "hệ sinh thái antidetect multilogin". Đã làm:

- **`GeckoRuntimeProvider.kt`**: thêm `.arguments(["-profile", <thư mục
  riêng của khe>, "-no-remote"])` vào `GeckoRuntimeSettings.Builder` — cờ
  dòng lệnh CHUẨN của Gecko (có trong tài liệu automation chính thức của
  GeckoView: `args: [-profile, "/path"]`). Nếu ăn thật, mỗi khe sẽ có
  `cookies.sqlite`/storage/permissions/cache RIÊNG BIỆT trên đĩa — cô lập
  sâu hơn hẳn so với chỉ dùng `contextId` (vốn chỉ tách theo-origin bên
  trong 1 hồ sơ vật lý dùng chung, và có rủi ro nhiều tiến trình cùng ghi
  vào 1 file SQLite).
  **⚠️ THÀNH THẬT VỀ MỨC ĐỘ CHẮC CHẮN**: đây là cờ chuẩn của Gecko/Firefox
  nhưng **`GeckoRuntimeSettings` không có API public riêng tên
  `.profileDir()`** cho việc này — tài liệu chính thức mới thấy nó dùng
  trong ngữ cảnh automation/geckodriver, CHƯA có xác nhận rõ ràng nó hoạt
  động giống hệt trong ngữ cảnh app Android nhúng GeckoView bình thường
  (không qua automation). **BẮT BUỘC kiểm tra sau khi build**: mở 2 khe
  khác nhau, đăng nhập 2 tài khoản khác nhau ở mỗi khe, dùng chức năng
  "Cookie Leak Test" có sẵn để xác nhận không rò rỉ; đồng thời có thể kiểm
  tra bằng cách xem `context.filesDir/gecko_profile_slot_N/` có thực sự
  chứa file hồ sơ Gecko (cookies.sqlite, prefs.js...) sau khi duyệt web hay
  không — nếu thư mục rỗng nghĩa là cờ `-profile` KHÔNG ăn, cần tìm cách
  khác (lớp `contextId` vẫn còn tác dụng làm lưới an toàn thứ 2 dù yếu hơn).
- **`FingerprintSpoofFeature.kt` + `GeckoViewEngine.kt`**: thêm 5 công tắc
  riêng lẻ (Canvas, Audio, Font enumeration, chặn WebRTC, đồng bộ
  User-Agent) thay vì chỉ 1 công tắc chính bật/tắt TRỌN GÓI — lưu vào
  `fp_t_canvas`/`fp_t_audio`/`fp_t_font`/`fp_t_webrtc`/`fp_t_uasync`, đọc
  đúng các key này khi build config gửi xuống `content.js` (trước đây
  hardcode `true` hết, không đọc UI thật).

### Lượt 5 — "Giới hạn thật" ở lượt 4 có ĐÚNG LÀ không sửa được không? Nếu dùng VM cho mỗi khe thì sao?

(Lưu ý: sau lượt này công tắc `fp_t_uasync` đã bị BỎ ở lượt tiếp theo — xem
phần cuối mục 2.8 — UA giờ luôn đi cùng hardware, không tách được nữa.)

**Vá được 1 phần bằng code thật (đã làm)**: `GeckoSessionSettings` có sẵn
`viewportMode(VIEWPORT_MODE_DESKTOP)` + `userAgentMode(USER_AGENT_MODE_DESKTOP)`
— ĐÚNG cơ chế "Yêu cầu trang web dành cho máy tính" mà Chrome/Firefox di
động THẬT dùng (viewport CSS 980px, bỏ qua `<meta viewport>` của trang).
Đây là **render THẬT đổi** (layout, `@media` query đều theo desktop), không
phải chỉ 1 property JS nói dối như trước — thu hẹp đáng kể khoảng cách đã
nêu ở lượt 4. Đã bật tự động khi chọn hồ sơ "desktop" (`GeckoViewEngine.createSession()`).
Vẫn KHÔNG hoàn hảo: 980px CSS khác con số 1920/2560 khai trong hồ sơ, và
pixel vật lý hiển thị ra vẫn là màn hình điện thoại thật — đã ghi rõ trong
UI, không nói quá.

**Câu hỏi VM cho mỗi khe — tách làm 2 vấn đề khác hẳn nhau, VM chỉ cứu được 1:**

1. **Vấn đề "màn hình/CPU/GPU giả không khớp render thật"** — NẾU dùng VM
   ĐÚNG NGHĨA (ảo hoá phần cứng thật, mỗi khe là 1 máy ảo có card màn hình
   ảo/độ phân giải ảo THẬT KHÁC NHAU) thì vấn đề này biến mất hoàn toàn —
   không phải "giả" gì cả, vì `screen.width` lúc đó là con số THẬT của màn
   hình ảo đó. Đây chính xác là cách các dịch vụ antidetect nghiêm túc quy
   mô lớn làm (mỗi profile = 1 máy/VM thật hoặc đám mây thật, không phải 1
   máy giả làm nhiều máy). NHƯNG:
   - Trên chính điện thoại: hầu hết máy Android tiêu dùng **không hỗ trợ ảo
     hoá phần cứng lồng nhau** (nested virtualization/KVM cho guest OS) —
     không root/kernel đặc biệt thì không chạy được VM Android/x86 tăng tốc
     phần cứng thật; chạy bằng giả lập phần mềm thuần (QEMU không KVM) thì
     chậm tới mức không dùng để duyệt web thời gian thực được.
   - Nếu chuyển hướng "VM" = máy chủ/máy ảo THẬT trên cloud (mỗi khe = 1
     phiên trên 1 máy chủ riêng, phone chỉ hiển thị lại) — đây là kiến trúc
     HOÀN TOÀN khác, về bản chất là xây 1 "trại trình duyệt" từ xa, không
     còn là "app Android quản lý nhiều khe GeckoView" nữa — chi phí hạ tầng
     + độ phức tạp tăng vọt, ngoài phạm vi dự án hiện tại.
2. **Vấn đề "khai là Chrome nhưng engine chạy thật là Gecko"** — **VM
   KHÔNG CỨU ĐƯỢC vấn đề này, dù là VM thật hay không**. Đây là vấn đề Ở
   TẦNG PHẦN MỀM (engine JS nào đang chạy), không phải tầng phần cứng/OS
   (VM ảo hoá cái gì). Nhét app GeckoView vào 1 VM thì bên trong VM đó vẫn
   là... GeckoView, vẫn chạy SpiderMonkey, vẫn KHÔNG PHẢI V8/Chromium thật.
   Muốn hết mismatch này CHỈ có 2 cách, cả 2 đều không phải "thêm VM":
   a) Đừng khai là Chrome nữa — dùng đúng UA Firefox/GeckoView thật (mất đi
      lý do ban đầu muốn giả Chrome, nhưng hết mismatch vì không nói dối gì
      cả); hoặc
   b) Thay hẳn engine render — nhúng Chromium thật (vd qua WebView của
      Android, vốn dùng Chromium) thay vì GeckoView. Đây là đổi kiến trúc
      lõi của app (khác hẳn lý do ban đầu chọn GeckoView — xem mục 2.1 bên
      dưới), không phải việc nhỏ, và tự nó cũng có đánh đổi riêng (WebView
      có cơ chế cô lập đa profile khác, cần đánh giá lại từ đầu).

**Tóm lại trả lời thẳng**: không phải "hoàn toàn không sửa được bằng code"
— phần viewport đã vá thật được 1 phần. Nhưng phần engine-fingerprint thì
đúng là bó tay bằng mọi cách trong kiến trúc hiện tại (VM hay không VM đều
vậy) — muốn hết hẳn phải đổi engine hoặc đổi UA cho khớp engine thật.

### Lượt 6 — Đổi UA sang Firefox thật + trả lời câu hỏi "sao không fake hết đi"

**Đã làm — đổi toàn bộ 20 UA sang Firefox/Gecko thật** (`rv:140.0`,
`DeviceProfiles.kt`), khớp với engine THẬT của app (GeckoView = Gecko).
Đây là lựa chọn đúng người dùng đề xuất — hết mismatch tận gốc thay vì cố
giả Chrome trên 1 engine không phải Chrome. 2 hồ sơ iPhone được ĐÁNH DẤU
CẢNH BÁO rõ trong tên hiển thị (không xoá, để người dùng tự quyết, nhưng
không im lặng cho ngang hàng với các hồ sơ khác) — lý do ở câu trả lời dưới.

**Trả lời các câu hỏi cụ thể:**

1. *"Đổi Chromium thì lấy gì build?"* — Hiểu lầm cần đính chính: KHÔNG cần
   tự build Chromium từ mã nguồn. Android có sẵn `android.webkit.WebView`
   — bản thân nó ĐÃ LÀ Chromium, cài sẵn trên máy (gói "Android System
   WebView"/Chrome cung cấp), dùng thẳng được, không cần build gì cả. NHƯNG
   dự án này đã CÂN NHẮC VÀ LOẠI BỎ WebView từ đầu (xem mục 2.1) — lý do
   chính: **WebView không hỗ trợ load WebExtension thật**, mà TOÀN BỘ cơ
   chế hiện có (proxy_config, fingerprint_spoof, eval_bridge — tức là gần
   như mọi tính năng antidetect đang có) đều dựa vào WebExtension API mà
   CHỈ GeckoView cung cấp. Đổi sang WebView lúc này = phá bỏ toàn bộ cơ chế
   đã xây, không phải chỉ "đổi UA". Vì vậy phương án thực tế nhất vẫn là
   đổi UA sang Firefox thật (đã làm), không đổi engine.
2. *"VM phải root mới được sao, có app clone chạy nhiều tài khoản không cần
   root mà?"* — Đúng, nhưng **app clone (Parallel Space, Dual Space,
   VirtualApp...) KHÔNG PHẢI VM**. Chúng hoạt động ở tầng Android
   framework (giả lập package identity, hook `PackageManager`/ClassLoader
   để 1 app tưởng mình có bản sao riêng), CHẠY TRÊN CÙNG kernel/CÙNG phần
   cứng thật — không có màn hình ảo, không có GPU ảo riêng. Vì vậy app
   clone giải quyết được đúng 1 việc: **cô lập dữ liệu/storage cho nhiều
   tài khoản của cùng 1 app** — CHÍNH LÀ việc dự án này đã làm, bằng cách
   sạch hơn (mỗi khe 1 tiến trình Android chính thức
   `android:process=":slotN"`, không cần hook API không chính thức dễ vỡ
   khi Android update). App clone KHÔNG giải quyết được vấn đề màn
   hình/CPU/GPU giả — vẫn y hệt giới hạn dự án đang gặp.
3. *"Thông tin đó cũng chỉ là trình duyệt báo qua thôi mà, không fake ghi
   đè được hết sao?"* — Câu hỏi đúng trọng tâm, tách rõ làm 2 loại:
   - **Loại A — 1 giá trị/property đơn giản mà trình duyệt "báo" ra**: UA
     string, `screen.width`, `navigator.platform`, header HTTP... **CÁI NÀY
     ĐÃ FAKE ĐƯỢC HẾT** — đúng như người dùng nói, đây chỉ là dữ liệu phần
     mềm tự nguyện gửi/khai, và app đã ghi đè được cả tầng JS lẫn tầng HTTP
     header thật (xem Lượt 4/5).
   - **Loại B — hành vi THẬT của engine/phần cứng đang chạy, không phải 1
     "field" cụ thể để ghi đè**: 3 ví dụ cụ thể:
     a) *Quirk riêng của JS engine* (định dạng `Error().stack`, cách làm
        tròn số thực, hành vi các hàm built-in) — SpiderMonkey (Gecko) và
        V8 (Chrome) có hàng trăm khác biệt nhỏ trong ĐÚNG CÁCH THỰC THI
        code, không phải 1 giá trị đọc ra được để đổi — muốn giả hết phải
        SỬA MÃ NGUỒN engine để nó cư xử y hệt V8, không phải ghi đè property.
     b) *Vân tay TLS/HTTP2 (JA3/JA4)* — thứ tự cipher suite, extension khi
        bắt tay TLS xảy ra Ở TẦNG MẠNG, TRƯỚC KHI có bất kỳ trang/JS nào
        chạy — do thư viện TLS biên dịch sẵn trong engine (NSS của Gecko)
        quyết định, KHÔNG CÓ API JS/WebExtension nào chạm tới được tầng
        này. Máy chủ hoàn toàn có thể phân biệt Gecko/Chrome ở bước bắt tay
        TLS, trước cả khi HTTP request đầu tiên được gửi.
     c) *Kết quả render WebGL/Canvas thật* — GPU thật của điện thoại (Mali/
        Adreno) tính toán ra pixel/số thực khác GPU NVIDIA thật sẽ tính ra,
        dù đã đổi NHÃN (`getParameter(VENDOR)`) — kiểm tra sâu là hash ảnh
        render ra, không phải chỉ đọc nhãn. App đã có thêm nhiễu ngẫu
        nhiên vào canvas/audio (giảm bớt, không xoá hết được vấn đề này).
   - **Vậy Loại B có sửa được không?** Về LÝ THUYẾT có — nhưng phải sửa/vá
     mã nguồn NATIVE của engine (TLS stack, JS interpreter, driver render),
     không phải thêm content script hay đổi property. Đây CHÍNH XÁC là
     việc các hãng antidetect browser thật (Multilogin, GoLogin...) làm —
     họ tự build lại Chromium từ mã nguồn có PATCH sâu vào tầng native,
     không dùng Chromium/WebView nguyên bản. Quy mô công việc này (build +
     duy trì 1 nhánh Chromium/Gecko riêng có patch) vượt xa 1 app Android
     do 1 người duy trì qua GitHub Actions free tier — đây là ranh giới
     thật giữa "sửa được bằng code ở tầng app/extension" (đã làm gần hết)
     và "phải sửa engine ở tầng native" (ngoài khả năng dự án hiện tại).

### Lượt 7 — Đính chính: "vá tầng native" KHÔNG có nghĩa là "bắt buộc Chromium"

Ở lượt 6, cách diễn đạt gây hiểu lầm "vấn đề tầng sâu chỉ Multilogin/GoLogin
mới sửa được (họ dùng Chromium tự build)" khiến tưởng như Chromium là điều
kiện bắt buộc để vá tầng native. KHÔNG ĐÚNG — tách lại cho rõ:

1. **Vấn đề TLS/JS-engine "không khớp" đã tự hết từ việc đổi UA sang
   Firefox thật (lượt 6) — không cần vá native.** Vấn đề đó CHỈ tồn tại
   KHI khai là Chrome trên engine Gecko thật (nói dối cần che). Giờ khai
   thật là Firefox thì TLS (NSS)/JS engine (SpiderMonkey) thật vốn dĩ đã
   là của Gecko rồi — không còn gì lệch để vá.
2. **Muốn vá native sâu hơn (vd tự thêm nhiễu vân tay ở tầng engine) thì
   patch được ngay trên Gecko** — Gecko cũng mã nguồn mở, tự build/patch
   được y như Chromium, không có gì riêng khiến CHỈ Chromium mới patch
   được. Khối lượng việc (build ~40GB, nhiều giờ) là NHƯ NHAU cho cả 2,
   đều vượt GitHub Actions free tier (xem mục 2.1) — không phải do chọn
   sai engine mà do quy mô build tự thân của bất kỳ engine trình duyệt nào.
3. **Vấn đề render WebGL/Canvas ra pixel thật (còn tồn tại, xem lượt 6 mục
   3c) — Chromium KHÔNG fix được**, vì đây là phần cứng GPU thật của điện
   thoại tính toán ra, không phụ thuộc engine nào cả.
4. **Lý do THẬT các hãng antidetect chọn Chromium**: không phải kỹ thuật,
   mà là thống kê nguỵ trang đám đông — Chrome/Chromium chiếm ~65% thị
   phần trình duyệt toàn cầu, Firefox ~3%. Hệ thống chống bot chấm điểm
   nghi ngờ 1 phần dựa vào độ phổ biến của tổ hợp trình duyệt+vân tay trong
   lưu lượng tổng — 1 điểm bất thường giữa đám đông lớn khó lộ hơn giữa
   nhóm nhỏ. Đây là lựa chọn "trà trộn", không phải giới hạn kỹ thuật.

**Kết luận cho quy mô dự án hiện tại**: giữ GeckoView + UA Firefox thật
(đã làm ở lượt 6) là lựa chọn ĐÚNG và HIỆU QUẢ NHẤT — không cần và không
nên nghĩ tới việc đổi engine hay tự build Chromium/Gecko patch, việc đó
vượt xa khả năng build qua GitHub Actions free tier của dự án 1 người.

### Lượt 8 — BUILD THẬT LẦN ĐẦU (GitHub Actions #135) — danh sách lỗi thật + đã sửa

Người dùng dán log build Gradle thật (build #135, FAILED, `compileDebugKotlin`).
Đây là xác nhận CÓ THẬT đầu tiên rằng code build hay không — mọi audit trước
đó (lượt 1-7) chỉ là đọc code, KHÔNG có trình biên dịch xác nhận. Log cho
thấy code có nhiều lỗi thật, phần lớn là API GeckoView bị ĐOÁN SAI bởi phiên
làm việc/AI khác trước đây (không phải phiên này viết ra) — đã tra lại từng
API qua javadoc chính thức của Mozilla (không đoán) rồi sửa:

- **`ProfileSlots.kt`** thiếu hẳn 4 hàm bị gọi ở nơi khác:
  `componentClassNameForSlot`, `getSlotAssignment`, `listProfiles`,
  `addProfile`, `setSlotAssignment` — đã thêm, lưu qua 1 SharedPreferences
  riêng (`profile_slots`) để đọc được từ mọi tiến trình.
- **`ForegroundState.kt`** thiếu hẳn hàm `broadcastActiveSlot` mà
  `MainActivity` gọi — đã thêm, và tiện thể sửa luôn 1 lỗ hổng liên quan:
  trước đây chỉ broadcast 1 LẦN lúc mở khe (URL luôn null) — giờ broadcast
  lại mỗi khi trang load xong, để `AutoClickAccessibilityService` có URL
  mới nhất mà so khớp (nếu không sửa, tính năng Accessibility mode sẽ mãi
  mãi không hoạt động dù build được).
- **`GeckoRuntimeProvider.kt`**: `consoleOutputEnabled` — tên bịa, tên thật
  là `consoleOutput` (đã tra javadoc xác nhận).
- **`GeckoViewEngine.kt`** — nhiều nhất, vì hầu hết API GeckoSession thật bị
  đoán sai hoàn toàn:
  - `session.canGoBack`/`session.canGoForward`/`session.currentUri` KHÔNG
    TỒN TẠI dưới dạng property đọc đồng bộ — GeckoSession chỉ đẩy các giá
    trị này qua callback bất đồng bộ (`NavigationDelegate.onCanGoBack`,
    `onCanGoForward`, `onLocationChange`). Đã thêm 2 field cache
    `canGoBack`/`canGoForward` vào `BrowserTab`, implement 3 callback trên
    để tự cập nhật cache, sửa `goBack/goForward/canGoBack/canGoForward` đọc
    từ cache thay vì gọi thẳng session.
  - `session.releaseSession()` không tồn tại (đó là API của `GeckoView`
    dùng để gỡ session khỏi View, không phải hàm đóng session) — tên thật
    để đóng hẳn 1 session là `session.close()`.
  - `onLoadError` sai chữ ký (`uri: String` phải là `uri: String?`, kiểu trả
    về phải là `GeckoResult<String>?` chứ không phải `GeckoResult<String>`)
    → lỗi "overrides nothing".
  - `onExternalResponse` dùng sai kiểu `GeckoSession.WebResponseInfo` (bịa,
    không tồn tại) — kiểu thật là `org.mozilla.geckoview.WebResponse`
    (top-level, không lồng trong GeckoSession), có sẵn property `.uri`.
  - `onFilePrompt` bị đặt SAI HẲN chỗ — code cũ đặt trong `ContentDelegate`
    với 1 tham số `callback: GeckoSession.FileCallback` (class này không hề
    tồn tại). API thật thuộc `PromptDelegate`, nhận 1 đối tượng
    `FilePrompt`, trả về `GeckoResult<PromptDelegate.PromptResponse>?` —
    ĐANG CHỜ hoàn thành (vì việc chọn file thật xảy ra bất đồng bộ qua
    Activity chọn file của Android). Viết lại đúng: lưu `prompt` +
    `GeckoResult` đang treo, thêm hàm `resolveFilePrompt(context, uri)` gọi
    từ `MainActivity.onActivityResult` để hoàn thành nó bằng
    `prompt.confirm(context, uri)`/`prompt.dismiss()`. Đây còn là 1 CẢI
    THIỆN CHỨC NĂNG THẬT — code cũ (trước khi sửa) chưa từng gọi API thật
    này, chỉ dispatch 1 CustomEvent JS tự chế mà trang bình thường (kể cả
    Colab) không hề lắng nghe → upload file qua `<input type="file">` CHƯA
    TỪNG hoạt động thật với trang thường, dù có vẻ "chạy được" khi test với
    trang tự viết.
  - `runtime.webExtensionController.ensureBuiltIn(uri, id)` nhận tham số
    đầu kiểu **String**, code cũ bọc `Uri.parse(...)` quanh nó → sai kiểu
    (`Uri` thay vì `String`). Bỏ `Uri.parse()`, truyền thẳng chuỗi.
- **`DownloadManagerFeature.kt`**: thiếu import `android.graphics.Color`.
- **`PageConverter.kt`**: lặp lại đúng lỗi quote-hở đã gặp nhiều lần trước
  (StreamSniffer/WebArchiver, xem mục 5 cũ) — lần này lồng bên trong `${...}`
  của 1 raw string 3-dấu-nháy, dễ sót vì trông giống "an toàn" do nằm trong
  raw string bên ngoài.

Sau khi sửa: quét lại toàn bộ 33 file — cân bằng ngoặc `{}` khớp, không còn
dấu `"` hở. Đã tra CHÍNH XÁC (không đoán) javadoc GeckoView cho mọi API động
tới trong lượt sửa này (`GeckoSession.NavigationDelegate`, `ContentDelegate`,
`PromptDelegate.FilePrompt`, `WebResponse`, `GeckoResult`,
`GeckoRuntimeSettings.Builder`, `WebExtensionController.ensureBuiltIn`) —
vẫn CHƯA build thử lại qua Actions để xác nhận 100% hết lỗi (có thể còn lỗi
khác mà Kotlin compiler chưa kịp báo ở lượt build #135 vì dừng sớm).



Ban đầu chỉ là 1 addon Firefox để giữ phiên Google Colab không bị ngắt khi
chuyển sang app khác/tắt màn hình. Sau khi phát hiện addon Firefox không đủ
quyền hệ thống để làm việc này, dự án chuyển thành **1 app trình duyệt
Android tự build từ đầu**, với Colab Live Keeper chỉ là 1 tính năng trong số
nhiều tính năng dự kiến (download, multi-profile, addon...).

**Ràng buộc quan trọng cần nhớ**: người dùng **không có PC**, chỉ có điện
thoại Android + trình duyệt di động (Chrome). Toàn bộ việc build APK diễn ra
qua **GitHub Actions** (miễn phí), code được viết ở đây rồi đóng gói thành
`.zip`, người dùng upload lên GitHub qua giao diện web mobile.

### Lượt 9 — App cài được nhưng crash khi mở — thêm công cụ bắt lỗi không cần máy tính

Người dùng báo "click vào là app tự crash thoát ra ngoài" — không có PC/adb
(đã biết từ đầu, xem ràng buộc ở mục 1) nên không lấy được logcat theo cách
thông thường. Đã làm 2 việc:

1. **Sửa 1 bug thật tìm được khi soát lại**: `MainActivity.onCreate()` xác
   định slot đang chạy CHỈ dựa vào Intent extra `"slot_index"` — nhưng
   launcher (bấm icon màn hình chính) KHÔNG BAO GIỜ gửi kèm extra tuỳ ý, nên
   nếu khe được mở theo cách nào đó không qua `ProfilePickerActivity` (vốn
   set extra này), nó sẽ luôn rơi về mặc định `slotIndex=0` — nếu khi đó khe
   0 cũng đang chạy ở tiến trình khác, 2 tiến trình khác nhau cùng cố mở
   CHUNG 1 thư mục hồ sơ Gecko (`gecko_profile_slot_0`, cờ `-profile` thêm ở
   lượt 3) cùng lúc — Gecko có khoá hồ sơ (`.parentlock`), việc này CÓ THỂ
   là nguyên nhân crash (native, không chắc chắn — xem mục 2 dưới). Đã sửa
   dùng `ProfileSlots.getCurrentSlotIndex()` (đọc tên tiến trình thật qua
   `ActivityManager`) làm nguồn chính, chỉ ưu tiên Intent extra khi có.
2. **Thêm cơ chế bắt crash không cần adb** (`LiveBrowserApp.kt` +
   `CrashReportActivity.kt` mới): cài `Thread.setDefaultUncaughtExceptionHandler`
   ở tầng Application (chạy sớm nhất, trước MỌI Activity) — bắt exception
   Kotlin/Java chưa xử lý, ghi ra file `last_crash.txt` (sống sót qua lần mở
   app kế tiếp) VÀ mở ngay 1 màn hình tối giản hiển thị full stack trace +
   20 dòng DebugLog gần nhất, có nút "Sao chép" để gửi lại. Cũng thêm mục
   "🩹 Xem crash gần nhất" vào menu chính để mở lại thủ công nếu lỡ bỏ qua.
   ⚠️ **GIỚI HẠN THẬT, đã ghi trong code**: đây là handler Ở TẦNG JVM — KHÔNG
   bắt được crash NATIVE (vd chính thư viện Gecko `libxul.so` crash ở tầng
   C++, đúng loại rủi ro chưa xác nhận của cờ `-profile`/`userAgentOverride`
   ở lượt 3 và 8). Nếu màn hình crash mới KHÔNG hiện ra khi crash (vẫn chỉ
   thấy dialog hệ thống "App đã dừng" cũ), gần như chắc chắn đây là crash
   native — lúc đó bắt buộc cần cách khác để xem log (bug report tích hợp
   sẵn của Android: Cài đặt > tuỳ chọn nhà phát triển > Báo cáo lỗi, không
   cần PC — hoặc nếu có PC sau này thì logcat vẫn là cách đáng tin nhất).

**Kết quả mong đợi**: build lại → cài → mở app → NẾU crash lần này sẽ tự
hiện ra 1 màn hình đọc được lý do, gửi lại nội dung đó (bấm "Sao chép") để
sửa tiếp DỰA TRÊN BẰNG CHỨNG THẬT, thay vì đoán như các lượt vá "giới hạn
thật"/native trước đó.



### 2.1. Engine trình duyệt: GeckoView (không dùng WebView)

- **Lý do đổi từ WebView sang GeckoView**: WebView (Chromium hệ thống)
  không hỗ trợ load WebExtension/addon thật. GeckoView (engine của Firefox,
  Mozilla phân phối dạng thư viện nhúng qua Maven) có hỗ trợ WebExtension
  API thật cho ứng dụng nhúng — mục tiêu dài hạn là load được addon thật.
- **Đã cân nhắc và loại bỏ**: tự fork Chromium (kiểu Kiwi Browser) — không
  khả thi vì cần build từ source (~40GB, nhiều giờ build), vượt xa giới hạn
  GitHub Actions free tier (6h/job, ~14GB đĩa).
- Dependency: `org.mozilla.geckoview:geckoview:${geckoviewVersion}` (xem
  `app/build.gradle`). **LƯU Ý**: tên artifact đúng là `geckoview` (KHÔNG
  phải `geckoview-release` — đã build lỗi thật với tên sai này, xem mục 5).
  Version hiện tại: `145.0.20251124145406` — **cần xác nhận lại số mới nhất**
  tại https://mvnrepository.com/artifact/org.mozilla.geckoview/geckoview/versions
  trước khi build nếu đã lâu không cập nhật.
- **CHƯA XÁC NHẬN**: artifact `geckoview` (không suffix) có phải bản đầy đủ
  hay bản "lite" thiếu tài nguyên runtime (cần `geckoview-omni` thay thế)?
  Build qua được nhưng nếu app crash lúc khởi tạo `GeckoRuntime`, đây là nghi
  phạm đầu tiên cần thử.

### 2.2. Kiến trúc "tiện ích" (Feature system) — điểm mạnh nhất của dự án

Không hardcode tính năng vào `MainActivity`. Mọi tiện ích implement interface
`BrowserFeature` (`core/BrowserFeature.kt`), đăng ký vào `FeatureRegistry`
(`core/FeatureRegistry.kt`). Thêm tiện ích mới = viết 1 class mới + thêm 1
dòng vào registry — **không đụng** `MainActivity`, `AutoClickAccessibilityService`,
hay `SettingsActivity`.

Feature hiện có:
- `features/colablive/ColabLiveKeeperFeature.kt` — giữ Colab sống.
- `features/downloads/DownloadManagerFeature.kt` — tải file media thường
  (KHÔNG hỗ trợ YouTube, xem mục 6).

### 2.3. `BrowserEngine` — lớp trừu tượng tách feature khỏi engine cụ thể

`core/BrowserEngine.kt` (interface) + `core/GeckoViewEngine.kt` (implementation
hiện tại, bọc GeckoView). Mọi feature chỉ biết tới `BrowserEngine`, không biết
gì về GeckoView hay WebView cụ thể. **Đây là quyết định kiến trúc đúng nhất
của dự án** — khi chuyển từ WebView sang GeckoView, `ColabLiveKeeperFeature`
và `DownloadManagerFeature` **không cần sửa 1 dòng nào**, chỉ cần viết
`GeckoViewEngine` mới. Nếu sau này đổi engine lần nữa, chỉ cần viết thêm 1
class engine mới.

### 2.4. Hệ thống "khe" (Profile Slots) — trình duyệt con độc lập

`core/ProfileSlots.kt` + khai báo `activity-alias` trong `AndroidManifest.xml`
(hiện tại: `SLOT_COUNT = 4`, tức 5 khe tổng cộng tính cả khe 0/chính).

- Mỗi khe = 1 **tiến trình Android riêng** (`android:process=":slotN"`),
  đây là ràng buộc nền tảng của Android (không tạo process tuỳ ý lúc runtime
  được, phải khai báo tĩnh trong Manifest).
- Gán profile (tên tự đặt, không giới hạn số lượng) vào khe (số lượng cố
  định) — đổi gán = khởi động lại đúng 1 khe đó qua `ProfilePickerActivity`.
- **CHƯA HOÀN THÀNH**: cô lập dữ liệu `GeckoRuntime` thật theo từng khe.
  Trước đây dùng `WebView.setDataDirectorySuffix()` cho việc này (khi còn
  dùng WebView) — GeckoView có cơ chế tương đương nhưng **CHƯA tra cứu API
  chính xác** (xem `LiveBrowserApp.kt`, có TODO ghi rõ). **Hệ quả hiện tại:
  mọi khe đang dùng chung 1 GeckoRuntime data — cookie/session KHÔNG cô lập
  thật giữa các khe.** Đây là việc ưu tiên cao cần làm tiếp.

### 2.5. Cấu hình theo từng khe (`AppPrefs`)

`core/AppPrefs.kt` — mọi cấu hình feature (bật/tắt, interval...) namespace
theo `slotIndex` tường minh (file SharedPreferences riêng: `browser_prefs_slotN`).
**Đã sửa 1 bug thật**: ban đầu cấu hình dùng chung toàn app (bật Colab ở khe
1 thì khe khác cũng bật theo) — đã sửa để mỗi khe độc lập hoàn toàn. Interface
`BrowserFeature` bắt buộc mọi hàm nhận `slotIndex` tường minh để tránh tái
phạm lỗi này khi thêm feature mới.

### 2.6. Cơ chế giữ Colab sống (2 chế độ song song)

Trong `ColabLiveKeeperFeature.kt`, người dùng chọn 1 trong 2 (cấu hình qua
Settings UI):

- **Chế độ DOM**: JS giả lập (`mousemove`, click nút Connect) qua "eval
  bridge" (xem mục 2.7). Không cần bật màn hình. **`isTrusted` của event
  KHÔNG đảm bảo = true** — nếu Colab kiểm tra cờ này, cách này thất bại.
  Chưa kiểm chứng thực tế Colab có check hay không.
- **Chế độ Accessibility**: `AutoClickAccessibilityService.kt` dùng
  `dispatchGesture()` — tap thật ở tầng input Android, gần như chắc chắn
  `isTrusted = true`. Đánh đổi: cần bật màn hình + đưa app lên foreground
  mỗi chu kỳ (mặc định 20 phút, dưới ngưỡng idle-timeout ~90 phút của Colab)
  để tap trúng đúng chỗ.
- Cả 2 chế độ đều **CHƯA được test thực tế** trên thiết bị (do các lỗi build
  chặn trước đó) — xem mục 4 "Việc cần làm tiếp theo", đây là việc ưu tiên
  SỐ 1 cần làm ngay khi app chạy ổn định.

### 2.7. "Eval bridge" — cách chạy JS trong GeckoView

GeckoView không có API kiểu `WebView.evaluateJavascript()`. Giải pháp: 1
WebExtension nội bộ tự đóng gói trong `assets/eval_bridge/` (`manifest.json`
+ `content.js`) — **KHÔNG PHẢI addon thật cho người dùng cài**, chỉ là hạ
tầng nội bộ. Cơ chế: content script mở `Port` qua
`browser.runtime.connectNative("browser")`, native side (`GeckoViewEngine.kt`)
nhận qua `session.webExtensionController.setMessageDelegate()`, gửi lệnh eval
qua `port.postMessage()`. **1 CHIỀU** (native → trang), không có giá trị trả
về thật — `evaluateJs()` trong `BrowserEngine` luôn callback `null`.

Cơ chế này giờ còn dùng thêm để **giả fingerprint** (xem mục 2.8) — phần
spoof canvas/WebGL nằm TĨNH trực tiếp trong `content.js` (chạy ngay lúc
`document_start`, không qua round-trip native vì cần chạy SỚM hơn cả lúc
trang kịp đọc giá trị thật).

### 2.8. `FingerprintSpoofFeature` — hồ sơ thiết bị TRỌN GÓI (đảm bảo nhất quán)

Bản đầu cho chọn từng thông số rời (WebGL/CPU/RAM độc lập) — rủi ro tự tạo
ra tổ hợp vô lý (vd platform Windows nhưng WebGL renderer của Apple), còn
dễ bị phát hiện hơn cả không giả gì. Đã sửa: `DeviceProfiles.kt` định nghĩa
**hồ sơ trọn gói tự nhất quán bên trong**:
- `HardwareProfile`: platform + WebGL vendor/renderer + hardwareConcurrency +
  deviceMemory đi CÙNG NHAU. **15 preset** — 10 loại `desktop` (Windows Intel
  x2, NVIDIA x2, AMD x2, MacBook M1/M2, Chromebook, Linux Mesa) + 5 loại
  `mobile` thật (Samsung/Xiaomi/Pixel/Oppo với GPU Mali/Adreno thật).
- `LocaleProfile`: timezone + ngôn ngữ đi CÙNG NHAU. **15 preset** — các nước
  Đông Nam Á (VN/SG/MY/TH/ID/PH), Đông Á (Nhật/Hàn/Đài/Ấn), Mỹ (2 múi giờ),
  Anh, Đức, Úc.
- Tổng **225 tổ hợp** (15×15), tăng từ 25 (5×5) ở bản đầu.

**Sửa nhận định trước đó (SAI, đã đính chính)**: "Chế độ máy tính" (đổi UA
sang desktop) và Hardware Profile spoof KHÔNG mâu thuẫn nhau về nguyên tắc
— điện thoại mở giao diện desktop là hành vi HOÀN TOÀN BÌNH THƯỜNG, mọi
trình duyệt di động đều có. Rủi ro thật chỉ nằm ở việc **chọn SAI LOẠI**
(vd bật Desktop Mode nhưng lại chọn Hardware Profile loại `mobile`, hoặc
ngược lại) — đã thêm field `category` ("desktop"/"mobile") vào mỗi
`HardwareProfile` + dòng gợi ý 💡 trong UI để người dùng tự khớp đúng loại
với trạng thái "Chế độ máy tính" đang bật/tắt. Chọn ngược lại KHÔNG lỗi kỹ
thuật gì, chỉ hiếm gặp hơn trong thực tế.

Random/Manual đều chọn CẢ hồ sơ (không chỉnh từng thông số) — loại bỏ khả
năng tạo tổ hợp không nhất quán **ngay từ thiết kế**, thay vì phải validate
rồi báo lỗi sau (cách này chắc chắn hơn, không có logic kiểm tra nào có thể
viết sai).

**Đã làm** (mặc định BẬT toàn bộ):
- Toggle riêng theo NHÓM: canvas / Hardware Profile / Locale Profile /
  chặn WebRTC (không còn per-signal rời như bản đầu).
- 2 chế độ: Random (seed bền theo `slotIndex`, mỗi khe ra hồ sơ khác nhau,
  ổn định qua các lần mở lại) hoặc Chỉ định (chọn hẳn 1 hồ sơ từ Spinner).
- Cơ chế truyền cấu hình: giống bản đầu (port riêng, đẩy config lúc
  content script connect, có fallback mặc định an toàn tại `document_start`).
- **Mới thêm so với bản đầu**: giả `navigator.platform`, giả
  `Date.prototype.getTimezoneOffset()` + `Intl.DateTimeFormat` (timezone),
  giả `navigator.language`/`languages`, và **chặn hẳn WebRTC**
  (`RTCPeerConnection`/`webkitRTCPeerConnection`/`RTCDataChannel` = undefined)
  để tránh rò IP thật qua ICE candidate.

**CHƯA làm** (liệt kê rõ để không quên):
- Audio fingerprint (`AudioContext` fingerprinting).
- Liệt kê font cài sẵn trên máy.
- User-Agent string chi tiết đồng bộ với Hardware Profile đã chọn (hiện
  "Chế độ máy tính" trong menu là cơ chế RIÊNG, độc lập, đổi
  `GeckoSessionSettings.userAgentMode`/`viewportMode` — CHƯA liên kết với
  platform/hồ sơ đã chọn trong Fingerprint Spoof, có thể gây KHÔNG NHẤT
  QUÁN nếu bật cả 2 cùng lúc theo hướng khác nhau — cần hợp nhất sau).
- Chỉ có 5 preset mỗi loại (Hardware/Locale) — chưa phải "sinh ngẫu nhiên
  không giới hạn" như trình duyệt antidetect thương mại thật.
- **QUAN TRỌNG HƠN CẢ VIỆC THÊM FINGERPRINT**: cookie/storage giờ ĐÃ cô lập
  thật giữa các khe qua `contextId` (mục 2.4) — không còn là ưu tiên số 1
  nữa như ghi chú cũ ở đây, đã sửa xong.
- ~~Không có cách nào giả IP thật~~ — **ĐÃ ĐÍNH CHÍNH, xem mục 2.13**: có
  cách làm được qua WebExtension Proxy API (`browser.proxy.onRequest`),
  không phải qua `GeckoRuntimeSettings` như dòng cũ này từng đoán. Kèm
  `ProxyScraper`/`ProxyHealthChecker` tự cào + kiểm tra proxy miễn phí.
  CHƯA test trên thiết bị thật (xem mục 4).
- Đây KHÔNG phải giải pháp toàn diện kiểu trình duyệt "antidetect" thương
  mại (Multilogin, GoLogin, AdsPower) — những sản phẩm đó là dự án riêng quy
  mô lớn với hàng chục vector fingerprint + hạ tầng proxy trả phí đáng tin
  cậy hơn hẳn proxy miễn phí cào tự động, không kỳ vọng đạt được mức đó chỉ
  qua vài file JS này.

### 2.9. Foreground Service + WakeLock

`KeepAliveService.kt` — Foreground Service thật (khác Firefox addon, không
cần mượn qua media session) + `PARTIAL_WAKE_LOCK` giữ CPU chạy khi màn hình
tắt. Chạy chung 1 instance cho toàn app (Android tự gộp, không tạo nhiều
service dù nhiều khe cùng gọi `startForegroundService`).

### 2.10. Broadcast liên-process (`ForegroundState`)

`core/ForegroundState.kt` — mỗi khe là 1 process riêng, Kotlin `object`
singleton (như `CurrentBrowserState` cũ) **KHÔNG chia sẻ được giữa các
process khác nhau**. Đã sửa bằng broadcast Intent thật
(`setPackage(packageName)` giới hạn nội bộ app) để `AutoClickAccessibilityService`
(luôn chạy ở khe 0) biết được khe nào đang thực sự active + URL của khe đó,
và bật ĐÚNG khe đó lên khi cần tap (trước đây có bug: luôn bật nhầm khe 0).

### 2.11. UI Settings — mỗi feature 1 màn hình riêng (không còn dồn chung)

Trước đây `SettingsActivity` nhồi UI của MỌI feature vào 1 màn hình cuộn dài
— dễ loãng khi thêm feature mới. Đã tách:
- `SettingsActivity.kt` — chỉ còn là DANH SÁCH tên feature (nút bấm điều
  hướng), không tự vẽ UI chi tiết nào.
- `FeatureSettingsActivity.kt` (mới) — nhận `feature_id` + `slot_index` qua
  Intent, tìm đúng feature trong `FeatureRegistry`, hiển thị
  `buildSettingsView()` của riêng feature đó chiếm toàn màn hình.
- Thêm feature mới **không cần sửa** `SettingsActivity`/`FeatureSettingsActivity`
  — tự động xuất hiện trong danh sách nhờ `FeatureRegistry`.

### 2.12. Debug Log — thay Toast thoáng qua

`core/DebugLog.kt` (ring buffer trong bộ nhớ, tối đa 300 dòng, có timestamp)
+ `DebugLogActivity.kt` (xem lại được, có nút Làm mới/Xoá log). Mọi chẩn
đoán trước đây dùng Toast (dễ mất, khó chụp màn hình kịp) giờ ghi vào đây:
`onLoadError`, `onPopupRequested`, `onNavigationAttempt`, `onFilePrompt`.
Truy cập qua menu 3 chấm → 🐞 Debug Log, hoặc từ danh sách Tiện ích.

### 2.13. Proxy riêng theo từng khe — đã tìm ra API đúng, ĐÍNH CHÍNH lại kết luận trước

**Trước đây kết luận SAI**: "GeckoView không hỗ trợ proxy-per-session, đây là
giới hạn thật, chấp nhận" — dựa trên việc thử `GeckoRuntimeSettings.arguments()`
(1 báo lỗi công khai xác nhận cách này không hoạt động) và thấy bug request
1348392 của Mozilla còn mở, nên kết luận vội KHÔNG có cách nào khác.

**Đính chính**: có API khác — `browser.proxy.onRequest`, chuẩn WebExtension
(không phải API riêng của GeckoView). Xác nhận qua Mozilla bug 1525486 (đội
Secure Proxy/Mozilla VPN, 2019): *"All evidence so far shows that we can do
what we need using the existing proxy APIs in WebExtensions."* Vì app đã có
sẵn hạ tầng đăng ký WebExtension (dùng cho eval_bridge, fingerprint_spoof),
chỉ cần thêm 1 extension thứ 3 theo đúng pattern đó.

**Đã code** (`assets/proxy_config/` + `core/proxy/`):
- `proxy_config/manifest.json` + `background.js` — dùng
  `browser.proxy.onRequest` (chọn proxy theo mỗi request) +
  `browser.webRequest.onAuthRequired` (xác thực user/pass nếu proxy yêu cầu
  đăng nhập). Khác content script (eval_bridge/fingerprint_spoof) —
  đây là **background script**, nên đăng ký message delegate ở **cấp
  extension** (`extension.setMessageDelegate`), không phải cấp session.
- `GeckoRuntimeProvider.kt` — đăng ký extension này CÓ ĐIỀU KIỆN (chỉ nếu
  `proxy_type != 0/Direct` trong cấu hình của khe đó), đẩy config thật
  (host/port/type/user/pass) xuống ngay lúc background script connect.
- `ProxyScraper.kt` — cào danh sách proxy miễn phí công khai từ ProxyScrape
  API (`api.proxyscrape.com`, xác nhận hoạt động thật qua tra cứu, có tài
  liệu chính thức tại docs.proxyscrape.com).
- `ProxyHealthChecker.kt` — kiểm tra SONG SONG (thread pool tối đa 20 luồng
  cùng lúc) từng proxy còn sống không (gọi thử `gstatic.com/generate_204`
  qua chính proxy đó, đo latency), chọn proxy có latency THẤP NHẤT trong số
  các proxy phản hồi thành công.
- UI: nút "🔍 Tự động tìm proxy nhanh nhất" trong màn hình Fingerprint Spoof
  — chạy trong background thread, tự điền + lưu host/port khi xong.

**CẢNH BÁO THẬT đã đưa vào UI** (không giấu): proxy miễn phí công khai có
thể log lại traffic, chèn quảng cáo, hoặc là honeypot — không dùng để đăng
nhập tài khoản quan trọng hay gửi dữ liệu nhạy cảm qua proxy loại này. Đây
là hạn chế cố hữu của MỌI proxy miễn phí công khai, không phải lỗi thiết kế
của tính năng — muốn an toàn hơn cần dùng proxy trả phí có uy tín (không
nằm trong phạm vi tính năng auto-scrape này).

**CHƯA XÁC NHẬN qua test thật trên thiết bị** (mục 4, ưu tiên #8) — toàn bộ
cụm tính năng này (extension + scraper + checker + UI) mới viết xong, chưa
build+chạy lần nào. Rủi ro cần kiểm chứng khi test thật:
- `browser.proxy.onRequest`/`browser.webRequest.onAuthRequired` có hoạt
  động đúng trên GeckoView Android (không chỉ Firefox desktop) hay không —
  đã có bằng chứng gián tiếp (bug 1525486) nhưng chưa tự tay xác nhận trên
  chính app này.
- Tốc độ cào + kiểm tra hàng chục proxy có đủ nhanh trong thực tế không
  (ước tính 1-2 phút cho toàn bộ quá trình, tuỳ tốc độ mạng + số lượng
  proxy trong danh sách cào được).
- Tỷ lệ proxy miễn phí còn sống thường RẤT THẤP (nhiều nguồn công khai ghi
  nhận 80-98% proxy free đã chết tại bất kỳ thời điểm nào) — cần chấp nhận
  đôi khi không tìm được proxy nào, không phải lỗi code.

### Lượt 10 — Ghi log ra file LIÊN TỤC (không chỉ lúc crash) để bắt được cả crash native

Người dùng hỏi đúng điểm yếu của cơ chế lượt 9: crash handler ở đó chỉ bắt
được exception TẦNG JVM — nếu crash là NATIVE (chính thư viện Gecko
`libxul.so` chết ở tầng C++, ví dụ do cờ `-profile` chưa xác nhận ở lượt 3),
tiến trình chết ngay lập tức, không kịp chạy qua bất kỳ handler Kotlin nào,
kể cả để "ghi nốt trước khi thoát". Đã sửa tận gốc: GHI FILE NGAY TỪ LÚC
CHẠY BÌNH THƯỜNG, không đợi tới lúc crash.

- **`DebugLog.kt` viết lại**: mỗi lần gọi `log()` giờ vừa lưu bộ nhớ (như
  cũ, xem nhanh qua `DebugLogActivity`) VỪA ghi ngay xuống file
  `debug_log.txt` trong `filesDir`, mở/ghi/ĐÓNG file mỗi dòng (đóng = flush
  thật xuống đĩa ngay, không giữ trong buffer chờ mất khi crash). Giới hạn
  file 2MB (tự cắt bớt) vì `KeepAliveService` có thể chạy liên tục hàng
  giờ/ngày. `LiveBrowserApp.onCreate()` gọi `DebugLog.init(context)` đầu
  tiên trước mọi log khác.
- **Thêm checkpoint log quanh đúng các lệnh gọi vào Gecko native nghi ngờ
  cao nhất**: trước/sau `GeckoRuntime.create()` (nghi phạm #1 — cờ
  `-profile` chưa xác nhận) và trước/sau `session.open(runtime)`, cùng từng
  bước trong `MainActivity.onCreate()`. Nếu crash native xảy ra, dòng CUỐI
  CÙNG còn lại trong file (dòng "bắt đầu..." mà không có dòng "...XONG"
  theo sau) chỉ thẳng ra bước nào gây crash — dù không có stack trace thật.
- **Thêm phòng thủ**: `GeckoRuntimeProvider.createRuntime()` giờ bọc
  `GeckoRuntime.create()` trong try-catch — nếu lỗi là loại JVM bắt được
  (không phải crash cứng), tự động thử lại KHÔNG dùng cờ `-profile` thay vì
  để cả app crash hẳn (vẫn còn cô lập qua `contextId`, chắc chắn hoạt động,
  dù mất lớp cô lập hồ sơ vật lý riêng).
- **`CrashReportActivity.kt`**: giờ LUÔN hiển thị đuôi file log (80 dòng
  gần nhất) dù có bắt được crash Kotlin hay không — trường hợp crash native
  (không có `crash_text` từ Intent), màn hình vẫn hiện được log file, kèm
  giải thích rõ đây nhiều khả năng là crash native và dòng cuối là manh mối.



**LƯU Ý QUAN TRỌNG**: dự án từng phân nhánh (fork) — 1 nhánh do Claude giữ,
1 nhánh (`v4_3`, file này) do người dùng/AI khác phát triển thêm nhiều tính
năng. Ngày hôm nay đã **audit toàn diện `v4_3`** và hợp nhất — từ giờ
`v4_3` là nguồn chính thức duy nhất, nhánh Claude cũ không dùng nữa.

- [x] Cookie/localStorage cô lập thật theo từng khe — `contextId` trong
      `GeckoViewEngine.kt` (đã XÁC NHẬN có thật qua audit, ban đầu Claude
      tưởng nhầm là thiếu do chỉ grep sai phạm vi 1 file)
- [x] Multi-tab thật — `createTab`/`switchToTab`/`closeTab`/`tabMeta` trong
      `GeckoViewEngine.kt` — ĐÃ CÓ, khác với ghi chú cũ "để sau"
- [x] `DownloadEngine.kt` — tải đa luồng thật (check `Accept-Ranges`, chia
      `RandomAccessFile` theo offset đúng chuẩn), pause/resume hoạt động
      **TRONG LÚC APP ĐANG CHẠY** (dùng `Thread.sleep` busy-wait + AtomicBoolean,
      KHÔNG lưu file/DB nên tắt app giữa chừng sẽ MẤT tiến trình — khác với
      "pause rồi tải tiếp sau" đúng nghĩa hoàn toàn, cần làm thêm nếu muốn
      persist qua restart)
- [x] `CookieLeakDetector.kt` + `test_leak.html` — công cụ tự kiểm chứng
      `contextId` hoạt động đúng, thực hành tốt

**Audit hôm nay tìm ra và ĐÃ SỬA các lỗi thật sau**:
- [x] **Lỗi biên dịch thật**: `GeckoRuntimeProvider.kt` gọi
      `AppPrefs.getString(null, ...)` — tham số `Context` không cho null,
      KHÔNG THỂ BUILD ĐƯỢC. Đã sửa (xoá code chết, xem mục 5).
- [x] **Tính năng giả (nguy hiểm)**: proxy/DNS-leak-protection tưởng đã làm
      nhưng dùng sai API (`Services.prefs` — API nội bộ Firefox, không tồn
      tại trong JS trang web) — lỗi bị NUỐT ÂM THẦM, khiến UI trông như hoạt
      động nhưng **KHÔNG che IP thật**. Đã thêm cảnh báo ⚠️ rõ ràng ở 3 nơi
      (UI Fingerprint Spoof, dialog Proxy Config, code comment) — xem mục 5.
- [x] **Bug NPE tiềm ẩn**: `DownloadEngine.pauseDownload()`/`cancelDownload()`
      dùng `downloads[id]!!` ngay sau `downloads[id]?.` — crash nếu `id`
      không tồn tại. Đã sửa dùng `val task = downloads[id] ?: return`.
- [x] **Code mồ côi**: xoá `DownloadPolicyManager.kt` + `DownloadLocationPicker.kt`
      (311 dòng, không nơi nào trong luồng chạy thật gọi tới — trùng chức
      năng với `DownloadPolicy`/`SaveLocationDialog` đang thực sự được dùng).

- [x] Kiến trúc feature module mở rộng được (`BrowserFeature`/`FeatureRegistry`)
- [x] `ColabLiveKeeperFeature` — 2 chế độ DOM/Accessibility, cấu hình được
      chu kỳ, cấu hình riêng theo từng khe
- [x] `DownloadManagerFeature` — bắt download file thường qua
      `DownloadManager` hệ thống (không phải engine đa luồng riêng)
- [x] Hệ thống khe/profile (`ProfileSlots`) — cô lập process thật, gán linh
      hoạt qua `ProfilePickerActivity`
- [x] Chuyển engine từ WebView sang GeckoView hoàn toàn
- [x] Eval bridge — chạy JS trong GeckoView
- [x] Navigation: Back/Forward, Reload, báo lỗi tải trang (`onLoadError`)
- [x] Xử lý popup OAuth cơ bản (`onNewSession` → điều hướng tab hiện tại)
- [x] Upload file cơ bản (`onFilePrompt` → `ACTION_OPEN_DOCUMENT` → copy
      `content://` thành `file://` thật, né giới hạn GeckoView)
- [x] UI giống Chrome cơ bản: omnibox bo tròn, icon vector back/forward/refresh,
      overflow menu 3 chấm
- [x] Chế độ máy tính (Desktop mode) — đổi User-Agent + viewport
- [x] Giả fingerprint — `FingerprintSpoofFeature` riêng biệt, toggle từng
      tín hiệu (canvas/WebGL/hardwareConcurrency/deviceMemory), chế độ
      Random (seed riêng bền vững theo khe) hoặc Chỉ định (chọn preset),
      cần khởi động lại khe để áp dụng (xem mục 2.8)
- [x] UI Settings tách riêng từng feature (`FeatureSettingsActivity`) thay
      vì dồn chung 1 màn hình cuộn dài (xem mục 2.11)
- [x] Debug Log bền vững (`DebugLogActivity`) thay Toast thoáng qua khó
      chụp màn hình kịp (xem mục 2.12)
- [x] Xin quyền `POST_NOTIFICATIONS` đúng cách (runtime, Android 13+)
- [x] CI build qua GitHub Actions (`build.yml`) — build được, có ABI split
      (nghi vấn hiệu quả thật, xem mục 5)

### Lượt 11 — CRASH THẬT ĐẦU TIÊN BẮT ĐƯỢC — vòng lặp tự nuôi nhau trong KeepAliveService (đã sửa, xác nhận bằng log thật)

Công cụ ghi log ra file ở lượt 10 phát huy tác dụng ngay lần đầu — người
dùng gửi lại crash report, log cho thấy CHÍNH XÁC nguyên nhân, không cần
đoán:

```
KeepAliveJob triggered → KeepAliveJob scheduled → KeepAliveService started
→ KeepAliveJob triggered → ... (lặp lại ~20+ lần trong đúng 1 giây)
→ IllegalStateException: schedule()/enqueue() called more than 250 times
  in the past 60000ms
```

**Nguyên nhân gốc**: `KeepAliveService.scheduleKeepAliveJob()` gọi
`jobScheduler.schedule(jobInfo)` VÔ ĐIỀU KIỆN mỗi lần service khởi động —
kể cả khi chính service đó được khởi động BỞI job (`KeepAliveJobService.onStartJob()`
gọi `KeepAliveService.start()`). Tạo thành vòng lặp tự nuôi nhau: job kích
hoạt → khởi động service → service tự lên lịch LẠI CHÍNH job đó → (JobScheduler
của Android, đặc biệt các bản OEM tuỳ biến, có thể kích hoạt gần như ngay
lập tức khi 1 job đang pending bị `schedule()` lại) → job kích hoạt lại →
lặp vô hạn → chạm giới hạn cứng 250 lần/60s của Android → toàn bộ app crash.

**Đã sửa** (`KeepAliveService.kt`): thêm 2 lá chắn trong `scheduleKeepAliveJob()`:
1. Kiểm tra `jobScheduler.getPendingJob(JOB_ID)` — đã có job đang chờ thì
   bỏ qua, không schedule lại (chặn tận gốc).
2. Chặn thêm theo thời gian — không schedule lại nếu vừa schedule cách đây
   chưa tới 60s, lưu ở `companion object` (sống qua việc Service bị Android
   huỷ/tạo lại instance mới liên tục, khác biến instance thường sẽ mất giá
   trị mỗi lần service restart).

Đây là lần đầu tiên trong toàn bộ dự án có 1 lỗi được xác nhận và sửa DỰA
TRÊN BẰNG CHỨNG THẬT (log file) thay vì suy đoán từ đọc code — đúng quy
trình đã đề ra ở các lượt trước. Công cụ ghi log ra file (lượt 10) chứng
minh hiệu quả ngay từ crash đầu tiên.



1. **Test thực tế trên thiết bị — CHƯA CÓ LẦN NÀO xác nhận `v4_3` build/chạy
   được sau khi hợp nhất fork hôm nay.** Toàn bộ fix hôm nay (contextId đã
   có sẵn xác nhận qua đọc code, proxy warning, NPE fix, xoá dead code) mới
   chỉ kiểm chứng bằng ĐỌC CODE, chưa build+cài+chạy thật. Việc đầu tiên: build
   qua GitHub Actions, cài, xác nhận không crash, xác nhận Colab Live Keeper
   thật sự giữ được phiên qua idle-timeout ~90 phút.
2. **Tích hợp YouTube downloader (NewPipeExtractor)** — dependency đã có
   trong `build.gradle` (`jsoup`, NewPipeExtractor qua JitPack) nhưng **KHÔNG
   có dòng code nào gọi tới** (`grep NewPipeExtractor` trong toàn bộ
   `app/src/main/java/` ra rỗng) — đây là việc lớn nhất còn thiếu thật sự,
   không phải chỉ "chưa hoàn thiện" mà là "chưa bắt đầu viết", dù nhìn
   `DownloadEngine.kt`/`IDMDownloadDialog.kt` có vẻ đã sẵn sàng hạ tầng để
   nhận URL stream từ NewPipeExtractor rồi tải qua chính `DownloadEngine`
   đã có (không cần viết engine tải riêng cho YouTube — dùng chung).
3. **Persist tiến trình download qua việc tắt app** — `DownloadEngine.kt`
   hiện chỉ pause/resume được TRONG LÚC APP ĐANG CHẠY (state trong RAM,
   `Thread.sleep` busy-wait). Đóng app giữa chừng = mất tiến trình. Cần lưu
   `downloadedBytes` mỗi segment ra file/SharedPreferences để resume đúng
   nghĩa sau khi mở lại app (đã có thiết kế mẫu tương tự ở nhánh Claude cũ
   trước khi fork — `DownloadModels.kt`/`DownloadTaskStore.kt` — có thể tham
   khảo lại nếu cần, dù nhánh đó không còn dùng làm nguồn chính).
4. Xác nhận artifact GeckoView đúng là `geckoview` hay cần `geckoview-omni`
   (mục 2.1) — build qua được không có nghĩa là chạy đúng, cần test crash
   thật lúc `GeckoRuntime` khởi tạo trên thiết bị.
5. Xác nhận ABI split có thực sự giảm size APK không (mục 5).
6. Hợp nhất "Chế độ máy tính" (đổi UA/viewport) với Hardware Profile của
   Fingerprint Spoof — vẫn là 2 cơ chế độc lập, có thể gây KHÔNG NHẤT QUÁN
   nếu chọn ngược hướng nhau.
7. Migrate sang tải addon WebExtension THẬT (không phải eval bridge nội bộ)
   — lý do gốc đổi sang GeckoView, chưa bắt đầu.
8. **Proxy riêng theo từng khe — ĐÃ TÌM RA CÁCH LÀM ĐƯỢC** (đính chính lại
   kết luận trước — xem mục 2.13 mới). Đã code xong: extension
   `assets/proxy_config/` (dùng `browser.proxy.onRequest`, API CHUẨN của
   WebExtension) + `ProxyScraper`/`ProxyHealthChecker` (tự cào danh sách
   proxy miễn phí từ ProxyScrape API, kiểm tra song song, chọn proxy nhanh
   nhất còn sống). **CHƯA TEST TRÊN THIẾT BỊ THẬT** — đây là việc ưu tiên
   cao cần làm ngay ở lượt tới, vì cả cụm tính năng này (proxy_config
   extension + ProxyScraper + ProxyHealthChecker + nút UI) mới chỉ viết
   xong, chưa build+chạy thử lần nào.
9. Audio fingerprint spoof, font enumeration spoof nếu cần mức ẩn danh cao
   hơn (ưu tiên thấp, chỉ làm nếu 1-8 đã ổn).
10. Che dấu vết fingerprint bị patch (`Function.prototype.toString()` lộ ra
    hàm đã bị ghi đè thay vì `"[native code]"`) — antidetect browser thương
    mại có xử lý, mình chưa làm — ưu tiên thấp, chỉ cần nếu đối thủ phát
    hiện có kiểm tra sâu tới mức này.

### Lượt 12 — Crash lặp lại y hệt sau khi báo đã sửa — bằng chứng đang chạy bản APK CŨ

Người dùng gửi lại crash y hệt lượt 11 sau khi báo đã build lại. Điểm mấu
chốt: stack trace vẫn ghi `KeepAliveService.kt:88` — CHÍNH XÁC số dòng cũ
TRƯỚC KHI sửa. Bản đã sửa thêm ~20 dòng code phía trên lệnh
`jobScheduler.schedule(jobInfo)`, nên nếu build mới thật sự đang chạy, số
dòng bắt buộc phải khác (giờ là dòng 120, đã xác nhận lại). Số dòng không
đổi = gần như chắc chắn đang cài/mở nhầm bản APK CŨ (build Actions cũ chưa
chạy lại, hoặc tải nhầm file .apk cũ, hoặc Android giữ bản cũ vì cài đè
không thành công âm thầm) — CHƯA PHẢI lỗi fix sai.

Đã rà lại toàn bộ: không tìm thêm nguồn gọi `KeepAliveService.start()` nào
khác ngoài 2 chỗ đã biết (`MainActivity.initServices()` gọi 1 lần lúc mở
app, và `KeepAliveJobService.onStartJob()` gọi lại khi job kích hoạt — đúng
thiết kế). Logic 2 lá chắn ở lượt 11 vẫn đúng, không phát hiện bug mới.

Thêm 1 lớp phòng thủ nữa cho chắc (đề xuất hợp lý từ 1 AI khác người dùng
tham khảo): bọc `jobScheduler.schedule(jobInfo)` trong try-catch bắt
`IllegalStateException` — nếu vì lý do khác (thiết bị/OEM cụ thể) 2 lá
chắn cũ vẫn không đủ, ít nhất KHÔNG để crash cả app, chỉ bỏ qua lần
schedule đó.

**Việc cần làm để xác nhận**: build lại từ ĐẦU qua GitHub Actions (đảm bảo
chạy Action MỚI, không dùng lại artifact cũ), GỠ CÀI ĐẶT bản cũ trước khi
cài bản mới (tránh trường hợp cài đè thất bại âm thầm giữ nguyên bản cũ).



| Vấn đề | Sai lầm cụ thể | Bài học |
|---|---|---|
| Fork Chromium (Kiwi-style) | Cân nhắc rồi loại bỏ — không khả thi trên GitHub Actions free (build từ source quá nặng) | Không thử lại hướng này trừ khi có hạ tầng build riêng |
| Tên artifact GeckoView | Dùng `geckoview-release` — build lỗi "Could not find". Tên đúng: `geckoview` (không suffix) | Luôn tra Maven thật trước khi đoán tên artifact |
| Version GeckoView | Đoán `150.0` (số ngắn) — sai định dạng, version thật có timestamp dài | Version GeckoView luôn có định dạng `xxx.0.yyyymmddhhmmss` |
| `GeckoView.session = ...` | Gán property trực tiếp — lỗi "'val' cannot be reassigned" vì GeckoView chỉ có `setSession()`, không có setter property chuẩn Kotlin | Luôn dùng `geckoView.setSession(session)` (gọi hàm), không gán property |
| Theme Activity | Khai `@android:style/Theme.Material.Light.NoActionBar` (theme gốc Android) cho `AppCompatActivity` — crash `IllegalStateException: You need to use a Theme.AppCompat theme` | `AppCompatActivity` bắt buộc theme dòng `Theme.AppCompat.*` hoặc `Theme.MaterialComponents.*` |
| Sed hàng loạt sửa `slotIndex` | Dùng `sed` để thêm tham số `slotIndex` vào nhiều lời gọi hàm cùng lúc — sót 1 chỗ (`setIntervalMinutes` trong `ColabLiveKeeperFeature.kt`), gây lỗi build `No value passed for parameter 'minutes'` | Sau khi sed hàng loạt, LUÔN `grep` lại toàn bộ để xác nhận không sót, không tin sed 100% |
| File upload gán sai `intent.type` | `prompt.mimeTypes` của Colab trả về `.ipynb` (PHẦN MỞ RỘNG FILE, không phải MIME type — MIME type thật luôn dạng `loại/loại-con`). Gán thẳng chuỗi này vào `intent.type` khiến `ACTION_OPEN_DOCUMENT` mở ra rồi tự huỷ ngay (`resultCode=0`, không có `data`) vì không provider nào khớp kiểu dữ liệu vô nghĩa — bug này ẩn rất lâu vì `onFilePrompt` VẪN được gọi đúng (dễ tưởng nhầm là lỗi ở tầng khác). Đã sửa: chỉ dùng mimeType nếu chứa `/` (đúng cú pháp thật), còn lại fallback `*/*` | Khi nhận dữ liệu từ trang web (mimeType, accept attribute...), LUÔN validate định dạng trước khi truyền thẳng vào Android API — không giả định trang web luôn trả đúng chuẩn |
| Kotlin shadowing `id` trong `.apply{}` | `FingerprintSpoofFeature.buildSettingsView()` gọi `AppPrefs.getBoolean(context, slotIndex, id, ...)` trực tiếp BÊN TRONG `Switch(context).apply { ... }` — `id` ở đó bị Kotlin hiểu nhầm thành `View.id` (Int, thuộc tính có sẵn của Android View) do `apply` đổi receiver, không phải `FingerprintSpoofFeature.id` (String) như ý muốn → lỗi build "Argument type mismatch: actual type is 'Int', but 'String' was expected" hàng loạt. `ColabLiveKeeperFeature`/`DownloadManagerFeature` KHÔNG dính lỗi này vì chúng gọi qua hàm bọc `isEnabled()/setEnabled()` thay vì gọi `AppPrefs` trực tiếp trong `.apply{}` | Khi viết feature mới có `buildSettingsView()`: (1) không bao giờ dùng bare `id`/`context` mơ hồ bên trong `.apply{}` của bất kỳ `View` con nào (Switch/Button/Spinner/RadioButton đều có thuộc tính `id: Int` kế thừa từ View, sẽ shadow); (2) luôn gán `val featureId = id` ra biến riêng ở đầu hàm rồi dùng biến đó xuyên suốt, hoặc gọi qua hàm bọc như 2 feature kia đã làm đúng từ đầu |
| Upload code lên GitHub | Hiểu nhầm ban đầu: tưởng không up được thư mục qua mobile browser nên định bắt tạo tay từng file — thực ra chỉ cần upload 1 file `.zip` duy nhất (chọn file đơn lẻ hoạt động bình thường trên mobile), rồi để `build.yml` tự `unzip` trong CI | Đừng phức tạp hoá quá mức khi chưa thử cách đơn giản trước |
| `build.yml` không tự cập nhật | Nhiều lần user chỉ upload lại file `.zip` mới nhưng KHÔNG sửa `build.yml` thật trong repo — Actions vẫn chạy bản `build.yml` CŨ, gây lỗi lặp lại y hệt dù code đã sửa | `.zip` và `.github/workflows/build.yml` là 2 thứ ĐỘC LẬP — sửa 1 cái không tự cập nhật cái kia. Chỉ cần nói rõ "lượt này CÓ/KHÔNG đổi build.yml" mỗi lần, đừng nhắc chung chung gây rối |
| Đường dẫn Artifact trong `build.yml` | Hardcode `app/build/outputs/apk/debug/app-debug.apk` — khi bật ABI split, tên file đổi thành `app-arm64-v8a-debug.apk`, gây lỗi "No files were found" | Dùng glob pattern (`**/*.apk`) thay vì đường dẫn cứng, kèm bước `find` chẩn đoán trước khi upload artifact |
| `ACTION_GET_CONTENT` cho file upload | Dùng để mở file picker — nghi ngờ không đáng tin cậy trên 1 số dòng máy (CAT S52) do phụ thuộc app nào có đăng ký intent-filter. Đã đổi sang `ACTION_OPEN_DOCUMENT` (đảm bảo có sẵn qua DocumentsUI hệ thống) — **CHƯA XÁC NHẬN fix có thực sự giải quyết được không**, đang chờ test |
| Quyền `POST_NOTIFICATIONS` | Chỉ khai trong Manifest, KHÔNG xin runtime — trên Android 13+, đây là quyền nguy hiểm bắt buộc xin lúc chạy, khai Manifest không đủ. App chạy được nhưng notification của Foreground Service âm thầm không hiện | Với quyền "dangerous" (list đầy đủ trong docs Android), luôn cần `ActivityCompat.requestPermissions()`, không chỉ khai Manifest |
| Play Protect chặn cài | App dùng `AccessibilityService` → bị Play Protect heuristic chặn cài (mọi APK sideload xin quyền này đều bị nghi ngờ, không phải lỗi code) | Cần tắt tạm "Scan apps with Play Protect" hoặc bật "Install unknown apps" đúng nguồn trước khi cài loại app này |
| Ước lượng % code phụ thuộc WebView | Ước đoán "~30-40%" lúc chưa đo — sau khi đo thật (`grep`) chỉ ~18% file, thấp hơn nhiều. Số liệu đoán trước khi có `BrowserEngine` bị coi là lỗi thời sau khi đã trừu tượng hoá | Luôn đo bằng `grep`/`wc` thật thay vì ước lượng khi bàn về mức độ ảnh hưởng của 1 thay đổi kiến trúc |
| Kết luận "GeckoView không cô lập được cookie" | Search lần đầu chỉ tra ở cấp `GeckoRuntime` (đúng là 1 runtime/process, không multi-instance được), KHÔNG tra ở cấp `GeckoSession` — dẫn tới khuyên bỏ hẳn GeckoView quay về WebView, SAI. API thật (`GeckoSessionSettings.Builder().contextId()`) nằm ở cấp session, tìm thấy ở lần search sau (vô tình, đang tra proxy) | Khi 1 kết luận "công nghệ X không làm được Y" dẫn tới quyết định kiến trúc lớn, PHẢI tra đủ MỌI cấp API liên quan trước khi kết luận dứt khoát, không dừng ở kết quả đầu tiên |
| `AppPrefs.getString(null, ...)` trong `GeckoRuntimeProvider.kt` | Gọi hàm yêu cầu `Context` non-null với `null` — lỗi biên dịch thật, KHÔNG THỂ BUILD. Code này do 1 AI/session khác viết (sau khi fork), không phải Claude viết ban đầu — nhưng vẫn phải audit kỹ vì đây là code đang chạy thật | Khi tiếp quản/audit code không tự viết, PHẢI đọc kỹ signature từng hàm được gọi, không giả định đúng chỉ vì "trông hợp lý" |
| Tính năng proxy/DNS-leak-protection "trông như đã làm" | `GeckoViewEngine.setupProxy()` sinh JS dùng `Services.prefs.*` — API nội bộ đặc quyền của chính Firefox (chrome-privileged), KHÔNG tồn tại trong ngữ cảnh JS thường mà `evaluateJs()` chạy vào. Lỗi `ReferenceError` bị try/catch NUỐT ÂM THẦM trong content.js, khiến UI trông như hoạt động bình thường nhưng KHÔNG che IP thật — rủi ro thật cho người dùng nếu tin tưởng nhầm | Trước khi tin 1 tính năng "đã làm", kiểm tra ĐƯỜNG ĐI THẬT của dữ liệu (ở đây: JS được eval ở ngữ cảnh nào — content script thường hay chrome-privileged), không chỉ nhìn code có "trông hợp lý" hay UI có đẹp không |
| `downloads[id]!!` ngay sau `downloads[id]?.` | `DownloadEngine.pauseDownload()`/`cancelDownload()` — nếu `id` không tồn tại, dòng `?.` an toàn nhưng dòng `!!` ngay sau đó crash NullPointerException | Khi thấy `?.` rồi `!!` trên cùng biến trong 2 dòng liền nhau, luôn nghi ngờ — nên gán ra `val` 1 lần bằng `?:  return` rồi dùng lại, không lặp lại truy cập map |
| Code mồ côi tích tụ qua nhiều phiên | `DownloadPolicyManager.kt`/`DownloadLocationPicker.kt` (311 dòng) trùng chức năng với `DownloadPolicy`/`SaveLocationDialog` đang dùng thật — có thể do nhiều AI/phiên làm việc độc lập, không biết file kia đã tồn tại | Trước khi viết class/file mới cho 1 chức năng, `grep` toàn bộ project xem đã có ai làm rồi chưa; định kỳ audit tìm code không được `FeatureRegistry`/luồng chính tham chiếu tới |

### Lượt 13 — 2 vấn đề thật: "các khe giống 1 khe" và "UA không đổi"

**Vấn đề 1 — khe không thật sự song song (Recents chỉ thấy 1, đổi khe mất khe cũ)**:
xác nhận qua tài liệu chính thức Android (`developer.android.com/guide/topics/manifest/activity-alias-element`):
`<activity-alias>` (cách 3 khe 1/2/3 đang dùng) CHỈ hỗ trợ
`enabled/exported/icon/label/name/permission/targetActivity` — KHÔNG hỗ trợ
`taskAffinity` (thuộc tính quyết định 1 Activity thuộc "task" nào, và do đó
Recents hiện bao nhiêu entry riêng biệt). Vì `taskAffinity` là thuộc tính
của chính Activity ĐÍCH (`MainActivity`), cả 3 alias TRƯỚC ĐÂY dùng CHUNG 1
taskAffinity — dù chạy 3 tiến trình khác nhau THẬT (`android:process` vẫn
hoạt động đúng trên alias), Android vẫn coi cả 3 chung 1 "task" ở tầng hệ
thống/Recents. Kết quả: đổi khe = điều hướng trong CÙNG 1 task (khe cũ bị
đẩy xuống, "biến mất" khỏi tầm nhìn), Recents chỉ hiện 1 entry dù có nhiều
tiến trình chạy ngầm thật.

Sửa: bỏ hẳn activity-alias, thay bằng 3 class RỖNG kế thừa `MainActivity`
(`MainActivitySlot1/2/3.kt`, không thêm code gì) để mỗi khe có 1 khai báo
`<activity>` THẬT riêng trong manifest — vì `taskAffinity` chỉ áp dụng được
cho `<activity>` thật, không áp dụng được cho alias. Mỗi khai báo giờ có
`android:taskAffinity` riêng (`....slot0/1/2/3`) → mỗi khe giờ là 1 task
độc lập thật, Recents sẽ hiện riêng từng khe, đổi khe không còn đẩy khe cũ
biến mất. `MainActivity` phải đổi từ `class` sang `open class` để cho phép
kế thừa (Kotlin mặc định final). `ProfileSlots.componentClassNameForSlot()`
+ `ProfilePickerActivity.openSlot()` cập nhật theo tên class mới, thêm
`FLAG_ACTIVITY_NEW_TASK` vào Intent mở khe.

**Vấn đề 2 — UA/fingerprint không đổi trên trang test**: không phải bug —
là giới hạn thật CHƯA ĐƯỢC THÔNG BÁO rõ cho người dùng. `userAgentOverride`
(header HTTP thật) và toàn bộ config fingerprint được gán CỐ ĐỊNH lúc tạo
GeckoSession (tab) — 1 tab ĐANG MỞ SẴN từ trước khi bật công tắc sẽ giữ
nguyên UA cũ dù bật/tắt/đổi hồ sơ sau đó, dù tải lại trang bao nhiêu lần
(giống hệt giới hạn của Proxy đã gặp, xem lượt 5). Thêm nữa: hồ sơ được
CACHE 1 LẦN cho cả vòng đời tiến trình khe (`GeckoViewEngine.resolveProfile()`),
nên kể cả MỞ TAB MỚI trong cùng lần chạy vẫn có thể không phản ánh thay đổi
mới nhất nếu hồ sơ đã được resolve từ trước đó trong CÙNG tiến trình. Cách
duy nhất chắc chắn áp dụng đúng thay đổi mới: ĐÓNG HẲN VÀ MỞ LẠI KHE (không
chỉ mở tab mới). Đã thêm Toast rõ ràng ở cả công tắc bật/tắt và nút "Áp
dụng Fingerprint" nói đúng yêu cầu này — trước đây hoàn toàn im lặng, khiến
tưởng tính năng bị hỏng.



- **YouTube video/playlist downloader**: dừng ở mức khảo sát. Không tự viết
  phần giải mã cipher YouTube (đây là việc reverse-engineer liên tục, YouTube
  chủ động chống, và vi phạm ToS trực tiếp — khác bản chất với việc "lách
  timeout" của Colab). Hướng đề xuất: dùng thư viện có sẵn
  **NewPipeExtractor** (Kotlin/Java thuần, nhẹ hơn yt-dlp+Python nhiều, NewPipe
  app dùng chính thư viện này) — coordinate Maven qua JitPack:
  `com.github.TeamNewPipe:NewPipeExtractor:v0.24.6` (kiểm tra version mới
  nhất). **CHƯA viết code wrapper cụ thể** vì chưa tra kỹ API chính xác
  (tên class `StreamExtractor`/`PlaylistExtractor`...), tránh đưa code sai.
- **Fork Chromium để load Chrome extension thật (kiểu Kiwi Browser)**: loại
  bỏ hẳn, không khả thi với hạ tầng build hiện có (mục 5).
- **Multi-tab thật**: xác nhận là tính năng lớn, để sau khi Colab chạy ổn
  định (theo đúng yêu cầu người dùng ưu tiên).
- **Load addon WebExtension thật** (không phải eval bridge nội bộ): đây là
  MỤC TIÊU CUỐI của việc đổi sang GeckoView, nhưng chưa bắt đầu implement —
  cần nghiên cứu thêm API cài đặt addon từ file `.xpi`/URL bên ngoài (khác
  với `ensureBuiltIn()` dùng cho eval bridge, vốn chỉ load resource đóng gói
  sẵn trong APK).

### Lượt 14 — Bug thanh địa chỉ, tự khởi động lại khi áp dụng fingerprint, đổi icon/tên, sửa lệch số khe

- **Bug thật, nghiêm trọng**: thanh địa chỉ set `inputType` nhưng KHÔNG set
  `imeOptions = IME_ACTION_GO` — bàn phím ảo gửi action KHÁC (Done/Next) với
  action mà listener đang chờ (`IME_ACTION_GO`), nên bấm Enter/nút tích trên
  bàn phím KHÔNG BAO GIỜ gọi tới `navigateToUrl()`. Đây là lỗi Android rất
  hay gặp (thiếu `imeOptions` dù đã set `inputType`). Đã sửa, kèm sửa luôn
  `inputType` thiếu `TYPE_CLASS_TEXT` (chỉ có variation flag một mình là sai
  quy ước, dù không gây lỗi rõ ràng).
- **Tự khởi động lại khe khi áp dụng fingerprint**: nút "Áp dụng Fingerprint"
  giờ tự đóng và mở lại khe ngay sau khi lưu (dùng lại đúng cơ chế
  `restartSlot` đã có ở `ProfilePickerActivity`) — không cần người dùng tự
  tắt/mở app thủ công nữa như lượt 13 yêu cầu tạm thời.
- **Đổi icon + tên hiển thị**: trước đây app KHÔNG khai báo `android:icon`
  nào cả (dùng icon mặc định "khả nghi" của Android) — đã thêm 1 icon vector
  tự vẽ (địa cầu + kinh/vĩ tuyến đơn giản, KHÔNG sao chép logo Chrome/
  Firefox/Safari nào, tránh vi phạm bản quyền/thương hiệu) làm adaptive icon
  (`minSdk 26`, không cần fallback PNG cho bản cũ hơn). Đổi tên hiển thị
  thành "AndroidCustomBrowser" theo yêu cầu.
- **Sửa lệch số khe**: `ProfileSlots.SLOT_COUNT` trước đây = 4 nhưng chỉ có
  3 khe phụ có Activity thật (`MainActivitySlot1/2/3`) — màn hình Chọn Khe
  hiện thêm 1 khe "ma" (khe 4) mà bấm vào sẽ mở NHẦM về khe 0 (rơi vào
  nhánh `else` của `componentClassNameForSlot`). Sửa `SLOT_COUNT = 3` cho
  khớp thực tế (khe 0 + 3 khe phụ = 4 khe dùng đồng thời được, không phải 5
  như UI cũ ngụ ý).

### Các yêu cầu lớn CHƯA làm (đã hỏi người dùng ưu tiên cái nào trước)

Người dùng đề cập 1 loạt tính năng UI trình duyệt còn thiếu trong cùng 1
lượt — liệt kê rõ, không lẫn với các bug đã sửa ở trên:

- **Chế độ ẩn danh (private/incognito)**: `usePrivateMode(false)` đang
  hardcode trong `GeckoViewEngine.createSession()` — CHƯA có UI/logic bật
  chế độ này. GeckoView hỗ trợ thật qua `GeckoSessionSettings.Builder().usePrivateMode(true)`.
- **Menu chuột phải/nhấn giữ link** (mở tab mới, mở ở khe khác, copy link,
  chia sẻ...): `GeckoSession.ContentDelegate.onContextMenu()` hiện đang để
  RỖNG (không làm gì) — cần implement dùng `ContextElement` (có sẵn link
  URL, loại phần tử...) + build menu Android thật.
- **Copy văn bản trên trang / copy địa chỉ URL**: chưa có nút/menu riêng
  cho việc này — GeckoView có text-selection API riêng
  (`GeckoSession.SelectionActionDelegate`) cần implement để copy được text
  trên trang, còn copy URL thanh địa chỉ chỉ cần 1 nút đơn giản hơn nhiều.
- **Giao diện quản lý tab kiểu Chrome** (lưới/thumbnail, gộp nhóm tab): tab
  bar hiện tại (thêm ở lượt 1) chỉ là 1 dải chip ngang đơn giản (tên + nút
  đóng) — không phải lưới thumbnail như Chrome, không có khái niệm "nhóm
  tab". Đây là 1 hạng mục UI lớn, không phải sửa nhỏ.
- Nút "mở tab mới" THỰC RA ĐÃ CÓ SẴN từ lượt 1 (icon `+` trên thanh công
  cụ) — không phải thiếu hoàn toàn, có thể do icon không rõ nghĩa/khó nhận
  ra nên người dùng tưởng không có.

Khối lượng 4 mục đầu (ẩn danh, context-menu link, copy text/URL, tab kiểu
Chrome) đủ lớn để cần làm riêng từng lượt, không gộp 1 lần — đã hỏi người
dùng chọn thứ tự ưu tiên trong lượt trả lời tiếp theo.

### Lượt 15 — Menu nhấn giữ link + copy URL (không hỏi ưu tiên được — người dùng không phản hồi bảng xếp hạng, tự chọn thứ tự)

- **Nhấn giữ link → menu thật**: `GeckoSession.ContentDelegate.onContextMenu()`
  trước đây để RỖNG — đã implement, hiện dialog 4 lựa chọn: Mở trong tab
  mới / Mở ở khe khác… (chọn khe, mở tiến trình khe đó kèm URL qua Intent
  extra `open_url` — `MainActivity.initServices()` đọc extra này thay cho
  `home_url` đã lưu nếu có) / Sao chép liên kết / Chia sẻ liên kết.
- **Sao chép URL hiện tại**: thêm vào menu chính.
- **Copy văn bản khi bôi đen trên trang — TIN TỐT, không cần code thêm**:
  tra mã nguồn GeckoView xác nhận chính `GeckoView` (class View) tự động
  gán `BasicSelectionActionDelegate` — bản triển khai copy/cut/share có sẵn
  của chính Mozilla — miễn là context truyền vào là 1 Activity thật (đúng
  trường hợp app này). Nhiều khả năng tính năng này ĐÃ HOẠT ĐỘNG SẴN, người
  dùng có thể chưa thử — không implement `SelectionActionDelegate` riêng để
  tránh trùng/xung đột với cơ chế mặc định.
- **Chế độ ẩn danh + giao diện tab kiểu Chrome (lưới/gộp nhóm)**: CHƯA làm
  — 2 việc còn lại trong danh sách lượt 14, cần 1 lượt riêng.

### Lượt 16 — Bug "Mở ở khe khác" khi khe đích đã mở sẵn, làm rõ cô lập, thêm lưới tab kiểu Chrome

- **Bug thật**: `MainActivity` dùng `launchMode="singleTask"` — nếu khe đích
  của "Mở ở khe khác" ĐÃ ĐANG CHẠY SẴN, Android gọi `onNewIntent()` thay vì
  `onCreate()` lại, nhưng hàm này chưa từng được override — extra
  `open_url` bị rơi mất âm thầm, khe đích chỉ hiện ra mà KHÔNG mở link. Đã
  thêm `onNewIntent()` xử lý đúng.
- **Làm rõ cô lập (người dùng hỏi trực tiếp)**: "Mở ở khe khác" chỉ truyền
  1 chuỗi URL qua Intent — KHÔNG mang theo fingerprint/cookie/session nào,
  khe đích tự đọc cấu hình CỦA CHÍNH NÓ (namespace theo `slotIndex` riêng
  trong AppPrefs). Không có đường nào để dữ liệu 2 khe trộn lẫn qua thao
  tác này. NHƯNG: "profile" (tên đặt ở màn hình Chọn Khe qua
  `ProfileSlots.addProfile/setSlotAssignment`) hiện chỉ là NHÃN HIỂN THỊ —
  không gắn với dữ liệu thật. Cô lập thật gắn cứng theo SỐ KHE (0-3), không
  theo tên profile — đổi tên gán cho khe không mang theo cookie/fingerprint
  cũ. Muốn "profile" thật sự di động (độc lập khỏi số khe) cần đổi kiến
  trúc lưu trữ (AppPrefs/thư mục Gecko/proxy) sang khoá theo ID profile
  thay vì slotIndex — CHƯA làm, việc lớn, cần xác nhận nhu cầu thật trước.
- **Lưới quản lý tab kiểu Chrome**: thêm nút "N" cạnh nút + trên thanh công
  cụ, bấm mở lưới 2 cột (thẻ tiêu đề+URL+nút đóng mỗi tab, thẻ "+" để mở tab
  mới), chạm thẻ để chuyển tab. Dải chip ngang cũ (lượt 1) vẫn giữ nguyên
  song song, không thay thế — tránh phá vỡ luồng đang dùng được.
  **CHƯA làm**: gộp nhóm tab theo màu như Chrome thật (feature riêng, phức
  tạp hơn nhiều, chưa có yêu cầu rõ ràng cần tới mức đó).
- **Chế độ ẩn danh**: vẫn CHƯA làm (còn lại từ lượt 14).




1. Sửa code trong dự án này.
2. Đóng gói `zip -r colab-live-browser-project.zip colab-live-browser`.
3. Upload `.zip` này vào **gốc repo GitHub** (Add file → Upload files, chọn
   1 file, hoạt động bình thường trên mobile).
4. **CHỈ KHI có sửa `.github/workflows/build.yml`**: phải sửa TAY file đó
   thật trong repo (Edit trực tiếp trên GitHub), zip không tự cập nhật nó.
5. Tab Actions tự chạy (push) hoặc bấm "Run workflow" thủ công
   (`workflow_dispatch`).
6. Tải APK từ mục Artifacts sau khi build xong.
7. Cài trên điện thoại — có thể cần tắt tạm Play Protect / bật "Install
   unknown apps" (mục 5).

### Lượt 17 — SỬA ĐÚNG KIẾN TRÚC GỐC: cô lập theo HỒ SƠ, không theo số khe (như hồ sơ trình duyệt PC)

Người dùng chỉ ra đúng: tài liệu GỐC (mục 2.4, viết từ trước khi tôi tham
gia) đã ghi rõ ý định ban đầu — "gán profile (tên tự đặt, không giới hạn
số lượng) vào khe" — nghĩa là hồ sơ phải là thực thể ĐỘC LẬP, DI ĐỘNG được
giữa các khe (giống hồ sơ Chrome/Firefox trên PC — chọn hồ sơ nào thì
"lắp" vào 1 cửa sổ để chạy), khe chỉ là "chỗ chạy" tạm thời. Tất cả các
lượt trước (1-16) đều lỡ hiện thực hoá SAI hướng: cô lập (AppPrefs, thư mục
hồ sơ Gecko, contextId, proxy, fingerprint) đều gắn CỨNG vào SỐ KHE cố định
(0-3) — "tên profile" trước đó chỉ là nhãn hiển thị, đổi gán không mang
theo dữ liệu gì cả.

**KHÔNG phải công cốc** — sửa được bằng cách đổi ĐÚNG 1 điểm trung tâm:

- **`AppPrefs.kt`** (điểm mấu chốt — MỌI cấu hình trong app đều đi qua đây):
  thêm hàm `namespace(context, slotIndex)` dịch "số khe" →
  "tên hồ sơ đang gán cho khe đó" (`ProfileSlots.getSlotAssignment`), rồi
  đổi MỌI key lưu trữ từ `"${slotIndex}_$key"` sang `"${namespace}_$key"`.
  Vì đây là 1 điểm trung tâm duy nhất, TOÀN BỘ hàng trăm chỗ gọi
  `AppPrefs.getXxx/setXxx(context, slotIndex, ...)` khắp app (fingerprint,
  proxy, home_url, download policy...) tự động chuyển sang cô lập-theo-hồ-sơ
  mà KHÔNG cần sửa gì thêm ở nơi gọi.
- **`GeckoRuntimeProvider.kt`**: thư mục hồ sơ Gecko vật lý (`-profile`) đổi
  tên theo hồ sơ đang gán thay vì số khe (có sanitize ký tự an toàn cho tên
  thư mục, vì tên hồ sơ do người dùng tự gõ).
- **`GeckoViewEngine.kt`**: `contextId` (lớp cô lập cookie/storage thứ 2)
  cũng đổi theo hồ sơ đang gán.
- **Bug nguy hiểm suýt gây leak thật đã CHẶN TRƯỚC KHI XẢY RA**: bản thân
  `ProfileSlots.getSlotAssignment()` TRƯỚC ĐÓ mặc định trả về CÙNG 1 chuỗi
  `"Mặc định"` cho MỌI khe chưa gán tên — nếu đổi AppPrefs sang khoá theo
  cái này NGAY mà không sửa trước, 4 khe chưa từng đặt tên sẽ NGAY LẬP TỨC
  gộp chung 1 namespace (đúng kiểu leak người dùng lo ngại). Đã sửa TRƯỚC:
  mỗi khe chưa gán giờ có namespace nội bộ RIÊNG BIỆT
  (`__slot_default_N`), hành vi mặc định (chưa ai đặt tên gì) giữ NGUYÊN
  cô lập như trước — chỉ khi người dùng CHỦ ĐỘNG tạo + gán 1 hồ sơ có tên
  thì cơ chế "di động theo hồ sơ" mới thật sự phát huy.
- **`ProfilePickerActivity.kt`**: thêm nút "Bỏ gán" (trả khe về namespace
  riêng của chính nó), sửa hiển thị dùng `getSlotAssignmentDisplay()` (che
  chuỗi nội bộ `__slot_default_N`, không hiện ra UI).

**Hành vi giờ đúng như PC**: tạo hồ sơ "Khách hàng A" → gán vào khe 1 → toàn
bộ cookie/fingerprint/proxy/hồ sơ Gecko của khe 1 giờ thuộc VỀ "Khách hàng
A", không phải "thuộc về khe 1". Đổi gán khe 1 sang hồ sơ "Khách hàng B" →
dữ liệu "Khách hàng A" KHÔNG bị xoá, vẫn nằm nguyên trên đĩa dưới tên
"Khách hàng A" — gán "Khách hàng A" vào khe 2 sau này sẽ load lại ĐÚNG dữ
liệu cũ đó, dù đang ở khe khác. Đây chính là cơ chế profile độc lập-di
động như trình duyệt PC mà tài liệu gốc yêu cầu.

⚠️ **Chưa build thử lại sau thay đổi này** — đây là thay đổi tương đối lớn,
cần build + test thật trên thiết bị để xác nhận (đặc biệt: tạo 2 hồ sơ, gán
vào 2 khe khác nhau, xác nhận cookie/fingerprint KHÔNG lẫn qua Cookie Leak
Test có sẵn).



- Asus Zenfone 8 (ZenUI, gần Android gốc)
- Sharp/CAT S52 (Bullitt Group, rugged, gần Android gốc, đôi khi thiếu 1 số
  app Google mặc định — có thể là nguyên nhân file picker không đáng tin cậy)

## 9. Ghi chú pháp lý/đạo đức đã bàn (không lặp lại cảnh báo dài dòng)

- Việc giữ phiên Colab "sống" khi không thực sự tính toán có thể vi phạm ToS
  của Google Colab (họ có thể hạn chế quota GPU/TPU miễn phí nếu phát hiện).
  Người dùng đã được thông báo, tự quyết định rủi ro.
- Google chủ động chặn đăng nhập từ trình duyệt nhúng "lạ" (embedded browser
  detection) — đây là biện pháp bảo mật thật của Google, không phải bug của
  app này, không có cách nào đảm bảo vượt qua được 100%.
