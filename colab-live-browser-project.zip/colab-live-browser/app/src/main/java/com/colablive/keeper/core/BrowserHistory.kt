package com.colablive.keeper.core

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * LỊCH SỬ DUYỆT WEB — tính năng thiếu thật (người dùng yêu cầu làm). Cố
 * tình KHÔNG dùng `GeckoSession.HistoryDelegate`/API lịch sử "chính chủ"
 * của GeckoView — không có mạng để tra đúng chữ ký hàm, đoán sai dễ gãy
 * build (bài học từ vụ MediaSession trước đây). Thay vào đó ghi lịch sử
 * bằng chính 2 hook ĐÃ CHẮC CHẮN hoạt động ổn định từ trước tới giờ trong
 * toàn app: `onPageLoadedListener` (biết URL vừa tải xong) và
 * `onTitleChangedListener` (biết tiêu đề trang, đến sau URL 1 chút) — xem
 * `GeckoViewEngine`/`MainActivity`.
 *
 * Lưu NGAY TRONG thư mục hồ sơ Gecko (giống `saved_tabs.json`) — đi theo
 * hồ sơ đúng như người dùng từng hỏi ("lịch sử có đi theo hồ sơ được
 * không"). Giới hạn tối đa [MAX_ENTRIES] mục, tự cắt bớt mục cũ nhất — bài
 * học từ bug "cache phình vô hạn" (mục 8s trong PROJECT_STATUS.md), không
 * lặp lại. Ghi trên LUỒNG NỀN (caller tự lo, xem `recordVisit`/
 * `updateTitle`) — bài học từ bug "chặn UI thread" (mục 8t).
 *
 * Tách thành object riêng (không nhét thẳng vào GeckoViewEngine) để
 * `HistoryActivity` đọc/xoá được mà không cần 1 GeckoViewEngine đang sống
 * — chỉ cần biết `slotIndex` để suy ra đúng hồ sơ, giống cách
 * `ProfileSlots`/`AppPrefs` đã làm.
 */
object BrowserHistory {
    private const val MAX_ENTRIES = 3000
    private val lock = Any()

    private fun safeDirNameFor(namespace: String) =
        "gecko_profile_" + namespace.replace(Regex("[^a-zA-Z0-9_-]"), "_")

    private fun historyFile(context: Context, slotIndex: Int): File {
        val profileNamespace = ProfileSlots.getSlotAssignment(context, slotIndex)
        val dir = File(context.filesDir, safeDirNameFor(profileNamespace))
        dir.mkdirs()
        return File(dir, "history.json")
    }

    private fun readArray(context: Context, slotIndex: Int): JSONArray {
        val f = historyFile(context, slotIndex)
        if (!f.exists()) return JSONArray()
        return try { JSONArray(f.readText()) } catch (e: Exception) { JSONArray() }
    }

    private fun writeArray(context: Context, slotIndex: Int, arr: JSONArray) {
        val f = historyFile(context, slotIndex)
        val tmp = File(f.parentFile, "history.json.tmp")
        tmp.writeText(arr.toString())
        tmp.renameTo(f)
    }

    /** Gọi khi 1 trang tải xong. CHẠY ĐỒNG BỘ trên luồng gọi — caller tự
     * gọi từ luồng nền nếu cần (xem `GeckoViewEngine.recordHistoryVisit`,
     * hàm đó đã tự bọc Thread sẵn). */
    fun recordVisit(context: Context, slotIndex: Int, url: String) {
        // BUG THẬT tự phát hiện khi thêm trang "Tab mới" (NewTabPage.kt):
        // trang đó là `file:///android_asset/new_tab/index.html?shortcuts=
        // <json dài, khác nhau mỗi lần>` — nếu không loại trừ ở đây, MỖI
        // LẦN bấm "Tab mới" sẽ ghi thêm 1 dòng lịch sử xấu xí (không phải
        // trang người dùng thật sự ghé), làm rác `HistoryActivity` và
        // chiếm dần chỗ trong giới hạn `MAX_ENTRIES` của lịch sử THẬT.
        // Loại trừ thêm `resource:` (trang "Tab mới" thật sự dùng
        // `resource://android/assets/...` — xem chú thích ở NewTabPage.kt
        // giải thích vì sao KHÔNG PHẢI `file:///android_asset/...`) và giữ
        // luôn `file:` phòng hờ — không có trang nội bộ hợp lệ nào khác
        // dùng 2 scheme này.
        // `colablive:` (mục 91) là điều hướng giả để trang "Tab mới" báo
        // lại việc thêm/xoá shortcut cho app — luôn bị deny ở
        // onLoadRequest nên thực ra không có cơ hội chạy tới đây, nhưng
        // vẫn loại trừ tường minh cho chắc (rẻ, không hại gì).
        if (url.isBlank() || url.startsWith("about:") || url.startsWith("data:") ||
            url.startsWith("file:") || url.startsWith("resource:") || url.startsWith("colablive:")) return
        synchronized(lock) {
            try {
                val arr = readArray(context, slotIndex)
                arr.put(JSONObject().apply {
                    put("url", url)
                    put("title", "")
                    put("time", System.currentTimeMillis())
                })
                val trimmed = if (arr.length() > MAX_ENTRIES) {
                    JSONArray().also {
                        for (i in (arr.length() - MAX_ENTRIES) until arr.length()) it.put(arr.get(i))
                    }
                } else arr
                writeArray(context, slotIndex, trimmed)
            } catch (e: Exception) {
                DebugLog.log("BrowserHistory.recordVisit lỗi: ${e.message}")
            }
        }
    }

    /** Cập nhật tiêu đề cho lượt ghé thăm GẦN NHẤT khớp URL (tiêu đề trang
     * thường đến SAU URL 1 chút qua sự kiện riêng). */
    fun updateTitle(context: Context, slotIndex: Int, url: String, title: String) {
        if (url.isBlank() || title.isBlank()) return
        synchronized(lock) {
            try {
                val arr = readArray(context, slotIndex)
                for (i in arr.length() - 1 downTo 0) {
                    val obj = arr.getJSONObject(i)
                    if (obj.optString("url") == url) {
                        obj.put("title", title)
                        break
                    }
                }
                writeArray(context, slotIndex, arr)
            } catch (e: Exception) {
                DebugLog.log("BrowserHistory.updateTitle lỗi: ${e.message}")
            }
        }
    }

    data class Entry(val url: String, val title: String, val time: Long)

    /** MỚI NHẤT TRƯỚC. Đọc file — gọi trên luồng nền nếu lịch sử lớn (xem
     * `HistoryActivity`). */
    fun readEntries(context: Context, slotIndex: Int): List<Entry> {
        return try {
            synchronized(lock) {
                val arr = readArray(context, slotIndex)
                (0 until arr.length()).map {
                    val o = arr.getJSONObject(it)
                    Entry(o.optString("url"), o.optString("title"), o.optLong("time"))
                }.reversed()
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun clear(context: Context, slotIndex: Int) {
        synchronized(lock) {
            try { historyFile(context, slotIndex).delete() } catch (e: Exception) { /* không có gì để xoá */ }
        }
    }

    /**
     * BUG THẬT (tự phát hiện, đã tránh lúc viết `HistoryActivity`): "xoá 1
     * mục" nếu làm kiểu xoá hết rồi gọi lại `recordVisit()` cho từng mục
     * còn lại thì SẼ HỎNG — `recordVisit()` luôn đặt `title=""` và
     * `time=lúc gọi`, ghi đè mất tiêu đề + thời gian THẬT của mọi mục
     * khác. Hàm này xoá ĐÚNG 1 mục trực tiếp trong JSON, giữ nguyên mọi
     * trường của các mục còn lại.
     */
    fun deleteEntry(context: Context, slotIndex: Int, url: String, time: Long) {
        synchronized(lock) {
            try {
                val arr = readArray(context, slotIndex)
                val kept = JSONArray()
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    if (obj.optString("url") == url && obj.optLong("time") == time) continue
                    kept.put(obj)
                }
                writeArray(context, slotIndex, kept)
            } catch (e: Exception) {
                DebugLog.log("BrowserHistory.deleteEntry lỗi: ${e.message}")
            }
        }
    }
}
