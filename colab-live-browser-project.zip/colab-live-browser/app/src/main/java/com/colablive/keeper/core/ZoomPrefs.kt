package com.colablive.keeper.core

import android.content.Context
import android.net.Uri

/**
 * Lưu mức "Thu phóng" THEO TÊN MIỀN (domain), không phải theo tab —
 * người dùng chỉ đúng: lưu theo tab thì đóng tab là mất, phải chỉnh lại
 * từ đầu mỗi lần mở lại trang đó — không giống cách Chrome thật nhớ zoom
 * theo từng trang web, còn nguyên dù đóng hết tab/khởi động lại app.
 *
 * Dùng `AppPrefs` (đã khoá đúng theo TÊN HỒ SƠ, không phải số khe — xác
 * nhận ở PROJECT_STATUS.md mục 8zzh) — key riêng theo domain, chỉ lưu khi
 * khác 100% (mặc định) để không phình `AppPrefs` với hàng trăm domain
 * chưa từng chỉnh zoom.
 */
object ZoomPrefs {
    private fun keyFor(host: String) = "zoom_${host.lowercase()}"

    fun getZoomForUrl(context: Context, slotIndex: Int, url: String): Int {
        val host = hostOf(url) ?: return 100
        return AppPrefs.getInt(context, slotIndex, keyFor(host), 100)
    }

    fun setZoomForUrl(context: Context, slotIndex: Int, url: String, percent: Int) {
        val host = hostOf(url) ?: return
        AppPrefs.setInt(context, slotIndex, keyFor(host), percent)
    }

    /**
     * FIX (PDF chẩn đoán): YouTube nhảy qua lại giữa m.youtube.com và
     * www.youtube.com liên tục (xác nhận qua log). Nếu zoom lưu lúc ở
     * m.youtube.com thì khi trang chuyển sang www.youtube.com → tra key
     * khác → ra mặc định 100%, mất zoom. Sửa: chuẩn hóa mọi subdomain
     * của youtube.com về "youtube.com" để dùng 1 key duy nhất.
     * Tương tự với google.com (google.com/m.google.com), v.v. nếu cần sau.
     */
    private fun hostOf(url: String): String? = try {
        val raw = Uri.parse(url).host?.takeIf { it.isNotBlank() } ?: return null
        normalizeHost(raw)
    } catch (e: Exception) {
        null
    }

    private fun normalizeHost(host: String): String {
        val lower = host.lowercase()
        // Chuẩn hóa tất cả subdomain của các domain có SPA navigation
        // phổ biến về root domain để zoom nhất quán
        return when {
            lower.endsWith(".youtube.com") -> "youtube.com"
            lower.endsWith(".google.com")  -> "google.com"
            lower.endsWith(".github.com")  -> "github.com"
            else -> lower
        }
    }
}
