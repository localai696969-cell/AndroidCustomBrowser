package com.colablive.keeper

/**
 * 3 class RỖNG kế thừa MainActivity — không thêm code gì cả, chỉ tồn tại để
 * mỗi khe có 1 TÊN CLASS RIÊNG khai báo <activity> thật trong manifest (thay
 * cho activity-alias cũ, vốn không hỗ trợ taskAffinity — xem giải thích chi
 * tiết trong AndroidManifest.xml và PROJECT_STATUS.md). MainActivity.onCreate()
 * đã tự xác định đúng khe qua tên tiến trình thật (ProfileSlots.getCurrentSlotIndex),
 * không dựa vào việc đang chạy qua class con nào — nên các class này không
 * cần override gì cả.
 */
class MainActivitySlot1 : MainActivity()
class MainActivitySlot2 : MainActivity()
class MainActivitySlot3 : MainActivity()
