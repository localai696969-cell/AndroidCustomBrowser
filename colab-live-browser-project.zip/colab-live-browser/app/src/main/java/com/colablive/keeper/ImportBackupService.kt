package com.colablive.keeper

import android.app.*
import android.content.*
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.colablive.keeper.core.DebugLog
import com.colablive.keeper.core.ProfileExportImport

/**
 * BUG THẬT tìm ra (người dùng báo đúng: "ghi đè profile như làm cảnh,
 * không thấy tác dụng gì" — log xác nhận: sau dòng "openInputStream()
 * THÀNH CÔNG, bắt đầu giải nén..." KHÔNG CÒN dòng log nào khác của
 * `importProfile()` (không "giải nén XONG", không "HOÀN TẤT", không lỗi)
 * trước khi TOÀN BỘ tiến trình app khởi động lại từ đầu — đúng dấu hiệu
 * tiến trình bị HỆ THỐNG GIẾT GIỮA CHỪNG lúc đang giải nén).
 *
 * Đối chiếu `ExportBackupService.kt` (đã tự sửa đúng bug HỆT NHƯ THẾ NÀY
 * cho chiều XUẤT hồ sơ — comment gốc ở đó giải thích rất rõ): `doImportActual()`
 * (`ProfilePickerActivity.kt`) TRƯỚC ĐÂY chạy việc giải nén trên 1
 * `Thread` TRẦN bên trong Activity — KHÔNG có gì bảo vệ khỏi bị hệ thống
 * giết tiến trình giữa chừng. Việc NHẬP còn dễ bị giết HƠN việc XUẤT: nó
 * LUÔN chạy NGAY SAU bước đóng hẳn 1 khe (`closeSlotGracefullyThen`) —
 * đúng khoảnh khắc tiến trình có ÍT hoạt động/activity hiển thị nhất
 * (activity của khe vừa đóng vừa `finish()`), dễ bị hệ thống coi là "nền,
 * có thể giết" hơn bất kỳ lúc nào khác.
 *
 * SỬA ĐÚNG GỐC (giống hệt pattern đã kiểm chứng ở `ExportBackupService`,
 * không phát minh cơ chế mới): chạy `importProfile()` bên trong 1
 * Foreground Service thật — Android KHÔNG được phép giết tiến trình đang
 * có foreground service hoạt động.
 */
class ImportBackupService : Service() {

    companion object {
        const val CHANNEL_ID = "live_browser_import"
        const val NOTIFICATION_ID = 3001
        const val ACTION_START = "com.colablive.keeper.IMPORT_START"
        const val ACTION_IMPORT_DONE = "com.colablive.keeper.IMPORT_DONE"
        const val EXTRA_PROFILE_NAME = "profile_name"
        const val EXTRA_SRC_URI = "src_uri"
        const val EXTRA_OVERWRITE = "overwrite"
        const val EXTRA_SUCCESS = "success"
        const val EXTRA_ERROR = "error"

        fun start(context: Context, profileName: String, srcUri: Uri, overwrite: Boolean) {
            val intent = Intent(context, ImportBackupService::class.java).apply {
                action = ACTION_START
                putExtra(EXTRA_PROFILE_NAME, profileName)
                putExtra(EXTRA_SRC_URI, srcUri)
                putExtra(EXTRA_OVERWRITE, overwrite)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }
    }

    private var wakeLock: PowerManager.WakeLock? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val name = intent?.getStringExtra(EXTRA_PROFILE_NAME)
        val uri: Uri? = intent?.getParcelableExtra(EXTRA_SRC_URI)
        val overwrite = intent?.getBooleanExtra(EXTRA_OVERWRITE, false) ?: false
        if (intent?.action != ACTION_START || name == null || uri == null) {
            DebugLog.log("ImportBackupService: thiếu action/extra hợp lệ (action=${intent?.action}, name=$name, uri=$uri) — dừng ngay")
            stopSelf(startId)
            return START_NOT_STICKY
        }

        startForeground(NOTIFICATION_ID, buildNotification(name))
        DebugLog.log("ImportBackupService: startForeground() ĐÃ GỌI XONG cho profile '$name' (overwrite=$overwrite) — process được bảo vệ khỏi bị hệ thống giết từ đây")

        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "LiveBrowser::ImportBackup").apply {
            setReferenceCounted(false)
            acquire(15 * 60 * 1000L)
        }
        DebugLog.log("ImportBackupService: WakeLock đã acquire (isHeld=${wakeLock?.isHeld})")

        Thread {
            DebugLog.log("ImportBackupService: Thread nền BẮT ĐẦU gọi importProfile()")
            val result = try {
                ProfileExportImport.importProfile(this, uri, name, overwrite)
            } catch (e: Exception) {
                DebugLog.log("ImportBackupService: importProfile() ném exception KHÔNG ĐƯỢC BẮT bên trong nó: ${e.javaClass.simpleName}: ${e.message}")
                Result.failure<Unit>(e)
            } finally {
                try { wakeLock?.let { if (it.isHeld) it.release() } } catch (e: Exception) { /* bỏ qua */ }
            }
            Handler(Looper.getMainLooper()).post {
                DebugLog.log("ImportBackupService: importProfile() ĐÃ TRẢ VỀ (success=${result.isSuccess}, error=${result.exceptionOrNull()?.message}) — gửi broadcast, dừng foreground service ngay sau đây")
                sendBroadcast(Intent(ACTION_IMPORT_DONE).apply {
                    setPackage(packageName)
                    putExtra(EXTRA_PROFILE_NAME, name)
                    putExtra(EXTRA_SUCCESS, result.isSuccess)
                    putExtra(EXTRA_ERROR, result.exceptionOrNull()?.message)
                })
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf(startId)
            }
        }.start()

        return START_NOT_STICKY
    }

    private fun buildNotification(profileName: String): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("📥 Đang nhập hồ sơ '$profileName'...")
            .setContentText("Giữ ứng dụng chạy nền, không tắt để tránh mất dữ liệu")
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Nhập hồ sơ", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Hiện khi đang giải nén file zip vào hồ sơ"
                setShowBadge(false)
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        // Cùng lý do/cách chẩn đoán như ExportBackupService.onDestroy() —
        // nếu KHÔNG thấy dòng "importProfile() ĐÃ TRẢ VỀ" ngay trước đó,
        // xác nhận chắc chắn service (và cả import) đã bị hệ thống giết
        // giữa chừng, không phải do code import tự dừng.
        DebugLog.log("ImportBackupService: onDestroy() được gọi (bình thường là do tự stopSelf() sau khi xong; nếu KHÔNG thấy dòng 'importProfile() ĐÃ TRẢ VỀ' ngay trước đó — service đã bị HỆ THỐNG GIẾT GIỮA CHỪNG)")
        wakeLock?.let { if (it.isHeld) it.release() }
        super.onDestroy()
    }
}
