package com.colablive.keeper

import android.app.*
import android.content.*
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.colablive.keeper.core.DebugLog
import com.colablive.keeper.core.ProfileExportImport

/**
 * BUG THẬT tìm ra (người dùng báo đúng: "ghi đè profile như làm cảnh,
 * không thấy tác dụng gì" — log xác nhận: sau dòng "openInputStream()
 * THÀNH CÔNG, bắt đầu giải nén..." KHÔNG CÒN dòng log nào khác của
 * `importProfile()` (không "giải nén XONG", không "HOÀN TẤT", không lỗi)
 * trước khi TOÀN BỘ tiến trình app khởi động lại từ đầu — đúng dấu hiệu
 * tiến trình bị HỆ THỐNG GIẾT GIỮA CHỪNG lúc đang giải nén).
 *
 * Đối chiếu `ExportBackupService.kt` (đã tự sửa đúng bug HỆT NHƯ THẾ NÀY
 * cho chiều XUẤT hồ sơ — comment gốc ở đó giải thích rất rõ): `doImportActual()`
 * (`ProfilePickerActivity.kt`) TRƯỚC ĐÂY chạy việc giải nén trên 1
 * `Thread` TRẦN bên trong Activity — KHÔNG có gì bảo vệ khỏi bị hệ thống
 * giết tiến trình giữa chừng. Việc NHẬP còn dễ bị giết HƠN việc XUẤT: nó
 * LUÔN chạy NGAY SAU bước đóng hẳn 1 khe (`closeSlotGracefullyThen`) —
 * đúng khoảnh khắc tiến trình có ÍT hoạt động/activity hiển thị nhất
 * (activity của khe vừa đóng vừa `finish()`), dễ bị hệ thống coi là "nền,
 * có thể giết" hơn bất kỳ lúc nào khác.
 *
 * SỬA ĐÚNG GỐC (giống hệt pattern đã kiểm chứng ở `ExportBackupService`,
 * không phát minh cơ chế mới): chạy `importProfile()` bên trong 1
 * Foreground Service thật — Android KHÔNG được phép giết tiến trình đang
 * có foreground service hoạt động.
 */
class ImportBackupService : Service() {

    companion object {
        const val CHANNEL_ID = "live_browser_import"
        const val NOTIFICATION_ID = 3001
        const val ACTION_START = "com.colablive.keeper.IMPORT_START"
        const val ACTION_IMPORT_DONE = "com.colablive.keeper.IMPORT_DONE"
        const val EXTRA_PROFILE_NAME = "profile_name"
        const val EXTRA_SRC_URI = "src_uri"
        const val EXTRA_OVERWRITE = "overwrite"
        const val EXTRA_SUCCESS = "success"
        const val EXTRA_ERROR = "error"

        // LỚP PHÒNG THỦ THỨ HAI (đã xác nhận cần thiết qua crash thật —
        // log cho thấy 11 luồng import CÙNG 1 tên hồ sơ chạy CHỒNG LÊN
        // NHAU trong ~13 giây, đua nhau đọc/ghi/xoá CÙNG thư mục tạm, gây
        // AssertionError trong deleteRecursively()). Lớp phòng thủ THỨ
        // NHẤT (vô hiệu hoá nút ngay khi bấm, xem ProfilePickerActivity)
        // chặn được nguồn gốc UI — nhưng lớp này chặn THEO TÊN HỒ SƠ ở
        // đúng tầng service, không phụ thuộc lời gọi tới từ đâu, phòng
        // trường hợp còn đường gọi nào khác chưa lường hết.
        private val profilesCurrentlyImporting = java.util.Collections.synchronizedSet(mutableSetOf<String>())

        fun start(context: Context, profileName: String, srcUri: Uri, overwrite: Boolean) {
            // FIX (race window URI SAF): trước đây Intent này KHÔNG có cờ
            // FLAG_GRANT_READ_URI_PERMISSION. Uri lấy từ ACTION_OPEN_DOCUMENT
            // trong ProfilePickerActivity CHỈ được cấp quyền đọc cho CHÍNH
            // activity đó — theo tài liệu Android chính thức (Storage Access
            // Framework), quyền này KHÔNG tự động lan sang component khác
            // (ở đây là Service) khi chỉ truyền Uri qua putExtra() thường.
            // Phải khai báo tường minh FLAG_GRANT_READ_URI_PERMISSION trên
            // đúng Intent dùng để khởi động Service thì quyền mới được cấp
            // cho Service đó (còn hiệu lực tới khi service kết thúc).
            // Trước đây việc "ghi đè hồ sơ đang chạy" mất tới ~2s chờ
            // closeSlotGracefullyThen() đóng khe xong mới gọi start() —
            // khoảng chờ này làm tăng khả năng activity gốc bị hệ thống dọn
            // dẹp/mất giữ tham chiếu quyền trước khi Service kịp
            // openInputStream(), dẫn tới SecurityException ném ra giữa lúc
            // đang đọc dữ liệu — đúng lúc log "biến mất" được quan sát.
            val intent = Intent(context, ImportBackupService::class.java).apply {
                action = ACTION_START
                putExtra(EXTRA_PROFILE_NAME, profileName)
                putExtra(EXTRA_SRC_URI, srcUri)
                putExtra(EXTRA_OVERWRITE, overwrite)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            // Cấp quyền tường minh thêm 1 lớp nữa (grantUriPermission trực
            // tiếp tới package của chính app) — phòng trường hợp 1 số ROM/
            // DocumentsProvider của app quản lý file bên thứ 3 (ví dụ log
            // đã thấy content://com.cxinventor.file.explorer.fileprovider/...)
            // không xử lý đúng cờ Intent ở trên.
            try {
                context.grantUriPermission(context.packageName, srcUri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e: SecurityException) {
                DebugLog.log("ImportBackupService.start(): grantUriPermission() lỗi (${e.message}) — vẫn tiếp tục, dựa vào cờ Intent")
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }
    }

    private var wakeLock: PowerManager.WakeLock? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val name = intent?.getStringExtra(EXTRA_PROFILE_NAME)
        val uri: Uri? = intent?.getParcelableExtra(EXTRA_SRC_URI)
        val overwrite = intent?.getBooleanExtra(EXTRA_OVERWRITE, false) ?: false
        if (intent?.action != ACTION_START || name == null || uri == null) {
            DebugLog.log("ImportBackupService: thiếu action/extra hợp lệ (action=${intent?.action}, name=$name, uri=$uri) — dừng ngay")
            stopSelf(startId)
            return START_NOT_STICKY
        }

        // LỚP PHÒNG THỦ THỨ HAI (xem chú thích đầy đủ ở companion object) —
        // chặn NGAY nếu profile này đang có 1 lượt import khác chạy dở,
        // trước khi kịp startForeground()/mở luồng nền nào cả.
        if (!profilesCurrentlyImporting.add(name)) {
            DebugLog.log("ImportBackupService: TỪ CHỐI — profile '$name' đang có 1 lượt import khác chạy dở, không cho chạy chồng lên (đây chính là nguyên nhân gốc gây crash AssertionError trong deleteRecursively() đã gặp thật)")
            sendBroadcast(Intent(ACTION_IMPORT_DONE).apply {
                setPackage(packageName)
                putExtra(EXTRA_PROFILE_NAME, name)
                putExtra(EXTRA_SUCCESS, false)
                putExtra(EXTRA_ERROR, "Đã có 1 lượt nhập hồ sơ '$name' khác đang chạy, vui lòng đợi xong")
            })
            stopSelf(startId)
            return START_NOT_STICKY
        }

        startForeground(NOTIFICATION_ID, buildNotification(name))
        DebugLog.log("ImportBackupService: startForeground() ĐÃ GỌI XONG cho profile '$name' (overwrite=$overwrite) — process được bảo vệ khỏi bị hệ thống giết từ đây")

        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "LiveBrowser::ImportBackup").apply {
            setReferenceCounted(false)
            acquire(15 * 60 * 1000L)
        }
        DebugLog.log("ImportBackupService: WakeLock đã acquire (isHeld=${wakeLock?.isHeld})")

        Thread {
            DebugLog.log("ImportBackupService: Thread nền BẮT ĐẦU gọi importProfile()")
            val result = try {
                ProfileExportImport.importProfile(this, uri, name, overwrite)
            } catch (e: Throwable) {
                // SỬA BUG THẬT gây crash (đã xảy ra thật — AssertionError
                // từ deleteRecursively() lúc 2 luồng import đua nhau xoá
                // cùng thư mục): `catch (e: Exception)` CŨ không bắt được
                // `AssertionError` vì nó là subclass của `Error`, KHÔNG
                // PHẢI `Exception` — lọt thẳng ra ngoài làm crash toàn bộ
                // tiến trình thay vì chỉ báo lỗi qua broadcast như bình
                // thường. Đổi sang `Throwable` để bắt được MỌI loại lỗi,
                // không riêng gì Exception. Lớp phòng thủ THỨ NHẤT (chặn
                // trùng tên ở trên) mới là fix GỐC ngăn race xảy ra —
                // đây chỉ là lưới an toàn CUỐI CÙNG phòng trường hợp còn
                // sót race khác chưa lường hết.
                DebugLog.log("ImportBackupService: importProfile() ném ${e.javaClass.simpleName} KHÔNG ĐƯỢC BẮT bên trong nó: ${e.message}")
                Result.failure<Unit>(Exception(e.message ?: e.javaClass.simpleName, e))
            } finally {
                try { wakeLock?.let { if (it.isHeld) it.release() } } catch (e: Exception) { /* bỏ qua */ }
                profilesCurrentlyImporting.remove(name)
            }
            Handler(Looper.getMainLooper()).post {
                DebugLog.log("ImportBackupService: importProfile() ĐÃ TRẢ VỀ (success=${result.isSuccess}, error=${result.exceptionOrNull()?.message}) — gửi broadcast, dừng foreground service ngay sau đây")
                sendBroadcast(Intent(ACTION_IMPORT_DONE).apply {
                    setPackage(packageName)
                    putExtra(EXTRA_PROFILE_NAME, name)
                    putExtra(EXTRA_SUCCESS, result.isSuccess)
                    putExtra(EXTRA_ERROR, result.exceptionOrNull()?.message)
                })
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf(startId)
            }
        }.start()

        return START_NOT_STICKY
    }

    private fun buildNotification(profileName: String): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("📥 Đang nhập hồ sơ '$profileName'...")
            .setContentText("Giữ ứng dụng chạy nền, không tắt để tránh mất dữ liệu")
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Nhập hồ sơ", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Hiện khi đang giải nén file zip vào hồ sơ"
                setShowBadge(false)
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        // Cùng lý do/cách chẩn đoán như ExportBackupService.onDestroy() —
        // nếu KHÔNG thấy dòng "importProfile() ĐÃ TRẢ VỀ" ngay trước đó,
        // xác nhận chắc chắn service (và cả import) đã bị hệ thống giết
        // giữa chừng, không phải do code import tự dừng.
        DebugLog.log("ImportBackupService: onDestroy() được gọi (bình thường là do tự stopSelf() sau khi xong; nếu KHÔNG thấy dòng 'importProfile() ĐÃ TRẢ VỀ' ngay trước đó — service đã bị HỆ THỐNG GIẾT GIỮA CHỪNG)")
        wakeLock?.let { if (it.isHeld) it.release() }
        super.onDestroy()
    }
}
