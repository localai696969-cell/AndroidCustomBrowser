package com.colablive.keeper

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Path
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.colablive.keeper.core.ForegroundState
import com.colablive.keeper.core.FeatureRegistry
import com.colablive.keeper.core.ProfileSlots

class AutoClickAccessibilityService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    private val fallbackIntervalMs = 15 * 60_000L

    @Volatile private var lastKnownUrl: String? = null
    @Volatile private var lastKnownSlotIndex: Int = 0

    private val urlReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            lastKnownUrl = intent?.getStringExtra(ForegroundState.EXTRA_URL)
            lastKnownSlotIndex = intent?.getIntExtra(ForegroundState.EXTRA_SLOT_INDEX, 0) ?: 0
        }
    }

    private val heartbeat = object : Runnable {
        override fun run() {
            scanAndTapIfNeeded()
            handler.postDelayed(this, nextIntervalMs())
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        val filter = IntentFilter(ForegroundState.ACTION_UPDATED)
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(urlReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(urlReceiver, filter)
        }
        handler.postDelayed(heartbeat, nextIntervalMs())
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        handler.removeCallbacks(heartbeat)
        runCatching { unregisterReceiver(urlReceiver) }
        super.onDestroy()
    }

    private fun matchingFeature() =
        FeatureRegistry.enabledFeatures(applicationContext, lastKnownSlotIndex).firstOrNull {
            it.matchesUrl(lastKnownUrl ?: "") &&
                it.accessibilityTargetTexts(applicationContext, lastKnownSlotIndex).isNotEmpty()
        }

    private fun nextIntervalMs(): Long =
        matchingFeature()?.let { it.intervalMinutes(applicationContext, lastKnownSlotIndex) * 60_000L }
            ?: fallbackIntervalMs

    private fun scanAndTapIfNeeded() {
        val feature = matchingFeature() ?: return
        val targets = feature.accessibilityTargetTexts(applicationContext, lastKnownSlotIndex)
        if (targets.isEmpty()) return
        bringSlotToForegroundThenTap(lastKnownSlotIndex, targets)
    }

    private fun bringSlotToForegroundThenTap(slotIndex: Int, targetTexts: List<String>) {
        val componentClassName = ProfileSlots.componentClassNameForSlot(slotIndex)
        val intent = Intent().apply {
            component = ComponentName(packageName, componentClassName)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
        }
        startActivity(intent)
        handler.postDelayed({ findAndTap(targetTexts) }, 400L)
    }

    private fun findAndTap(targetTexts: List<String>) {
        val root = rootInActiveWindow ?: return
        val node = findNodeByText(root, targetTexts) ?: return

        val bounds = Rect()
        node.getBoundsInScreen(bounds)

        if (bounds.width() > 0 && bounds.height() > 0) {
            dispatchTap(bounds.centerX().toFloat(), bounds.centerY().toFloat())
            handler.postDelayed({ performGlobalAction(GLOBAL_ACTION_BACK) }, 800L)
        } else {
            var target: AccessibilityNodeInfo? = node
            while (target != null && !target.isClickable) target = target.parent
            target?.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        }
    }

    private fun dispatchTap(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0L, 50L)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, null, null)
    }

    private fun findNodeByText(
        node: AccessibilityNodeInfo,
        texts: List<String>
    ): AccessibilityNodeInfo? {
        val nodeText = node.text?.toString() ?: node.contentDescription?.toString()
        if (nodeText != null && texts.any { nodeText.contains(it, ignoreCase = true) }) {
            return node
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = findNodeByText(child, texts)
            if (found != null) return found
        }
        return null
    }
}
