package com.colablive.keeper.features.downloads

import android.content.Context
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintManager
import android.webkit.WebView
import android.webkit.WebViewClient
import com.colablive.keeper.core.DebugLog
import java.io.File

class PageConverter(private val context: Context) {

    fun convertToPdf(htmlFile: File, outputFile: File, callback: (Boolean) -> Unit) {
        val webView = WebView(context)
        webView.loadUrl("file://${htmlFile.absolutePath}")
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                val printManager = context.getSystemService(Context.PRINT_SERVICE) as PrintManager
                val adapter = webView.createPrintDocumentAdapter("Document")
                printManager.print("PDF", adapter, PrintAttributes.Builder().build())
                callback(true)
            }
        }
    }

    fun convertToTxt(htmlFile: File, outputFile: File): Boolean {
        return try {
            val text = htmlFile.readText()
                .replace(Regex("<[^>]*>"), " ")
                .replace(Regex("\s+"), " ")
                .trim()
            outputFile.writeText(text)
            DebugLog.log("PageConverter: TXT saved to ${outputFile.absolutePath}")
            true
        } catch (e: Exception) {
            DebugLog.log("PageConverter TXT error: ${e.message}")
            false
        }
    }
}
