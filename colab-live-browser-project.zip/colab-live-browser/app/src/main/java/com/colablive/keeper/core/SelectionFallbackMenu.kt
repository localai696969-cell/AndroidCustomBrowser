package com.colablive.keeper.core

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.PixelFormat
import android.os.SystemClock
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

/**
 * FIX BUG THẬT (đã ghi chú trong PROJECT_STATUS.md mục 52.1/53.2/58: "trong
 * Colab không có menu dán/copy khi nhấn đè"): trên các trang dùng editor vẽ
 * bằng canvas hoặc DOM tuỳ biến sâu (Monaco/CodeMirror mà Colab dùng cho ô
 * code — KHÔNG phải `<textarea>`/`contenteditable` chuẩn mà Gecko theo dõi
 * qua `GeckoSession.SelectionActionDelegate`), long-press vẫn được trang tự
 * xử lý bằng JS nội bộ của nó (đặt caret, có thể tự vẽ "vùng bôi xanh") —
 * nhưng Gecko không biết có SELECTION THẬT SỰ ở cấp DOM/accessibility, nên
 * KHÔNG BAO GIỜ gọi `onShowActionRequest()` → không có custom action bar
 * (`GeckoView.ActionBarDelegateBackground` không được kích hoạt) → người
 * dùng không có cách nào Copy/Paste bằng menu hệ thống trong các ô này.
 * Log thật xác nhận: có rất nhiều dòng `onShowActionRequest`/`onHideAction`
 * trong lúc dùng claude.ai (DOM chuẩn, Gecko theo dõi được) nhưng KHÔNG một
 * dòng nào xảy ra trong lúc tương tác với các ô code của Colab.
 *
 * Đây là giới hạn thật của GeckoView (không có API "buộc" trang báo cáo
 * selection nó tự vẽ bằng canvas) — không thể sửa "cho đúng" bằng cách gọi
 * lại API Gecko nào đó. Giải pháp thực tế: tự phát hiện long-press bằng
 * touch event ở tầng Activity (không phụ thuộc trang có hợp tác hay không),
 * đợi 1 khoảng ngắn xem Gecko có tự hiện menu thật không (`engine.
 * lastSelectionActionUptime` mới cập nhật → có, bỏ qua, tránh hiện TRÙNG 2
 * menu trên các trang DOM chuẩn) — nếu không, hiện menu nổi tối giản
 * (Copy/Cut/Paste) ngay tại điểm nhấn, thao tác qua:
 *   - Copy/Cut: đọc `window.getSelection().toString()` bằng JS (Monaco vẫn
 *     cập nhật `window.getSelection()` thật dù tự vẽ giao diện, vì input
 *     thật vẫn là 1 `<textarea>` ẩn theo cơ chế chuẩn của Monaco) rồi ghi
 *     vào `ClipboardManager` của Android — không cần trang hợp tác gì thêm.
 *   - Paste: đọc clipboard Android, chèn vào bằng
 *     `document.execCommand('insertText', false, text)` sau khi đảm bảo
 *     phần tử đang có focus (Monaco luôn giữ focus ở textarea ẩn của nó khi
 *     con trỏ đang nhấp nháy trong ô code, kể cả sau long-press).
 *
 * Không cố phát hiện "đây có phải Colab hay không" bằng domain — cách này
 * tổng quát, chạy được với bất kỳ trang nào rơi vào đúng tình huống Gecko
 * không tự hiện menu (an toàn: nếu Gecko ĐÃ hiện menu thật, class này im
 * lặng không làm gì).
 *
 * THÀNH THẬT VỀ GIỚI HẠN CÒN LẠI (đối chiếu mục 68.1 PROJECT_STATUS.md,
 * tra sâu hơn TRƯỚC lượt này): Gecko không tự tạo được BẤT KỲ selection
 * nào (không chỉ thiếu menu, thiếu cả caret/handle) trên vùng Monaco tự
 * vẽ — vì Monaco render nội dung bằng các `<div>` định vị tuyệt đối theo
 * dòng/cột (không phải text node liền mạch trình duyệt hiểu là 1 đoạn văn
 * bản), nên `window.getSelection()` CÓ THỂ trả về rỗng dù mắt thường thấy
 * vùng bôi xanh do chính Monaco tự vẽ bằng CSS overlay (không phải Selection
 * API của trình duyệt). Nếu đúng vậy, nút "Sao chép/Cắt" trong menu này sẽ
 * KHÔNG hiện ra được (vì hasSelection=false) dù người dùng thấy có vùng bôi
 * xanh — đây là giới hạn thật CHƯA kiểm chứng được nếu không có máy thật,
 * không phải lỗi của class này. Ngược lại, "Dán" nhiều khả năng vẫn hoạt
 * động vì chỉ cần `document.activeElement` đúng là ô nhập của Monaco (input
 * capturetextarea của nó), không phụ thuộc Selection API. Đã thêm phương
 * án dự phòng: nếu `window.getSelection()` rỗng NHƯNG `document.activeElement`
 * là 1 ô nhập/textarea/contentEditable (khớp Monaco), vẫn hiện "Sao chép
 * tất cả dòng hiện tại" dùng `document.execCommand('selectAll')` rồi mới
 * đọc `getSelection()` lần 2 — nếu selectAll cũng không tạo ra gì, coi như
 * xác nhận thêm bằng chứng cho giả thuyết mục 68.1, không còn gì để thử
 * thêm ở tầng JS công khai.
 */
class SelectionFallbackMenu(
    private val context: Context,
    private val hostView: View,
    private val engineProvider: () -> GeckoViewEngine
) {
    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    private val handler = android.os.Handler(android.os.Looper.getMainLooper())

    private var popupView: View? = null
    private var downX = 0f
    private var downY = 0f
    private var downTime = 0L
    private var longPressPending = false
    private var moved = false

    private val LONG_PRESS_MS = 500L
    private val TOUCH_SLOP = 24f // px — nới hơn slop hệ thống 1 chút, tránh trigger nhầm khi cuộn

    private val longPressCheck = Runnable {
        if (!moved) {
            checkFallbackNeeded(downX, downY)
        }
    }

    fun onTouch(ev: MotionEvent) {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                dismiss()
                downX = ev.rawX
                downY = ev.rawY
                downTime = SystemClock.uptimeMillis()
                moved = false
                longPressPending = true
                handler.postDelayed(longPressCheck, LONG_PRESS_MS)
            }
            MotionEvent.ACTION_MOVE -> {
                if (kotlin.math.abs(ev.rawX - downX) > TOUCH_SLOP || kotlin.math.abs(ev.rawY - downY) > TOUCH_SLOP) {
                    moved = true
                    if (longPressPending) {
                        handler.removeCallbacks(longPressCheck)
                        longPressPending = false
                    }
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (longPressPending) {
                    handler.removeCallbacks(longPressCheck)
                    longPressPending = false
                }
            }
        }
    }

    private fun checkFallbackNeeded(x: Float, y: Float) {
        longPressPending = false
        val checkAtUptime = SystemClock.uptimeMillis()
        // Đợi thêm 350ms: nếu long-press này là trên DOM chuẩn, Gecko thường
        // gọi onShowActionRequest trong khoảng này. Không đợi lâu hơn để
        // tránh cảm giác trễ khi thật sự cần fallback.
        handler.postDelayed({
            val engine = engineProvider()
            val geckoHandledIt = engine.lastSelectionActionUptime >= checkAtUptime
            if (!geckoHandledIt) {
                showFallbackMenu(x, y)
            }
        }, 350L)
    }

    private fun showFallbackMenu(x: Float, y: Float) {
        val engine = engineProvider()
        // Tự kiểm có selection thật (text) không, mới quyết định hiện Copy/Cut
        // hay chỉ hiện Paste — tránh hiện menu rỗng gây khó hiểu.
        engine.evaluateJs("(function(){try{return String(window.getSelection().toString());}catch(e){return '';}})()") { result ->
            val hasSelection = !result.isNullOrEmpty() && result != "null"
            if (hasSelection) {
                handler.post { buildAndShowPopup(x, y, hasSelection = true) }
                return@evaluateJs
            }
            // Rỗng — có thể do Monaco không dùng Selection API chuẩn (mục
            // 68.1). Kiểm thêm: nếu đang focus vào ô nhập/textarea, có
            // "Chọn tất cả rồi sao chép" như phương án dự phòng — không đòi
            // hỏi phải có sẵn selection từ trước.
            engine.evaluateJs(
                """(function(){
                    var a = document.activeElement;
                    if (!a) return 'none';
                    var editable = a.isContentEditable || a.tagName==='INPUT' || a.tagName==='TEXTAREA';
                    return editable ? 'editable' : 'none';
                })()"""
            ) { editableResult ->
                handler.post {
                    buildAndShowPopup(x, y, hasSelection = false, activeElementEditable = editableResult == "editable")
                }
            }
        }
    }

    private fun buildAndShowPopup(x: Float, y: Float, hasSelection: Boolean, activeElementEditable: Boolean = false) {
        dismiss()

        val density = context.resources.displayMetrics.density
        fun dp(v: Int) = (v * density).toInt()

        val container = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(0xFF2B2B2B.toInt())
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }

        fun addItem(label: String, onClick: () -> Unit) {
            val tv = TextView(context).apply {
                text = label
                setTextColor(0xFFFFFFFF.toInt())
                textSize = 14f
                setPadding(dp(14), dp(10), dp(14), dp(10))
                setOnClickListener {
                    onClick()
                    dismiss()
                }
            }
            container.addView(tv)
        }

        if (hasSelection) {
            addItem("Sao chép") { copySelectionToClipboard() }
            addItem("Cắt") { cutSelectionToClipboard() }
        } else if (activeElementEditable) {
            // Phương án dự phòng cho Monaco/CodeMirror (xem giải thích ở đầu
            // file) — không có selection thật để biết CHÍNH XÁC người dùng
            // định chọn gì, nên chỉ đề nghị "chọn hết rồi chép" thay vì đoán.
            addItem("Chọn hết & Sao chép") { selectAllThenCopy() }
        }
        if (clipboard.hasPrimaryClip()) {
            addItem("Dán") { pasteFromClipboard() }
        }

        if (container.childCount == 0) return // không có gì để làm — không hiện menu trống

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_PANEL,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            this.x = x.toInt().coerceAtLeast(0)
            // Hiện phía TRÊN điểm nhấn 1 chút (giống menu chọn chuẩn của hệ
            // thống) để ngón tay không che mất menu vừa hiện ra.
            this.y = (y - dp(70)).toInt().coerceAtLeast(dp(24))
            token = hostView.windowToken
        }

        try {
            windowManager.addView(container, params)
            popupView = container
        } catch (e: Exception) {
            DebugLog.log("SelectionFallbackMenu: lỗi hiện popup — ${e.message}")
        }
    }

    private fun copySelectionToClipboard() {
        val engine = engineProvider()
        engine.evaluateJs("(function(){try{return String(window.getSelection().toString());}catch(e){return '';}})()") { result ->
            if (!result.isNullOrEmpty() && result != "null") {
                handler.post {
                    clipboard.setPrimaryClip(ClipData.newPlainText("colab-live-browser", result))
                }
            }
        }
    }

    private fun cutSelectionToClipboard() {
        val engine = engineProvider()
        engine.evaluateJs(
            """(function(){
                try {
                    var t = String(window.getSelection().toString());
                    if (t) { document.execCommand('delete'); }
                    return t;
                } catch(e) { return ''; }
            })()"""
        ) { result ->
            if (!result.isNullOrEmpty() && result != "null") {
                handler.post {
                    clipboard.setPrimaryClip(ClipData.newPlainText("colab-live-browser", result))
                }
            }
        }
    }

    private fun selectAllThenCopy() {
        val engine = engineProvider()
        engine.evaluateJs(
            """(function(){
                try {
                    document.execCommand('selectAll');
                    return String(window.getSelection().toString());
                } catch(e) { return ''; }
            })()"""
        ) { result ->
            if (!result.isNullOrEmpty() && result != "null") {
                handler.post {
                    clipboard.setPrimaryClip(ClipData.newPlainText("colab-live-browser", result))
                }
            } else {
                // Kết quả rỗng CẢ SAU selectAll — thêm bằng chứng thật cho
                // giả thuyết mục 68.1 (Monaco không dùng Selection API
                // chuẩn). Ghi log để lần sau có dữ liệu thật thay vì đoán.
                DebugLog.log("SelectionFallbackMenu: selectAll+copy vẫn rỗng — có thể xác nhận thêm giả thuyết mục 68.1 (Monaco không lộ selection qua Selection API chuẩn)")
            }
        }
    }

    private fun pasteFromClipboard() {
        val clip = clipboard.primaryClip ?: return
        if (clip.itemCount == 0) return
        val text = clip.getItemAt(0).coerceToText(context)?.toString() ?: return
        // JSON.stringify để escape an toàn (xuống dòng, dấu nháy...) trước khi
        // chèn vào chuỗi script — text dán có thể chứa BẤT KỲ ký tự nào.
        val jsonEscaped = org.json.JSONObject.quote(text)
        val engine = engineProvider()
        engine.evaluateJs(
            """(function(){
                try {
                    var el = document.activeElement;
                    if (!el) return 'no-active-element';
                    document.execCommand('insertText', false, $jsonEscaped);
                    return 'ok';
                } catch(e) { return 'err:' + e.message; }
            })()"""
        ) { result ->
            DebugLog.log("SelectionFallbackMenu: paste kết quả=$result")
        }
    }

    fun dismiss() {
        popupView?.let {
            try { windowManager.removeView(it) } catch (e: Exception) { /* đã bị gỡ hoặc window chết — bỏ qua */ }
        }
        popupView = null
    }
}
