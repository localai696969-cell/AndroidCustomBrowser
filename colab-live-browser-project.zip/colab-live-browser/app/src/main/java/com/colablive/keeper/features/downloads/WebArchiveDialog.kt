package com.colablive.keeper.features.downloads

import android.app.AlertDialog
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.view.*
import android.widget.*
import com.colablive.keeper.core.DebugLog
import org.mozilla.geckoview.GeckoView

/**
 * Dialog tải trang web + chuyển đổi định dạng + xem trước.
 */
class WebArchiveDialog(
    private val context: Context,
    private val url: String,
    private val title: String,
    private val geckoView: GeckoView
) {

    private val handler = Handler(Looper.getMainLooper())
    private val archiver = WebArchiver(context)
    private val converter = PageConverter(context)
    private var previewHtml: String = ""

    fun show() {
        val scrollView = ScrollView(context)
        val container = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
        }

        // Title
        container.addView(TextView(context).apply {
            text = "🌐 Lưu Trang Web"
            textSize = 20f
            setTextColor(Color.BLACK)
            setPadding(0, 0, 0, 16)
        })

        // URL
        container.addView(TextView(context).apply {
            text = url
            textSize = 12f
            setTextColor(Color.GRAY)
            setPadding(0, 0, 0, 16)
        })

        // Preview section
        container.addView(TextView(context).apply {
            text = "📸 Xem trước"
            textSize = 16f
            setTextColor(Color.BLACK)
            setPadding(0, 8, 0, 8)
        })

        val previewImage = ImageView(context).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 400)
            setBackgroundColor(Color.LTGRAY)
            scaleType = ImageView.ScaleType.CENTER_CROP
        }
        container.addView(previewImage)

        // Capture preview
        capturePreview(previewImage)

        // Format selection
        container.addView(TextView(context).apply {
            text = "📦 Chọn định dạng lưu:"
            textSize = 16f
            setTextColor(Color.BLACK)
            setPadding(0, 16, 0, 8)
        })

        // Format options
        val formatGroup = RadioGroup(context).apply {
            orientation = RadioGroup.VERTICAL
        }

        val formats = listOf(
            "html_full" to "📁 HTML đầy đủ (HTML + CSS + JS + Ảnh riêng)",
            "html_single" to "📄 HTML đơn (Một file duy nhất)",
            "pdf" to "📄 PDF (Trang in)",
            "epub" to "📚 EPUB (eBook)",
            "txt" to "📝 TXT (Văn bản thuần)"
        )

        formats.forEachIndexed { index, (value, label) ->
            formatGroup.addView(RadioButton(context).apply {
                text = label
                id = index
                if (index == 0) isChecked = true
            })
        }
        container.addView(formatGroup)

        // File name input
        container.addView(TextView(context).apply {
            text = "📝 Tên file:"
            textSize = 14f
            setTextColor(Color.DKGRAY)
            setPadding(0, 16, 0, 8)
        })

        val fileNameInput = EditText(context).apply {
            setText(title.replace(Regex("[\\/:*?\"<>|]"), "_").take(40))
            setSingleLine(true)
        }
        container.addView(fileNameInput)

        scrollView.addView(container)

        val dialog = AlertDialog.Builder(context)
            .setView(scrollView)
            .setPositiveButton("⬇️ Lưu") { _, _ ->
                val selectedFormat = formats[formatGroup.checkedRadioButtonId].first
                val fileName = fileNameInput.text.toString()
                startDownload(selectedFormat, fileName)
            }
            .setNegativeButton("Huỷ", null)
            .create()

        dialog.show()
    }

    private fun capturePreview(imageView: ImageView) {
        // Tạm thời: Hiển thị placeholder
        // Thực tế cần capture từ GeckoView
        imageView.setImageDrawable(null)
        imageView.setBackgroundColor(Color.parseColor("#E0E0E0"))
    }

    private fun startDownload(format: String, fileName: String) {
        when (format) {
            "html_full" -> {
                Toast.makeText(context, "Đang tải trang đầy đủ...", Toast.LENGTH_SHORT).show()
                archiver.archivePage(url, fileName) { result ->
                    if (result.success) {
                        showResultDialog("✅ Đã lưu!", "Đường dẫn: ${result.path}\nFiles: ${result.fileCount}\nSize: ${formatBytes(result.totalSize)}")
                    } else {
                        showResultDialog("❌ Lỗi", "Không thể tải trang.")
                    }
                }
            }
            "html_single" -> {
                // FIX BUG THẬT: trước đây chỉ hiện Toast rồi KHÔNG LÀM GÌ
                // (TODO bỏ trống) — người dùng tưởng đang tải nhưng không
                // có file nào được tạo ra. Tải HTML gốc, không tách
                // resources — dùng đúng `getHtmlContent()` (đã sửa, xem
                // dưới) rồi ghi thẳng ra file .html.
                Toast.makeText(context, "Đang tải HTML đơn...", Toast.LENGTH_SHORT).show()
                getHtmlContent { html ->
                    if (html == null) {
                        showResultDialog("❌ Lỗi", "Không thể tải HTML trang.")
                        return@getHtmlContent
                    }
                    try {
                        val baseDir = java.io.File(context.getExternalFilesDir(null), "WebArchives")
                        baseDir.mkdirs()
                        val safeName = fileName.replace(Regex("[\\\\/:*?\"<>|]"), "_")
                        val outFile = java.io.File(baseDir, "$safeName.html")
                        outFile.writeText(html)
                        showResultDialog("✅ Đã lưu!", "Đường dẫn: ${outFile.absolutePath}\nSize: ${formatBytes(outFile.length())}")
                    } catch (e: Exception) {
                        showResultDialog("❌ Lỗi", "Không ghi được file: ${e.message}")
                    }
                }
            }
            "pdf" -> {
                Toast.makeText(context, "Đang chuyển sang PDF...", Toast.LENGTH_SHORT).show()
                converter.convertToPdf(url, fileName) { result ->
                    if (result.success) {
                        showResultDialog("✅ PDF đã tạo!", "Đường dẫn: ${result.path}")
                    } else {
                        showResultDialog("❌ Lỗi", "Không thể tạo PDF.")
                    }
                }
            }
            "epub" -> {
                Toast.makeText(context, "Đang chuyển sang EPUB...", Toast.LENGTH_SHORT).show()
                // Lấy HTML content
                getHtmlContent { html ->
                    converter.convertToEpub(fileName, "Unknown", html ?: "") { result ->
                        if (result.success) {
                            showResultDialog("✅ EPUB đã tạo!", "Đường dẫn: ${result.path}")
                        } else {
                            showResultDialog("❌ Lỗi", "Không thể tạo EPUB.")
                        }
                    }
                }
            }
            "txt" -> {
                Toast.makeText(context, "Đang chuyển sang TXT...", Toast.LENGTH_SHORT).show()
                getTextContent { text ->
                    converter.convertToTxt(fileName, text ?: "") { result ->
                        if (result.success) {
                            showResultDialog("✅ TXT đã tạo!", "Đường dẫn: ${result.path}")
                        } else {
                            showResultDialog("❌ Lỗi", "Không thể tạo TXT.")
                        }
                    }
                }
            }
        }
    }

    /**
     * FIX BUG THẬT: trước đây LUÔN `callback(null)` — khiến nhánh EPUB nhận
     * `html ?: ""` = rỗng, tạo EPUB 0 nội dung dù báo thành công. Tái dùng
     * `archiver.fetchRawHtml()` (mới thêm ở `WebArchiver.kt`, dùng lại đúng
     * `OkHttpClient` đã có sẵn và đã chứng minh hoạt động qua
     * `archivePage()`) thay vì cố lấy DOM sống qua GeckoView — đơn giản
     * hơn, không cần thêm cầu nối JS mới, và khớp đúng cách `WebArchiver`
     * đã lấy HTML cho chế độ "Tải trang đầy đủ".
     */
    private fun getHtmlContent(callback: (String?) -> Unit) {
        archiver.fetchRawHtml(url, callback)
    }

    /**
     * FIX BUG THẬT tương tự: trước đây LUÔN `callback(null)` — nhánh TXT
     * nhận `text ?: ""` = rỗng, tạo TXT 0 nội dung dù báo thành công.
     */
    private fun getTextContent(callback: (String?) -> Unit) {
        archiver.fetchPlainText(url, callback)
    }

    private fun showResultDialog(title: String, message: String) {
        AlertDialog.Builder(context)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("OK", null)
            .show()
    }

    private fun formatBytes(bytes: Long): String {
        return when {
            bytes >= 1024 * 1024 * 1024 -> "%.2f GB".format(bytes / 1024.0 / 1024.0 / 1024.0)
            bytes >= 1024 * 1024 -> "%.2f MB".format(bytes / 1024.0 / 1024.0)
            bytes >= 1024 -> "%.2f KB".format(bytes / 1024.0)
            else -> "$bytes B"
        }
    }
}
