package com.colablive.keeper.core

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter

object ForegroundState {
    const val ACTION_UPDATED = "com.colablive.keeper.ACTION_SLOT_UPDATED"
    const val EXTRA_URL = "url"
    const val EXTRA_SLOT_INDEX = "slot_index"

    @Volatile
    var lastKnownUrl: String? = null

    fun broadcastActiveSlot(context: Context, slotIndex: Int, url: String? = null) {
        lastKnownUrl = url
        val intent = Intent(ACTION_UPDATED).apply {
            putExtra(EXTRA_SLOT_INDEX, slotIndex)
            url?.let { putExtra(EXTRA_URL, it) }
            setPackage(context.packageName)
        }
        context.sendBroadcast(intent)
    }
}
