package com.colablive.keeper.core

/**
 * Mỗi "khe" (profile slot) chạy trong process Android riêng — nghĩa là 1
 * Kotlin `object` singleton bình thường KHÔNG được chia sẻ giữa các khe (mỗi
 * process có bộ nhớ JVM riêng biệt hoàn toàn). Để AutoClickAccessibilityService
 * (chạy trong process chính) biết được URL + khe nào đang thực sự ở foreground
 * lúc người dùng đang dùng 1 khe khác, PHẢI dùng cơ chế liên-process thật:
 * broadcast Intent (setPackage giới hạn trong app mình, không public ra ngoài).
 */
object ForegroundState {
    const val ACTION_UPDATED = "com.colablive.keeper.ACTION_FOREGROUND_UPDATED"
    const val EXTRA_URL = "extra_url"
    const val EXTRA_SLOT_INDEX = "extra_slot_index"
}
