package com.colablive.keeper

import android.os.Bundle
import android.widget.ScrollView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.colablive.keeper.core.FeatureRegistry

/**
 * Màn hình riêng cho ĐÚNG 1 feature — nhận feature_id + slot_index qua
 * Intent, tìm feature trong FeatureRegistry, hiển thị buildSettingsView()
 * của riêng nó chiếm toàn màn hình. Thêm feature mới KHÔNG cần sửa file này.
 */
class FeatureSettingsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val slotIndex = intent.getIntExtra("slot_index", 0)
        val featureId = intent.getStringExtra("feature_id")
        val feature = FeatureRegistry.features.firstOrNull { it.id == featureId }

        if (feature == null) {
            Toast.makeText(this, "Không tìm thấy feature", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        title = feature.displayName
        setContentView(ScrollView(this).apply { addView(feature.buildSettingsView(this@FeatureSettingsActivity, slotIndex)) })
    }
}
