package com.colablive.keeper

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.format.DateUtils
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.colablive.keeper.core.BrowserBookmarks
import com.colablive.keeper.core.ProfileSlots

/**
 * Màn hình BOOKMARK — tính năng thiếu thật trước đây (người dùng yêu cầu
 * làm, cùng lúc với "ẩn danh"/"group tabs"). Đi theo ĐÚNG khuôn mẫu
 * `HistoryActivity.kt` đã có sẵn — cùng cách mở URL đã chọn qua
 * `setResult()`/`open_url` (màn hình này không có `engine` sống để tự mở
 * trang), cùng cách xoá 1 mục/xoá hết. Khác 1 điểm: KHÔNG giới hạn hiển
 * thị theo trang (bookmark thường ít hơn lịch sử nhiều — không cần
 * `displayLimit`/nút "Xem thêm").
 */
class BookmarkActivity : AppCompatActivity() {

    private var slotIndex = 0
    private lateinit var listLayout: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        slotIndex = intent.getIntExtra("slot_index", 0)
        render()
    }

    private fun render() {
        val density = resources.displayMetrics.density
        val padding = (12 * density).toInt()

        val entries = BrowserBookmarks.readAll(this, slotIndex)

        val clearButton = Button(this).apply {
            text = "🗑 Xoá toàn bộ bookmark"
            setOnClickListener { confirmClear() }
        }

        listLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(padding, padding, padding, padding)
        }
        buildRows(entries)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(TextView(this@BookmarkActivity).apply {
                text = "⭐ Bookmark — Khe $slotIndex (${ProfileSlots.getSlotAssignmentDisplay(this@BookmarkActivity, slotIndex)})"
                textSize = 13f
                setTextColor(Color.GRAY)
                setPadding(padding, padding, padding, 0)
            })
            addView(clearButton)
            addView(
                ScrollView(this@BookmarkActivity).apply { addView(listLayout) },
                LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
            )
        }
        setContentView(root)
    }

    private fun buildRows(entries: List<BrowserBookmarks.Bookmark>) {
        listLayout.removeAllViews()
        if (entries.isEmpty()) {
            listLayout.addView(TextView(this).apply {
                text = "Chưa có bookmark nào. Bấm icon ⭐ cạnh ô địa chỉ để lưu trang đang xem."
                setPadding(0, (24 * resources.displayMetrics.density).toInt(), 0, 0)
            })
            return
        }
        val density = resources.displayMetrics.density
        val ripple = android.util.TypedValue().also {
            theme.resolveAttribute(android.R.attr.selectableItemBackground, it, true)
        }.resourceId

        entries.forEach { entry ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(0, (10 * density).toInt(), 0, (10 * density).toInt())
                isClickable = true
                isFocusable = true
                setBackgroundResource(ripple)
                setOnClickListener {
                    setResult(RESULT_OK, Intent().putExtra("open_url", entry.url))
                    finish()
                }
                setOnLongClickListener {
                    confirmDeleteOne(entry)
                    true
                }
            }
            row.addView(TextView(this).apply {
                text = "⭐ " + entry.title.ifBlank { entry.url }
                textSize = 15f
                setTextColor(Color.BLACK)
                maxLines = 1
            })
            row.addView(TextView(this).apply {
                text = entry.url
                textSize = 12f
                setTextColor(Color.GRAY)
                maxLines = 1
            })
            row.addView(TextView(this).apply {
                text = "Đã lưu " + DateUtils.getRelativeTimeSpanString(entry.time)
                textSize = 11f
                setTextColor(Color.LTGRAY)
            })
            listLayout.addView(row)
        }
    }

    private fun confirmDeleteOne(entry: BrowserBookmarks.Bookmark) {
        AlertDialog.Builder(this)
            .setMessage("Xoá bookmark này?\n${entry.title.ifBlank { entry.url }}")
            .setPositiveButton("Xoá") { _, _ ->
                BrowserBookmarks.delete(this, slotIndex, entry.url)
                Toast.makeText(this, "Đã xoá", Toast.LENGTH_SHORT).show()
                render()
            }
            .setNegativeButton("Huỷ", null)
            .show()
    }

    private fun confirmClear() {
        AlertDialog.Builder(this)
            .setTitle("Xoá toàn bộ bookmark?")
            .setMessage("Không thể hoàn tác.")
            .setPositiveButton("Xoá hết") { _, _ ->
                BrowserBookmarks.clear(this, slotIndex)
                Toast.makeText(this, "Đã xoá bookmark", Toast.LENGTH_SHORT).show()
                render()
            }
            .setNegativeButton("Huỷ", null)
            .show()
    }
}
