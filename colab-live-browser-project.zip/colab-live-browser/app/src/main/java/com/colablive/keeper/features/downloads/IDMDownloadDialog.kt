package com.colablive.keeper.features.downloads

import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.view.*
import android.widget.*
import com.colablive.keeper.core.DebugLog
import java.text.DecimalFormat

/**
 * IDM-like Download Dialog — Danh sách download với pause/resume/cancel, progress bar, speed.
 */
class IDMDownloadDialog(private val context: Context, private val engine: DownloadEngine) {

    private val handler = Handler(Looper.getMainLooper())
    private val dialog: AlertDialog
    private val listContainer: LinearLayout
    private val refreshRunnable = object : Runnable {
        override fun run() {
            refreshList()
            handler.postDelayed(this, 500)
        }
    }

    init {
        val scrollView = ScrollView(context)
        listContainer = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 16, 16, 16)
        }
        scrollView.addView(listContainer)

        dialog = AlertDialog.Builder(context)
            .setTitle("⬇️ Downloads (IDM)")
            .setView(scrollView)
            .setPositiveButton("Đóng") { _, _ ->
                handler.removeCallbacks(refreshRunnable)
            }
            .setNeutralButton("Tải mới") { _, _ ->
                showAddDownloadDialog()
            }
            .create()
    }

    fun show() {
        dialog.show()
        refreshList()
        handler.post(refreshRunnable)
    }

    private fun refreshList() {
        listContainer.removeAllViews()
        val downloads = engine.getAllDownloads()

        if (downloads.isEmpty()) {
            listContainer.addView(TextView(context).apply {
                text = "Chưa có download nào."
                textSize = 16f
                setTextColor(Color.GRAY)
                gravity = Gravity.CENTER
                setPadding(0, 50, 0, 50)
            })
            return
        }

        downloads.forEach { task ->
            val itemView = createDownloadItem(task)
            listContainer.addView(itemView)
            listContainer.addView(View(context).apply {
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1)
                setBackgroundColor(Color.LTGRAY)
            })
        }
    }

    private fun createDownloadItem(task: DownloadEngine.DownloadTask): View {
        val container = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 12, 12, 12)
        }

        // File name + status
        val headerRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val nameText = TextView(context).apply {
            text = task.fileName
            textSize = 14f
            setTextColor(Color.BLACK)
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }

        val statusText = TextView(context).apply {
            text = when {
                task.isComplete.get() -> "✅ Done"
                task.isPaused.get() -> "⏸️ Paused"
                task.isCancelled.get() -> "❌ Cancelled"
                else -> "⏳ Running"
            }
            textSize = 12f
            setTextColor(when {
                task.isComplete.get() -> Color.GREEN
                task.isPaused.get() -> Color.parseColor("#FF9800")
                task.isCancelled.get() -> Color.RED
                else -> Color.BLUE
            })
        }

        headerRow.addView(nameText)
        headerRow.addView(statusText)
        container.addView(headerRow)

        // Progress bar
        val progressBar = ProgressBar(context, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = if (task.totalBytes > 0) {
                ((task.downloadedBytes.get() * 100) / task.totalBytes).toInt()
            } else 0
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 8)
        }
        container.addView(progressBar)

        // Info row: size + speed + buttons
        val infoRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val sizeText = TextView(context).apply {
            val downloaded = formatBytes(task.downloadedBytes.get())
            val total = if (task.totalBytes > 0) formatBytes(task.totalBytes) else "?"
            text = "$downloaded / $total"
            textSize = 12f
            setTextColor(Color.DKGRAY)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }

        // Buttons
        val btnSize = 36
        val btnParams = LinearLayout.LayoutParams(btnSize, btnSize)
        btnParams.setMargins(4, 0, 4, 0)

        if (!task.isComplete.get() && !task.isCancelled.get()) {
            val pauseBtn = ImageButton(context).apply {
                setImageResource(android.R.drawable.ic_media_pause)
                setBackgroundColor(Color.TRANSPARENT)
                setOnClickListener {
                    if (task.isPaused.get()) {
                        engine.resumeDownload(task.id)
                    } else {
                        engine.pauseDownload(task.id)
                    }
                }
                layoutParams = btnParams
            }
            infoRow.addView(pauseBtn)
        }

        val deleteBtn = ImageButton(context).apply {
            setImageResource(android.R.drawable.ic_delete)
            setBackgroundColor(Color.TRANSPARENT)
            setOnClickListener {
                AlertDialog.Builder(context)
                    .setTitle("Xóa download?")
                    .setMessage(task.fileName)
                    .setPositiveButton("Xóa") { _, _ ->
                        engine.deleteDownload(task.id)
                        refreshList()
                    }
                    .setNegativeButton("Huỷ", null)
                    .show()
            }
            layoutParams = btnParams
        }
        infoRow.addView(deleteBtn)

        infoRow.addView(sizeText)
        container.addView(infoRow)

        return container
    }

    private fun showAddDownloadDialog() {
        val layout = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
        }

        val urlInput = EditText(context).apply {
            hint = "URL download..."
            setSingleLine(true)
        }
        layout.addView(urlInput)

        val nameInput = EditText(context).apply {
            hint = "Tên file (tùy chọn)..."
            setSingleLine(true)
        }
        layout.addView(nameInput)

        AlertDialog.Builder(context)
            .setTitle("Thêm Download")
            .setView(layout)
            .setPositiveButton("Tải") { _, _ ->
                val url = urlInput.text.toString()
                val name = nameInput.text.toString().takeIf { it.isNotEmpty() }
                    ?: url.substringAfterLast("/").takeIf { it.isNotEmpty() } ?: "download"
                if (url.isNotEmpty()) {
                    engine.startDownload(url, name)
                    refreshList()
                }
            }
            .setNegativeButton("Huỷ", null)
            .show()
    }

    private fun formatBytes(bytes: Long): String {
        val df = DecimalFormat("0.00")
        return when {
            bytes >= 1024 * 1024 * 1024 -> "${df.format(bytes / 1024.0 / 1024.0 / 1024.0)} GB"
            bytes >= 1024 * 1024 -> "${df.format(bytes / 1024.0 / 1024.0)} MB"
            bytes >= 1024 -> "${df.format(bytes / 1024.0)} KB"
            else -> "$bytes B"
        }
    }
}
