package com.colablive.keeper

import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.colablive.keeper.core.FeatureRegistry

/**
 * QUAN TRỌNG: SettingsActivity không khai báo android:process riêng, nên nó
 * LUÔN chạy trong process chính (khe 0) — bất kể được mở từ khe nào. Nếu
 * không nhận slotIndex tường minh qua Intent extra, nó sẽ đọc/ghi nhầm cấu
 * hình của khe 0 dù người dùng đang ở khe 2 — đây chính là kiểu lỗi
 * "1 thằng tắt cả đám tắt theo" bạn lo, giờ được chặn bằng cách bắt buộc
 * MainActivity phải truyền đúng slotIndex của chính nó khi mở màn hình này.
 */
class SettingsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val slotIndex = intent.getIntExtra("slot_index", 0)
        val padding = (16 * resources.displayMetrics.density).toInt()

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.TOP
        }

        container.addView(TextView(this).apply {
            text = "Tiện ích trình duyệt — Khe $slotIndex"
            textSize = 20f
            setPadding(padding, padding, padding, padding / 2)
        })

        for (feature in FeatureRegistry.features) {
            container.addView(TextView(this).apply {
                text = feature.displayName
                textSize = 16f
                setPadding(padding, padding, padding, padding / 4)
            })
            container.addView(feature.buildSettingsView(this, slotIndex))
        }

        setContentView(ScrollView(this).apply { addView(container) })
    }
}
