package com.colablive.keeper

import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.colablive.keeper.core.FeatureRegistry

/**
 * Chỉ là DANH SÁCH điều hướng — không còn nhồi UI của mọi feature vào 1 màn
 * hình cuộn dài như trước (dễ loãng khi thêm nhiều feature). Bấm vào 1
 * feature mở FeatureSettingsActivity riêng cho đúng feature đó.
 */
class SettingsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val slotIndex = intent.getIntExtra("slot_index", 0)
        val padding = (16 * resources.displayMetrics.density).toInt()

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.TOP
            setPadding(padding, padding, padding, padding)
        }

        container.addView(TextView(this).apply {
            text = "Tiện ích — Khe $slotIndex"
            textSize = 20f
        })

        for (feature in FeatureRegistry.features) {
            container.addView(Button(this).apply {
                text = feature.displayName
                setOnClickListener {
                    startActivity(
                        Intent(this@SettingsActivity, FeatureSettingsActivity::class.java)
                            .putExtra("slot_index", slotIndex)
                            .putExtra("feature_id", feature.id)
                    )
                }
            })
        }

        container.addView(Button(this).apply {
            text = "🐞 Debug Log"
            setOnClickListener {
                startActivity(Intent(this@SettingsActivity, DebugLogActivity::class.java))
            }
        })

        setContentView(ScrollView(this).apply { addView(container) })
    }
}
