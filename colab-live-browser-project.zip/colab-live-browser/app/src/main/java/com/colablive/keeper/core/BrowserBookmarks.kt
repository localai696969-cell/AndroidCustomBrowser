package com.colablive.keeper.core

import org.json.JSONArray
import org.json.JSONObject
import android.content.Context
import java.io.File

/**
 * BOOKMARK — tính năng thiếu thật (người dùng yêu cầu làm, cùng lúc với
 * "ẩn danh"/"group tabs" — `grep "Bookmark"` ra RỖNG trước phiên này, xác
 * nhận chưa hề có, không phải ghi chú lỗi thời).
 *
 * Đi theo ĐÚNG khuôn mẫu đã có của `BrowserHistory.kt` (cùng cách lưu
 * JSON trong thư mục hồ sơ Gecko, cùng cách khoá `synchronized`, cùng lý
 * do không dùng API "chính chủ" nào của GeckoView vì không có để tra cứu
 * chữ ký) — CHỈ khác 1 điểm quan trọng: bookmark KHÔNG có giới hạn
 * `MAX_ENTRIES` tự cắt bớt như lịch sử — người dùng bookmark là CHỦ Ý lưu
 * lâu dài, tự động xoá bớt mục cũ nhất sẽ mất dữ liệu người dùng cố tình
 * giữ, khác hẳn lịch sử (chỉ là log tự động, mất bớt không sao).
 */
object BrowserBookmarks {
    private val lock = Any()

    private fun safeDirNameFor(namespace: String) =
        "gecko_profile_" + namespace.replace(Regex("[^a-zA-Z0-9_-]"), "_")

    private fun bookmarksFile(context: Context, slotIndex: Int): File {
        val profileNamespace = ProfileSlots.getSlotAssignment(context, slotIndex)
        val dir = File(context.filesDir, safeDirNameFor(profileNamespace))
        dir.mkdirs()
        return File(dir, "bookmarks.json")
    }

    private fun readArray(context: Context, slotIndex: Int): JSONArray {
        val f = bookmarksFile(context, slotIndex)
        if (!f.exists()) return JSONArray()
        return try { JSONArray(f.readText()) } catch (e: Exception) { JSONArray() }
    }

    private fun writeArray(context: Context, slotIndex: Int, arr: JSONArray) {
        val f = bookmarksFile(context, slotIndex)
        val tmp = File(f.parentFile, "bookmarks.json.tmp")
        tmp.writeText(arr.toString())
        tmp.renameTo(f)
    }

    data class Bookmark(val url: String, val title: String, val time: Long)

    fun isBookmarked(context: Context, slotIndex: Int, url: String): Boolean {
        if (url.isBlank()) return false
        return synchronized(lock) {
            try {
                val arr = readArray(context, slotIndex)
                (0 until arr.length()).any { arr.getJSONObject(it).optString("url") == url }
            } catch (e: Exception) { false }
        }
    }

    /** Bật/tắt bookmark cho URL này — trả về trạng thái MỚI sau khi đổi
     * (true = vừa thêm, false = vừa xoá), để nơi gọi tự cập nhật icon sao
     * ngay mà không cần đọc lại. */
    fun toggle(context: Context, slotIndex: Int, url: String, title: String): Boolean {
        if (url.isBlank()) return false
        synchronized(lock) {
            try {
                val arr = readArray(context, slotIndex)
                val kept = JSONArray()
                var wasBookmarked = false
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    if (obj.optString("url") == url) {
                        wasBookmarked = true
                        continue // bỏ mục này = xoá bookmark
                    }
                    kept.put(obj)
                }
                if (!wasBookmarked) {
                    kept.put(JSONObject().apply {
                        put("url", url)
                        put("title", title.ifBlank { url })
                        put("time", System.currentTimeMillis())
                    })
                }
                writeArray(context, slotIndex, kept)
                return !wasBookmarked
            } catch (e: Exception) {
                DebugLog.log("BrowserBookmarks.toggle lỗi: ${e.message}")
                return false
            }
        }
    }

    /** MỚI NHẤT TRƯỚC — cùng thứ tự hiển thị như lịch sử, quen thuộc cho người dùng. */
    fun readAll(context: Context, slotIndex: Int): List<Bookmark> {
        return try {
            synchronized(lock) {
                val arr = readArray(context, slotIndex)
                (0 until arr.length()).map {
                    val o = arr.getJSONObject(it)
                    Bookmark(o.optString("url"), o.optString("title"), o.optLong("time"))
                }.reversed()
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun delete(context: Context, slotIndex: Int, url: String) {
        synchronized(lock) {
            try {
                val arr = readArray(context, slotIndex)
                val kept = JSONArray()
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    if (obj.optString("url") == url) continue
                    kept.put(obj)
                }
                writeArray(context, slotIndex, kept)
            } catch (e: Exception) {
                DebugLog.log("BrowserBookmarks.delete lỗi: ${e.message}")
            }
        }
    }

    fun clear(context: Context, slotIndex: Int) {
        synchronized(lock) {
            try { bookmarksFile(context, slotIndex).delete() } catch (e: Exception) { /* không có gì để xoá */ }
        }
    }
}
