package com.colablive.keeper

import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.colablive.keeper.core.DebugLog
import com.colablive.keeper.core.ProfileSlots

class DebugLogActivity : AppCompatActivity() {
    private lateinit var logText: TextView
    private var slotIndex = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // BUG THẬT đã sửa (người dùng phát hiện: mở Debug Log từ Khe 1
        // nhưng luôn chỉ thấy log của Khe 0): Activity này KHÔNG khai báo
        // `android:process` trong Manifest, nên Android LUÔN chạy nó
        // trong tiến trình MẶC ĐỊNH (= Khe 0) bất kể bấm mở từ khe nào —
        // xem chú thích đầy đủ ở `DebugLog.kt`. Nhận tường minh
        // `slot_index` từ Intent (đúng cách `HistoryActivity`/
        // `BookmarkActivity` đã làm từ đầu) — đọc file theo ĐÚNG khe đó,
        // không dựa vào tiến trình nào đang thực thi Activity.
        slotIndex = intent.getIntExtra("slot_index", 0)

        val padding = (12 * resources.displayMetrics.density).toInt()

        logText = TextView(this).apply {
            setPadding(padding, padding, padding, padding)
            textSize = 12f
            setTextIsSelectable(true)
        }

        val refreshButton = Button(this).apply {
            text = "Làm mới"
            setOnClickListener { refresh() }
        }
        val clearButton = Button(this).apply {
            text = "Xoá log"
            setOnClickListener { DebugLog.clearFile(this@DebugLogActivity, slotIndex); refresh() }
        }
        val checkIsolationButton = Button(this).apply {
            text = "🔍 Kiểm tra cô lập hồ sơ"
            setOnClickListener { showIsolationCheck() }
        }
        val buttonRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(refreshButton)
            addView(clearButton)
            addView(checkIsolationButton)
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(TextView(this@DebugLogActivity).apply {
                val rawProcName = if (android.os.Build.VERSION.SDK_INT >= 28) android.app.Application.getProcessName() else "(SDK<28)"
                text = "Debug Log — Khe $slotIndex (${ProfileSlots.getSlotAssignmentDisplay(this@DebugLogActivity, slotIndex)})\n" +
                    "[Màn hình này đang thực thi trong tiến trình: $rawProcName — có thể KHÁC tiến trình của Khe $slotIndex, không sao cả vì log đọc thẳng từ file trên đĩa]"
                textSize = 13f
                setPadding(padding, padding, padding, 0)
            })
            addView(buttonRow)
            addView(
                ScrollView(this@DebugLogActivity).apply { addView(logText) },
                LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
            )
        }
        setContentView(root)
        refresh()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        // Đọc thẳng từ file theo `slotIndex` — KHÔNG dùng `DebugLog.getAll()`
        // (bộ nhớ trong tiến trình, chỉ đúng nếu Activity đang chạy ĐÚNG
        // tiến trình của khe đó — không đảm bảo, xem chú thích ở onCreate).
        // Mới nhất lên đầu — không cần cuộn xuống cuối mỗi lần mở lại.
        val content = DebugLog.readFullFile(this, slotIndex)
        logText.text = content.lines().reversed().joinToString("\n").ifBlank { "(chưa có log nào cho khe $slotIndex)" }
    }

    /**
     * KHÔNG SUY LUẬN NỮA — đọc THẲNG hệ thống file thật để trả lời câu hỏi
     * "hồ sơ Gecko của các khe có thật sự tách biệt trên đĩa không, hay
     * đang dùng chung 1 thư mục (= leak cookie/session/storage giữa các
     * khe)". `GeckoRuntimeProvider` dùng cờ `-profile` (đã ghi rõ trong
     * code là CHƯA XÁC NHẬN có ăn thật trên thiết bị hay không) — đây là
     * cách kiểm chứng TRỰC TIẾP, không qua suy luận: liệt kê từng thư mục
     * `gecko_profile_*` trong `filesDir` của app (dùng chung giữa MỌI tiến
     * trình vì cùng 1 app, cùng 1 user Android) — nếu 2 khe cho ra chỉ 1
     * thư mục DUY NHẤT có dữ liệu (cookies.sqlite, storage/...) trong khi
     * khe kia trống rỗng hoặc không tồn tại, tức -profile KHÔNG ăn thật —
     * mọi khe đang chia sẻ vật lý 1 hồ sơ (contextId ở lớp 2 vẫn cô lập
     * được storage theo-origin, nhưng KHÔNG cô lập được site permission/
     * cache cấp-profile như -profile lẽ ra phải làm).
     */
    private fun showIsolationCheck() {
        val sb = StringBuilder()
        sb.append("=== KIỂM TRA CÔ LẬP HỒ SƠ GECKO (đọc thẳng đĩa, không suy luận) ===\n\n")
        for (slot in 0..ProfileSlots.SLOT_COUNT) {
            val namespace = ProfileSlots.getSlotAssignment(this, slot)
            val dirName = "gecko_profile_" + namespace.replace(Regex("[^a-zA-Z0-9_-]"), "_")
            val dir = java.io.File(filesDir, dirName)
            sb.append("Khe $slot (hồ sơ '$namespace') → thư mục: $dirName\n")
            if (!dir.exists()) {
                sb.append("  ❌ THƯ MỤC KHÔNG TỒN TẠI (chưa từng mở khe này, hoặc -profile không tạo được thư mục riêng)\n\n")
                continue
            }
            val files = dir.listFiles()
            if (files == null || files.isEmpty()) {
                sb.append("  ⚠️ THƯ MỤC RỖNG (tồn tại nhưng Gecko chưa ghi gì vào đây — nghi ngờ -profile không thật sự được Gecko dùng)\n\n")
                continue
            }
            sb.append("  ✅ CÓ ${files.size} mục, tổng ${files.sumOf { if (it.isFile) it.length() else 0L } / 1024} KB:\n")
            files.sortedByDescending { it.lastModified() }.take(10).forEach { f ->
                val time = java.text.SimpleDateFormat("MM-dd HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date(f.lastModified()))
                sb.append("    - ${f.name} (sửa lúc $time, ${if (f.isDirectory) "thư mục" else "${f.length()} bytes"})\n")
            }
            sb.append("\n")
        }
        sb.append(
            "\nCÁCH ĐỌC KẾT QUẢ:\n" +
            "- Mỗi khe có thư mục RIÊNG, CÓ dữ liệu (cookies.sqlite/storage) sau khi đã browse ở khe đó → cô lập THẬT SỰ hoạt động.\n" +
            "- Nếu 2 khe cho ra CÙNG 1 tên thư mục (namespace trùng nhau) → 2 khe đang GÁN CHUNG 1 hồ sơ (xem lại ProfilePickerActivity đã gán hồ sơ nào cho khe nào — đây có thể là lựa chọn CÓ CHỦ Ý của bạn, không phải bug).\n" +
            "- Nếu thư mục tồn tại nhưng RỖNG dù đã browse nhiều — dấu hiệu -profile không ăn, cần điều tra tiếp ở tầng GeckoView."
        )

        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Kiểm tra cô lập hồ sơ")
            .setMessage(sb.toString())
            .setPositiveButton("Đóng", null)
            .setNeutralButton("Sao chép") { _, _ ->
                val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText("isolation_check", sb.toString()))
            }
            .show()
    }
}
