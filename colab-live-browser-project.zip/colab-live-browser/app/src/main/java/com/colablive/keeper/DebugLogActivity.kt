package com.colablive.keeper

import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.colablive.keeper.core.DebugLog

class DebugLogActivity : AppCompatActivity() {
    private lateinit var logText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val padding = (12 * resources.displayMetrics.density).toInt()

        logText = TextView(this).apply {
            setPadding(padding, padding, padding, padding)
            textSize = 12f
            setTextIsSelectable(true)
        }

        val refreshButton = Button(this).apply {
            text = "Làm mới"
            setOnClickListener { refresh() }
        }
        val clearButton = Button(this).apply {
            text = "Xoá log"
            setOnClickListener { DebugLog.clear(); refresh() }
        }
        val buttonRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(refreshButton)
            addView(clearButton)
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(buttonRow)
            addView(
                ScrollView(this@DebugLogActivity).apply { addView(logText) },
                LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
            )
        }
        setContentView(root)
        refresh()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        // Mới nhất lên đầu — không cần cuộn xuống cuối mỗi lần mở lại
        logText.text = DebugLog.getAll().reversed().joinToString("\n\n").ifEmpty { "(chưa có log nào)" }
    }
}
