package com.colablive.keeper

import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.colablive.keeper.core.DebugLog
import com.colablive.keeper.core.ProfileSlots

class DebugLogActivity : AppCompatActivity() {
    private lateinit var logText: TextView
    private var slotIndex = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // BUG THẬT đã sửa (người dùng phát hiện: mở Debug Log từ Khe 1
        // nhưng luôn chỉ thấy log của Khe 0): Activity này KHÔNG khai báo
        // `android:process` trong Manifest, nên Android LUÔN chạy nó
        // trong tiến trình MẶC ĐỊNH (= Khe 0) bất kể bấm mở từ khe nào —
        // xem chú thích đầy đủ ở `DebugLog.kt`. Nhận tường minh
        // `slot_index` từ Intent (đúng cách `HistoryActivity`/
        // `BookmarkActivity` đã làm từ đầu) — đọc file theo ĐÚNG khe đó,
        // không dựa vào tiến trình nào đang thực thi Activity.
        slotIndex = intent.getIntExtra("slot_index", 0)

        val padding = (12 * resources.displayMetrics.density).toInt()

        logText = TextView(this).apply {
            setPadding(padding, padding, padding, padding)
            textSize = 12f
            setTextIsSelectable(true)
        }

        val refreshButton = Button(this).apply {
            text = "Làm mới"
            setOnClickListener { refresh() }
        }
        val clearButton = Button(this).apply {
            text = "Xoá log"
            setOnClickListener { DebugLog.clearFile(this@DebugLogActivity, slotIndex); refresh() }
        }
        val buttonRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(refreshButton)
            addView(clearButton)
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(TextView(this@DebugLogActivity).apply {
                text = "Debug Log — Khe $slotIndex (${ProfileSlots.getSlotAssignmentDisplay(this@DebugLogActivity, slotIndex)})"
                textSize = 13f
                setPadding(padding, padding, padding, 0)
            })
            addView(buttonRow)
            addView(
                ScrollView(this@DebugLogActivity).apply { addView(logText) },
                LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
            )
        }
        setContentView(root)
        refresh()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        // Đọc thẳng từ file theo `slotIndex` — KHÔNG dùng `DebugLog.getAll()`
        // (bộ nhớ trong tiến trình, chỉ đúng nếu Activity đang chạy ĐÚNG
        // tiến trình của khe đó — không đảm bảo, xem chú thích ở onCreate).
        // Mới nhất lên đầu — không cần cuộn xuống cuối mỗi lần mở lại.
        val content = DebugLog.readFullFile(this, slotIndex)
        logText.text = content.lines().reversed().joinToString("\n").ifBlank { "(chưa có log nào cho khe $slotIndex)" }
    }
}
