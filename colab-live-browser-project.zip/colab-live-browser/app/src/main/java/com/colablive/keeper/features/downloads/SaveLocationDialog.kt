package com.colablive.keeper.features.downloads

import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.os.Environment
import android.view.*
import android.widget.*
import com.colablive.keeper.core.FolderPickerBridge
import java.io.File

/**
 * Dialog hỏi lưu file ở đâu trước khi download.
 */
class SaveLocationDialog(private val context: Context) {

    data class SaveResult(
        val confirmed: Boolean,
        val fileName: String,
        val directory: String,
        val locationType: String = "downloads" // "downloads"/"documents"/"pictures"/"movies"/"music"/"custom" — DownloadEngine cần đúng giá trị NÀY, không phải path đã tính sẵn ở `directory` (Scoped Storage Android 10+ cần biết collection, không phải path)
    )

    fun show(
        url: String,
        suggestedFileName: String,
        callback: (SaveResult) -> Unit
    ) {
        val scrollView = ScrollView(context)
        val container = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
        }

        // URL
        container.addView(TextView(context).apply {
            text = "🔗 $url"
            textSize = 12f
            setTextColor(Color.GRAY)
            setPadding(0, 0, 0, 16)
        })

        // File name
        container.addView(TextView(context).apply {
            text = "📝 Tên file:"
            textSize = 14f
            setTextColor(Color.DKGRAY)
        })

        val fileNameInput = EditText(context).apply {
            setText(suggestedFileName)
            setSingleLine(true)
        }
        container.addView(fileNameInput)

        // Save location
        container.addView(TextView(context).apply {
            text = "📁 Lưu vào:"
            textSize = 14f
            setTextColor(Color.DKGRAY)
            setPadding(0, 16, 0, 8)
        })

        val locationGroup = RadioGroup(context).apply {
            orientation = RadioGroup.VERTICAL
        }

        val locations = listOf(
            "downloads" to "📥 Downloads (mặc định)",
            "documents" to "📄 Documents",
            "pictures" to "🖼️ Pictures",
            "movies" to "🎬 Movies",
            "music" to "🎵 Music",
            "custom" to "📂 Tùy chọn..."
        )

        locations.forEachIndexed { index, (value, label) ->
            locationGroup.addView(RadioButton(context).apply {
                text = label
                id = index
                if (index == 0) isChecked = true
                tag = value
            })
        }
        container.addView(locationGroup)

        // Custom path input (ẩn mặc định)
        val customPathInput = EditText(context).apply {
            hint = "/storage/emulated/0/MyFolder"
            visibility = View.GONE
            setSingleLine(true)
        }
        container.addView(customPathInput)

        // BUG THẬT (người dùng phản ánh 2 lần): trước đây "Tuỳ chọn" bắt
        // gõ TAY đường dẫn — không có cách duyệt thư mục thật như trình
        // duyệt khác. Thêm nút chọn thư mục THẬT qua Storage Access
        // Framework (`FolderPickerBridge`) — kết quả trả về là 1 "tree
        // URI" (`content://...`), KHÔNG PHẢI đường dẫn file thường, ghi
        // thẳng vào `customPathInput` — `DownloadEngine` tự nhận diện
        // tiền tố `content://` để chọn đúng cách ghi (qua `DocumentFile`),
        // khác hẳn cách ghi file thường cho đường dẫn gõ tay kiểu cũ.
        val pickFolderButton = Button(context).apply {
            text = "📁 Chọn thư mục"
            visibility = View.GONE
            setOnClickListener {
                FolderPickerBridge.requestFolder(context) { uri ->
                    if (uri != null) {
                        customPathInput.setText(uri.toString())
                    }
                }
            }
        }
        container.addView(pickFolderButton)

        locationGroup.setOnCheckedChangeListener { _, checkedId ->
            val selected = locations[checkedId]
            val isCustom = selected.first == "custom"
            customPathInput.visibility = if (isCustom) View.VISIBLE else View.GONE
            pickFolderButton.visibility = if (isCustom) View.VISIBLE else View.GONE
        }

        // File size (nếu biết)
        container.addView(TextView(context).apply {
            text = "ℹ️ Kích thước: Đang xác định..."
            textSize = 12f
            setTextColor(Color.GRAY)
            setPadding(0, 8, 0, 0)
        })

        scrollView.addView(container)

        AlertDialog.Builder(context)
            .setTitle("⬇️ Tải File")
            .setView(scrollView)
            .setPositiveButton("Tải") { _, _ ->
                val fileName = fileNameInput.text.toString()
                val selectedLocation = locations[locationGroup.checkedRadioButtonId]
                val directory = when (selectedLocation.first) {
                    // CHỈ dùng để HIỂN THỊ cho người dùng xem + mkdirs() (cần
                    // trên Android ≤9) — nơi lưu THẬT SỰ trên Android 10+ do
                    // `DownloadEngine.copyToPublicDownloads()` quyết định qua
                    // MediaStore (đọc `locationType`, không đọc path này).
                    "downloads" -> Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).absolutePath
                    "documents" -> Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS).absolutePath
                    "pictures" -> Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).absolutePath
                    "movies" -> Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES).absolutePath
                    "music" -> Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC).absolutePath
                    "custom" -> customPathInput.text.toString()
                    else -> Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).absolutePath
                }
                callback(SaveResult(true, fileName, directory, selectedLocation.first))
            }
            .setNegativeButton("Huỷ") { _, _ ->
                callback(SaveResult(false, "", ""))
            }
            .setNeutralButton("Chặn domain") { _, _ ->
                // Chặn domain này
                callback(SaveResult(false, "", "BLOCK_DOMAIN"))
            }
            .show()
    }
}
