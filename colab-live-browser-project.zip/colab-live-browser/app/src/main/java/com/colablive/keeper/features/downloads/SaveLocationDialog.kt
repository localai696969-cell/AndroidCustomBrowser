package com.colablive.keeper.features.downloads

import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.os.Environment
import android.view.*
import android.widget.*
import java.io.File

/**
 * Dialog hỏi lưu file ở đâu trước khi download.
 */
class SaveLocationDialog(private val context: Context) {

    data class SaveResult(
        val confirmed: Boolean,
        val fileName: String,
        val directory: String
    )

    fun show(
        url: String,
        suggestedFileName: String,
        callback: (SaveResult) -> Unit
    ) {
        val scrollView = ScrollView(context)
        val container = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
        }

        // URL
        container.addView(TextView(context).apply {
            text = "🔗 $url"
            textSize = 12f
            setTextColor(Color.GRAY)
            setPadding(0, 0, 0, 16)
        })

        // File name
        container.addView(TextView(context).apply {
            text = "📝 Tên file:"
            textSize = 14f
            setTextColor(Color.DKGRAY)
        })

        val fileNameInput = EditText(context).apply {
            setText(suggestedFileName)
            setSingleLine(true)
        }
        container.addView(fileNameInput)

        // Save location
        container.addView(TextView(context).apply {
            text = "📁 Lưu vào:"
            textSize = 14f
            setTextColor(Color.DKGRAY)
            setPadding(0, 16, 0, 8)
        })

        val locationGroup = RadioGroup(context).apply {
            orientation = RadioGroup.VERTICAL
        }

        val locations = listOf(
            "downloads" to "📥 Downloads (mặc định)",
            "documents" to "📄 Documents",
            "pictures" to "🖼️ Pictures",
            "movies" to "🎬 Movies",
            "music" to "🎵 Music",
            "custom" to "📂 Tùy chọn..."
        )

        locations.forEachIndexed { index, (value, label) ->
            locationGroup.addView(RadioButton(context).apply {
                text = label
                id = index
                if (index == 0) isChecked = true
                tag = value
            })
        }
        container.addView(locationGroup)

        // Custom path input (ẩn mặc định)
        val customPathInput = EditText(context).apply {
            hint = "/storage/emulated/0/MyFolder"
            visibility = View.GONE
            setSingleLine(true)
        }
        container.addView(customPathInput)

        locationGroup.setOnCheckedChangeListener { _, checkedId ->
            val selected = locations[checkedId]
            customPathInput.visibility = if (selected.first == "custom") View.VISIBLE else View.GONE
        }

        // File size (nếu biết)
        container.addView(TextView(context).apply {
            text = "ℹ️ Kích thước: Đang xác định..."
            textSize = 12f
            setTextColor(Color.GRAY)
            setPadding(0, 8, 0, 0)
        })

        scrollView.addView(container)

        AlertDialog.Builder(context)
            .setTitle("⬇️ Tải File")
            .setView(scrollView)
            .setPositiveButton("Tải") { _, _ ->
                val fileName = fileNameInput.text.toString()
                val selectedLocation = locations[locationGroup.checkedRadioButtonId]
                val directory = when (selectedLocation.first) {
                    "downloads" -> context.getExternalFilesDir(null)?.absolutePath + "/downloads"
                    "documents" -> Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS).absolutePath
                    "pictures" -> Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).absolutePath
                    "movies" -> Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES).absolutePath
                    "music" -> Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC).absolutePath
                    "custom" -> customPathInput.text.toString()
                    else -> context.getExternalFilesDir(null)?.absolutePath + "/downloads"
                }
                callback(SaveResult(true, fileName, directory))
            }
            .setNegativeButton("Huỷ") { _, _ ->
                callback(SaveResult(false, "", ""))
            }
            .setNeutralButton("Chặn domain") { _, _ ->
                // Chặn domain này
                callback(SaveResult(false, "", "BLOCK_DOMAIN"))
            }
            .show()
    }
}
