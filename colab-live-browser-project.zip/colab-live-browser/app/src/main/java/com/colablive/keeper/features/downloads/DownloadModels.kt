package com.colablive.keeper.features.downloads

import android.net.Uri

/**
 * Data classes cho Download Manager
 */
data class DownloadItem(
    val id: Long,
    val url: String,
    val fileName: String,
    val status: DownloadStatus,
    val progress: Int = 0,
    val totalBytes: Long = 0,
    val downloadedBytes: Long = 0,
    val errorMessage: String? = null
)

enum class DownloadStatus {
    PENDING,
    RUNNING,
    PAUSED,
    SUCCESSFUL,
    FAILED,
    CANCELLED
}

data class StreamInfo(
    val url: String,
    val quality: String,
    val format: String,
    val size: Long = 0
)

data class ArchiveResult(
    val success: Boolean,
    val filePath: String? = null,
    val error: String? = null
)
