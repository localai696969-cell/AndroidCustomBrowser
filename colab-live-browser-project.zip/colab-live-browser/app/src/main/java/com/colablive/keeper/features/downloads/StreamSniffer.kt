package com.colablive.keeper.features.downloads

import android.content.Context
import com.colablive.keeper.core.DebugLog
import java.net.HttpURLConnection
import java.net.URL

class StreamSniffer(private val context: Context) {

    data class MediaStream(
        val url: String,
        val type: String,
        val quality: String?,
        val size: Long
    )

    fun sniffMediaStreams(pageUrl: String): List<MediaStream> {
        val streams = mutableListOf<MediaStream>()

        // Common video patterns
        val patterns = listOf(
            Regex("https?://[^\s"<>|]+\.(mp4|webm|mkv|m3u8|mpd)[^\s"<>|]*", RegexOption.IGNORE_CASE),
            Regex("https?://[^\s"<>|]+/video/[^\s"<>|]+", RegexOption.IGNORE_CASE),
            Regex("https?://[^\s"<>|]+/stream/[^\s"<>|]+", RegexOption.IGNORE_CASE)
        )

        try {
            val connection = URL(pageUrl).openConnection() as HttpURLConnection
            connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64)")
            val content = connection.inputStream.bufferedReader().use { it.readText() }
            connection.disconnect()

            for (pattern in patterns) {
                pattern.findAll(content).forEach { match ->
                    val url = match.value
                    val type = when {
                        url.contains(".m3u8", ignoreCase = true) -> "HLS"
                        url.contains(".mpd", ignoreCase = true) -> "DASH"
                        url.contains(".mp4", ignoreCase = true) -> "MP4"
                        url.contains(".webm", ignoreCase = true) -> "WEBM"
                        else -> "Unknown"
                    }

                    val size = getContentLength(url)
                    if (size > 0 || type == "HLS" || type == "DASH") {
                        streams.add(MediaStream(url, type, null, size))
                    }
                }
            }
        } catch (e: Exception) {
            DebugLog.log("StreamSniffer error: ${e.message}")
        }

        return streams.distinctBy { it.url }
    }

    private fun getContentLength(url: String): Long {
        return try {
            val conn = URL(url).openConnection() as HttpURLConnection
            conn.requestMethod = "HEAD"
            conn.connectTimeout = 5000
            val length = conn.contentLengthLong
            conn.disconnect()
            length
        } catch (e: Exception) { -1 }
    }
}
