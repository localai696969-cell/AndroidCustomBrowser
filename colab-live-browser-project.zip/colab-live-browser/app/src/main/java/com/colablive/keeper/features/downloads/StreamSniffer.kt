package com.colablive.keeper.features.downloads

import android.content.Context
import com.colablive.keeper.core.DebugLog
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import java.util.regex.Pattern

/**
 * Phat hien media links trong HTML (video, audio, HLS, DASH).
 */
class StreamSniffer(private val context: Context) {

    fun sniffMedia(url: String, html: String?): List<MediaStream> {
        val streams = mutableListOf<MediaStream>()
        val doc = html?.let { Jsoup.parse(it, url) }

        // Video tags
        doc?.select("video[src], video source[src]")?.forEach { el ->
            val src = el.absUrl("src")
            if (src.isNotEmpty()) {
                streams.add(MediaStream(src, "HTML5 Video", "mp4", 0))
            }
        }

        // Audio tags
        doc?.select("audio[src], audio source[src]")?.forEach { el ->
            val src = el.absUrl("src")
            if (src.isNotEmpty()) {
                streams.add(MediaStream(src, "HTML5 Audio", "mp3", 0))
            }
        }

        // HLS (m3u8)
        val hlsPattern = Pattern.compile("https?://[^\\s\"<>|]+\\.m3u8[^\\s\"<>|]*", Pattern.CASE_INSENSITIVE)
        val hlsMatcher = hlsPattern.matcher(html ?: "")
        while (hlsMatcher.find()) {
            val url = hlsMatcher.group()
            if (streams.none { it.url == url }) {
                streams.add(MediaStream(url, "HLS Stream", "m3u8", 0))
            }
        }

        // DASH (mpd)
        val dashPattern = Pattern.compile("https?://[^\\s\"<>|]+\\.mpd[^\\s\"<>|]*", Pattern.CASE_INSENSITIVE)
        val dashMatcher = dashPattern.matcher(html ?: "")
        while (dashMatcher.find()) {
            val url = dashMatcher.group()
            if (streams.none { it.url == url }) {
                streams.add(MediaStream(url, "DASH Stream", "mpd", 0))
            }
        }

        // Direct video links
        val videoPattern = Pattern.compile("https?://[^\\s\"<>|]+\\.(mp4|webm|mkv)[^\\s\"<>|]*", Pattern.CASE_INSENSITIVE)
        val videoMatcher = videoPattern.matcher(html ?: "")
        while (videoMatcher.find()) {
            val url = videoMatcher.group()
            if (streams.none { it.url == url }) {
                val ext = url.substringAfterLast('.').substringBefore('?').substringBefore('#')
                streams.add(MediaStream(url, "Direct Video", ext, 0))
            }
        }

        DebugLog.log("StreamSniffer: Found ${streams.size} streams for $url")
        return streams
    }

    data class MediaStream(
        val url: String,
        val type: String,
        val format: String,
        val estimatedSize: Long
    )
}
