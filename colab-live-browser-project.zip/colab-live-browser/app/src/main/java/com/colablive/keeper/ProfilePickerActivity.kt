package com.colablive.keeper

import android.app.ActivityManager
import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.colablive.keeper.core.ProfileSlots

class ProfilePickerActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    private fun render() {
        val padding = (16 * resources.displayMetrics.density).toInt()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(padding, padding, padding, padding)
        }

        layout.addView(TextView(this).apply {
            text = "${ProfileSlots.SLOT_COUNT + 1} khe dùng ĐỒNG THỜI được (khe 0 = cửa sổ chính). " +
                "Gán profile bất kỳ vào khe bất kỳ — đổi gán chỉ khởi động lại đúng khe đó."
            textSize = 16f
        })

        for (slotIndex in 0..ProfileSlots.SLOT_COUNT) {
            val assigned = ProfileSlots.getSlotAssignment(this, slotIndex)
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            row.addView(Button(this).apply {
                text = "Khe $slotIndex: $assigned"
                setOnClickListener { openSlot(slotIndex) }
            })
            row.addView(Button(this).apply {
                text = "Đổi"
                setOnClickListener { showReassignDialog(slotIndex) }
            })
            layout.addView(row)
        }

        layout.addView(TextView(this).apply {
            text = "\nCác profile đã tạo:"
            textSize = 16f
        })
        layout.addView(TextView(this).apply {
            text = ProfileSlots.listProfiles(this@ProfilePickerActivity).joinToString(", ")
        })

        val newNameInput = EditText(this).apply { hint = "Tên profile mới (vd: Cá nhân, Công việc, KH A...)" }
        layout.addView(newNameInput)
        layout.addView(Button(this).apply {
            text = "Thêm profile mới vào danh sách"
            setOnClickListener {
                val name = newNameInput.text.toString().trim()
                if (name.isNotEmpty()) {
                    ProfileSlots.addProfile(this@ProfilePickerActivity, name)
                    newNameInput.setText("")
                    render()
                }
            }
        })

        setContentView(layout)
    }

    private fun openSlot(slotIndex: Int) {
        val className = ProfileSlots.componentClassNameForSlot(slotIndex)
        startActivity(Intent().apply {
            component = ComponentName(packageName, className)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        })
    }

    // Dialog đơn giản dạng danh sách nút bấm (tránh phụ thuộc thêm thư viện dialog)
    private fun showReassignDialog(slotIndex: Int) {
        val padding = (16 * resources.displayMetrics.density).toInt()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(padding, padding, padding, padding)
        }
        layout.addView(TextView(this).apply { text = "Gán profile nào vào Khe $slotIndex?" })
        for (name in ProfileSlots.listProfiles(this)) {
            layout.addView(Button(this).apply {
                text = name
                setOnClickListener {
                    ProfileSlots.setSlotAssignment(this@ProfilePickerActivity, slotIndex, name)
                    restartSlot(slotIndex)
                }
            })
        }
        setContentView(layout)
    }

    /**
     * Khởi động lại ĐÚNG 1 khe (không đụng các khe khác đang chạy).
     * Khe 0 (chính) là process đang chạy chính activity này -> phải tự kill+relaunch.
     * Khe khác -> kill process của khe đó qua ActivityManager rồi mở lại.
     */
    private fun restartSlot(slotIndex: Int) {
        if (slotIndex == 0) {
            val relaunch = packageManager.getLaunchIntentForPackage(packageName)?.apply {
                addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(relaunch)
            Runtime.getRuntime().exit(0)
        } else {
            val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
            val targetProcessName = "$packageName:slot$slotIndex"
            am.runningAppProcesses
                ?.firstOrNull { it.processName == targetProcessName }
                ?.let { android.os.Process.killProcess(it.pid) }
            openSlot(slotIndex)
        }
        render()
    }
}
