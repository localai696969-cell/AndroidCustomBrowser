package com.colablive.keeper

import android.app.ActivityManager
import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.colablive.keeper.core.ProfileSlots

class ProfilePickerActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    private fun render() {
        val padding = (16 * resources.displayMetrics.density).toInt()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(padding, padding, padding, padding)
        }

        layout.addView(TextView(this).apply {
            text = "${ProfileSlots.SLOT_COUNT + 1} khe dùng ĐỒNG THỜI được (khe 0 = cửa sổ chính). " +
                "Gán profile bất kỳ vào khe bất kỳ — đổi gán chỉ khởi động lại đúng khe đó."
            textSize = 16f
        })

        for (slotIndex in 0..ProfileSlots.SLOT_COUNT) {
            val assigned = ProfileSlots.getSlotAssignmentDisplay(this, slotIndex)
            // BUG THẬT đã sửa: row trước đây là LinearLayout HORIZONTAL không
            // có LayoutParams/weight nào cả. Nút "Khe X: ..." có text dài
            // (nhất là khi chưa gán, ví dụ "CHƯA GÁN HỒ SƠ — DỮ LIỆU RIÊNG
            // CỦA KHE CHÍNH") tự đo wrap_content rộng HƠN cả màn hình, đẩy
            // nút "Đổi" ra ngoài lề phải, KHÔNG hiển thị — người dùng không
            // có cách nào bấm vào "Đổi" để gán profile, chỉ bấm được đúng
            // nút mở khe. Sửa bằng weight: nút chính co giãn vừa khung hình
            // còn lại (weight=1, width=0dp), nút "Đổi" giữ nguyên kích thước
            // tự nhiên (weight=0) nên luôn hiển thị đủ trên mọi màn hình.
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
            }
            row.addView(Button(this).apply {
                text = "Khe $slotIndex: $assigned"
                setOnClickListener { openSlot(slotIndex) }
                layoutParams = LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f
                )
            })
            row.addView(Button(this).apply {
                text = "Đổi"
                setOnClickListener { showReassignDialog(slotIndex) }
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
                )
            })
            layout.addView(row)
        }

        layout.addView(TextView(this).apply {
            text = "\nCác profile đã tạo:"
            textSize = 16f
        })
        layout.addView(TextView(this).apply {
            text = ProfileSlots.listProfiles(this@ProfilePickerActivity).joinToString(", ")
        })

        val newNameInput = EditText(this).apply { hint = "Tên profile mới (vd: Cá nhân, Công việc, KH A...)" }
        layout.addView(newNameInput)
        layout.addView(Button(this).apply {
            text = "Thêm profile mới vào danh sách"
            setOnClickListener {
                val name = newNameInput.text.toString().trim()
                if (name.isNotEmpty()) {
                    ProfileSlots.addProfile(this@ProfilePickerActivity, name)
                    newNameInput.setText("")
                    render()
                }
            }
        })

        setContentView(layout)
    }

    private fun openSlot(slotIndex: Int) {
        val className = ProfileSlots.componentClassNameForSlot(slotIndex)
        startActivity(Intent().apply {
            component = ComponentName(packageName, className)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        })
    }

    // Dialog đơn giản dạng danh sách nút bấm (tránh phụ thuộc thêm thư viện dialog)
    private fun showReassignDialog(slotIndex: Int) {
        val padding = (16 * resources.displayMetrics.density).toInt()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(padding, padding, padding, padding)
        }
        layout.addView(TextView(this).apply { text = "Gán profile nào vào Khe $slotIndex?" })
        val profiles = ProfileSlots.listProfiles(this)
        if (profiles.isEmpty()) {
            layout.addView(TextView(this).apply {
                text = "Chưa có profile nào — tạo 1 cái ở màn hình trước (ô \"Tên profile mới\") rồi quay lại đây."
            })
        }
        for (name in profiles) {
            // BUG THẬT đã sửa: trước đây danh sách này cho gán 1 hồ sơ vào
            // NHIỀU khe cùng lúc, không cảnh báo gì — như trong ảnh chụp
            // màn hình bạn gửi (TEST 1 gán cả Khe 1 lẫn Khe 3). Vì 4 khe
            // chạy SONG SONG thật (xem `GeckoRuntimeProvider`: mỗi khe tự mở
            // 1 `GeckoRuntime` trỏ `-profile` vào ĐÚNG 1 thư mục theo TÊN hồ
            // sơ) — 2 khe cùng gán 1 tên = 2 tiến trình Gecko cùng mở CHUNG 1
            // thư mục hồ sơ CÙNG LÚC. Firefox/Gecko không hỗ trợ 2 instance
            // cùng mở 1 hồ sơ đồng thời (khoá file/lock, dễ lỗi hoặc hỏng
            // cookie/session) — đây không phải lỗi vặt UI, mà là rủi ro
            // HỎNG DỮ LIỆU thật. Chặn hẳn, không cho chọn nữa.
            val usedByOther = ProfileSlots.findOtherSlotUsingProfile(this, slotIndex, name)
            layout.addView(Button(this).apply {
                text = if (usedByOther != null) "⚠️ $name (đang chạy ở Khe $usedByOther — không thể gán trùng)" else name
                if (usedByOther != null) {
                    isEnabled = false
                } else {
                    setOnClickListener {
                        ProfileSlots.setSlotAssignment(this@ProfilePickerActivity, slotIndex, name)
                        restartSlot(slotIndex)
                    }
                }
            })
        }
        layout.addView(Button(this).apply {
            text = "— Bỏ gán (dùng dữ liệu riêng của khe, không chung profile) —"
            setOnClickListener {
                ProfileSlots.unassignSlot(this@ProfilePickerActivity, slotIndex)
                restartSlot(slotIndex)
            }
        })
        // Tính năng MỚI — trả lời đúng câu hỏi "khe mở ra mà chưa có profile
        // nào thì làm sao đặt tên cho profile đang mở trong khe": khe CHƯA
        // TỪNG gán hồ sơ vẫn có dữ liệu riêng (cookie/đăng nhập) nằm trong
        // namespace nội bộ `__slot_default_N` — trước đây KHÔNG có cách nào
        // biến dữ liệu đó thành 1 hồ sơ có tên (chỉ có cách tạo hồ sơ MỚI
        // TRẮNG rồi gán, mất hết dữ liệu cũ). Chỉ hiện nút này khi khe CHƯA
        // gán hồ sơ nào (mới có dữ liệu "mồ côi" cần đặt tên).
        val isUnassigned = ProfileSlots.getSlotAssignmentDisplay(this, slotIndex).startsWith("(chưa gán hồ sơ")
        if (isUnassigned) {
            layout.addView(TextView(this).apply {
                text = "\nKhe này CHƯA gán hồ sơ nào nhưng có thể đã có dữ liệu " +
                    "riêng (cookie/đăng nhập). Đặt tên cho dữ liệu đó để dùng " +
                    "lại/di chuyển được như hồ sơ khác:"
                textSize = 13f
            })
            val promoteInput = EditText(this).apply { hint = "Tên hồ sơ mới cho dữ liệu đang có trong Khe $slotIndex" }
            layout.addView(promoteInput)
            layout.addView(Button(this).apply {
                text = "Đặt tên cho dữ liệu đang có trong khe này"
                setOnClickListener {
                    val newName = promoteInput.text.toString().trim()
                    when {
                        newName.isEmpty() ->
                            android.widget.Toast.makeText(this@ProfilePickerActivity, "Chưa nhập tên", android.widget.Toast.LENGTH_SHORT).show()
                        newName.startsWith("__slot_default_") ->
                            android.widget.Toast.makeText(this@ProfilePickerActivity, "Tên không hợp lệ", android.widget.Toast.LENGTH_SHORT).show()
                        ProfileSlots.listProfiles(this@ProfilePickerActivity).contains(newName) ->
                            android.widget.Toast.makeText(this@ProfilePickerActivity, "Tên này đã tồn tại — chọn tên khác", android.widget.Toast.LENGTH_SHORT).show()
                        else -> {
                            ProfileSlots.schedulePromoteSlotData(this@ProfilePickerActivity, slotIndex, newName)
                            restartSlot(slotIndex)
                        }
                    }
                }
            })
        }
        setContentView(layout)
    }

    /**
     * Khởi động lại ĐÚNG 1 khe (không đụng các khe khác đang chạy).
     * Khe 0 (chính) là process đang chạy chính activity này -> phải tự kill+relaunch.
     * Khe khác -> kill process của khe đó qua ActivityManager rồi mở lại.
     */
    private fun restartSlot(slotIndex: Int) {
        if (slotIndex == 0) {
            val relaunch = packageManager.getLaunchIntentForPackage(packageName)?.apply {
                addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(relaunch)
            Runtime.getRuntime().exit(0)
        } else {
            val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
            val targetProcessName = "$packageName:slot$slotIndex"
            am.runningAppProcesses
                ?.firstOrNull { it.processName == targetProcessName }
                ?.let { android.os.Process.killProcess(it.pid) }
            /**
             * BUG THẬT đã sửa — nguyên nhân crash "IllegalStateException: Only
             * one GeckoRuntime instance is allowed" (crash log gửi lên):
             * `killProcess()` chỉ GỬI tín hiệu kill cho hệ thống, KHÔNG đảm
             * bảo process đó (và GeckoRuntime native bên trong — dọn dẹp
             * IPC/socket/luồng native KHÔNG tức thời) đã thật sự chết xong.
             * Trước đây gọi `openSlot()` NGAY sau `killProcess()` — nếu
             * process cũ chưa kịp chết hẳn, hệ thống có thể gắn Activity MỚI
             * vào process CŨ (chưa chết) thay vì tạo process sạch mới → 2 lần
             * gọi GeckoRuntime.create() trong CÙNG 1 process → crash ngay
             * (Gecko chỉ cho phép ĐÚNG 1 instance mỗi process, không phải mỗi
             * khe). Đây cũng là nguyên nhân hiện tượng "mở lại thấy restart
             * lặp lại liên tục" trong log — mỗi lần crash, tiến trình chung
             * (bao gồm Khe 0 + các service nền) có thể bị kéo chết theo, tạo
             * cảm giác "đóng 1 cái là đóng cả trình duyệt".
             *
             * Sửa: đợi xác nhận process cũ THẬT SỰ biến mất khỏi
             * `runningAppProcesses` (kiểm tra mỗi 100ms, tối đa ~1.5 giây) rồi
             * mới mở lại — nếu quá 1.5 giây vẫn chưa xác nhận được thì vẫn mở
             * (không treo vô thời hạn), nhưng thực tế process chết nhanh hơn
             * nhiều so với mốc này.
             */
            waitForProcessDeathThenOpen(targetProcessName, slotIndex)
            render()
            return
        }
        render()
    }

    private fun waitForProcessDeathThenOpen(targetProcessName: String, slotIndex: Int, attemptsLeft: Int = 15) {
        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        val stillAlive = am.runningAppProcesses?.any { it.processName == targetProcessName } == true
        if (!stillAlive || attemptsLeft <= 0) {
            openSlot(slotIndex)
            return
        }
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
            waitForProcessDeathThenOpen(targetProcessName, slotIndex, attemptsLeft - 1)
        }, 100L)
    }
}
