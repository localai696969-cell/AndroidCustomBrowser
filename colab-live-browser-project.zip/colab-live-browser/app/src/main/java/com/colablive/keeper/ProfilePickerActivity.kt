package com.colablive.keeper

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.*
import com.colablive.keeper.core.ProfileSlots

class ProfilePickerActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 16, 16, 16)
        }

        val title = TextView(this).apply {
            text = "Chon Khe Profile"
            textSize = 20f
            setPadding(0, 0, 0, 16)
        }
        container.addView(title)

        for (slotIndex in 0 until ProfileSlots.SLOT_COUNT) {
            val slotName = ProfileSlots.getSlotName(slotIndex)
            val profiles = ProfileSlots.listProfiles()
            val assignedProfile = ProfileSlots.getSlotAssignment(slotIndex)
            val currentProfile = profiles.find { it.id == assignedProfile }?.name ?: "Mac dinh"

            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, 8, 0, 8)
            }

            val label = TextView(this).apply {
                text = "$slotName: $currentProfile"
                textSize = 16f
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            row.addView(label)

            val spinner = Spinner(this)
            val profileNames = profiles.map { it.name }
            val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, profileNames)
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            spinner.adapter = adapter
            spinner.setSelection(profiles.indexOfFirst { it.id == assignedProfile }.coerceAtLeast(0))
            spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>, view: View, position: Int, id: Long) {
                    val selectedProfile = profiles[position]
                    ProfileSlots.setSlotAssignment(slotIndex, selectedProfile.id)
                }
                override fun onNothingSelected(parent: AdapterView<*>) {}
            }
            row.addView(spinner)

            val clearBtn = Button(this).apply {
                text = "Xoa"
                setOnClickListener {
                    ProfileSlots.clearSlot(this@ProfilePickerActivity, slotIndex)
                    label.text = "$slotName: Mac dinh"
                }
            }
            row.addView(clearBtn)

            container.addView(row)
        }

        val addProfileBtn = Button(this).apply {
            text = "+ Them Profile"
            setOnClickListener { showAddProfileDialog() }
        }
        container.addView(addProfileBtn)

        setContentView(container)
    }

    private fun showAddProfileDialog() {
        val input = EditText(this).apply {
            hint = "Ten profile"
        }
        AlertDialog.Builder(this)
            .setTitle("Them Profile")
            .setView(input)
            .setPositiveButton("Them") { _, _ ->
                val name = input.text.toString()
                if (name.isNotEmpty()) {
                    ProfileSlots.addProfile(name, 0)
                    recreate()
                }
            }
            .setNegativeButton("Huy", null)
            .show()
    }

    companion object {
        fun launch(activity: Activity) {
            val intent = Intent(activity, ProfilePickerActivity::class.java)
            activity.startActivity(intent)
        }
    }
}
