package com.colablive.keeper

import android.app.ActivityManager
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.colablive.keeper.core.CrashBreadcrumb
import com.colablive.keeper.core.DebugLog
import com.colablive.keeper.core.ProfileExportImport
import com.colablive.keeper.core.ProfileSlots

class ProfilePickerActivity : AppCompatActivity() {

    // Nhớ đang XUẤT hồ sơ nào — cần dùng lại khi onActivityResult() trả về
    // (sau khi người dùng chọn xong nơi lưu file qua SAF).
    private var pendingExportProfileName: String? = null
    // FIX MỚI (xem PROJECT_STATUS.md mục 10) — lưu lại khe cần đóng SAU KHI
    // có URI từ SAF picker (đảo thứ tự so với trước, xem chú thích đầy đủ
    // ở nút export)
    private var pendingExportRunningSlot: Int? = null

    companion object {
        private const val REQUEST_EXPORT = 1001
        private const val REQUEST_IMPORT = 1002
    }

    /**
     * Nhận kết quả từ `ExportBackupService` (chạy trong Foreground Service
     * thật, xem chú thích đầy đủ ở file đó — thay cho Thread trần trước
     * đây gây bug "backup 0B" khi hệ thống giết tiến trình giữa chừng).
     * Đăng ký ở `onCreate`/gỡ ở `onDestroy` (không phải onResume/onPause)
     * vì việc export có thể mất nhiều phút với hồ sơ nặng — Activity có
     * thể bị xoay màn hình/onPause tạm thời trong lúc đó, không muốn mất
     * broadcast nếu đúng lúc đó activity đang onPause.
     */
    private val exportDoneReceiver = object : android.content.BroadcastReceiver() {
        override fun onReceive(context: android.content.Context?, intent: Intent?) {
            // Nhận được broadcast này (dù thành công hay lỗi) nghĩa là đã
            // qua khỏi bước rủi ro an toàn — xoá breadcrumb (xem CrashBreadcrumb.kt)
            com.colablive.keeper.core.CrashBreadcrumb.clear(this@ProfilePickerActivity)
            val name = intent?.getStringExtra(ExportBackupService.EXTRA_PROFILE_NAME) ?: "?"
            val success = intent?.getBooleanExtra(ExportBackupService.EXTRA_SUCCESS, false) ?: false
            val error = intent?.getStringExtra(ExportBackupService.EXTRA_ERROR)
            val skippedFiles = intent?.getStringArrayExtra(ExportBackupService.EXTRA_SKIPPED_FILES)?.toList() ?: emptyList()
            val entriesWritten = intent?.getIntExtra(ExportBackupService.EXTRA_ENTRIES_WRITTEN, 0) ?: 0
            val bytesWritten = intent?.getLongExtra(ExportBackupService.EXTRA_BYTES_WRITTEN, 0L) ?: 0L
            if (success) {
                // FIX MỚI (mục 15) — tổng kết ĐẦY ĐỦ theo đúng yêu cầu: "cái
                // gì xuất thiếu, cái gì xuất rồi" — hiện rõ tổng số file +
                // dung lượng ĐÃ xuất, và TÊN CHÍNH XÁC từng file bị bỏ qua
                // (không chỉ số lượng như trước). Nội dung cảnh báo đã sửa
                // theo đúng hiểu biết ở mục 12 (SQLite WAL an toàn để copy
                // khi đang mở — không còn khuyến cáo đóng khe nữa, vì rủi
                // ro thật chỉ là 1 thao tác ghi cuối cùng dang dở, không
                // phải mất cả phiên đăng nhập).
                val bytesReadable = when {
                    bytesWritten >= 1_000_000 -> "%.1f MB".format(bytesWritten / 1_000_000.0)
                    bytesWritten >= 1_000 -> "%.1f KB".format(bytesWritten / 1_000.0)
                    else -> "$bytesWritten byte"
                }
                if (skippedFiles.isNotEmpty()) {
                    AlertDialog.Builder(this@ProfilePickerActivity)
                        .setTitle("Xuất '$name' xong")
                        .setMessage(
                            "Đã xuất: $entriesWritten file, $bytesReadable.\n\n" +
                                "Bỏ qua ${skippedFiles.size} file (đúng lúc đang ghi dở khi đọc):\n" +
                                skippedFiles.joinToString("\n") { "• $it" } +
                                "\n\nRủi ro thật rất nhỏ: SQLite (Gecko dùng) an toàn để sao chép " +
                                "kể cả khi đang mở — nhiều nhất chỉ mất đúng 1 thao tác ghi cuối " +
                                "cùng trùng đúng khoảnh khắc xuất, không phải mất cả phiên đăng nhập."
                        )
                        .setPositiveButton("Đã hiểu", null)
                        .show()
                } else {
                    Toast.makeText(this@ProfilePickerActivity, "Xuất '$name' xong: $entriesWritten file, $bytesReadable.", Toast.LENGTH_LONG).show()
                }
            } else {
                Toast.makeText(this@ProfilePickerActivity, "Xuất lỗi: $error", Toast.LENGTH_LONG).show()
            }
            render()
        }
    }

    /**
     * FIX BUG THẬT (mirror `exportDoneReceiver` — xem chú thích đầy đủ ở
     * `ImportBackupService.kt`): trước đây `doImportActual()` tự xử lý
     * kết quả import ngay trong `runOnUiThread {}` của chính Thread trần
     * đó — giờ import chạy trong Service riêng, kết quả phải nhận qua
     * broadcast giống hệt cách export đã làm.
     */
    private val importDoneReceiver = object : android.content.BroadcastReceiver() {
        override fun onReceive(context: android.content.Context?, intent: Intent?) {
            com.colablive.keeper.core.CrashBreadcrumb.clear(this@ProfilePickerActivity)
            val name = intent?.getStringExtra(ImportBackupService.EXTRA_PROFILE_NAME) ?: "?"
            val success = intent?.getBooleanExtra(ImportBackupService.EXTRA_SUCCESS, false) ?: false
            val error = intent?.getStringExtra(ImportBackupService.EXTRA_ERROR)
            if (success) {
                Toast.makeText(this@ProfilePickerActivity, "Nhập '$name' xong — vào \"Đổi\" ở 1 khe để gán và dùng.", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this@ProfilePickerActivity, "Nhập lỗi: $error", Toast.LENGTH_LONG).show()
                DebugLog.log("Import profile lỗi: $error")
            }
            render()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        androidx.core.content.ContextCompat.registerReceiver(
            this, exportDoneReceiver,
            android.content.IntentFilter(ExportBackupService.ACTION_EXPORT_DONE),
            androidx.core.content.ContextCompat.RECEIVER_NOT_EXPORTED
        )
        androidx.core.content.ContextCompat.registerReceiver(
            this, importDoneReceiver,
            android.content.IntentFilter(ImportBackupService.ACTION_IMPORT_DONE),
            androidx.core.content.ContextCompat.RECEIVER_NOT_EXPORTED
        )
        render()
    }

    override fun onDestroy() {
        try { unregisterReceiver(exportDoneReceiver) } catch (e: Exception) { /* đã gỡ rồi, bỏ qua */ }
        try { unregisterReceiver(importDoneReceiver) } catch (e: Exception) { /* đã gỡ rồi, bỏ qua */ }
        super.onDestroy()
    }

    private fun render() {
        val padding = (16 * resources.displayMetrics.density).toInt()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(padding, padding, padding, padding)
        }

        layout.addView(TextView(this).apply {
            text = "${ProfileSlots.SLOT_COUNT + 1} khe dùng ĐỒNG THỜI được (khe 0 = cửa sổ chính). " +
                "Gán profile bất kỳ vào khe bất kỳ — đổi gán chỉ khởi động lại đúng khe đó."
            textSize = 16f
        })

        for (slotIndex in 0..ProfileSlots.SLOT_COUNT) {
            val assigned = ProfileSlots.getSlotAssignmentDisplay(this, slotIndex)
            // BUG THẬT đã sửa: row trước đây là LinearLayout HORIZONTAL không
            // có LayoutParams/weight nào cả. Nút "Khe X: ..." có text dài
            // (nhất là khi chưa gán, ví dụ "CHƯA GÁN HỒ SƠ — DỮ LIỆU RIÊNG
            // CỦA KHE CHÍNH") tự đo wrap_content rộng HƠN cả màn hình, đẩy
            // nút "Đổi" ra ngoài lề phải, KHÔNG hiển thị — người dùng không
            // có cách nào bấm vào "Đổi" để gán profile, chỉ bấm được đúng
            // nút mở khe. Sửa bằng weight: nút chính co giãn vừa khung hình
            // còn lại (weight=1, width=0dp), nút "Đổi" giữ nguyên kích thước
            // tự nhiên (weight=0) nên luôn hiển thị đủ trên mọi màn hình.
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
            }
            row.addView(Button(this).apply {
                text = "Khe $slotIndex: $assigned"
                setOnClickListener { openSlot(slotIndex) }
                layoutParams = LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f
                )
            })
            row.addView(Button(this).apply {
                text = "Đổi"
                setOnClickListener { showReassignDialog(slotIndex) }
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
                )
            })
            layout.addView(row)
        }

        layout.addView(TextView(this).apply {
            text = "\nCác profile đã tạo:"
            textSize = 16f
        })
        layout.addView(TextView(this).apply {
            text = ProfileSlots.listProfiles(this@ProfilePickerActivity).joinToString(", ")
        })

        val newNameInput = EditText(this).apply { hint = "Tên profile mới (vd: Cá nhân, Công việc, KH A...)" }
        layout.addView(newNameInput)
        layout.addView(Button(this).apply {
            text = "Thêm profile mới vào danh sách"
            setOnClickListener {
                val name = newNameInput.text.toString().trim()
                if (name.isNotEmpty()) {
                    ProfileSlots.addProfile(this@ProfilePickerActivity, name)
                    newNameInput.setText("")
                    render()
                }
            }
        })

        // TÍNH NĂNG MỚI — trả lời câu hỏi "mỗi profile là 1 dữ liệu độc
        // lập... có restore được khi gỡ cài lại, hoặc mang qua máy khác
        // không". Trước đây KHÔNG — dữ liệu chỉ nằm trong bộ nhớ riêng của
        // app, Android tự xoá khi gỡ cài, không có cách nào lấy ra. Giờ có
        // thể xuất 1 hồ sơ ra file .zip (chọn nơi lưu tuỳ ý — Tải xuống,
        // Google Drive, thẻ nhớ...) rồi nhập lại — kể cả trên máy khác, hay
        // sau khi gỡ cài lại app. Xem `ProfileExportImport.kt`.
        layout.addView(TextView(this).apply {
            text = "\nSao lưu / khôi phục hồ sơ (mang qua máy khác, hoặc giữ lại khi gỡ cài app):"
            textSize = 14f
        })
        val exportRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        exportRow.addView(Button(this).apply {
            text = "Xuất hồ sơ ra file..."
            setOnClickListener { showExportChooserDialog() }
        })
        exportRow.addView(Button(this).apply {
            text = "Nhập hồ sơ từ file..."
            setOnClickListener {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "application/zip"
                }
                startActivityForResult(intent, REQUEST_IMPORT)
            }
        })
        layout.addView(exportRow)

        // TÍNH NĂNG MỚI — người dùng yêu cầu: nút xoá hẳn 1 hồ sơ (khác với
        // ghi đè/nhập — đây là XOÁ VĨNH VIỄN dữ liệu hồ sơ khỏi máy, dùng
        // khi không cần hồ sơ đó nữa, ví dụ hồ sơ test hoặc khách hàng đã
        // xong việc). Xoá gồm: xoá thư mục dữ liệu Gecko thật (cookies,
        // lịch sử, bookmark, tab đã lưu — TẤT CẢ đều nằm chung 1 thư mục
        // `gecko_profile_<tên>` — xem `safeDirNameFor` dùng chung 4 nơi:
        // GeckoRuntimeProvider/BrowserBookmarks/BrowserHistory/ProfileExportImport),
        // xoá khỏi danh sách hồ sơ đã lưu, và gỡ gán khỏi bất kỳ khe nào
        // đang trỏ tới nó (khe đó quay về hồ sơ mặc định riêng, KHÔNG xoá
        // nhầm dữ liệu khe khác). AN TOÀN: nếu hồ sơ đang được 1 khe THẬT
        // SỰ chạy (tiến trình sống), đóng khe đàng hoàng (tái dùng đúng
        // `closeSlotGracefullyThen` đã kiểm chứng) TRƯỚC khi xoá — tránh
        // đúng lớp bug đã từng xảy ra ở ghi đè (xoá thư mục ngay dưới chân
        // 1 tiến trình đang mở file).
        layout.addView(TextView(this).apply {
            text = "\nXoá hồ sơ (KHÔNG thể hoàn tác — cân nhắc xuất ra file trước nếu cần giữ lại):"
            textSize = 14f
        })
        layout.addView(Button(this).apply {
            text = "Xoá hồ sơ..."
            setOnClickListener { showDeleteProfileChooserDialog() }
        })

        setContentView(layout)
    }

    private fun showDeleteProfileChooserDialog() {
        val padding = (16 * resources.displayMetrics.density).toInt()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(padding, padding, padding, padding)
        }
        layout.addView(TextView(this).apply { text = "Xoá hồ sơ nào? (không thể hoàn tác)" })
        val profiles = ProfileSlots.listProfiles(this)
        if (profiles.isEmpty()) {
            layout.addView(TextView(this).apply { text = "Chưa có hồ sơ nào để xoá." })
        }
        val dialogRef = arrayOfNulls<AlertDialog>(1)
        for (name in profiles) {
            layout.addView(Button(this).apply {
                text = name
                setOnClickListener {
                    dialogRef[0]?.dismiss()
                    confirmAndDeleteProfile(name)
                }
            })
        }
        dialogRef[0] = AlertDialog.Builder(this)
            .setTitle("Xoá hồ sơ")
            .setView(layout)
            .setNegativeButton("Đóng", null)
            .show()
    }

    private fun confirmAndDeleteProfile(name: String) {
        AlertDialog.Builder(this)
            .setTitle("Xác nhận xoá '$name'")
            .setMessage("Toàn bộ dữ liệu hồ sơ này (lịch sử, cookie/đăng nhập, bookmark, tab đã lưu) sẽ bị XOÁ VĨNH VIỄN khỏi máy — không thể hoàn tác. Vẫn xoá?")
            .setPositiveButton("Xoá") { _, _ -> deleteProfileNow(name) }
            .setNegativeButton("Huỷ", null)
            .show()
    }

    private fun deleteProfileNow(name: String) {
        DebugLog.log("ProfilePickerActivity: nút XOÁ hồ sơ '$name' được xác nhận — bắt đầu xử lý")
        val runningSlot = (0..ProfileSlots.SLOT_COUNT).firstOrNull {
            ProfileSlots.getSlotAssignment(this@ProfilePickerActivity, it) == name
        }
        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        val processAlive = runningSlot != null && am.runningAppProcesses?.any {
            it.processName == (if (runningSlot == 0) packageName else "$packageName:slot$runningSlot")
        } == true
        DebugLog.log("ProfilePickerActivity: xoá '$name' — runningSlot=$runningSlot processAlive=$processAlive (nếu processAlive=true, đóng khe đàng hoàng trước rồi mới xoá)")
        if (processAlive && runningSlot != null) {
            Toast.makeText(this, "Đang đóng Khe $runningSlot trước khi xoá...", Toast.LENGTH_SHORT).show()
            closeSlotGracefullyThen(runningSlot, "XOÁ hồ sơ '$name'") { doDeleteProfileActual(name) }
        } else {
            doDeleteProfileActual(name)
        }
    }

    private fun doDeleteProfileActual(name: String) {
        // FIX MỚI (mục 13) — bằng chứng thật từ log: xoá hồ sơ crash native
        // ngay cả sau khi đã có 700ms settle delay (mục 9), trong khi import
        // (chỉ xoá thư mục Gecko thật SAU 10-15s giải nén) luôn sống sót.
        // Tăng thêm độ trễ TRƯỚC KHI đụng vào đúng thư mục Gecko vừa
        // shutdown — mitigation dựa trên bằng chứng so sánh chéo thật,
        // không phải đoán mù. CHƯA CHẮC ĐỦ — cần log lần tới xác nhận.
        DebugLog.log("ProfilePickerActivity: xoá '$name' — chờ thêm 2500ms trước khi đụng vào thư mục Gecko thật (mitigation dựa trên bằng chứng so sánh với import, xem PROJECT_STATUS.md mục 13)")
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
            try {
                val ok = ProfileSlots.deleteProfileCompletely(this, name)
                com.colablive.keeper.core.CrashBreadcrumb.clear(this)
                if (ok) {
                    DebugLog.log("ProfilePickerActivity: xoá '$name' HOÀN TẤT")
                    Toast.makeText(this, "Đã xoá '$name'.", Toast.LENGTH_LONG).show()
                } else {
                    DebugLog.log("ProfilePickerActivity: xoá '$name' — không tìm thấy thư mục dữ liệu (có thể đã trống từ trước), vẫn gỡ khỏi danh sách")
                    Toast.makeText(this, "Đã gỡ '$name' khỏi danh sách (không có dữ liệu để xoá).", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                DebugLog.log("ProfilePickerActivity: xoá '$name' LỖI — ${e.javaClass.simpleName}: ${e.message}")
                Toast.makeText(this, "Xoá lỗi: ${e.message}", Toast.LENGTH_LONG).show()
            }
            render()
        }, 2500L)

    }

    private fun showExportChooserDialog() {
        val padding = (16 * resources.displayMetrics.density).toInt()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(padding, padding, padding, padding)
        }
        layout.addView(TextView(this).apply { text = "Xuất hồ sơ nào?" })
        val profiles = ProfileSlots.listProfiles(this)
        if (profiles.isEmpty()) {
            layout.addView(TextView(this).apply { text = "Chưa có hồ sơ nào để xuất." })
        }
        for (name in profiles) {
            layout.addView(Button(this).apply {
                text = name
                setOnClickListener {
                    /**
                     * FIX THIẾU LOG (người dùng báo: "đã bấm export rồi mà
                     * log không bắt được gì" — đúng, có 1 khoảng "hộp đen"
                     * hoàn toàn không log giữa lúc bấm nút và lúc
                     * ExportBackupService chạy, gồm cả bước
                     * `closeSlotGracefullyThen` có thể mất tới 2s). Thêm
                     * log NGAY từ đây — nếu lần sau vẫn không thấy dòng
                     * này, nghĩa là chính onClickListener KHÔNG được gọi
                     * (lỗi ở tầng UI/click, không phải logic export).
                     */
                    DebugLog.log("ProfilePickerActivity: nút export '$name' được bấm — bắt đầu xử lý")
                    // FIX MỚI, QUAN TRỌNG (xem PROJECT_STATUS.md mục 11) —
                    // BỎ HẲN bước "đóng khe đàng hoàng trước khi export".
                    // Lý do: tra lại toàn bộ lịch sử — cơ chế này (thêm để
                    // Gecko checkpoint WAL, tránh thiếu cookie/đăng nhập MỚI
                    // NHẤT trong file xuất ra) được thêm TRƯỚC session này,
                    // và KHÔNG có bất kỳ log thật nào trong toàn bộ tài liệu
                    // xác nhận export THÀNH CÔNG (có số byte thật > 0) kể từ
                    // khi cơ chế này tồn tại — mọi lần export sau đó đều
                    // hoặc 0B hoặc crash im lặng (kể cả sau khi đảo thứ tự ở
                    // mục 10). Người dùng xác nhận export từng chạy tốt
                    // TRƯỚC — tức là TRƯỚC KHI có cơ chế "đóng khe trước khi
                    // export" này. Đánh đổi: xuất trực tiếp không đóng khe
                    // có thể (hiếm) thiếu đúng thao tác ghi CUỐI CÙNG chưa
                    // kịp checkpoint xuống đĩa (VD phiên đăng nhập vừa xong
                    // trong vài giây gần nhất) — nhưng đây là đánh đổi CHẤP
                    // NHẬN ĐƯỢC so với export hoàn toàn không dùng được.
                    val runningSlot = (0..ProfileSlots.SLOT_COUNT).firstOrNull {
                        ProfileSlots.getSlotAssignment(this@ProfilePickerActivity, it) == name
                    }
                    val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
                    val processAlive = runningSlot != null && am.runningAppProcesses?.any {
                        it.processName == (if (runningSlot == 0) packageName else "$packageName:slot$runningSlot")
                    } == true
                    DebugLog.log("ProfilePickerActivity: export '$name' — runningSlot=$runningSlot processAlive=$processAlive — xuất TRỰC TIẾP (SQLite WAL an toàn để copy khi đang mở — xem PROJECT_STATUS.md mục 12)")
                    if (processAlive) {
                        Toast.makeText(this@ProfilePickerActivity, "Đang xuất '$name' (Khe $runningSlot vẫn đang chạy — SQLite WAL an toàn để sao chép lúc đang mở, chỉ có rủi ro cực nhỏ mất đúng 1 thao tác ghi cuối cùng nếu trùng khoảnh khắc)", Toast.LENGTH_LONG).show()
                    }
                    pendingExportProfileName = name
                    openExportPicker(name)
                }
            })
        }
        setContentView(layout)
    }

    /**
     * Tách riêng bước mở SAF picker chọn nơi lưu file .zip — gọi sau khi
     * đã (nếu cần) đóng khe đàng hoàng xong, hoặc gọi thẳng nếu hồ sơ
     * không hề đang chạy ở khe nào.
     */
    private fun openExportPicker(name: String) {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/zip"
            putExtra(Intent.EXTRA_TITLE, "${name}_backup.zip")
        }
        DebugLog.log("ProfilePickerActivity: openExportPicker('$name') — chuẩn bị startActivityForResult(ACTION_CREATE_DOCUMENT)")
        try {
            startActivityForResult(intent, REQUEST_EXPORT)
        } catch (e: Exception) {
            // Có thể không có app nào xử lý ACTION_CREATE_DOCUMENT (rất hiếm
            // trên Android hiện đại, nhưng ROM tuỳ biến có thể gỡ bỏ) — trước
            // đây sẽ crash im lặng hoặc không rõ lý do, giờ báo rõ.
            DebugLog.log("ProfilePickerActivity: startActivityForResult(ACTION_CREATE_DOCUMENT) LỖI: ${e.javaClass.simpleName}: ${e.message}")
            Toast.makeText(this, "Không mở được hộp thoại chọn nơi lưu: ${e.message}", Toast.LENGTH_LONG).show()
            pendingExportProfileName = null
        }
    }

    /**
     * Đóng 1 khe đàng hoàng rồi mới chạy tiếp `onClosed` — TÁI SỬ DỤNG
     * chính xác cơ chế broadcast + chờ ACK thật đã có ở `restartSlot()`
     * (xem chú thích ở đó: đã từng sửa lỗi đoán mù thời gian 400ms không
     * đủ, giờ luôn đợi tín hiệu ACK thật, có mốc dự phòng 2 giây phòng khe
     * không tự đóng được vì lý do gì đó). Dùng lại y hệt cho mục đích
     * export để đảm bảo Gecko flush + nhả khóa file trước khi nén zip.
     */
    private fun closeSlotGracefullyThen(slotIndex: Int, actionDescription: String, postAckSettleDelayMs: Long = 700L, onClosed: () -> Unit) {
        var handled = false
        // FIX MỚI — mitigation phòng thủ, KHÔNG PHẢI fix triệt để (xem chú
        // thích dài trong PROJECT_STATUS.md mục 9): log thật cho thấy
        // `runtime.shutdown()` TRẢ VỀ BÌNH THƯỜNG (không ném exception),
        // nhưng 2-5 giây SAU ĐÓ cả tiến trình biến mất — không có bất kỳ
        // dòng log lỗi nào, kể cả sau khi đã bọc try/catch quanh code gọi
        // shutdown() (xem mục 8 — ĐÃ XÁC NHẬN SAI VỊ TRÍ, không bắt được gì
        // vì exception không ném ra từ đúng chỗ được bọc). Đây là dấu hiệu
        // gần như chắc chắn của NATIVE crash bên trong chính GeckoView SDK,
        // xảy ra bất đồng bộ SAU khi shutdown() đã trả về — loại lỗi này
        // KHÔNG thể bắt bằng try/catch Kotlin ở bất kỳ đâu trong code app.
        // Thêm 1 khoảng chờ ngắn SAU KHI nhận ACK, TRƯỚC KHI làm việc nặng
        // tiếp theo (giải nén/mở SAF picker) — cho dọn dẹp native của
        // Gecko thêm thời gian ổn định trước khi tiến trình bận việc khác.
        // ĐÂY LÀ MITIGATION, KHÔNG PHẢI FIX CHẮC CHẮN — cần log logcat thật
        // ở mức hệ thống (không phải DebugLog của app) mới xác nhận được
        // nguyên nhân gốc chính xác.
        //
        // FIX MỚI (mục 19) — BẰNG CHỨNG THẬT xác nhận: crash lúc ghi đè
        // xảy ra NGAY TRONG lúc chờ 700ms này — TRƯỚC CẢ khi code chạm tới
        // bất kỳ file import nào (breadcrumb ghi rõ "GHI ĐÈ hồ sơ X", rồi
        // im lặng, không hề có dòng "BẮT ĐẦU import" tiếp theo). Vậy rủi ro
        // KHÔNG liên quan tới việc code đụng thư mục Gecko sớm hay muộn —
        // mà liên quan tới việc GHI ĐÈ ĐÚNG hồ sơ ĐANG CHẠY trong CHÍNH khe
        // đó (native cleanup của Gecko cho đúng profile vừa dùng cần nhiều
        // thời gian hơn hẳn so với đóng khe bình thường/nhập hồ sơ khác).
        // Cho phép gọi nơi khác truyền độ trễ DÀI HƠN hẳn riêng cho trường
        // hợp này — mặc định vẫn 700ms cho các luồng khác (đã xác nhận ổn
        // định qua rất nhiều log).
        val POST_ACK_SETTLE_DELAY_MS = postAckSettleDelayMs
        // FIX MỚI (mục 18) — trước đây breadcrumb chỉ ghi tên hàm chung
        // chung ("closeSlotGracefullyThen"), KHÔNG ghi rõ đang chuẩn bị làm
        // gì (import ghi đè hồ sơ nào, xoá hồ sơ nào...). Khi crash xảy ra
        // NGAY TRONG bước đóng khe (trước cả khi kịp log "BẮT ĐẦU import"),
        // hoàn toàn KHÔNG có cách nào biết được đây là lượt ghi đè hay xoá
        // hay gì khác — đúng tình huống đang gặp phải (nhiều log không có
        // dòng "nút X được bấm" ngay trước crash). Giờ truyền thẳng mô tả
        // hành động cụ thể vào breadcrumb — lần crash tiếp theo (nếu có)
        // sẽ biết CHÍNH XÁC đang định làm gì.
        CrashBreadcrumb.write(this, "closeSlotGracefullyThen slot=$slotIndex — chuẩn bị: $actionDescription")
        val ackReceiver = object : android.content.BroadcastReceiver() {
            override fun onReceive(context: android.content.Context?, intent: Intent?) {
                if (handled) return
                handled = true
                try { unregisterReceiver(this) } catch (e: Exception) { /* đã gỡ rồi, bỏ qua */ }
                DebugLog.log("ProfilePickerActivity: nhận ACK đóng khe $slotIndex — chờ thêm ${POST_ACK_SETTLE_DELAY_MS}ms cho dọn dẹp native ổn định trước khi tiếp tục (mitigation, xem PROJECT_STATUS.md mục 9)")
                CrashBreadcrumb.write(this@ProfilePickerActivity, "closeSlotGracefullyThen slot=$slotIndex — ĐÃ nhận ACK, đang chờ settle rồi thực hiện: $actionDescription")
                android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({ onClosed() }, POST_ACK_SETTLE_DELAY_MS)
            }
        }
        androidx.core.content.ContextCompat.registerReceiver(
            this, ackReceiver,
            android.content.IntentFilter(ProfileSlots.gracefulCloseAckAction(slotIndex)),
            androidx.core.content.ContextCompat.RECEIVER_NOT_EXPORTED
        )
        sendBroadcast(Intent(ProfileSlots.gracefulCloseAction(slotIndex)).apply {
            setPackage(packageName)
        })
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
            if (!handled) {
                handled = true
                try { unregisterReceiver(ackReceiver) } catch (e: Exception) { /* đã gỡ rồi, bỏ qua */ }
                DebugLog.log("ProfilePickerActivity: Khe $slotIndex không gửi ACK đóng khe trong 2s — vẫn tiếp tục export, có thể vài file mới nhất bị bỏ qua nếu khe thật sự chưa đóng xong")
                CrashBreadcrumb.write(this@ProfilePickerActivity, "closeSlotGracefullyThen slot=$slotIndex — TIMEOUT 2s không có ACK, vẫn tiếp tục thực hiện: $actionDescription")
                onClosed()
            }
        }, 2000L)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        // BUG THẬT đã tìm ra (người dùng báo: "export profile hình như bị
        // lỗi, không xuất được nữa" — không kèm thông báo lỗi cụ thể nào):
        // nhánh này TRƯỚC ĐÂY hoàn toàn IM LẶNG khi hộp thoại SAF (chọn nơi
        // lưu file .zip cho export, hoặc chọn file .zip nguồn cho import)
        // không trả về RESULT_OK — kể cả người dùng vô tình bấm ra ngoài
        // làm mất hộp thoại, hay hộp thoại không mở lên đúng lúc do đang ở
        // giữa quá trình đóng khe đàng hoàng (`closeSlotGracefullyThen`
        // chạy TRƯỚC `openExportPicker`, có độ trễ tới 2s) — người dùng chỉ
        // thấy "bấm export xong không có gì xảy ra", KHÔNG có cách nào biết
        // đây là do họ (vô tình) huỷ hộp thoại hay do lỗi thật. Việc export
        // NÉM EXCEPTION thật (VD lỗi ghi file, hết dung lượng) đã có toast
        // báo đầy đủ từ trước (nhánh `result.isSuccess` bên dưới) — không
        // đụng vào nhánh đó, chỉ thêm phản hồi cho nhánh im lặng này.
        if (resultCode != RESULT_OK || data?.data == null) {
            com.colablive.keeper.core.CrashBreadcrumb.clear(this)
            val what = if (requestCode == REQUEST_EXPORT) "xuất hồ sơ" else "nhập hồ sơ"
            DebugLog.log("ProfilePickerActivity: onActivityResult($requestCode) không trả về RESULT_OK (resultCode=$resultCode, data.data=${data?.data}) — coi là người dùng đã huỷ bước chọn nơi lưu/file")
            Toast.makeText(this, "Đã huỷ $what (không chọn nơi lưu/file).", Toast.LENGTH_SHORT).show()
            pendingExportProfileName = null
            render()
            return
        }
        val uri: Uri = data.data!!
        when (requestCode) {
            REQUEST_EXPORT -> {
                val name = pendingExportProfileName
                pendingExportProfileName = null
                pendingExportRunningSlot = null // không còn dùng, giữ field lại phòng revert sau nhưng luôn null
                if (name == null) { render(); return }
                Toast.makeText(this, "Đang xuất '$name'...", Toast.LENGTH_SHORT).show()
                /**
                 * FIX BUG THẬT "backup profile 0B" (bản vá trước — WakeLock
                 * trên Thread trần — không đủ, xem chú thích đầy đủ ở
                 * ExportBackupService.kt): chuyển việc nén zip vào Foreground
                 * Service thật, Android không được phép giết tiến trình
                 * đang có foreground service giữa chừng. Kết quả trả về qua
                 * broadcast `exportDoneReceiver` (đăng ký ở onCreate), không
                 * cần runOnUiThread thủ công ở đây nữa.
                 *
                 * FIX MỚI (mục 11) — KHÔNG còn đóng khe trước export nữa
                 * (xem chú thích đầy đủ ở nút export) — xuất trực tiếp
                 * ngay khi có URI, quay về đúng luồng đơn giản đã từng
                 * chạy được trước khi cơ chế "đóng khe trước export" được
                 * thêm vào.
                 */
                ExportBackupService.start(this, name, uri)
            }
            REQUEST_IMPORT -> showImportNameDialog(uri)
        }
    }

    private fun doImport(uri: Uri, name: String, overwrite: Boolean) {
        /**
         * BUG NGHIÊM TRỌNG tự tìm ra (người dùng chỉ đúng: "sửa bug nhỏ
         * thành bug lớn tan nát" — bản vá "cho phép ghi đè" trước đó THIẾU
         * kiểm tra hồ sơ đích có đang được 1 KHE CHẠY THẬT SỰ sử dụng hay
         * không trước khi `targetDir.deleteRecursively()`). Nếu người
         * dùng ghi đè đúng lúc khe đó đang chạy (GeckoRuntime còn giữ file
         * SQLite mở), xoá thư mục ngay dưới chân 1 tiến trình đang hoạt
         * động có thể gây crash/hỏng dữ liệu — NẶNG HƠN NHIỀU so với bug
         * gốc (chỉ là tab list rỗng). Sửa: tái dùng ĐÚNG cơ chế đã có sẵn
         * cho export (`closeSlotGracefullyThen` — đóng khe đàng hoàng qua
         * broadcast+ACK thật, để Gecko tự checkpoint + nhả khoá file trước)
         * — KHÔNG viết logic mới, dùng lại nguyên xi pattern đã kiểm chứng.
         */
        val runningSlot = (0..ProfileSlots.SLOT_COUNT).firstOrNull {
            ProfileSlots.getSlotAssignment(this@ProfilePickerActivity, it) == name
        }
        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        val processAlive = runningSlot != null && am.runningAppProcesses?.any {
            it.processName == (if (runningSlot == 0) packageName else "$packageName:slot$runningSlot")
        } == true
        if (processAlive && runningSlot != null) {
            Toast.makeText(this@ProfilePickerActivity, "Đang đóng Khe $runningSlot trước khi ghi đè (tránh xoá dữ liệu đang mở)...", Toast.LENGTH_SHORT).show()
            closeSlotGracefullyThen(
                runningSlot,
                if (overwrite) "GHI ĐÈ hồ sơ '$name'" else "nhập hồ sơ MỚI '$name'",
                // FIX MỚI (mục 19) — độ trễ DÀI HƠN HẲN riêng cho GHI ĐÈ
                // (4000ms thay vì 700ms mặc định) — xem chú thích đầy đủ ở
                // định nghĩa hàm. Import hồ sơ MỚI vẫn giữ 700ms mặc định
                // (đã xác nhận ổn định qua rất nhiều log thật).
                postAckSettleDelayMs = if (overwrite) 4000L else 700L
            ) { doImportActual(uri, name, overwrite) }
        } else {
            doImportActual(uri, name, overwrite)
        }
    }

    private fun doImportActual(uri: Uri, name: String, overwrite: Boolean) {
        // FIX BUG THẬT (xem chú thích đầy đủ ở ImportBackupService.kt):
        // đổi từ Thread trần (dễ bị hệ thống giết giữa chừng, đặc biệt
        // đúng lúc vừa đóng xong 1 khe — ít activity hiển thị nhất) sang
        // Foreground Service — đúng pattern đã kiểm chứng ở export.
        ImportBackupService.start(this@ProfilePickerActivity, name, uri, overwrite)
    }

    private fun showImportNameDialog(uri: Uri) {
        val padding = (16 * resources.displayMetrics.density).toInt()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(padding, padding, padding, padding)
        }
        layout.addView(TextView(this).apply { text = "Đặt tên cho hồ sơ vừa nhập:" })
        val nameInput = EditText(this).apply { hint = "Tên hồ sơ mới" }
        layout.addView(nameInput)
        layout.addView(Button(this).apply {
            text = "Nhập"
            setOnClickListener {
                val name = nameInput.text.toString().trim()
                when {
                    name.isEmpty() -> Toast.makeText(this@ProfilePickerActivity, "Chưa nhập tên", Toast.LENGTH_SHORT).show()
                    name.startsWith("__slot_default_") -> Toast.makeText(this@ProfilePickerActivity, "Tên không hợp lệ", Toast.LENGTH_SHORT).show()
                    ProfileSlots.listProfiles(this@ProfilePickerActivity).contains(name) -> {
                        /**
                         * BUG THIẾT KẾ THẬT (người dùng chỉ ra đúng, rất gay
                         * gắt và có lý — trước đây chặn CỨNG ở ngay đây,
                         * không cho nhập tên trùng, buộc người dùng phải GỠ
                         * CÀI ĐẶT TOÀN BỘ APP chỉ để test/dùng import — vô
                         * lý cho 1 tính năng "backup/restore"): thay vì chặn
                         * hẳn, hỏi xác nhận GHI ĐÈ — người dùng chủ động
                         * quyết định, không cần xóa gì ở tầng hệ điều hành.
                         */
                        AlertDialog.Builder(this@ProfilePickerActivity)
                            .setTitle("Hồ sơ '$name' đã tồn tại")
                            .setMessage(
                                "Ghi đè? TOÀN BỘ dữ liệu hiện có của hồ sơ '$name' " +
                                    "(cookie, đăng nhập, lịch sử, tab đang mở...) sẽ bị " +
                                    "THAY THẾ HOÀN TOÀN bằng dữ liệu trong file backup " +
                                    "đang nhập — không thể hoàn tác."
                            )
                            .setPositiveButton("Ghi đè") { _, _ -> doImport(uri, name, overwrite = true) }
                            .setNegativeButton("Hủy", null)
                            .show()
                    }
                    else -> doImport(uri, name, overwrite = false)
                }
            }
        })
        setContentView(layout)
    }

    private fun openSlot(slotIndex: Int) {
        val className = ProfileSlots.componentClassNameForSlot(slotIndex)
        startActivity(Intent().apply {
            component = ComponentName(packageName, className)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        })
    }

    // Dialog đơn giản dạng danh sách nút bấm (tránh phụ thuộc thêm thư viện dialog)
    private fun showReassignDialog(slotIndex: Int) {
        val padding = (16 * resources.displayMetrics.density).toInt()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(padding, padding, padding, padding)
        }
        layout.addView(TextView(this).apply { text = "Gán profile nào vào Khe $slotIndex?" })
        val profiles = ProfileSlots.listProfiles(this)
        if (profiles.isEmpty()) {
            layout.addView(TextView(this).apply {
                text = "Chưa có profile nào — tạo 1 cái ở màn hình trước (ô \"Tên profile mới\") rồi quay lại đây."
            })
        }
        for (name in profiles) {
            // BUG THẬT đã sửa: trước đây danh sách này cho gán 1 hồ sơ vào
            // NHIỀU khe cùng lúc, không cảnh báo gì — như trong ảnh chụp
            // màn hình bạn gửi (TEST 1 gán cả Khe 1 lẫn Khe 3). Vì 4 khe
            // chạy SONG SONG thật (xem `GeckoRuntimeProvider`: mỗi khe tự mở
            // 1 `GeckoRuntime` trỏ `-profile` vào ĐÚNG 1 thư mục theo TÊN hồ
            // sơ) — 2 khe cùng gán 1 tên = 2 tiến trình Gecko cùng mở CHUNG 1
            // thư mục hồ sơ CÙNG LÚC. Firefox/Gecko không hỗ trợ 2 instance
            // cùng mở 1 hồ sơ đồng thời (khoá file/lock, dễ lỗi hoặc hỏng
            // cookie/session) — đây không phải lỗi vặt UI, mà là rủi ro
            // HỎNG DỮ LIỆU thật. Chặn hẳn, không cho chọn nữa.
            val usedByOther = ProfileSlots.findOtherSlotUsingProfile(this, slotIndex, name)
            layout.addView(Button(this).apply {
                text = if (usedByOther != null) "⚠️ $name (đang chạy ở Khe $usedByOther — không thể gán trùng)" else name
                if (usedByOther != null) {
                    isEnabled = false
                } else {
                    setOnClickListener {
                        // BUG THẬT đã sửa ("restore profile mất open tabs" —
                        // xem giải thích đầy đủ ở ProfileSlots.schedulePendingReassign):
                        // KHÔNG gọi setSlotAssignment() ngay ở đây nữa — chỉ
                        // LƯU Ý ĐỊNH, để khe cũ kịp lưu ĐÚNG tab của NÓ (theo
                        // assignment CŨ) trước khi assignment đổi, tránh ghi
                        // đè nhầm lên saved_tabs.json của hồ sơ MỚI.
                        ProfileSlots.schedulePendingReassign(this@ProfilePickerActivity, slotIndex, name)
                        restartSlot(slotIndex)
                    }
                }
            })
        }
        layout.addView(Button(this).apply {
            text = "— Bỏ gán (dùng dữ liệu riêng của khe, không chung profile) —"
            setOnClickListener {
                // Cùng lý do/pattern như nhánh "gán hồ sơ có tên" ở trên —
                // xem chú thích đầy đủ ở ProfileSlots.schedulePendingReassign.
                ProfileSlots.schedulePendingReassign(this@ProfilePickerActivity, slotIndex, null)
                restartSlot(slotIndex)
            }
        })
        // Tính năng MỚI — trả lời đúng câu hỏi "khe mở ra mà chưa có profile
        // nào thì làm sao đặt tên cho profile đang mở trong khe": khe CHƯA
        // TỪNG gán hồ sơ vẫn có dữ liệu riêng (cookie/đăng nhập) nằm trong
        // namespace nội bộ `__slot_default_N` — trước đây KHÔNG có cách nào
        // biến dữ liệu đó thành 1 hồ sơ có tên (chỉ có cách tạo hồ sơ MỚI
        // TRẮNG rồi gán, mất hết dữ liệu cũ). Chỉ hiện nút này khi khe CHƯA
        // gán hồ sơ nào (mới có dữ liệu "mồ côi" cần đặt tên).
        val isUnassigned = ProfileSlots.getSlotAssignmentDisplay(this, slotIndex).startsWith("(chưa gán hồ sơ")
        if (isUnassigned) {
            layout.addView(TextView(this).apply {
                text = "\nKhe này CHƯA gán hồ sơ nào nhưng có thể đã có dữ liệu " +
                    "riêng (cookie/đăng nhập). Đặt tên cho dữ liệu đó để dùng " +
                    "lại/di chuyển được như hồ sơ khác:"
                textSize = 13f
            })
            val promoteInput = EditText(this).apply { hint = "Tên hồ sơ mới cho dữ liệu đang có trong Khe $slotIndex" }
            layout.addView(promoteInput)
            layout.addView(Button(this).apply {
                text = "Đặt tên cho dữ liệu đang có trong khe này"
                setOnClickListener {
                    val newName = promoteInput.text.toString().trim()
                    when {
                        newName.isEmpty() ->
                            android.widget.Toast.makeText(this@ProfilePickerActivity, "Chưa nhập tên", android.widget.Toast.LENGTH_SHORT).show()
                        newName.startsWith("__slot_default_") ->
                            android.widget.Toast.makeText(this@ProfilePickerActivity, "Tên không hợp lệ", android.widget.Toast.LENGTH_SHORT).show()
                        ProfileSlots.listProfiles(this@ProfilePickerActivity).contains(newName) ->
                            android.widget.Toast.makeText(this@ProfilePickerActivity, "Tên này đã tồn tại — chọn tên khác", android.widget.Toast.LENGTH_SHORT).show()
                        else -> {
                            ProfileSlots.schedulePromoteSlotData(this@ProfilePickerActivity, slotIndex, newName)
                            restartSlot(slotIndex)
                        }
                    }
                }
            })
        }
        setContentView(layout)
    }

    /**
     * Khởi động lại ĐÚNG 1 khe (không đụng các khe khác đang chạy).
     * Khe 0 (chính) là process đang chạy chính activity này -> phải tự kill+relaunch.
     * Khe khác -> kill process của khe đó qua ActivityManager rồi mở lại.
     */
    private fun restartSlot(slotIndex: Int) {
        /**
         * BUG THẬT đã sửa 2 LƯỢT: lượt 1 (kill cứng ngay lập tức) đã sửa
         * bằng graceful-close broadcast, nhưng lượt đó vẫn ĐOÁN MÙ 400ms là
         * đủ thời gian cho khe tự đóng xong — người dùng test lại vẫn báo
         * mất dữ liệu, tức 400ms không đủ trong thực tế (máy chậm, hoặc
         * `finish()` không chạy `onDestroy()` ngay lập tức mà xếp hàng bất
         * đồng bộ). Sửa đúng lần này: đợi ĐÚNG tín hiệu XÁC NHẬN thật từ khe
         * đó (`MainActivity` gửi lại NGAY SAU KHI `engine.release()` đã chạy
         * xong, xem `onDestroy()`) — không đoán thời gian nữa, có nhận ack
         * là làm tiếp NGAY. Vẫn giữ mốc giới hạn tối đa 2 giây làm phương án
         * dự phòng (phòng khi khe không tự đóng được vì lý do gì đó, ví dụ
         * Activity đã bị hệ thống dọn từ trước nên không còn ai nhận
         * broadcast yêu cầu đóng để mà gửi lại ack).
         */
        // FIX MỚI (mục 18) — thêm CrashBreadcrumb ở đây, giống hệt
        // `closeSlotGracefullyThen`. Hàm này (đổi hồ sơ gán cho khe) là 1
        // luồng RIÊNG, ĐỘC LẬP, dùng chính cơ chế đóng-khe-rồi-làm-tiếp
        // tương tự — nhưng trước đây KHÔNG được theo dõi bằng breadcrumb,
        // nên nếu nó cũng crash, không cách nào biết được. Thêm vào để lần
        // sau có bằng chứng đầy đủ, không bỏ sót nguồn crash nào.
        CrashBreadcrumb.write(this, "restartSlot slot=$slotIndex — chuẩn bị đổi hồ sơ gán cho khe này")
        var handled = false
        val ackReceiver = object : android.content.BroadcastReceiver() {
            override fun onReceive(context: android.content.Context?, intent: Intent?) {
                if (handled) return
                handled = true
                try { unregisterReceiver(this) } catch (e: Exception) { /* đã gỡ rồi, bỏ qua */ }
                CrashBreadcrumb.write(this@ProfilePickerActivity, "restartSlot slot=$slotIndex — ĐÃ nhận ACK, gọi doRestartSlot() ngay")
                doRestartSlot(slotIndex)
            }
        }
        androidx.core.content.ContextCompat.registerReceiver(
            this, ackReceiver,
            android.content.IntentFilter(ProfileSlots.gracefulCloseAckAction(slotIndex)),
            androidx.core.content.ContextCompat.RECEIVER_NOT_EXPORTED
        )
        sendBroadcast(Intent(ProfileSlots.gracefulCloseAction(slotIndex)).apply {
            setPackage(packageName)
        })
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
            if (!handled) {
                handled = true
                try { unregisterReceiver(ackReceiver) } catch (e: Exception) { /* đã gỡ rồi, bỏ qua */ }
                CrashBreadcrumb.write(this@ProfilePickerActivity, "restartSlot slot=$slotIndex — TIMEOUT 2s, gọi doRestartSlot() ngay")
                doRestartSlot(slotIndex)
            }
        }, 2000L)
    }

    private fun doRestartSlot(slotIndex: Int) {
        if (slotIndex == 0) {
            // FIX MỚI (mục 18): xoá breadcrumb TRƯỚC KHI thoát chủ động —
            // đây là Runtime.exit(0) CÓ CHỦ ĐÍCH (đổi hồ sơ), KHÔNG PHẢI
            // crash. Nếu không xoá, lần khởi động tiếp theo sẽ báo NHẦM
            // "[CHẨN ĐOÁN NATIVE CRASH]" cho 1 thao tác hoàn toàn bình
            // thường, gây hiểu sai.
            CrashBreadcrumb.clear(this)
            val relaunch = packageManager.getLaunchIntentForPackage(packageName)?.apply {
                addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(relaunch)
            Runtime.getRuntime().exit(0)
        } else {
            CrashBreadcrumb.clear(this) // khe khác (0) chết — process này (đang chạy đây) vẫn sống tiếp bình thường
            val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
            val targetProcessName = "$packageName:slot$slotIndex"
            am.runningAppProcesses
                ?.firstOrNull { it.processName == targetProcessName }
                ?.let { android.os.Process.killProcess(it.pid) }
            /**
             * BUG THẬT đã sửa — nguyên nhân crash "IllegalStateException: Only
             * one GeckoRuntime instance is allowed" (crash log gửi lên):
             * `killProcess()` chỉ GỬI tín hiệu kill cho hệ thống, KHÔNG đảm
             * bảo process đó (và GeckoRuntime native bên trong — dọn dẹp
             * IPC/socket/luồng native KHÔNG tức thời) đã thật sự chết xong.
             * Trước đây gọi `openSlot()` NGAY sau `killProcess()` — nếu
             * process cũ chưa kịp chết hẳn, hệ thống có thể gắn Activity MỚI
             * vào process CŨ (chưa chết) thay vì tạo process sạch mới → 2 lần
             * gọi GeckoRuntime.create() trong CÙNG 1 process → crash ngay
             * (Gecko chỉ cho phép ĐÚNG 1 instance mỗi process, không phải mỗi
             * khe). Đây cũng là nguyên nhân hiện tượng "mở lại thấy restart
             * lặp lại liên tục" trong log — mỗi lần crash, tiến trình chung
             * (bao gồm Khe 0 + các service nền) có thể bị kéo chết theo, tạo
             * cảm giác "đóng 1 cái là đóng cả trình duyệt".
             *
             * Sửa: đợi xác nhận process cũ THẬT SỰ biến mất khỏi
             * `runningAppProcesses` (kiểm tra mỗi 100ms, tối đa ~1.5 giây) rồi
             * mới mở lại — nếu quá 1.5 giây vẫn chưa xác nhận được thì vẫn mở
             * (không treo vô thời hạn), nhưng thực tế process chết nhanh hơn
             * nhiều so với mốc này.
             */
            waitForProcessDeathThenOpen(targetProcessName, slotIndex)
            render()
            return
        }
        render()
    }

    private fun waitForProcessDeathThenOpen(targetProcessName: String, slotIndex: Int, attemptsLeft: Int = 15) {
        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        val stillAlive = am.runningAppProcesses?.any { it.processName == targetProcessName } == true
        if (!stillAlive || attemptsLeft <= 0) {
            openSlot(slotIndex)
            return
        }
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
            waitForProcessDeathThenOpen(targetProcessName, slotIndex, attemptsLeft - 1)
        }, 100L)
    }
}
