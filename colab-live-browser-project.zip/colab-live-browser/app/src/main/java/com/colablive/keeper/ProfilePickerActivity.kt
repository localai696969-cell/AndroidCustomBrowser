package com.colablive.keeper

import android.app.ActivityManager
import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.colablive.keeper.core.ProfileSlots

class ProfilePickerActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    private fun render() {
        val padding = (16 * resources.displayMetrics.density).toInt()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(padding, padding, padding, padding)
        }

        layout.addView(TextView(this).apply {
            text = "${ProfileSlots.SLOT_COUNT + 1} khe dùng ĐỒNG THỜI được (khe 0 = cửa sổ chính). " +
                "Gán profile bất kỳ vào khe bất kỳ — đổi gán chỉ khởi động lại đúng khe đó."
            textSize = 16f
        })

        for (slotIndex in 0..ProfileSlots.SLOT_COUNT) {
            val assigned = ProfileSlots.getSlotAssignmentDisplay(this, slotIndex)
            // BUG THẬT đã sửa: row trước đây là LinearLayout HORIZONTAL không
            // có LayoutParams/weight nào cả. Nút "Khe X: ..." có text dài
            // (nhất là khi chưa gán, ví dụ "CHƯA GÁN HỒ SƠ — DỮ LIỆU RIÊNG
            // CỦA KHE CHÍNH") tự đo wrap_content rộng HƠN cả màn hình, đẩy
            // nút "Đổi" ra ngoài lề phải, KHÔNG hiển thị — người dùng không
            // có cách nào bấm vào "Đổi" để gán profile, chỉ bấm được đúng
            // nút mở khe. Sửa bằng weight: nút chính co giãn vừa khung hình
            // còn lại (weight=1, width=0dp), nút "Đổi" giữ nguyên kích thước
            // tự nhiên (weight=0) nên luôn hiển thị đủ trên mọi màn hình.
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
            }
            row.addView(Button(this).apply {
                text = "Khe $slotIndex: $assigned"
                setOnClickListener { openSlot(slotIndex) }
                layoutParams = LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f
                )
            })
            row.addView(Button(this).apply {
                text = "Đổi"
                setOnClickListener { showReassignDialog(slotIndex) }
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
                )
            })
            layout.addView(row)
        }

        layout.addView(TextView(this).apply {
            text = "\nCác profile đã tạo:"
            textSize = 16f
        })
        layout.addView(TextView(this).apply {
            text = ProfileSlots.listProfiles(this@ProfilePickerActivity).joinToString(", ")
        })

        val newNameInput = EditText(this).apply { hint = "Tên profile mới (vd: Cá nhân, Công việc, KH A...)" }
        layout.addView(newNameInput)
        layout.addView(Button(this).apply {
            text = "Thêm profile mới vào danh sách"
            setOnClickListener {
                val name = newNameInput.text.toString().trim()
                if (name.isNotEmpty()) {
                    ProfileSlots.addProfile(this@ProfilePickerActivity, name)
                    newNameInput.setText("")
                    render()
                }
            }
        })

        setContentView(layout)
    }

    private fun openSlot(slotIndex: Int) {
        val className = ProfileSlots.componentClassNameForSlot(slotIndex)
        startActivity(Intent().apply {
            component = ComponentName(packageName, className)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        })
    }

    // Dialog đơn giản dạng danh sách nút bấm (tránh phụ thuộc thêm thư viện dialog)
    private fun showReassignDialog(slotIndex: Int) {
        val padding = (16 * resources.displayMetrics.density).toInt()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(padding, padding, padding, padding)
        }
        layout.addView(TextView(this).apply { text = "Gán profile nào vào Khe $slotIndex?" })
        val profiles = ProfileSlots.listProfiles(this)
        if (profiles.isEmpty()) {
            layout.addView(TextView(this).apply {
                text = "Chưa có profile nào — tạo 1 cái ở màn hình trước (ô \"Tên profile mới\") rồi quay lại đây."
            })
        }
        for (name in profiles) {
            layout.addView(Button(this).apply {
                text = name
                setOnClickListener {
                    ProfileSlots.setSlotAssignment(this@ProfilePickerActivity, slotIndex, name)
                    restartSlot(slotIndex)
                }
            })
        }
        layout.addView(Button(this).apply {
            text = "— Bỏ gán (dùng dữ liệu riêng của khe, không chung profile) —"
            setOnClickListener {
                ProfileSlots.unassignSlot(this@ProfilePickerActivity, slotIndex)
                restartSlot(slotIndex)
            }
        })
        setContentView(layout)
    }

    /**
     * Khởi động lại ĐÚNG 1 khe (không đụng các khe khác đang chạy).
     * Khe 0 (chính) là process đang chạy chính activity này -> phải tự kill+relaunch.
     * Khe khác -> kill process của khe đó qua ActivityManager rồi mở lại.
     */
    private fun restartSlot(slotIndex: Int) {
        if (slotIndex == 0) {
            val relaunch = packageManager.getLaunchIntentForPackage(packageName)?.apply {
                addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(relaunch)
            Runtime.getRuntime().exit(0)
        } else {
            val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
            val targetProcessName = "$packageName:slot$slotIndex"
            am.runningAppProcesses
                ?.firstOrNull { it.processName == targetProcessName }
                ?.let { android.os.Process.killProcess(it.pid) }
            openSlot(slotIndex)
        }
        render()
    }
}
