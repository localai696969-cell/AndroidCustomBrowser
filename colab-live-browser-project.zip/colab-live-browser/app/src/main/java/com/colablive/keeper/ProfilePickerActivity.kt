package com.colablive.keeper

import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.colablive.keeper.core.ProfileSlots
import com.colablive.keeper.core.DebugLog

class ProfilePickerActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 16, 16, 16)
        }

        for (slotIndex in 0 until ProfileSlots.SLOT_COUNT) {
            val slotView = createSlotView(slotIndex)
            container.addView(slotView)
        }

        val addBtn = Button(this).apply {
            text = "Thêm Profile"
            setOnClickListener { showAddProfileDialog() }
        }
        container.addView(addBtn)

        setContentView(ScrollView(this).apply { addView(container) })
    }

    private fun createSlotView(slotIndex: Int): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 16, 16, 16)
            setBackgroundResource(android.R.drawable.dialog_holo_light_frame)
        }

        val slotName = ProfileSlots.getSlotName(slotIndex)
        val assignedProfile = ProfileSlots.getSlotAssignment(slotIndex)

        card.addView(TextView(this).apply {
            text = slotName
            textSize = 18f
        })

        card.addView(TextView(this).apply {
            text = "Profile: ${assignedProfile ?: "Chưa gán"}"
            textSize = 14f
        })

        val profiles = ProfileSlots.listProfiles()
        val profileSpinner = Spinner(this)
        val profileNames = listOf("Chưa gán") + profiles.map { it.name }
        profileSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, profileNames).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }

        profileSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (position > 0) {
                    val profile = profiles[position - 1]
                    ProfileSlots.setSlotAssignment(slotIndex, profile.id)
                    launchSlot(slotIndex)
                }
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        card.addView(profileSpinner)

        val launchBtn = Button(this).apply {
            text = "Mở $slotName"
            setOnClickListener { launchSlot(slotIndex) }
        }
        card.addView(launchBtn)

        return card
    }

    private fun showAddProfileDialog() {
        val editText = EditText(this).apply { hint = "Tên profile" }
        AlertDialog.Builder(this)
            .setTitle("Thêm Profile mới")
            .setView(editText)
            .setPositiveButton("Thêm") { _, _ ->
                val name = editText.text.toString()
                if (name.isNotEmpty()) {
                    val profile = ProfileSlots.addProfile(name, 0)
                    Toast.makeText(this, "Đã thêm: ${profile.name}", Toast.LENGTH_SHORT).show()
                    recreate()
                }
            }
            .setNegativeButton("Hủy", null)
            .show()
    }

    private fun launchSlot(slotIndex: Int) {
        val componentName = ComponentName(
            packageName,
            ProfileSlots.componentClassNameForSlot(slotIndex)
        )
        val intent = Intent().apply {
            component = componentName
            putExtra("slot_index", slotIndex)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }
        startActivity(intent)
        DebugLog.log("Launched slot $slotIndex")
    }
}
