package com.colablive.keeper

import android.app.ActivityManager
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.colablive.keeper.core.DebugLog
import com.colablive.keeper.core.ProfileExportImport
import com.colablive.keeper.core.ProfileSlots

class ProfilePickerActivity : AppCompatActivity() {

    // Nhớ đang XUẤT hồ sơ nào — cần dùng lại khi onActivityResult() trả về
    // (sau khi người dùng chọn xong nơi lưu file qua SAF).
    private var pendingExportProfileName: String? = null

    companion object {
        private const val REQUEST_EXPORT = 1001
        private const val REQUEST_IMPORT = 1002
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    private fun render() {
        val padding = (16 * resources.displayMetrics.density).toInt()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(padding, padding, padding, padding)
        }

        layout.addView(TextView(this).apply {
            text = "${ProfileSlots.SLOT_COUNT + 1} khe dùng ĐỒNG THỜI được (khe 0 = cửa sổ chính). " +
                "Gán profile bất kỳ vào khe bất kỳ — đổi gán chỉ khởi động lại đúng khe đó."
            textSize = 16f
        })

        for (slotIndex in 0..ProfileSlots.SLOT_COUNT) {
            val assigned = ProfileSlots.getSlotAssignmentDisplay(this, slotIndex)
            // BUG THẬT đã sửa: row trước đây là LinearLayout HORIZONTAL không
            // có LayoutParams/weight nào cả. Nút "Khe X: ..." có text dài
            // (nhất là khi chưa gán, ví dụ "CHƯA GÁN HỒ SƠ — DỮ LIỆU RIÊNG
            // CỦA KHE CHÍNH") tự đo wrap_content rộng HƠN cả màn hình, đẩy
            // nút "Đổi" ra ngoài lề phải, KHÔNG hiển thị — người dùng không
            // có cách nào bấm vào "Đổi" để gán profile, chỉ bấm được đúng
            // nút mở khe. Sửa bằng weight: nút chính co giãn vừa khung hình
            // còn lại (weight=1, width=0dp), nút "Đổi" giữ nguyên kích thước
            // tự nhiên (weight=0) nên luôn hiển thị đủ trên mọi màn hình.
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
            }
            row.addView(Button(this).apply {
                text = "Khe $slotIndex: $assigned"
                setOnClickListener { openSlot(slotIndex) }
                layoutParams = LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f
                )
            })
            row.addView(Button(this).apply {
                text = "Đổi"
                setOnClickListener { showReassignDialog(slotIndex) }
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
                )
            })
            layout.addView(row)
        }

        layout.addView(TextView(this).apply {
            text = "\nCác profile đã tạo:"
            textSize = 16f
        })
        layout.addView(TextView(this).apply {
            text = ProfileSlots.listProfiles(this@ProfilePickerActivity).joinToString(", ")
        })

        val newNameInput = EditText(this).apply { hint = "Tên profile mới (vd: Cá nhân, Công việc, KH A...)" }
        layout.addView(newNameInput)
        layout.addView(Button(this).apply {
            text = "Thêm profile mới vào danh sách"
            setOnClickListener {
                val name = newNameInput.text.toString().trim()
                if (name.isNotEmpty()) {
                    ProfileSlots.addProfile(this@ProfilePickerActivity, name)
                    newNameInput.setText("")
                    render()
                }
            }
        })

        // TÍNH NĂNG MỚI — trả lời câu hỏi "mỗi profile là 1 dữ liệu độc
        // lập... có restore được khi gỡ cài lại, hoặc mang qua máy khác
        // không". Trước đây KHÔNG — dữ liệu chỉ nằm trong bộ nhớ riêng của
        // app, Android tự xoá khi gỡ cài, không có cách nào lấy ra. Giờ có
        // thể xuất 1 hồ sơ ra file .zip (chọn nơi lưu tuỳ ý — Tải xuống,
        // Google Drive, thẻ nhớ...) rồi nhập lại — kể cả trên máy khác, hay
        // sau khi gỡ cài lại app. Xem `ProfileExportImport.kt`.
        layout.addView(TextView(this).apply {
            text = "\nSao lưu / khôi phục hồ sơ (mang qua máy khác, hoặc giữ lại khi gỡ cài app):"
            textSize = 14f
        })
        val exportRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        exportRow.addView(Button(this).apply {
            text = "Xuất hồ sơ ra file..."
            setOnClickListener { showExportChooserDialog() }
        })
        exportRow.addView(Button(this).apply {
            text = "Nhập hồ sơ từ file..."
            setOnClickListener {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "application/zip"
                }
                startActivityForResult(intent, REQUEST_IMPORT)
            }
        })
        layout.addView(exportRow)

        setContentView(layout)
    }

    private fun showExportChooserDialog() {
        val padding = (16 * resources.displayMetrics.density).toInt()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(padding, padding, padding, padding)
        }
        layout.addView(TextView(this).apply { text = "Xuất hồ sơ nào?" })
        val profiles = ProfileSlots.listProfiles(this)
        if (profiles.isEmpty()) {
            layout.addView(TextView(this).apply { text = "Chưa có hồ sơ nào để xuất." })
        }
        for (name in profiles) {
            layout.addView(Button(this).apply {
                text = name
                setOnClickListener {
                    // FIX BUG THẬT: trước đây chỉ CẢNH BÁO rồi vẫn export
                    // ngay dù hồ sơ đang chạy — Gecko giữ khóa file
                    // cookies.sqlite-wal/logins.sqlite-wal (nơi chứa các ghi
                    // gần nhất CHƯA được checkpoint vào file .sqlite chính,
                    // ví dụ đúng phiên đăng nhập Google vừa xong) →
                    // `zipDirRecursive` bỏ qua file đó khi khóa → khi nhập
                    // lại hồ sơ, cookie phiên đăng nhập mới nhất bị THIẾU,
                    // dù file .sqlite chính (cũ hơn) vẫn export được bình
                    // thường → RẤT có thể là nguyên nhân gốc của bug "restore
                    // hồ sơ thì bị đăng xuất tài khoản Google" người dùng báo.
                    //
                    // Sửa tận gốc: CHỦ ĐỘNG đóng khe đàng hoàng trước (tái sử
                    // dụng ĐÚNG cơ chế broadcast + chờ ACK thật đã có ở
                    // `restartSlot()` — không đoán mù thời gian) để Gecko tự
                    // checkpoint + nhả khóa toàn bộ file, rồi MỚI bắt đầu
                    // export — đảm bảo file .zip luôn đầy đủ 100%, không cần
                    // người dùng tự nhớ đóng khe thủ công nữa.
                    val runningSlot = (0..ProfileSlots.SLOT_COUNT).firstOrNull {
                        ProfileSlots.getSlotAssignment(this@ProfilePickerActivity, it) == name
                    }
                    val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
                    val processAlive = runningSlot != null && am.runningAppProcesses?.any {
                        it.processName == (if (runningSlot == 0) packageName else "$packageName:slot$runningSlot")
                    } == true
                    pendingExportProfileName = name
                    if (processAlive && runningSlot != null) {
                        Toast.makeText(this@ProfilePickerActivity, "Đang đóng Khe $runningSlot để xuất đầy đủ dữ liệu (kể cả phiên đăng nhập mới nhất)...", Toast.LENGTH_SHORT).show()
                        closeSlotGracefullyThen(runningSlot) { openExportPicker(name) }
                    } else {
                        openExportPicker(name)
                    }
                }
            })
        }
        setContentView(layout)
    }

    /**
     * Tách riêng bước mở SAF picker chọn nơi lưu file .zip — gọi sau khi
     * đã (nếu cần) đóng khe đàng hoàng xong, hoặc gọi thẳng nếu hồ sơ
     * không hề đang chạy ở khe nào.
     */
    private fun openExportPicker(name: String) {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/zip"
            putExtra(Intent.EXTRA_TITLE, "${name}_backup.zip")
        }
        startActivityForResult(intent, REQUEST_EXPORT)
    }

    /**
     * Đóng 1 khe đàng hoàng rồi mới chạy tiếp `onClosed` — TÁI SỬ DỤNG
     * chính xác cơ chế broadcast + chờ ACK thật đã có ở `restartSlot()`
     * (xem chú thích ở đó: đã từng sửa lỗi đoán mù thời gian 400ms không
     * đủ, giờ luôn đợi tín hiệu ACK thật, có mốc dự phòng 2 giây phòng khe
     * không tự đóng được vì lý do gì đó). Dùng lại y hệt cho mục đích
     * export để đảm bảo Gecko flush + nhả khóa file trước khi nén zip.
     */
    private fun closeSlotGracefullyThen(slotIndex: Int, onClosed: () -> Unit) {
        var handled = false
        val ackReceiver = object : android.content.BroadcastReceiver() {
            override fun onReceive(context: android.content.Context?, intent: Intent?) {
                if (handled) return
                handled = true
                try { unregisterReceiver(this) } catch (e: Exception) { /* đã gỡ rồi, bỏ qua */ }
                onClosed()
            }
        }
        androidx.core.content.ContextCompat.registerReceiver(
            this, ackReceiver,
            android.content.IntentFilter(ProfileSlots.gracefulCloseAckAction(slotIndex)),
            androidx.core.content.ContextCompat.RECEIVER_NOT_EXPORTED
        )
        sendBroadcast(Intent(ProfileSlots.gracefulCloseAction(slotIndex)).apply {
            setPackage(packageName)
        })
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
            if (!handled) {
                handled = true
                try { unregisterReceiver(ackReceiver) } catch (e: Exception) { /* đã gỡ rồi, bỏ qua */ }
                DebugLog.log("ProfilePickerActivity: Khe $slotIndex không gửi ACK đóng khe trong 2s — vẫn tiếp tục export, có thể vài file mới nhất bị bỏ qua nếu khe thật sự chưa đóng xong")
                onClosed()
            }
        }, 2000L)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        // BUG THẬT đã tìm ra (người dùng báo: "export profile hình như bị
        // lỗi, không xuất được nữa" — không kèm thông báo lỗi cụ thể nào):
        // nhánh này TRƯỚC ĐÂY hoàn toàn IM LẶNG khi hộp thoại SAF (chọn nơi
        // lưu file .zip cho export, hoặc chọn file .zip nguồn cho import)
        // không trả về RESULT_OK — kể cả người dùng vô tình bấm ra ngoài
        // làm mất hộp thoại, hay hộp thoại không mở lên đúng lúc do đang ở
        // giữa quá trình đóng khe đàng hoàng (`closeSlotGracefullyThen`
        // chạy TRƯỚC `openExportPicker`, có độ trễ tới 2s) — người dùng chỉ
        // thấy "bấm export xong không có gì xảy ra", KHÔNG có cách nào biết
        // đây là do họ (vô tình) huỷ hộp thoại hay do lỗi thật. Việc export
        // NÉM EXCEPTION thật (VD lỗi ghi file, hết dung lượng) đã có toast
        // báo đầy đủ từ trước (nhánh `result.isSuccess` bên dưới) — không
        // đụng vào nhánh đó, chỉ thêm phản hồi cho nhánh im lặng này.
        if (resultCode != RESULT_OK || data?.data == null) {
            val what = if (requestCode == REQUEST_EXPORT) "xuất hồ sơ" else "nhập hồ sơ"
            DebugLog.log("ProfilePickerActivity: onActivityResult($requestCode) không trả về RESULT_OK (resultCode=$resultCode, data.data=${data?.data}) — coi là người dùng đã huỷ bước chọn nơi lưu/file")
            Toast.makeText(this, "Đã huỷ $what (không chọn nơi lưu/file).", Toast.LENGTH_SHORT).show()
            pendingExportProfileName = null
            render()
            return
        }
        val uri: Uri = data.data!!
        when (requestCode) {
            REQUEST_EXPORT -> {
                val name = pendingExportProfileName
                pendingExportProfileName = null
                if (name == null) { render(); return }
                Toast.makeText(this, "Đang xuất '$name'...", Toast.LENGTH_SHORT).show()
                Thread {
                    val result = ProfileExportImport.exportProfile(this, name, uri)
                    runOnUiThread {
                        if (result.isSuccess) {
                            Toast.makeText(this, "Xuất '$name' xong.", Toast.LENGTH_LONG).show()
                        } else {
                            Toast.makeText(this, "Xuất lỗi: ${result.exceptionOrNull()?.message}", Toast.LENGTH_LONG).show()
                        }
                        render()
                    }
                }.start()
            }
            REQUEST_IMPORT -> showImportNameDialog(uri)
        }
    }

    private fun doImport(uri: Uri, name: String, overwrite: Boolean) {
        /**
         * BUG NGHIÊM TRỌNG tự tìm ra (người dùng chỉ đúng: "sửa bug nhỏ
         * thành bug lớn tan nát" — bản vá "cho phép ghi đè" trước đó THIẾU
         * kiểm tra hồ sơ đích có đang được 1 KHE CHẠY THẬT SỰ sử dụng hay
         * không trước khi `targetDir.deleteRecursively()`). Nếu người
         * dùng ghi đè đúng lúc khe đó đang chạy (GeckoRuntime còn giữ file
         * SQLite mở), xoá thư mục ngay dưới chân 1 tiến trình đang hoạt
         * động có thể gây crash/hỏng dữ liệu — NẶNG HƠN NHIỀU so với bug
         * gốc (chỉ là tab list rỗng). Sửa: tái dùng ĐÚNG cơ chế đã có sẵn
         * cho export (`closeSlotGracefullyThen` — đóng khe đàng hoàng qua
         * broadcast+ACK thật, để Gecko tự checkpoint + nhả khoá file trước)
         * — KHÔNG viết logic mới, dùng lại nguyên xi pattern đã kiểm chứng.
         */
        val runningSlot = (0..ProfileSlots.SLOT_COUNT).firstOrNull {
            ProfileSlots.getSlotAssignment(this@ProfilePickerActivity, it) == name
        }
        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        val processAlive = runningSlot != null && am.runningAppProcesses?.any {
            it.processName == (if (runningSlot == 0) packageName else "$packageName:slot$runningSlot")
        } == true
        if (processAlive && runningSlot != null) {
            Toast.makeText(this@ProfilePickerActivity, "Đang đóng Khe $runningSlot trước khi ghi đè (tránh xoá dữ liệu đang mở)...", Toast.LENGTH_SHORT).show()
            closeSlotGracefullyThen(runningSlot) { doImportActual(uri, name, overwrite) }
        } else {
            doImportActual(uri, name, overwrite)
        }
    }

    private fun doImportActual(uri: Uri, name: String, overwrite: Boolean) {
        Toast.makeText(this@ProfilePickerActivity, "Đang nhập...", Toast.LENGTH_SHORT).show()
        Thread {
            val result = ProfileExportImport.importProfile(this@ProfilePickerActivity, uri, name, overwrite)
            runOnUiThread {
                if (result.isSuccess) {
                    Toast.makeText(this@ProfilePickerActivity, "Nhập '$name' xong — vào \"Đổi\" ở 1 khe để gán và dùng.", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(this@ProfilePickerActivity, "Nhập lỗi: ${result.exceptionOrNull()?.message}", Toast.LENGTH_LONG).show()
                    DebugLog.log("Import profile lỗi: ${result.exceptionOrNull()}")
                }
                render()
            }
        }.start()
    }

    private fun showImportNameDialog(uri: Uri) {
        val padding = (16 * resources.displayMetrics.density).toInt()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(padding, padding, padding, padding)
        }
        layout.addView(TextView(this).apply { text = "Đặt tên cho hồ sơ vừa nhập:" })
        val nameInput = EditText(this).apply { hint = "Tên hồ sơ mới" }
        layout.addView(nameInput)
        layout.addView(Button(this).apply {
            text = "Nhập"
            setOnClickListener {
                val name = nameInput.text.toString().trim()
                when {
                    name.isEmpty() -> Toast.makeText(this@ProfilePickerActivity, "Chưa nhập tên", Toast.LENGTH_SHORT).show()
                    name.startsWith("__slot_default_") -> Toast.makeText(this@ProfilePickerActivity, "Tên không hợp lệ", Toast.LENGTH_SHORT).show()
                    ProfileSlots.listProfiles(this@ProfilePickerActivity).contains(name) -> {
                        /**
                         * BUG THIẾT KẾ THẬT (người dùng chỉ ra đúng, rất gay
                         * gắt và có lý — trước đây chặn CỨNG ở ngay đây,
                         * không cho nhập tên trùng, buộc người dùng phải GỠ
                         * CÀI ĐẶT TOÀN BỘ APP chỉ để test/dùng import — vô
                         * lý cho 1 tính năng "backup/restore"): thay vì chặn
                         * hẳn, hỏi xác nhận GHI ĐÈ — người dùng chủ động
                         * quyết định, không cần xóa gì ở tầng hệ điều hành.
                         */
                        AlertDialog.Builder(this@ProfilePickerActivity)
                            .setTitle("Hồ sơ '$name' đã tồn tại")
                            .setMessage(
                                "Ghi đè? TOÀN BỘ dữ liệu hiện có của hồ sơ '$name' " +
                                    "(cookie, đăng nhập, lịch sử, tab đang mở...) sẽ bị " +
                                    "THAY THẾ HOÀN TOÀN bằng dữ liệu trong file backup " +
                                    "đang nhập — không thể hoàn tác."
                            )
                            .setPositiveButton("Ghi đè") { _, _ -> doImport(uri, name, overwrite = true) }
                            .setNegativeButton("Hủy", null)
                            .show()
                    }
                    else -> doImport(uri, name, overwrite = false)
                }
            }
        })
        setContentView(layout)
    }

    private fun openSlot(slotIndex: Int) {
        val className = ProfileSlots.componentClassNameForSlot(slotIndex)
        startActivity(Intent().apply {
            component = ComponentName(packageName, className)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        })
    }

    // Dialog đơn giản dạng danh sách nút bấm (tránh phụ thuộc thêm thư viện dialog)
    private fun showReassignDialog(slotIndex: Int) {
        val padding = (16 * resources.displayMetrics.density).toInt()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(padding, padding, padding, padding)
        }
        layout.addView(TextView(this).apply { text = "Gán profile nào vào Khe $slotIndex?" })
        val profiles = ProfileSlots.listProfiles(this)
        if (profiles.isEmpty()) {
            layout.addView(TextView(this).apply {
                text = "Chưa có profile nào — tạo 1 cái ở màn hình trước (ô \"Tên profile mới\") rồi quay lại đây."
            })
        }
        for (name in profiles) {
            // BUG THẬT đã sửa: trước đây danh sách này cho gán 1 hồ sơ vào
            // NHIỀU khe cùng lúc, không cảnh báo gì — như trong ảnh chụp
            // màn hình bạn gửi (TEST 1 gán cả Khe 1 lẫn Khe 3). Vì 4 khe
            // chạy SONG SONG thật (xem `GeckoRuntimeProvider`: mỗi khe tự mở
            // 1 `GeckoRuntime` trỏ `-profile` vào ĐÚNG 1 thư mục theo TÊN hồ
            // sơ) — 2 khe cùng gán 1 tên = 2 tiến trình Gecko cùng mở CHUNG 1
            // thư mục hồ sơ CÙNG LÚC. Firefox/Gecko không hỗ trợ 2 instance
            // cùng mở 1 hồ sơ đồng thời (khoá file/lock, dễ lỗi hoặc hỏng
            // cookie/session) — đây không phải lỗi vặt UI, mà là rủi ro
            // HỎNG DỮ LIỆU thật. Chặn hẳn, không cho chọn nữa.
            val usedByOther = ProfileSlots.findOtherSlotUsingProfile(this, slotIndex, name)
            layout.addView(Button(this).apply {
                text = if (usedByOther != null) "⚠️ $name (đang chạy ở Khe $usedByOther — không thể gán trùng)" else name
                if (usedByOther != null) {
                    isEnabled = false
                } else {
                    setOnClickListener {
                        ProfileSlots.setSlotAssignment(this@ProfilePickerActivity, slotIndex, name)
                        restartSlot(slotIndex)
                    }
                }
            })
        }
        layout.addView(Button(this).apply {
            text = "— Bỏ gán (dùng dữ liệu riêng của khe, không chung profile) —"
            setOnClickListener {
                ProfileSlots.unassignSlot(this@ProfilePickerActivity, slotIndex)
                restartSlot(slotIndex)
            }
        })
        // Tính năng MỚI — trả lời đúng câu hỏi "khe mở ra mà chưa có profile
        // nào thì làm sao đặt tên cho profile đang mở trong khe": khe CHƯA
        // TỪNG gán hồ sơ vẫn có dữ liệu riêng (cookie/đăng nhập) nằm trong
        // namespace nội bộ `__slot_default_N` — trước đây KHÔNG có cách nào
        // biến dữ liệu đó thành 1 hồ sơ có tên (chỉ có cách tạo hồ sơ MỚI
        // TRẮNG rồi gán, mất hết dữ liệu cũ). Chỉ hiện nút này khi khe CHƯA
        // gán hồ sơ nào (mới có dữ liệu "mồ côi" cần đặt tên).
        val isUnassigned = ProfileSlots.getSlotAssignmentDisplay(this, slotIndex).startsWith("(chưa gán hồ sơ")
        if (isUnassigned) {
            layout.addView(TextView(this).apply {
                text = "\nKhe này CHƯA gán hồ sơ nào nhưng có thể đã có dữ liệu " +
                    "riêng (cookie/đăng nhập). Đặt tên cho dữ liệu đó để dùng " +
                    "lại/di chuyển được như hồ sơ khác:"
                textSize = 13f
            })
            val promoteInput = EditText(this).apply { hint = "Tên hồ sơ mới cho dữ liệu đang có trong Khe $slotIndex" }
            layout.addView(promoteInput)
            layout.addView(Button(this).apply {
                text = "Đặt tên cho dữ liệu đang có trong khe này"
                setOnClickListener {
                    val newName = promoteInput.text.toString().trim()
                    when {
                        newName.isEmpty() ->
                            android.widget.Toast.makeText(this@ProfilePickerActivity, "Chưa nhập tên", android.widget.Toast.LENGTH_SHORT).show()
                        newName.startsWith("__slot_default_") ->
                            android.widget.Toast.makeText(this@ProfilePickerActivity, "Tên không hợp lệ", android.widget.Toast.LENGTH_SHORT).show()
                        ProfileSlots.listProfiles(this@ProfilePickerActivity).contains(newName) ->
                            android.widget.Toast.makeText(this@ProfilePickerActivity, "Tên này đã tồn tại — chọn tên khác", android.widget.Toast.LENGTH_SHORT).show()
                        else -> {
                            ProfileSlots.schedulePromoteSlotData(this@ProfilePickerActivity, slotIndex, newName)
                            restartSlot(slotIndex)
                        }
                    }
                }
            })
        }
        setContentView(layout)
    }

    /**
     * Khởi động lại ĐÚNG 1 khe (không đụng các khe khác đang chạy).
     * Khe 0 (chính) là process đang chạy chính activity này -> phải tự kill+relaunch.
     * Khe khác -> kill process của khe đó qua ActivityManager rồi mở lại.
     */
    private fun restartSlot(slotIndex: Int) {
        /**
         * BUG THẬT đã sửa 2 LƯỢT: lượt 1 (kill cứng ngay lập tức) đã sửa
         * bằng graceful-close broadcast, nhưng lượt đó vẫn ĐOÁN MÙ 400ms là
         * đủ thời gian cho khe tự đóng xong — người dùng test lại vẫn báo
         * mất dữ liệu, tức 400ms không đủ trong thực tế (máy chậm, hoặc
         * `finish()` không chạy `onDestroy()` ngay lập tức mà xếp hàng bất
         * đồng bộ). Sửa đúng lần này: đợi ĐÚNG tín hiệu XÁC NHẬN thật từ khe
         * đó (`MainActivity` gửi lại NGAY SAU KHI `engine.release()` đã chạy
         * xong, xem `onDestroy()`) — không đoán thời gian nữa, có nhận ack
         * là làm tiếp NGAY. Vẫn giữ mốc giới hạn tối đa 2 giây làm phương án
         * dự phòng (phòng khi khe không tự đóng được vì lý do gì đó, ví dụ
         * Activity đã bị hệ thống dọn từ trước nên không còn ai nhận
         * broadcast yêu cầu đóng để mà gửi lại ack).
         */
        var handled = false
        val ackReceiver = object : android.content.BroadcastReceiver() {
            override fun onReceive(context: android.content.Context?, intent: Intent?) {
                if (handled) return
                handled = true
                try { unregisterReceiver(this) } catch (e: Exception) { /* đã gỡ rồi, bỏ qua */ }
                doRestartSlot(slotIndex)
            }
        }
        androidx.core.content.ContextCompat.registerReceiver(
            this, ackReceiver,
            android.content.IntentFilter(ProfileSlots.gracefulCloseAckAction(slotIndex)),
            androidx.core.content.ContextCompat.RECEIVER_NOT_EXPORTED
        )
        sendBroadcast(Intent(ProfileSlots.gracefulCloseAction(slotIndex)).apply {
            setPackage(packageName)
        })
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
            if (!handled) {
                handled = true
                try { unregisterReceiver(ackReceiver) } catch (e: Exception) { /* đã gỡ rồi, bỏ qua */ }
                doRestartSlot(slotIndex)
            }
        }, 2000L)
    }

    private fun doRestartSlot(slotIndex: Int) {
        if (slotIndex == 0) {
            val relaunch = packageManager.getLaunchIntentForPackage(packageName)?.apply {
                addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(relaunch)
            Runtime.getRuntime().exit(0)
        } else {
            val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
            val targetProcessName = "$packageName:slot$slotIndex"
            am.runningAppProcesses
                ?.firstOrNull { it.processName == targetProcessName }
                ?.let { android.os.Process.killProcess(it.pid) }
            /**
             * BUG THẬT đã sửa — nguyên nhân crash "IllegalStateException: Only
             * one GeckoRuntime instance is allowed" (crash log gửi lên):
             * `killProcess()` chỉ GỬI tín hiệu kill cho hệ thống, KHÔNG đảm
             * bảo process đó (và GeckoRuntime native bên trong — dọn dẹp
             * IPC/socket/luồng native KHÔNG tức thời) đã thật sự chết xong.
             * Trước đây gọi `openSlot()` NGAY sau `killProcess()` — nếu
             * process cũ chưa kịp chết hẳn, hệ thống có thể gắn Activity MỚI
             * vào process CŨ (chưa chết) thay vì tạo process sạch mới → 2 lần
             * gọi GeckoRuntime.create() trong CÙNG 1 process → crash ngay
             * (Gecko chỉ cho phép ĐÚNG 1 instance mỗi process, không phải mỗi
             * khe). Đây cũng là nguyên nhân hiện tượng "mở lại thấy restart
             * lặp lại liên tục" trong log — mỗi lần crash, tiến trình chung
             * (bao gồm Khe 0 + các service nền) có thể bị kéo chết theo, tạo
             * cảm giác "đóng 1 cái là đóng cả trình duyệt".
             *
             * Sửa: đợi xác nhận process cũ THẬT SỰ biến mất khỏi
             * `runningAppProcesses` (kiểm tra mỗi 100ms, tối đa ~1.5 giây) rồi
             * mới mở lại — nếu quá 1.5 giây vẫn chưa xác nhận được thì vẫn mở
             * (không treo vô thời hạn), nhưng thực tế process chết nhanh hơn
             * nhiều so với mốc này.
             */
            waitForProcessDeathThenOpen(targetProcessName, slotIndex)
            render()
            return
        }
        render()
    }

    private fun waitForProcessDeathThenOpen(targetProcessName: String, slotIndex: Int, attemptsLeft: Int = 15) {
        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        val stillAlive = am.runningAppProcesses?.any { it.processName == targetProcessName } == true
        if (!stillAlive || attemptsLeft <= 0) {
            openSlot(slotIndex)
            return
        }
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
            waitForProcessDeathThenOpen(targetProcessName, slotIndex, attemptsLeft - 1)
        }, 100L)
    }
}
