package com.colablive.keeper.core

import android.content.Context
import android.net.Uri
import org.json.JSONObject
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * Xuất/nhập 1 hồ sơ (dữ liệu trình duyệt Gecko + cấu hình fingerprint/proxy
 * trong AppPrefs) thành 1 file .zip di động được — trả lời câu hỏi "mỗi
 * profile là 1 dữ liệu độc lập... có restore được khi gỡ cài lại, hoặc
 * mang qua máy khác không". TRƯỚC ĐÂY: hoàn toàn KHÔNG — dữ liệu chỉ nằm
 * trong bộ nhớ riêng của app (`/data/user/0/.../files`), Android tự xoá
 * sạch khi gỡ cài, không có cách nào lấy ra/đưa vào.
 *
 * Cấu trúc file .zip xuất ra:
 *   profile_data/...           toàn bộ thư mục hồ sơ Gecko (cookie, đăng
 *                               nhập, cache, lịch sử — places.sqlite nằm ở
 *                               đây, xem câu hỏi về lịch sử)
 *   app_prefs.json              cấu hình fingerprint/proxy/... của hồ sơ
 *   manifest.json                tên hồ sơ gốc + thời điểm xuất (tham khảo)
 *
 * CHỈ dùng java.util.zip (thư viện Java chuẩn, luôn có sẵn, không phụ
 * thuộc thư viện ngoài) — không đụng API GeckoView nào, nên không có rủi ro
 * đoán sai API như các phần MediaSession đã từng nói.
 */
/**
 * Ném ra khi import trùng tên hồ sơ ĐÃ ĐĂNG KÝ và người gọi CHƯA xác nhận
 * ghi đè (`overwrite=false`) — UI (`ProfilePickerActivity`) bắt riêng
 * exception này để hiện dialog hỏi "Ghi đè?" thay vì báo lỗi chung chung.
 */
class ProfileAlreadyExistsException(message: String) : Exception(message)

object ProfileExportImport {

    /**
     * Xuất hồ sơ `profileName` ra `destUri` (URI người dùng chọn qua
     * Storage Access Framework — xem `ProfilePickerActivity`). Chạy trên
     * luồng nền (I/O có thể chậm với hồ sơ lớn).
     */
    fun exportProfile(context: Context, profileName: String, destUri: Uri): Result<Unit> {
        /**
         * FIX THIẾU LOG (người dùng yêu cầu đúng: "export profile vẫn lỗi
         * 0B mà không hề có log chẩn đoán nào để tra tiếp" — trước đây
         * hàm này gần như câm lặng, chỉ log khi CATCH được exception, còn
         * trường hợp "chạy xong không lỗi gì nhưng zip vẫn rỗng/thiếu dữ
         * liệu" thì hoàn toàn không có manh mối). Thêm log ở TỪNG bước —
         * đủ để lần test tới trả lời dứt điểm: profileDir có tồn tại
         * không, có bao nhiêu file trong đó, mỗi entry ghi được bao nhiêu
         * byte, tổng cộng file zip ra bao nhiêu byte — không còn phải đoán.
         */
        val profileDir = File(context.filesDir, safeDirNameFor(profileName))
        val dirFileCount = if (profileDir.exists()) profileDir.walkTopDown().count { it.isFile } else -1
        DebugLog.log("ProfileExportImport.exportProfile BẮT ĐẦU: profileName='$profileName' profileDir=${profileDir.absolutePath} exists=${profileDir.exists()} soFileBenTrong=$dirFileCount destUri=$destUri")
        var totalBytesWritten = 0L
        var totalEntriesWritten = 0
        return try {
            val profileDirLocal = profileDir
            context.contentResolver.openOutputStream(destUri)?.use { out ->
                CountingOutputStream(out) { totalBytesWritten = it }.let { counting ->
                ZipOutputStream(counting).use { zip ->
                    // 1) Cấu hình AppPrefs (fingerprint/proxy/...) của hồ sơ này
                    val prefsJson = JSONObject()
                    AppPrefs.exportNamespace(context, profileName).forEach { (k, v) ->
                        prefsJson.put(k, v)
                    }
                    val prefsBytes = prefsJson.toString().toByteArray()
                    writeZipEntry(zip, "app_prefs.json", prefsBytes)
                    totalEntriesWritten++
                    DebugLog.log("ProfileExportImport.exportProfile: đã ghi app_prefs.json (${prefsBytes.size} byte, ${AppPrefs.exportNamespace(context, profileName).size} key)")

                    // 2) Thông tin tham khảo
                    val manifest = JSONObject().apply {
                        put("profile_name", profileName)
                        put("exported_at", System.currentTimeMillis())
                        put("app_version", BuildMarker.VERSION)
                    }
                    val manifestBytes = manifest.toString().toByteArray()
                    writeZipEntry(zip, "manifest.json", manifestBytes)
                    totalEntriesWritten++
                    DebugLog.log("ProfileExportImport.exportProfile: đã ghi manifest.json (${manifestBytes.size} byte)")

                    // 3) Toàn bộ thư mục dữ liệu trình duyệt (nếu có)
                    if (profileDirLocal.exists()) {
                        val (filesZipped, bytesZipped) = zipDirRecursive(zip, profileDirLocal, "profile_data")
                        totalEntriesWritten += filesZipped
                        DebugLog.log("ProfileExportImport.exportProfile: đã ghi profile_data/ ($filesZipped file, ~$bytesZipped byte trước nén — số byte SAU nén xem ở dòng tổng kết cuối)")
                    } else {
                        DebugLog.log("ProfileExportImport.exportProfile: profileDir KHÔNG TỒN TẠI ('${profileDirLocal.absolutePath}') — zip xuất ra sẽ CHỈ có app_prefs.json + manifest.json, KHÔNG có dữ liệu duyệt web nào (cookie/lịch sử/đăng nhập) — đây rất có thể là nguyên nhân 0B/gần-0B nếu tên hồ sơ không khớp thư mục thật")
                    }
                }
                }
            } ?: run {
                DebugLog.log("ProfileExportImport.exportProfile: openOutputStream(destUri) trả về NULL — không mở được nơi lưu, có thể quyền SAF đã bị thu hồi")
                return Result.failure(IllegalStateException("Không mở được nơi lưu file"))
            }
            DebugLog.log("ProfileExportImport.exportProfile HOÀN TẤT: tổng $totalEntriesWritten entry, TỔNG CỘNG $totalBytesWritten byte đã ghi thật vào file zip (đây là con số quyết định — nếu số này = 0 hoặc rất nhỏ dù các bước trên báo ghi thành công, khả năng cao OutputStream bị đóng/cắt ngang bởi hệ thống TRƯỚC KHI dữ liệu được flush xuống đĩa thật, xem thêm ExportBackupService.kt)")
            Result.success(Unit)
        } catch (e: Exception) {
            DebugLog.log("ProfileExportImport.exportProfile LỖI (đã ghi được $totalEntriesWritten entry / $totalBytesWritten byte trước khi lỗi): ${e.javaClass.simpleName}: ${e.message}")
            Result.failure(e)
        }
    }

    /** Đếm số byte thật sự chảy qua OutputStream — để biết chính xác zip
     * cuối cùng nặng bao nhiêu, không phải suy đoán từ kích thước file gốc
     * (nén có thể làm nhỏ đi nhiều, và đây là con số THẬT NẰM TRÊN ĐĨA). */
    private class CountingOutputStream(
        private val delegate: OutputStream,
        private val onCount: (Long) -> Unit
    ) : OutputStream() {
        private var count = 0L
        override fun write(b: Int) { delegate.write(b); count++; onCount(count) }
        override fun write(b: ByteArray, off: Int, len: Int) { delegate.write(b, off, len); count += len; onCount(count) }
        override fun flush() = delegate.flush()
        override fun close() = delegate.close()
    }

    /**
     * Nhập 1 file .zip đã xuất trước đó thành hồ sơ TÊN MỚI `targetProfileName`
     * (không ghi đè hồ sơ đang tồn tại — để an toàn, người gọi tự kiểm tra
     * tên chưa trùng trước khi gọi hàm này, xem `ProfilePickerActivity`).
     *
     * BUG THẬT (người dùng báo: nhập "vpscolab691" liên tục báo "Đã có dữ
     * liệu cho tên hồ sơ này rồi" dù chưa từng nhập thành công lần nào —
     * xác nhận qua ảnh chụp màn hình: hồ sơ này KHÔNG hề xuất hiện trong
     * danh sách profile đã gán, tức `ProfileSlots` chưa từng đăng ký nó):
     * code CŨ ghi file trực tiếp vào `targetDir` ngay trong lúc giải nén —
     * nếu bất kỳ bước nào giữa chừng ném exception (file zip lỗi, hết
     * dung lượng, `AppPrefs.importNamespace`/`ProfileSlots.addProfile` lỗi,
     * v.v.), hàm trả `Result.failure` NHƯNG `targetDir` đã có sẵn 1 phần
     * dữ liệu rồi — không hề dọn dẹp. Lần thử lại SAU đó luôn bị chặn ngay
     * từ `if (targetDir.exists())`, dù dữ liệu thật KHÔNG đầy đủ/hợp lệ —
     * đúng như người dùng mô tả "báo có mà thực tế chưa có".
     *
     * Sửa theo mô hình TRANSACTION ATOMIC: giải nén vào 1 thư mục TẠM
     * riêng, chỉ đổi tên (rename — thao tác tức thời, không copy lại) thành
     * `targetDir` thật SAU KHI mọi bước (giải nén + AppPrefs +
     * ProfileSlots.addProfile) đã thành công hoàn toàn. Bất kỳ lỗi nào
     * giữa chừng đều tự xoá sạch thư mục tạm — `targetDir` CHỈ tồn tại khi
     * import thật sự xong xuôi, khớp đúng ý nghĩa của thông báo lỗi.
     *
     * Đồng thời DỌN RÁC MỒ CÔI: nếu `targetDir` đã tồn tại từ MỘT LẦN THỬ
     * LỖI TRƯỚC (từ bản cũ chưa có fix này) nhưng tên hồ sơ đó CHƯA TỪNG
     * được đăng ký trong `ProfileSlots.listProfiles()`, coi đó là rác mồ
     * côi — tự xoá rồi cho phép import lại, thay vì chặn vĩnh viễn buộc
     * người dùng phải tự vào file manager xoá thủ công.
     */
    /**
     * BUG THIẾT KẾ THẬT (người dùng chỉ ra đúng, rất gay gắt và có lý):
     * trước đây `importProfile()` CHẶN CỨNG nếu tên hồ sơ đích ĐÃ đăng ký
     * — không có cách nào ghi đè, buộc người dùng phải GỠ CÀI ĐẶT TOÀN BỘ
     * APP (xóa sạch mọi hồ sơ khác, mọi dữ liệu khác) chỉ để "test" hoặc
     * thực sự dùng chức năng import — vô lý cho 1 tính năng có tên là
     * "backup/restore". Sửa: thêm tham số `overwrite` — mặc định vẫn
     * `false` (an toàn, không âm thầm ghi đè ngoài ý muốn), nhưng CHO PHÉP
     * gọi lại với `overwrite=true` sau khi người dùng xác nhận qua dialog
     * cảnh báo rõ ràng (xem `ProfilePickerActivity.kt`), không cần xóa gì
     * ở tầng hệ điều hành cả.
     */
    fun importProfile(context: Context, srcUri: Uri, targetProfileName: String, overwrite: Boolean = false): Result<Unit> {
        val targetDir = File(context.filesDir, safeDirNameFor(targetProfileName))
        val tmpDir = File(context.filesDir, safeDirNameFor(targetProfileName) + ".importing_tmp")
        return try {
            if (targetDir.exists()) {
                val isRegistered = ProfileSlots.listProfiles(context).contains(targetProfileName)
                if (isRegistered && !overwrite) {
                    return Result.failure(
                        ProfileAlreadyExistsException("Đã có dữ liệu cho tên hồ sơ này rồi")
                    )
                }
                if (isRegistered) {
                    // Ghi đè CÓ CHỦ Ý (người dùng đã xác nhận) — xóa dữ liệu
                    // CŨ trước khi giải nén dữ liệu MỚI vào cùng tên, để
                    // không lẫn file cũ/mới với nhau trong cùng thư mục.
                    DebugLog.log("ProfileExportImport.importProfile: ghi đè hồ sơ '$targetProfileName' theo yêu cầu người dùng (overwrite=true)")
                    targetDir.deleteRecursively()
                } else {
                    // Rác mồ côi (chưa từng đăng ký) — tự dọn để cho import
                    // lại, không bắt người dùng tự xoá thủ công ngoài app.
                    DebugLog.log("ProfileExportImport.importProfile: '$targetProfileName' có thư mục trên đĩa nhưng CHƯA đăng ký trong ProfileSlots — coi là rác mồ côi từ lần import lỗi trước, tự xoá để import lại")
                    targetDir.deleteRecursively()
                }
            }
            // Dọn thư mục tạm còn sót từ lần thử TRƯỚC ĐÓ nữa (nếu app bị
            // kill giữa chừng, không kịp chạy tới catch/finally dọn dẹp).
            if (tmpDir.exists()) tmpDir.deleteRecursively()

            context.contentResolver.openInputStream(srcUri)?.use { input ->
                ZipInputStream(input).use { zip ->
                    var entry: ZipEntry? = zip.nextEntry
                    var prefsJsonText: String? = null
                    while (entry != null) {
                        val name = entry.name
                        when {
                            name == "app_prefs.json" -> {
                                prefsJsonText = zip.readBytes().toString(Charsets.UTF_8)
                            }
                            name.startsWith("profile_data/") -> {
                                val relPath = name.removePrefix("profile_data/")
                                if (relPath.isNotBlank()) {
                                    // Ghi vào THƯ MỤC TẠM, không phải targetDir thật
                                    val outFile = File(tmpDir, relPath)
                                    if (entry.isDirectory) {
                                        outFile.mkdirs()
                                    } else {
                                        outFile.parentFile?.mkdirs()
                                        outFile.outputStream().use { fout -> zip.copyTo(fout) }
                                    }
                                }
                            }
                            // manifest.json — chỉ tham khảo, không cần xử lý gì thêm
                        }
                        zip.closeEntry()
                        entry = zip.nextEntry
                    }
                    prefsJsonText?.let { text ->
                        val json = JSONObject(text)
                        val map = mutableMapOf<String, Any?>()
                        json.keys().forEach { k -> map[k] = json.get(k) }
                        AppPrefs.importNamespace(context, targetProfileName, map)
                    }
                }
            } ?: return Result.failure(IllegalStateException("Không mở được file đã chọn"))
            // COMMIT ATOMIC: mọi bước giải nén + AppPrefs đã xong xuôi —
            // giờ mới đổi tên thư mục tạm thành thư mục thật. rename() là
            // thao tác tức thời (không copy lại toàn bộ dữ liệu), và chỉ
            // tới đây `targetDir` mới thật sự tồn tại — khớp đúng ý nghĩa
            // "đã có dữ liệu" của thông báo lỗi ở đầu hàm.
            if (!tmpDir.renameTo(targetDir)) {
                throw IllegalStateException("Không đổi tên được thư mục tạm sang hồ sơ thật (rename thất bại)")
            }
            ProfileSlots.addProfile(context, targetProfileName)
            Result.success(Unit)
        } catch (e: Exception) {
            DebugLog.log("ProfileExportImport.importProfile lỗi: ${e.javaClass.simpleName}: ${e.message}")
            // Dọn sạch thư mục TẠM nếu còn — đảm bảo lần thử lại SAU không
            // bị chặn bởi rác của lần lỗi NÀY (đây chính là nguyên nhân gốc
            // của bug "báo có mà thực tế chưa có" — xem chú thích ở đầu hàm).
            try {
                if (tmpDir.exists()) tmpDir.deleteRecursively()
            } catch (cleanupError: Exception) {
                DebugLog.log("ProfileExportImport.importProfile: dọn tmpDir lỗi (không nghiêm trọng): ${cleanupError.message}")
            }
            Result.failure(e)
        }
    }

    private fun writeZipEntry(zip: ZipOutputStream, name: String, bytes: ByteArray) {
        zip.putNextEntry(ZipEntry(name))
        zip.write(bytes)
        zip.closeEntry()
    }

    /** Trả về (số file đã zip, tổng byte GỐC trước nén) để hàm gọi log
     * tổng kết — giúp so sánh với byte SAU nén (từ CountingOutputStream)
     * nếu cần chẩn đoán tỉ lệ nén bất thường. */
    private fun zipDirRecursive(zip: ZipOutputStream, dir: File, entryPrefix: String): Pair<Int, Long> {
        val files = dir.listFiles() ?: run {
            DebugLog.log("ProfileExportImport.zipDirRecursive: listFiles() trả về NULL cho '${dir.absolutePath}' (không có quyền đọc, hoặc không phải thư mục) — bỏ qua toàn bộ nhánh này")
            return 0 to 0L
        }
        var fileCount = 0
        var byteCount = 0L
        for (f in files) {
            val entryName = "$entryPrefix/${f.name}"
            if (f.isDirectory) {
                val (c, b) = zipDirRecursive(zip, f, entryName)
                fileCount += c
                byteCount += b
            } else {
                try {
                    zip.putNextEntry(ZipEntry(entryName))
                    f.inputStream().use { it.copyTo(zip) }
                    zip.closeEntry()
                    fileCount++
                    byteCount += f.length()
                } catch (e: Exception) {
                    // Gecko có thể đang khoá 1 vài file (sqlite -wal/-shm) nếu hồ
                    // sơ đang chạy — bỏ qua file đó, không làm hỏng cả gói xuất.
                    // Khuyến cáo đóng hẳn khe trước khi xuất (xem UI cảnh báo).
                    DebugLog.log("Bỏ qua file khi xuất (có thể đang bị khoá): ${f.path} (${f.length()} byte) — ${e.javaClass.simpleName}: ${e.message}")
                }
            }
        }
        return fileCount to byteCount
    }

    /** PHẢI khớp CHÍNH XÁC với `GeckoRuntimeProvider.safeDirNameFor` — trùng
     * logic vì đây là 2 lớp khác nhau, không dùng chung được (tránh vòng
     * phụ thuộc core<->core không cần thiết); nếu sửa 1 bên nhớ sửa bên kia. */
    private fun safeDirNameFor(namespace: String) =
        "gecko_profile_" + namespace.replace(Regex("[^a-zA-Z0-9_-]"), "_")
}
