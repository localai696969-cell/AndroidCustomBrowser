package com.colablive.keeper.core

import android.content.Context
import android.net.Uri
import org.json.JSONObject
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * Xuất/nhập 1 hồ sơ (dữ liệu trình duyệt Gecko + cấu hình fingerprint/proxy
 * trong AppPrefs) thành 1 file .zip di động được — trả lời câu hỏi "mỗi
 * profile là 1 dữ liệu độc lập... có restore được khi gỡ cài lại, hoặc
 * mang qua máy khác không". TRƯỚC ĐÂY: hoàn toàn KHÔNG — dữ liệu chỉ nằm
 * trong bộ nhớ riêng của app (`/data/user/0/.../files`), Android tự xoá
 * sạch khi gỡ cài, không có cách nào lấy ra/đưa vào.
 *
 * Cấu trúc file .zip xuất ra:
 *   profile_data/...           toàn bộ thư mục hồ sơ Gecko (cookie, đăng
 *                               nhập, cache, lịch sử — places.sqlite nằm ở
 *                               đây, xem câu hỏi về lịch sử)
 *   app_prefs.json              cấu hình fingerprint/proxy/... của hồ sơ
 *   manifest.json                tên hồ sơ gốc + thời điểm xuất (tham khảo)
 *
 * CHỈ dùng java.util.zip (thư viện Java chuẩn, luôn có sẵn, không phụ
 * thuộc thư viện ngoài) — không đụng API GeckoView nào, nên không có rủi ro
 * đoán sai API như các phần MediaSession đã từng nói.
 */
object ProfileExportImport {

    /**
     * Xuất hồ sơ `profileName` ra `destUri` (URI người dùng chọn qua
     * Storage Access Framework — xem `ProfilePickerActivity`). Chạy trên
     * luồng nền (I/O có thể chậm với hồ sơ lớn).
     */
    fun exportProfile(context: Context, profileName: String, destUri: Uri): Result<Unit> {
        return try {
            val profileDir = File(context.filesDir, safeDirNameFor(profileName))
            context.contentResolver.openOutputStream(destUri)?.use { out ->
                ZipOutputStream(out).use { zip ->
                    // 1) Cấu hình AppPrefs (fingerprint/proxy/...) của hồ sơ này
                    val prefsJson = JSONObject()
                    AppPrefs.exportNamespace(context, profileName).forEach { (k, v) ->
                        prefsJson.put(k, v)
                    }
                    writeZipEntry(zip, "app_prefs.json", prefsJson.toString().toByteArray())

                    // 2) Thông tin tham khảo
                    val manifest = JSONObject().apply {
                        put("profile_name", profileName)
                        put("exported_at", System.currentTimeMillis())
                        put("app_version", BuildMarker.VERSION)
                    }
                    writeZipEntry(zip, "manifest.json", manifest.toString().toByteArray())

                    // 3) Toàn bộ thư mục dữ liệu trình duyệt (nếu có)
                    if (profileDir.exists()) {
                        zipDirRecursive(zip, profileDir, "profile_data")
                    }
                }
            } ?: return Result.failure(IllegalStateException("Không mở được nơi lưu file"))
            Result.success(Unit)
        } catch (e: Exception) {
            DebugLog.log("ProfileExportImport.exportProfile lỗi: ${e.javaClass.simpleName}: ${e.message}")
            Result.failure(e)
        }
    }

    /**
     * Nhập 1 file .zip đã xuất trước đó thành hồ sơ TÊN MỚI `targetProfileName`
     * (không ghi đè hồ sơ đang tồn tại — để an toàn, người gọi tự kiểm tra
     * tên chưa trùng trước khi gọi hàm này, xem `ProfilePickerActivity`).
     *
     * BUG THẬT (người dùng báo: nhập "vpscolab691" liên tục báo "Đã có dữ
     * liệu cho tên hồ sơ này rồi" dù chưa từng nhập thành công lần nào —
     * xác nhận qua ảnh chụp màn hình: hồ sơ này KHÔNG hề xuất hiện trong
     * danh sách profile đã gán, tức `ProfileSlots` chưa từng đăng ký nó):
     * code CŨ ghi file trực tiếp vào `targetDir` ngay trong lúc giải nén —
     * nếu bất kỳ bước nào giữa chừng ném exception (file zip lỗi, hết
     * dung lượng, `AppPrefs.importNamespace`/`ProfileSlots.addProfile` lỗi,
     * v.v.), hàm trả `Result.failure` NHƯNG `targetDir` đã có sẵn 1 phần
     * dữ liệu rồi — không hề dọn dẹp. Lần thử lại SAU đó luôn bị chặn ngay
     * từ `if (targetDir.exists())`, dù dữ liệu thật KHÔNG đầy đủ/hợp lệ —
     * đúng như người dùng mô tả "báo có mà thực tế chưa có".
     *
     * Sửa theo mô hình TRANSACTION ATOMIC: giải nén vào 1 thư mục TẠM
     * riêng, chỉ đổi tên (rename — thao tác tức thời, không copy lại) thành
     * `targetDir` thật SAU KHI mọi bước (giải nén + AppPrefs +
     * ProfileSlots.addProfile) đã thành công hoàn toàn. Bất kỳ lỗi nào
     * giữa chừng đều tự xoá sạch thư mục tạm — `targetDir` CHỈ tồn tại khi
     * import thật sự xong xuôi, khớp đúng ý nghĩa của thông báo lỗi.
     *
     * Đồng thời DỌN RÁC MỒ CÔI: nếu `targetDir` đã tồn tại từ MỘT LẦN THỬ
     * LỖI TRƯỚC (từ bản cũ chưa có fix này) nhưng tên hồ sơ đó CHƯA TỪNG
     * được đăng ký trong `ProfileSlots.listProfiles()`, coi đó là rác mồ
     * côi — tự xoá rồi cho phép import lại, thay vì chặn vĩnh viễn buộc
     * người dùng phải tự vào file manager xoá thủ công.
     */
    fun importProfile(context: Context, srcUri: Uri, targetProfileName: String): Result<Unit> {
        val targetDir = File(context.filesDir, safeDirNameFor(targetProfileName))
        val tmpDir = File(context.filesDir, safeDirNameFor(targetProfileName) + ".importing_tmp")
        return try {
            if (targetDir.exists()) {
                val isRegistered = ProfileSlots.listProfiles(context).contains(targetProfileName)
                if (isRegistered) {
                    return Result.failure(IllegalStateException("Đã có dữ liệu cho tên hồ sơ này rồi"))
                }
                // Rác mồ côi (chưa từng đăng ký) — tự dọn để cho import lại,
                // không bắt người dùng tự xoá thủ công ngoài app.
                DebugLog.log("ProfileExportImport.importProfile: '$targetProfileName' có thư mục trên đĩa nhưng CHƯA đăng ký trong ProfileSlots — coi là rác mồ côi từ lần import lỗi trước, tự xoá để import lại")
                targetDir.deleteRecursively()
            }
            // Dọn thư mục tạm còn sót từ lần thử TRƯỚC ĐÓ nữa (nếu app bị
            // kill giữa chừng, không kịp chạy tới catch/finally dọn dẹp).
            if (tmpDir.exists()) tmpDir.deleteRecursively()

            context.contentResolver.openInputStream(srcUri)?.use { input ->
                ZipInputStream(input).use { zip ->
                    var entry: ZipEntry? = zip.nextEntry
                    var prefsJsonText: String? = null
                    while (entry != null) {
                        val name = entry.name
                        when {
                            name == "app_prefs.json" -> {
                                prefsJsonText = zip.readBytes().toString(Charsets.UTF_8)
                            }
                            name.startsWith("profile_data/") -> {
                                val relPath = name.removePrefix("profile_data/")
                                if (relPath.isNotBlank()) {
                                    // Ghi vào THƯ MỤC TẠM, không phải targetDir thật
                                    val outFile = File(tmpDir, relPath)
                                    if (entry.isDirectory) {
                                        outFile.mkdirs()
                                    } else {
                                        outFile.parentFile?.mkdirs()
                                        outFile.outputStream().use { fout -> zip.copyTo(fout) }
                                    }
                                }
                            }
                            // manifest.json — chỉ tham khảo, không cần xử lý gì thêm
                        }
                        zip.closeEntry()
                        entry = zip.nextEntry
                    }
                    prefsJsonText?.let { text ->
                        val json = JSONObject(text)
                        val map = mutableMapOf<String, Any?>()
                        json.keys().forEach { k -> map[k] = json.get(k) }
                        AppPrefs.importNamespace(context, targetProfileName, map)
                    }
                }
            } ?: return Result.failure(IllegalStateException("Không mở được file đã chọn"))
            // COMMIT ATOMIC: mọi bước giải nén + AppPrefs đã xong xuôi —
            // giờ mới đổi tên thư mục tạm thành thư mục thật. rename() là
            // thao tác tức thời (không copy lại toàn bộ dữ liệu), và chỉ
            // tới đây `targetDir` mới thật sự tồn tại — khớp đúng ý nghĩa
            // "đã có dữ liệu" của thông báo lỗi ở đầu hàm.
            if (!tmpDir.renameTo(targetDir)) {
                throw IllegalStateException("Không đổi tên được thư mục tạm sang hồ sơ thật (rename thất bại)")
            }
            ProfileSlots.addProfile(context, targetProfileName)
            Result.success(Unit)
        } catch (e: Exception) {
            DebugLog.log("ProfileExportImport.importProfile lỗi: ${e.javaClass.simpleName}: ${e.message}")
            // Dọn sạch thư mục TẠM nếu còn — đảm bảo lần thử lại SAU không
            // bị chặn bởi rác của lần lỗi NÀY (đây chính là nguyên nhân gốc
            // của bug "báo có mà thực tế chưa có" — xem chú thích ở đầu hàm).
            try {
                if (tmpDir.exists()) tmpDir.deleteRecursively()
            } catch (cleanupError: Exception) {
                DebugLog.log("ProfileExportImport.importProfile: dọn tmpDir lỗi (không nghiêm trọng): ${cleanupError.message}")
            }
            Result.failure(e)
        }
    }

    private fun writeZipEntry(zip: ZipOutputStream, name: String, bytes: ByteArray) {
        zip.putNextEntry(ZipEntry(name))
        zip.write(bytes)
        zip.closeEntry()
    }

    private fun zipDirRecursive(zip: ZipOutputStream, dir: File, entryPrefix: String) {
        val files = dir.listFiles() ?: return
        for (f in files) {
            val entryName = "$entryPrefix/${f.name}"
            if (f.isDirectory) {
                zipDirRecursive(zip, f, entryName)
            } else {
                try {
                    zip.putNextEntry(ZipEntry(entryName))
                    f.inputStream().use { it.copyTo(zip) }
                    zip.closeEntry()
                } catch (e: Exception) {
                    // Gecko có thể đang khoá 1 vài file (sqlite -wal/-shm) nếu hồ
                    // sơ đang chạy — bỏ qua file đó, không làm hỏng cả gói xuất.
                    // Khuyến cáo đóng hẳn khe trước khi xuất (xem UI cảnh báo).
                    DebugLog.log("Bỏ qua file khi xuất (có thể đang bị khoá): ${f.path} — ${e.message}")
                }
            }
        }
    }

    /** PHẢI khớp CHÍNH XÁC với `GeckoRuntimeProvider.safeDirNameFor` — trùng
     * logic vì đây là 2 lớp khác nhau, không dùng chung được (tránh vòng
     * phụ thuộc core<->core không cần thiết); nếu sửa 1 bên nhớ sửa bên kia. */
    private fun safeDirNameFor(namespace: String) =
        "gecko_profile_" + namespace.replace(Regex("[^a-zA-Z0-9_-]"), "_")
}
