package com.colablive.keeper.core

import android.content.Context
import android.net.Uri
import org.json.JSONObject
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * Xuất/nhập 1 hồ sơ (dữ liệu trình duyệt Gecko + cấu hình fingerprint/proxy
 * trong AppPrefs) thành 1 file .zip di động được — trả lời câu hỏi "mỗi
 * profile là 1 dữ liệu độc lập... có restore được khi gỡ cài lại, hoặc
 * mang qua máy khác không". TRƯỚC ĐÂY: hoàn toàn KHÔNG — dữ liệu chỉ nằm
 * trong bộ nhớ riêng của app (`/data/user/0/.../files`), Android tự xoá
 * sạch khi gỡ cài, không có cách nào lấy ra/đưa vào.
 *
 * Cấu trúc file .zip xuất ra:
 *   profile_data/...           toàn bộ thư mục hồ sơ Gecko (cookie, đăng
 *                               nhập, cache, lịch sử — places.sqlite nằm ở
 *                               đây, xem câu hỏi về lịch sử)
 *   app_prefs.json              cấu hình fingerprint/proxy/... của hồ sơ
 *   manifest.json                tên hồ sơ gốc + thời điểm xuất (tham khảo)
 *
 * CHỈ dùng java.util.zip (thư viện Java chuẩn, luôn có sẵn, không phụ
 * thuộc thư viện ngoài) — không đụng API GeckoView nào, nên không có rủi ro
 * đoán sai API như các phần MediaSession đã từng nói.
 */
/**
 * Ném ra khi import trùng tên hồ sơ ĐÃ ĐĂNG KÝ và người gọi CHƯA xác nhận
 * ghi đè (`overwrite=false`) — UI (`ProfilePickerActivity`) bắt riêng
 * exception này để hiện dialog hỏi "Ghi đè?" thay vì báo lỗi chung chung.
 */
class ProfileAlreadyExistsException(message: String) : Exception(message)

object ProfileExportImport {

    /**
     * Xuất hồ sơ `profileName` ra `destUri` (URI người dùng chọn qua
     * Storage Access Framework — xem `ProfilePickerActivity`). Chạy trên
     * luồng nền (I/O có thể chậm với hồ sơ lớn).
     */
    fun exportProfile(context: Context, profileName: String, destUri: Uri): Result<ExportSummary> {
        /**
         * FIX THIẾU LOG (người dùng yêu cầu đúng: "export profile vẫn lỗi
         * 0B mà không hề có log chẩn đoán nào để tra tiếp" — trước đây
         * hàm này gần như câm lặng, chỉ log khi CATCH được exception, còn
         * trường hợp "chạy xong không lỗi gì nhưng zip vẫn rỗng/thiếu dữ
         * liệu" thì hoàn toàn không có manh mối). Thêm log ở TỪNG bước —
         * đủ để lần test tới trả lời dứt điểm: profileDir có tồn tại
         * không, có bao nhiêu file trong đó, mỗi entry ghi được bao nhiêu
         * byte, tổng cộng file zip ra bao nhiêu byte — không còn phải đoán.
         */
        val profileDir = File(context.filesDir, safeDirNameFor(profileName))
        val dirFileCount = if (profileDir.exists()) profileDir.walkTopDown().count { it.isFile } else -1
        DebugLog.log("ProfileExportImport.exportProfile BẮT ĐẦU: profileName='$profileName' profileDir=${profileDir.absolutePath} exists=${profileDir.exists()} soFileBenTrong=$dirFileCount destUri=$destUri")
        var totalBytesWritten = 0L
        var totalEntriesWritten = 0
        var skippedLockedFiles = 0
        return try {
            val profileDirLocal = profileDir
            context.contentResolver.openOutputStream(destUri)?.use { out ->
                CountingOutputStream(out) { totalBytesWritten = it }.let { counting ->
                ZipOutputStream(counting).use { zip ->
                    // 1) Cấu hình AppPrefs (fingerprint/proxy/...) của hồ sơ này
                    val prefsJson = JSONObject()
                    AppPrefs.exportNamespace(context, profileName).forEach { (k, v) ->
                        prefsJson.put(k, v)
                    }
                    val prefsBytes = prefsJson.toString().toByteArray()
                    writeZipEntry(zip, "app_prefs.json", prefsBytes)
                    totalEntriesWritten++
                    DebugLog.log("ProfileExportImport.exportProfile: đã ghi app_prefs.json (${prefsBytes.size} byte, ${AppPrefs.exportNamespace(context, profileName).size} key)")

                    // 2) Thông tin tham khảo
                    val manifest = JSONObject().apply {
                        put("profile_name", profileName)
                        put("exported_at", System.currentTimeMillis())
                        put("app_version", BuildMarker.VERSION)
                    }
                    val manifestBytes = manifest.toString().toByteArray()
                    writeZipEntry(zip, "manifest.json", manifestBytes)
                    totalEntriesWritten++
                    DebugLog.log("ProfileExportImport.exportProfile: đã ghi manifest.json (${manifestBytes.size} byte)")

                    // 3) Toàn bộ thư mục dữ liệu trình duyệt (nếu có)
                    if (profileDirLocal.exists()) {
                        val (filesZipped, bytesZipped, skipped) = zipDirRecursive(zip, profileDirLocal, "profile_data")
                        totalEntriesWritten += filesZipped
                        skippedLockedFiles = skipped
                        DebugLog.log("ProfileExportImport.exportProfile: đã ghi profile_data/ ($filesZipped file, ~$bytesZipped byte trước nén — số byte SAU nén xem ở dòng tổng kết cuối, BỎ QUA $skipped file bị khoá)")
                    } else {
                        DebugLog.log("ProfileExportImport.exportProfile: profileDir KHÔNG TỒN TẠI ('${profileDirLocal.absolutePath}') — zip xuất ra sẽ CHỈ có app_prefs.json + manifest.json, KHÔNG có dữ liệu duyệt web nào (cookie/lịch sử/đăng nhập) — đây rất có thể là nguyên nhân 0B/gần-0B nếu tên hồ sơ không khớp thư mục thật")
                    }
                }
                }
            } ?: run {
                DebugLog.log("ProfileExportImport.exportProfile: openOutputStream(destUri) trả về NULL — không mở được nơi lưu, có thể quyền SAF đã bị thu hồi")
                return Result.failure(IllegalStateException("Không mở được nơi lưu file"))
            }
            /**
             * FIX MỚI (liên quan trực tiếp tới bug "ghi đè mất dữ liệu" —
             * xem chú thích lớn ở `importProfile`): TRƯỚC ĐÂY việc file bị
             * khoá (sqlite -wal/-shm khi khe đang chạy lúc export) chỉ ghi
             * vào DebugLog, người dùng KHÔNG CÓ CÁCH NÀO biết bản backup
             * vừa tạo ra bị THIẾU dữ liệu — dễ dẫn tới việc sau này dùng
             * chính bản backup thiếu đó để "ghi đè" (import overwrite),
             * tưởng đang khôi phục lại nhưng thực chất đang THAY dữ liệu
             * ĐẦY ĐỦ hiện tại bằng dữ liệu THIẾU. Trả kèm `skippedLockedFiles`
             * trong kết quả để UI (`ProfilePickerActivity`) hiện cảnh báo
             * RÕ RÀNG ngay lúc export xong, thay vì im lặng.
             */
            DebugLog.log("ProfileExportImport.exportProfile HOÀN TẤT: tổng $totalEntriesWritten entry, TỔNG CỘNG $totalBytesWritten byte đã ghi thật vào file zip, BỎ QUA $skippedLockedFiles file bị khoá (đây là con số quyết định — nếu số byte = 0 hoặc rất nhỏ dù các bước trên báo ghi thành công, khả năng cao OutputStream bị đóng/cắt ngang bởi hệ thống TRƯỚC KHI dữ liệu được flush xuống đĩa thật, xem thêm ExportBackupService.kt)")
            Result.success(ExportSummary(totalEntriesWritten, totalBytesWritten, skippedLockedFiles))
        } catch (e: Exception) {
            DebugLog.log("ProfileExportImport.exportProfile LỖI (đã ghi được $totalEntriesWritten entry / $totalBytesWritten byte trước khi lỗi): ${e.javaClass.simpleName}: ${e.message}")
            Result.failure(e)
        }
    }

    /** Tóm tắt kết quả export — `skippedLockedFiles > 0` nghĩa là bản
     * backup CÓ THỂ THIẾU dữ liệu (thường do khe đang chạy lúc export,
     * Gecko khoá file sqlite -wal/-shm) — UI nên cảnh báo rõ, đặc biệt
     * quan trọng nếu bản backup này sau này dùng để GHI ĐÈ hồ sơ khác. */
    data class ExportSummary(val entriesWritten: Int, val bytesWritten: Long, val skippedLockedFiles: Int)

    /** Đếm số byte thật sự chảy qua OutputStream — để biết chính xác zip
     * cuối cùng nặng bao nhiêu, không phải suy đoán từ kích thước file gốc
     * (nén có thể làm nhỏ đi nhiều, và đây là con số THẬT NẰM TRÊN ĐĨA). */
    private class CountingOutputStream(
        private val delegate: OutputStream,
        private val onCount: (Long) -> Unit
    ) : OutputStream() {
        private var count = 0L
        override fun write(b: Int) { delegate.write(b); count++; onCount(count) }
        override fun write(b: ByteArray, off: Int, len: Int) { delegate.write(b, off, len); count += len; onCount(count) }
        override fun flush() = delegate.flush()
        override fun close() = delegate.close()
    }

    /**
     * Nhập 1 file .zip đã xuất trước đó thành hồ sơ TÊN MỚI `targetProfileName`
     * (không ghi đè hồ sơ đang tồn tại — để an toàn, người gọi tự kiểm tra
     * tên chưa trùng trước khi gọi hàm này, xem `ProfilePickerActivity`).
     *
     * BUG THẬT (người dùng báo: nhập "vpscolab691" liên tục báo "Đã có dữ
     * liệu cho tên hồ sơ này rồi" dù chưa từng nhập thành công lần nào —
     * xác nhận qua ảnh chụp màn hình: hồ sơ này KHÔNG hề xuất hiện trong
     * danh sách profile đã gán, tức `ProfileSlots` chưa từng đăng ký nó):
     * code CŨ ghi file trực tiếp vào `targetDir` ngay trong lúc giải nén —
     * nếu bất kỳ bước nào giữa chừng ném exception (file zip lỗi, hết
     * dung lượng, `AppPrefs.importNamespace`/`ProfileSlots.addProfile` lỗi,
     * v.v.), hàm trả `Result.failure` NHƯNG `targetDir` đã có sẵn 1 phần
     * dữ liệu rồi — không hề dọn dẹp. Lần thử lại SAU đó luôn bị chặn ngay
     * từ `if (targetDir.exists())`, dù dữ liệu thật KHÔNG đầy đủ/hợp lệ —
     * đúng như người dùng mô tả "báo có mà thực tế chưa có".
     *
     * Sửa theo mô hình TRANSACTION ATOMIC: giải nén vào 1 thư mục TẠM
     * riêng, chỉ đổi tên (rename — thao tác tức thời, không copy lại) thành
     * `targetDir` thật SAU KHI mọi bước (giải nén + AppPrefs +
     * ProfileSlots.addProfile) đã thành công hoàn toàn. Bất kỳ lỗi nào
     * giữa chừng đều tự xoá sạch thư mục tạm — `targetDir` CHỈ tồn tại khi
     * import thật sự xong xuôi, khớp đúng ý nghĩa của thông báo lỗi.
     *
     * Đồng thời DỌN RÁC MỒ CÔI: nếu `targetDir` đã tồn tại từ MỘT LẦN THỬ
     * LỖI TRƯỚC (từ bản cũ chưa có fix này) nhưng tên hồ sơ đó CHƯA TỪNG
     * được đăng ký trong `ProfileSlots.listProfiles()`, coi đó là rác mồ
     * côi — tự xoá rồi cho phép import lại, thay vì chặn vĩnh viễn buộc
     * người dùng phải tự vào file manager xoá thủ công.
     */
    /**
     * BUG THIẾT KẾ THẬT (người dùng chỉ ra đúng, rất gay gắt và có lý):
     * trước đây `importProfile()` CHẶN CỨNG nếu tên hồ sơ đích ĐÃ đăng ký
     * — không có cách nào ghi đè, buộc người dùng phải GỠ CÀI ĐẶT TOÀN BỘ
     * APP (xóa sạch mọi hồ sơ khác, mọi dữ liệu khác) chỉ để "test" hoặc
     * thực sự dùng chức năng import — vô lý cho 1 tính năng có tên là
     * "backup/restore". Sửa: thêm tham số `overwrite` — mặc định vẫn
     * `false` (an toàn, không âm thầm ghi đè ngoài ý muốn), nhưng CHO PHÉP
     * gọi lại với `overwrite=true` sau khi người dùng xác nhận qua dialog
     * cảnh báo rõ ràng (xem `ProfilePickerActivity.kt`), không cần xóa gì
     * ở tầng hệ điều hành cả.
     */
    fun importProfile(context: Context, srcUri: Uri, targetProfileName: String, overwrite: Boolean = false): Result<Unit> {
        val targetDir = File(context.filesDir, safeDirNameFor(targetProfileName))
        val tmpDir = File(context.filesDir, safeDirNameFor(targetProfileName) + ".importing_tmp")
        return try {
            var willOverwriteExisting = false
            if (targetDir.exists()) {
                val isRegistered = ProfileSlots.listProfiles(context).contains(targetProfileName)
                if (isRegistered && !overwrite) {
                    return Result.failure(
                        ProfileAlreadyExistsException("Đã có dữ liệu cho tên hồ sơ này rồi")
                    )
                }
                /**
                 * BUG THẬT NGHIÊM TRỌNG đã sửa (người dùng báo, hoàn toàn
                 * đúng: "khi restore ghi đè profile cùng tên thì gần như
                 * tất cả mọi dữ liệu đều bị mất hết"): code CŨ gọi
                 * `targetDir.deleteRecursively()` NGAY TẠI ĐÂY — tức XOÁ
                 * SẠCH dữ liệu TỐT hiện có TRƯỚC KHI biết chắc file zip
                 * đang nhập có đầy đủ/hợp lệ hay không. Nếu file zip backup
                 * bị thiếu dữ liệu (chính hàm `zipDirRecursive` đã tự ghi
                 * chú: khi xuất LÚC khe đang chạy, các file sqlite khoá
                 * `-wal`/`-shm` bị BỎ QUA ÂM THẦM, chỉ ghi log — không báo
                 * cho người dùng biết bản backup không đầy đủ), hoặc quá
                 * trình giải nén bị lỗi giữa chừng (hết dung lượng, file
                 * zip hỏng, v.v.) — dữ liệu CŨ đã bị xoá mất VĨNH VIỄN,
                 * trong khi dữ liệu MỚI từ bản backup lại không đầy đủ
                 * bằng — đúng khớp triệu chứng "mất gần hết dữ liệu" dù
                 * thao tác "restore" tưởng như đã thành công.
                 *
                 * Đây CHÍNH LÀ việc vi phạm nguyên tắc ATOMIC mà hàm này ĐÃ
                 * áp dụng ĐÚNG cho nhánh import thường (giải nén vào thư
                 * mục TẠM trước, chỉ rename thành thật SAU KHI mọi bước
                 * thành công) — nhưng lại BỎ SÓT áp dụng cho đúng bước xoá
                 * dữ liệu CŨ khi ghi đè. Sửa: KHÔNG xoá `targetDir` ở đây
                 * nữa — chỉ đánh dấu `willOverwriteExisting = true`, để
                 * việc xoá dữ liệu cũ dời tới NGAY TRƯỚC bước rename cuối
                 * cùng (xem bên dưới) — tại đó, thư mục tạm đã giải nén
                 * XONG HẲN và chắc chắn hợp lệ, giảm tối đa khoảng thời
                 * gian dữ liệu cũ có thể bị mất mà không có gì thay thế.
                 */
                DebugLog.log(
                    if (isRegistered) "ProfileExportImport.importProfile: sẽ ghi đè hồ sơ '$targetProfileName' theo yêu cầu người dùng (overwrite=true) — dữ liệu CŨ sẽ CHỈ bị xoá SAU KHI giải nén dữ liệu MỚI xong xuôi hoàn toàn (an toàn hơn xoá ngay từ đầu)"
                    else "ProfileExportImport.importProfile: '$targetProfileName' có thư mục trên đĩa nhưng CHƯA đăng ký trong ProfileSlots — coi là rác mồ côi từ lần import lỗi trước, sẽ tự xoá SAU KHI giải nén dữ liệu mới xong (không phải ngay bây giờ)"
                )
                willOverwriteExisting = true
            }
            // Dọn thư mục tạm còn sót từ lần thử TRƯỚC ĐÓ nữa (nếu app bị
            // kill giữa chừng, không kịp chạy tới catch/finally dọn dẹp).
            if (tmpDir.exists()) tmpDir.deleteRecursively()

            var profileDataFilesExtracted = 0
            context.contentResolver.openInputStream(srcUri)?.use { input ->
                ZipInputStream(input).use { zip ->
                    var entry: ZipEntry? = zip.nextEntry
                    var prefsJsonText: String? = null
                    while (entry != null) {
                        val name = entry.name
                        when {
                            name == "app_prefs.json" -> {
                                prefsJsonText = zip.readBytes().toString(Charsets.UTF_8)
                            }
                            name.startsWith("profile_data/") -> {
                                val relPath = name.removePrefix("profile_data/")
                                if (relPath.isNotBlank()) {
                                    // Ghi vào THƯ MỤC TẠM, không phải targetDir thật
                                    val outFile = File(tmpDir, relPath)
                                    if (entry.isDirectory) {
                                        outFile.mkdirs()
                                    } else {
                                        outFile.parentFile?.mkdirs()
                                        outFile.outputStream().use { fout -> zip.copyTo(fout) }
                                        profileDataFilesExtracted++
                                    }
                                }
                            }
                            // manifest.json — chỉ tham khảo, không cần xử lý gì thêm
                        }
                        zip.closeEntry()
                        entry = zip.nextEntry
                    }
                    prefsJsonText?.let { text ->
                        val json = JSONObject(text)
                        val map = mutableMapOf<String, Any?>()
                        json.keys().forEach { k -> map[k] = json.get(k) }
                        AppPrefs.importNamespace(context, targetProfileName, map)
                    }
                }
            } ?: return Result.failure(IllegalStateException("Không mở được file đã chọn"))

            /**
             * KIỂM TRA AN TOÀN THÊM (theo đúng tinh thần "không đoán mù" —
             * nếu bản backup rõ ràng RỖNG hoặc gần rỗng trong khi SẮP xoá
             * dữ liệu cũ để thay bằng nó, dừng lại và báo lỗi rõ ràng thay
             * vì âm thầm tiến hành ghi đè bằng dữ liệu thiếu). Chỉ áp dụng
             * khi CÓ ghi đè — nếu là hồ sơ hoàn toàn mới (targetDir chưa hề
             * tồn tại), 0 file profile_data vẫn hợp lệ (hồ sơ mới tinh chưa
             * từng duyệt web gì cả).
             */
            if (willOverwriteExisting && profileDataFilesExtracted == 0) {
                DebugLog.log("ProfileExportImport.importProfile: DỪNG LẠI TRƯỚC KHI GHI ĐÈ — file zip giải nén ra 0 file profile_data/ nào (rất có thể export lỗi/rỗng, hoặc export lúc khe đang chạy khiến toàn bộ file bị khoá và bỏ qua) — KHÔNG xoá dữ liệu cũ để tránh mất trắng")
                tmpDir.deleteRecursively()
                return Result.failure(IllegalStateException("File backup có vẻ rỗng (0 file dữ liệu duyệt web) — đã HUỶ để tránh xoá mất dữ liệu hiện có. Kiểm tra lại file backup, hoặc đảm bảo khe đã đóng hẳn lúc export."))
            }

            // COMMIT ATOMIC: mọi bước giải nén + AppPrefs đã xong xuôi.
            // CHỈ TỚI ĐÂY mới xoá dữ liệu CŨ (nếu ghi đè) — ngay trước khi
            // đổi tên thư mục tạm thành thư mục thật, giảm tối đa khoảng
            // thời gian "không còn dữ liệu cũ mà cũng chưa có dữ liệu mới".
            if (willOverwriteExisting && targetDir.exists()) {
                targetDir.deleteRecursively()
            }
            if (!tmpDir.renameTo(targetDir)) {
                throw IllegalStateException("Không đổi tên được thư mục tạm sang hồ sơ thật (rename thất bại)")
            }
            ProfileSlots.addProfile(context, targetProfileName)
            Result.success(Unit)
        } catch (e: Exception) {
            DebugLog.log("ProfileExportImport.importProfile lỗi: ${e.javaClass.simpleName}: ${e.message}")
            // Dọn sạch thư mục TẠM nếu còn — đảm bảo lần thử lại SAU không
            // bị chặn bởi rác của lần lỗi NÀY (đây chính là nguyên nhân gốc
            // của bug "báo có mà thực tế chưa có" — xem chú thích ở đầu hàm).
            // LƯU Ý: nhờ sửa đổi ở trên, nếu lỗi xảy ra TRƯỚC bước xoá
            // targetDir (tức trong lúc giải nén/AppPrefs), dữ liệu CŨ vẫn
            // CÒN NGUYÊN — không bị mất, đúng tinh thần "atomic" cho cả 2
            // nhánh import mới VÀ ghi đè.
            try {
                if (tmpDir.exists()) tmpDir.deleteRecursively()
            } catch (cleanupError: Exception) {
                DebugLog.log("ProfileExportImport.importProfile: dọn tmpDir lỗi (không nghiêm trọng): ${cleanupError.message}")
            }
            Result.failure(e)
        }
    }

    private fun writeZipEntry(zip: ZipOutputStream, name: String, bytes: ByteArray) {
        zip.putNextEntry(ZipEntry(name))
        zip.write(bytes)
        zip.closeEntry()
    }

    /** Trả về (số file đã zip, tổng byte GỐC trước nén, số file BỊ BỎ QUA
     * vì khoá) để hàm gọi log tổng kết + cảnh báo người dùng nếu cần. */
    private fun zipDirRecursive(zip: ZipOutputStream, dir: File, entryPrefix: String): Triple<Int, Long, Int> {
        val files = dir.listFiles() ?: run {
            DebugLog.log("ProfileExportImport.zipDirRecursive: listFiles() trả về NULL cho '${dir.absolutePath}' (không có quyền đọc, hoặc không phải thư mục) — bỏ qua toàn bộ nhánh này")
            return Triple(0, 0L, 0)
        }
        var fileCount = 0
        var byteCount = 0L
        var skippedCount = 0
        for (f in files) {
            val entryName = "$entryPrefix/${f.name}"
            if (f.isDirectory) {
                val (c, b, s) = zipDirRecursive(zip, f, entryName)
                fileCount += c
                byteCount += b
                skippedCount += s
            } else {
                try {
                    zip.putNextEntry(ZipEntry(entryName))
                    f.inputStream().use { it.copyTo(zip) }
                    zip.closeEntry()
                    fileCount++
                    byteCount += f.length()
                } catch (e: Exception) {
                    // Gecko có thể đang khoá 1 vài file (sqlite -wal/-shm) nếu hồ
                    // sơ đang chạy — bỏ qua file đó, không làm hỏng cả gói xuất.
                    // Khuyến cáo đóng hẳn khe trước khi xuất (xem UI cảnh báo).
                    DebugLog.log("Bỏ qua file khi xuất (có thể đang bị khoá): ${f.path} (${f.length()} byte) — ${e.javaClass.simpleName}: ${e.message}")
                    skippedCount++
                }
            }
        }
        return Triple(fileCount, byteCount, skippedCount)
    }

    /** PHẢI khớp CHÍNH XÁC với `GeckoRuntimeProvider.safeDirNameFor` — trùng
     * logic vì đây là 2 lớp khác nhau, không dùng chung được (tránh vòng
     * phụ thuộc core<->core không cần thiết); nếu sửa 1 bên nhớ sửa bên kia. */
    private fun safeDirNameFor(namespace: String) =
        "gecko_profile_" + namespace.replace(Regex("[^a-zA-Z0-9_-]"), "_")
}
