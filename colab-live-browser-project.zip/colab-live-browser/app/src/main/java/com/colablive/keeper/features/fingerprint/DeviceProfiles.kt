package com.colablive.keeper.features.fingerprint

/**
 * Hồ sơ thiết bị TRỌN GÓI — mỗi phần tử đã tự nhất quán bên trong (không thể
 * ra tổ hợp platform Windows + WebGL Apple M1 kiểu vô lý). Random/Manual đều
 * chọn CẢ HỒ SƠ, không chỉnh từng thông số rời — cách này loại bỏ khả năng
 * tạo ra tổ hợp không nhất quán ngay từ thiết kế, thay vì phải validate rồi
 * báo lỗi sau.
 */
data class HardwareProfile(
    val label: String,
    val platform: String,          // navigator.platform
    val webglVendor: String,
    val webglRenderer: String,
    val hardwareConcurrency: Int,
    val deviceMemory: Int
)

data class LocaleProfile(
    val label: String,
    val timezoneName: String,           // IANA timezone, dùng cho Intl.DateTimeFormat
    val timezoneOffsetMinutes: Int,      // phút lệch so với UTC (dương = phía đông UTC)
    val language: String                 // navigator.language
)

object DeviceProfiles {
    val HARDWARE = listOf(
        HardwareProfile("Windows - Intel UHD", "Win32", "Intel Inc.", "Intel Iris OpenGL Engine", 4, 8),
        HardwareProfile("Windows - NVIDIA GTX", "Win32", "NVIDIA Corporation", "NVIDIA GeForce GTX 1660/PCIe/SSE2", 8, 16),
        HardwareProfile("Windows - AMD Radeon", "Win32", "AMD", "AMD Radeon RX 580 Series", 6, 16),
        HardwareProfile("MacBook - Apple M1", "MacIntel", "Apple Inc.", "Apple M1", 8, 8),
        HardwareProfile("Chromebook - Intel", "Linux armv8l", "Google Inc. (Intel)", "ANGLE (Intel, Intel(R) UHD Graphics 620, OpenGL 4.5)", 4, 4)
    )

    val LOCALE = listOf(
        LocaleProfile("Việt Nam", "Asia/Ho_Chi_Minh", 420, "vi-VN"),
        LocaleProfile("Singapore", "Asia/Singapore", 480, "en-SG"),
        LocaleProfile("Nhật Bản", "Asia/Tokyo", 540, "ja-JP"),
        LocaleProfile("Mỹ (New York)", "America/New_York", -300, "en-US"),
        LocaleProfile("Anh (London)", "Europe/London", 0, "en-GB")
    )
}
