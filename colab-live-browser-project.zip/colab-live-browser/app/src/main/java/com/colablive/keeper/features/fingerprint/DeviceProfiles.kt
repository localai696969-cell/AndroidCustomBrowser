package com.colablive.keeper.features.fingerprint

/**
 * Hồ sơ thiết bị TRỌN GÓI - đảm bảo nhất quán nội bộ.
 * V4.1: Thêm timezone đồng bộ proxy, auto behavior support.
 */
object DeviceProfiles {

    data class HardwareProfile(
        val name: String,
        val category: String,
        val platform: String,
        val userAgent: String,
        val webglVendor: String,
        val webglRenderer: String,
        val hardwareConcurrency: Int,
        val deviceMemory: Int,
        val screenWidth: Int,
        val screenHeight: Int,
        val colorDepth: Int,
        val pixelRatio: Float,
        /** 0 cho desktop (chuột) thật — máy Android chạy app này LUÔN có cảm
         * ứng thật, nếu không set field này thì chọn 1 hồ sơ desktop vẫn để
         * lộ maxTouchPoints > 0 thật, mâu thuẫn với UA/platform giả Windows. */
        val maxTouchPoints: Int
    )

    data class LocaleProfile(
        val name: String,
        val timezone: String,
        val language: String,
        val languages: List<String>,
        val locale: String
    )

    // ===== 20 Hardware Presets =====
    // UA dùng Firefox/Gecko THẬT (rv:140.0) — KHỚP với engine thật của app
    // (GeckoView = Gecko/SpiderMonkey). Trước đây dùng UA Chrome trong khi
    // engine chạy thật là Gecko — mismatch tận gốc không cách nào vá triệt
    // để bằng override property được (xem PROJECT_STATUS.md mục "Lượt 6").
    // ⚠️ rv:140.0 là số phiên bản Firefox HỢP LÝ tại thời điểm viết — Firefox
    // ra bản mới ~mỗi 4 tuần, CẦN cập nhật số này định kỳ để không bị lộ vì
    // là số phiên bản quá cũ/không tồn tại.
    val hardwareProfiles = listOf(
        HardwareProfile("Windows 11 + Intel i7 + RTX 3060", "desktop", "Win32",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0",
            "NVIDIA Corporation", "NVIDIA GeForce RTX 3060/PCIe/SSE2", 16, 32, 1920, 1080, 24, 1.0f, 0),
        HardwareProfile("Windows 11 + Intel i5 + GTX 1660", "desktop", "Win32",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0",
            "NVIDIA Corporation", "NVIDIA GeForce GTX 1660/PCIe/SSE2", 8, 16, 1920, 1080, 24, 1.0f, 0),
        HardwareProfile("Windows 10 + AMD Ryzen 5 + RX 6700", "desktop", "Win32",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0",
            "AMD", "AMD Radeon RX 6700 XT", 12, 32, 2560, 1440, 24, 1.0f, 0),
        HardwareProfile("Windows 10 + AMD Ryzen 7 + RX 580", "desktop", "Win32",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0",
            "AMD", "AMD Radeon RX 580", 16, 64, 1920, 1080, 24, 1.0f, 0),
        HardwareProfile("MacBook Pro M3 14-inch", "desktop", "MacIntel",
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:140.0) Gecko/20100101 Firefox/140.0",
            "Apple Inc.", "Apple M3 Pro GPU", 12, 36, 3024, 1964, 30, 2.0f, 0),
        HardwareProfile("MacBook Air M2 13-inch", "desktop", "MacIntel",
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:140.0) Gecko/20100101 Firefox/140.0",
            "Apple Inc.", "Apple M2 GPU", 8, 24, 2560, 1664, 30, 2.0f, 0),
        HardwareProfile("iMac M3 24-inch", "desktop", "MacIntel",
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:140.0) Gecko/20100101 Firefox/140.0",
            "Apple Inc.", "Apple M3 GPU", 8, 16, 4480, 2520, 30, 2.0f, 0),
        HardwareProfile("Ubuntu + Intel i7 + Mesa", "desktop", "Linux x86_64",
            "Mozilla/5.0 (X11; Linux x86_64; rv:140.0) Gecko/20100101 Firefox/140.0",
            "Intel", "Mesa Intel(R) UHD Graphics 770", 16, 32, 1920, 1080, 24, 1.0f, 0),
        HardwareProfile("Fedora + AMD Ryzen + Mesa", "desktop", "Linux x86_64",
            "Mozilla/5.0 (X11; Linux x86_64; rv:140.0) Gecko/20100101 Firefox/140.0",
            "AMD", "AMD Radeon Graphics (radeonsi, renoir, LLVM 17.0.6, DRM 3.57)", 8, 16, 2560, 1440, 24, 1.0f, 0),
        HardwareProfile("Chromebook Pixel (Linux/Crostini) ⚠️", "desktop", "Linux x86_64",
            "Mozilla/5.0 (X11; Linux x86_64; rv:140.0) Gecko/20100101 Firefox/140.0",
            "Intel", "Mesa Intel(R) HD Graphics 5500", 4, 8, 2560, 1700, 24, 2.0f, 0),
        HardwareProfile("Samsung Galaxy S24 Ultra", "mobile", "Linux armv8l",
            "Mozilla/5.0 (Android 14; Mobile; rv:140.0) Gecko/140.0 Firefox/140.0",
            "ARM", "Mali-G720 Immortalis MP12", 8, 12, 3120, 1440, 24, 3.5f, 5),
        HardwareProfile("Samsung Galaxy S24", "mobile", "Linux armv8l",
            "Mozilla/5.0 (Android 14; Mobile; rv:140.0) Gecko/140.0 Firefox/140.0",
            "ARM", "Mali-G720 MP7", 8, 8, 2340, 1080, 24, 2.6f, 5),
        HardwareProfile("Samsung Galaxy A55", "mobile", "Linux armv8l",
            "Mozilla/5.0 (Android 14; Mobile; rv:140.0) Gecko/140.0 Firefox/140.0",
            "ARM", "Mali-G68 MP5", 8, 8, 2340, 1080, 24, 2.6f, 5),
        HardwareProfile("Xiaomi 14 Ultra", "mobile", "Linux armv8l",
            "Mozilla/5.0 (Android 14; Mobile; rv:140.0) Gecko/140.0 Firefox/140.0",
            "Qualcomm", "Adreno (TM) 750", 16, 16, 3200, 1440, 24, 3.2f, 5),
        HardwareProfile("Xiaomi Redmi Note 13 Pro", "mobile", "Linux armv8l",
            "Mozilla/5.0 (Android 13; Mobile; rv:140.0) Gecko/140.0 Firefox/140.0",
            "Qualcomm", "Adreno (TM) 710", 8, 12, 2712, 1220, 24, 2.4f, 5),
        HardwareProfile("Google Pixel 8 Pro", "mobile", "Linux armv8l",
            "Mozilla/5.0 (Android 14; Mobile; rv:140.0) Gecko/140.0 Firefox/140.0",
            "Google Inc.", "Mali-G715 MP7", 8, 12, 2992, 1344, 24, 2.5f, 5),
        HardwareProfile("Google Pixel 8a", "mobile", "Linux armv8l",
            "Mozilla/5.0 (Android 14; Mobile; rv:140.0) Gecko/140.0 Firefox/140.0",
            "Google Inc.", "Mali-G715 MP7", 8, 8, 2400, 1080, 24, 2.0f, 5),
        HardwareProfile("iPhone 15 Pro Max ⚠️ KHÔNG THỂ NHẤT QUÁN", "mobile", "iPhone",
            "Mozilla/5.0 (iPhone; CPU iPhone OS 17_5_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) FxiOS/140.0 Mobile/15E148 Safari/605.1.15",
            "Apple Inc.", "Apple GPU", 6, 8, 2796, 1290, 24, 3.0f, 5),
        HardwareProfile("iPhone 15 ⚠️ KHÔNG THỂ NHẤT QUÁN", "mobile", "iPhone",
            "Mozilla/5.0 (iPhone; CPU iPhone OS 17_5_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) FxiOS/140.0 Mobile/15E148 Safari/605.1.15",
            "Apple Inc.", "Apple GPU", 6, 6, 2556, 1179, 24, 2.8f, 5),
        HardwareProfile("OnePlus 12", "mobile", "Linux armv8l",
            "Mozilla/5.0 (Android 14; Mobile; rv:140.0) Gecko/140.0 Firefox/140.0",
            "Qualcomm", "Adreno (TM) 750", 16, 16, 3168, 1440, 24, 3.2f, 5)
    )

    // ===== 20 Locale Presets với Timezone =====
    val localeProfiles = listOf(
        LocaleProfile("Việt Nam", "Asia/Ho_Chi_Minh", "vi-VN", listOf("vi-VN", "vi", "en-US", "en"), "vi-VN"),
        LocaleProfile("Singapore", "Asia/Singapore", "en-SG", listOf("en-SG", "en", "zh-SG", "zh"), "en-SG"),
        LocaleProfile("Malaysia", "Asia/Kuala_Lumpur", "ms-MY", listOf("ms-MY", "en-MY", "en", "zh"), "ms-MY"),
        LocaleProfile("Thái Lan", "Asia/Bangkok", "th-TH", listOf("th-TH", "en"), "th-TH"),
        LocaleProfile("Indonesia", "Asia/Jakarta", "id-ID", listOf("id-ID", "en"), "id-ID"),
        LocaleProfile("Philippines", "Asia/Manila", "en-PH", listOf("en-PH", "en", "tl"), "en-PH"),
        LocaleProfile("Nhật Bản", "Asia/Tokyo", "ja-JP", listOf("ja-JP", "ja", "en"), "ja-JP"),
        LocaleProfile("Hàn Quốc", "Asia/Seoul", "ko-KR", listOf("ko-KR", "ko", "en"), "ko-KR"),
        LocaleProfile("Đài Loan", "Asia/Taipei", "zh-TW", listOf("zh-TW", "zh", "en"), "zh-TW"),
        LocaleProfile("Ấn Độ", "Asia/Kolkata", "en-IN", listOf("en-IN", "hi-IN", "en", "hi"), "en-IN"),
        LocaleProfile("Mỹ (East)", "America/New_York", "en-US", listOf("en-US", "en"), "en-US"),
        LocaleProfile("Mỹ (West)", "America/Los_Angeles", "en-US", listOf("en-US", "en", "es-US", "es"), "en-US"),
        LocaleProfile("Anh", "Europe/London", "en-GB", listOf("en-GB", "en"), "en-GB"),
        LocaleProfile("Đức", "Europe/Berlin", "de-DE", listOf("de-DE", "de", "en"), "de-DE"),
        LocaleProfile("Pháp", "Europe/Paris", "fr-FR", listOf("fr-FR", "fr", "en"), "fr-FR"),
        LocaleProfile("Úc", "Australia/Sydney", "en-AU", listOf("en-AU", "en"), "en-AU"),
        LocaleProfile("Canada", "America/Toronto", "en-CA", listOf("en-CA", "fr-CA", "en", "fr"), "en-CA"),
        LocaleProfile("Brazil", "America/Sao_Paulo", "pt-BR", listOf("pt-BR", "pt", "en"), "pt-BR"),
        LocaleProfile("Nga", "Europe/Moscow", "ru-RU", listOf("ru-RU", "ru", "en"), "ru-RU"),
        LocaleProfile("Trung Quốc", "Asia/Shanghai", "zh-CN", listOf("zh-CN", "zh", "en"), "zh-CN")
    )

    /**
     * Random theo slotIndex (bền — cùng slot luôn ra cùng profile).
     */
    fun getRandomProfile(slotIndex: Int): Pair<HardwareProfile, LocaleProfile> {
        val seed = slotIndex * 7919L + 104729L
        val hwIndex = (seed % hardwareProfiles.size).toInt()
        val locIndex = ((seed * 31) % localeProfiles.size).toInt()
        return hardwareProfiles[hwIndex] to localeProfiles[locIndex]
    }

    /**
     * Random theo timestamp (đổi mới MỖI LẦN gọi).
     */
    fun getRandomProfileFresh(): Pair<HardwareProfile, LocaleProfile> {
        val timestamp = System.currentTimeMillis()
        val hwIndex = ((timestamp * 7919L) % hardwareProfiles.size).toInt()
        val locIndex = ((timestamp * 104729L) % localeProfiles.size).toInt()
        return hardwareProfiles[hwIndex] to localeProfiles[locIndex]
    }

    fun getProfileByIndex(hwIndex: Int, locIndex: Int): Pair<HardwareProfile, LocaleProfile> {
        val safeHw = hwIndex.coerceIn(0, hardwareProfiles.size - 1)
        val safeLoc = locIndex.coerceIn(0, localeProfiles.size - 1)
        return hardwareProfiles[safeHw] to localeProfiles[safeLoc]
    }
}
