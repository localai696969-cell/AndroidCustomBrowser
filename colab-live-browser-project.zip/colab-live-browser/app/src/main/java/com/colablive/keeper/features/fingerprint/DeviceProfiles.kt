package com.colablive.keeper.features.fingerprint

/**
 * Hồ sơ thiết bị TRỌN GÓI — mỗi phần tử đã tự nhất quán bên trong (không thể
 * ra tổ hợp platform Windows + WebGL Apple M1 kiểu vô lý). Random/Manual đều
 * chọn CẢ HỒ SƠ, không chỉnh từng thông số rời — cách này loại bỏ khả năng
 * tạo ra tổ hợp không nhất quán ngay từ thiết kế, thay vì phải validate rồi
 * báo lỗi sau.
 */
data class HardwareProfile(
    val label: String,
    val category: String,          // "desktop" hoặc "mobile" — gợi ý khớp với "Chế độ máy tính"
    val platform: String,          // navigator.platform
    val webglVendor: String,
    val webglRenderer: String,
    val hardwareConcurrency: Int,
    val deviceMemory: Int
)

data class LocaleProfile(
    val label: String,
    val timezoneName: String,           // IANA timezone, dùng cho Intl.DateTimeFormat
    val timezoneOffsetMinutes: Int,      // phút lệch so với UTC (dương = phía đông UTC)
    val language: String                 // navigator.language
)

object DeviceProfiles {
    // "desktop" — nên đi cùng lúc BẬT "Chế độ máy tính" (menu) để nhất quán.
    // "mobile" — nên đi cùng lúc TẮT "Chế độ máy tính" (giữ UA điện thoại thật).
    // Bật/tắt ngược lại KHÔNG lỗi kỹ thuật gì, chỉ là hiếm gặp hơn trong thực tế.
    val HARDWARE = listOf(
        // ==== desktop ====
        HardwareProfile("Windows - Intel UHD 620", "desktop", "Win32", "Intel Inc.", "Intel(R) UHD Graphics 620", 4, 8),
        HardwareProfile("Windows - Intel Iris Xe", "desktop", "Win32", "Intel Inc.", "Intel(R) Iris(R) Xe Graphics", 8, 16),
        HardwareProfile("Windows - NVIDIA GTX 1660", "desktop", "Win32", "NVIDIA Corporation", "NVIDIA GeForce GTX 1660/PCIe/SSE2", 8, 16),
        HardwareProfile("Windows - NVIDIA RTX 3060", "desktop", "Win32", "NVIDIA Corporation", "NVIDIA GeForce RTX 3060/PCIe/SSE2", 12, 16),
        HardwareProfile("Windows - AMD Radeon RX580", "desktop", "Win32", "AMD", "AMD Radeon RX 580 Series", 6, 16),
        HardwareProfile("Windows - AMD Radeon RX6600", "desktop", "Win32", "AMD", "AMD Radeon RX 6600", 8, 16),
        HardwareProfile("MacBook - Apple M1", "desktop", "MacIntel", "Apple Inc.", "Apple M1", 8, 8),
        HardwareProfile("MacBook - Apple M2", "desktop", "MacIntel", "Apple Inc.", "Apple M2", 8, 16),
        HardwareProfile("Chromebook - Intel UHD", "desktop", "Linux armv8l", "Google Inc. (Intel)", "ANGLE (Intel, Intel(R) UHD Graphics 620, OpenGL 4.5)", 4, 4),
        HardwareProfile("Linux - Intel Mesa", "desktop", "Linux x86_64", "Intel Open Source Technology Center", "Mesa Intel(R) UHD Graphics 620 (KBL GT2)", 4, 8),
        // ==== mobile (Android thật) ====
        HardwareProfile("Samsung Galaxy - Mali G78", "mobile", "Linux armv8l", "ARM", "Mali-G78 MP14", 8, 8),
        HardwareProfile("Samsung Galaxy - Adreno 740", "mobile", "Linux armv8l", "Qualcomm", "Adreno (TM) 740", 8, 12),
        HardwareProfile("Xiaomi - Adreno 660", "mobile", "Linux armv8l", "Qualcomm", "Adreno (TM) 660", 8, 8),
        HardwareProfile("Google Pixel - Mali G710", "mobile", "Linux armv8l", "ARM", "Mali-G710 MC10", 8, 8),
        HardwareProfile("Oppo/Realme - Mali G57", "mobile", "Linux armv8l", "ARM", "Mali-G57 MC2", 6, 6)
    )

    val LOCALE = listOf(
        LocaleProfile("Việt Nam", "Asia/Ho_Chi_Minh", 420, "vi-VN"),
        LocaleProfile("Singapore", "Asia/Singapore", 480, "en-SG"),
        LocaleProfile("Malaysia", "Asia/Kuala_Lumpur", 480, "ms-MY"),
        LocaleProfile("Thái Lan", "Asia/Bangkok", 420, "th-TH"),
        LocaleProfile("Indonesia", "Asia/Jakarta", 420, "id-ID"),
        LocaleProfile("Philippines", "Asia/Manila", 480, "en-PH"),
        LocaleProfile("Nhật Bản", "Asia/Tokyo", 540, "ja-JP"),
        LocaleProfile("Hàn Quốc", "Asia/Seoul", 540, "ko-KR"),
        LocaleProfile("Đài Loan", "Asia/Taipei", 480, "zh-TW"),
        LocaleProfile("Ấn Độ", "Asia/Kolkata", 330, "en-IN"),
        LocaleProfile("Mỹ (New York)", "America/New_York", -300, "en-US"),
        LocaleProfile("Mỹ (Los Angeles)", "America/Los_Angeles", -480, "en-US"),
        LocaleProfile("Anh (London)", "Europe/London", 0, "en-GB"),
        LocaleProfile("Đức (Berlin)", "Europe/Berlin", 60, "de-DE"),
        LocaleProfile("Úc (Sydney)", "Australia/Sydney", 660, "en-AU")
    )
}
