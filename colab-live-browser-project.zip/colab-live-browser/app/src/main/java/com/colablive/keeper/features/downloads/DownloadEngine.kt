package com.colablive.keeper.features.downloads

import android.content.Context
import android.os.Handler
import android.os.Looper
import com.colablive.keeper.core.DebugLog
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.RandomAccessFile
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

/**
 * Download Engine — Multi-thread (4 connections) + Pause/Resume (HTTP Range).
 */
class DownloadEngine(private val context: Context) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
        .readTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
        .build()

    private val executor = Executors.newFixedThreadPool(8)
    private val downloads = ConcurrentHashMap<String, DownloadTask>()
    private val handler = Handler(Looper.getMainLooper())

    companion object {
        const val THREAD_COUNT = 4
    }

    data class DownloadTask(
        val id: String,
        val url: String,
        val fileName: String,
        val filePath: String,
        var totalBytes: Long = -1,
        val downloadedBytes: AtomicLong = AtomicLong(0),
        val isPaused: AtomicBoolean = AtomicBoolean(false),
        val isCancelled: AtomicBoolean = AtomicBoolean(false),
        val isComplete: AtomicBoolean = AtomicBoolean(false),
        val progressListeners: MutableList<(Int, Long, Long) -> Unit> = mutableListOf(),
        val statusListeners: MutableList<(DownloadStatus) -> Unit> = mutableListOf()
    )

    enum class DownloadStatus { PENDING, RUNNING, PAUSED, COMPLETED, FAILED, CANCELLED }

    fun startDownload(url: String, fileName: String, headers: Map<String, String> = emptyMap()): String {
        val id = System.currentTimeMillis().toString()
        val downloadDir = File(context.getExternalFilesDir(null), "downloads")
        downloadDir.mkdirs()
        val filePath = File(downloadDir, fileName).absolutePath

        val task = DownloadTask(id = id, url = url, fileName = fileName, filePath = filePath)
        downloads[id] = task
        executor.execute { downloadWithResume(task, headers) }
        return id
    }

    private fun downloadWithResume(task: DownloadTask, headers: Map<String, String>) {
        try {
            notifyStatus(task, DownloadStatus.RUNNING)

            val headRequest = Request.Builder().url(task.url).head().apply {
                headers.forEach { (k, v) -> header(k, v) }
            }.build()

            val headResponse = client.newCall(headRequest).execute()
            val acceptRanges = headResponse.header("Accept-Ranges")
            val contentLength = headResponse.header("Content-Length")?.toLongOrNull() ?: -1
            task.totalBytes = contentLength

            if (acceptRanges == "bytes" && contentLength > 0) {
                downloadMultiThread(task, headers)
            } else {
                downloadSingleThread(task, headers)
            }
        } catch (e: Exception) {
            DebugLog.log("Download error: ${e.message}")
            notifyStatus(task, DownloadStatus.FAILED)
        }
    }

    private fun downloadMultiThread(task: DownloadTask, headers: Map<String, String>) {
        val file = RandomAccessFile(task.filePath, "rw")
        file.setLength(task.totalBytes)
        val chunkSize = task.totalBytes / THREAD_COUNT
        val threads = mutableListOf<Thread>()

        for (i in 0 until THREAD_COUNT) {
            val start = i * chunkSize
            val end = if (i == THREAD_COUNT - 1) task.totalBytes - 1 else (i + 1) * chunkSize - 1
            val thread = Thread { downloadChunk(task, file, start, end, headers) }
            threads.add(thread)
            thread.start()
        }
        threads.forEach { it.join() }
        file.close()

        if (!task.isCancelled.get()) {
            if (task.downloadedBytes.get() >= task.totalBytes) {
                task.isComplete.set(true)
                notifyStatus(task, DownloadStatus.COMPLETED)
            } else {
                notifyStatus(task, DownloadStatus.PAUSED)
            }
        }
    }

    private fun downloadChunk(task: DownloadTask, file: RandomAccessFile, start: Long, end: Long, headers: Map<String, String>) {
        var position = start
        while (position < end && !task.isCancelled.get()) {
            while (task.isPaused.get() && !task.isCancelled.get()) {
                Thread.sleep(100)
            }
            if (task.isCancelled.get()) break

            try {
                val request = Request.Builder().url(task.url)
                    .header("Range", "bytes=$position-$end")
                    .apply { headers.forEach { (k, v) -> header(k, v) } }
                    .build()

                client.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) return
                    response.body?.byteStream()?.use { input ->
                        val buffer = ByteArray(8192)
                        var read: Int
                        while (input.read(buffer).also { read = it } != -1) {
                            if (task.isCancelled.get()) break
                            while (task.isPaused.get() && !task.isCancelled.get()) Thread.sleep(100)
                            synchronized(file) {
                                file.seek(position)
                                file.write(buffer, 0, read)
                            }
                            position += read
                            val downloaded = task.downloadedBytes.addAndGet(read.toLong())
                            notifyProgress(task, downloaded, task.totalBytes)
                        }
                    }
                }
            } catch (e: Exception) {
                Thread.sleep(1000)
            }
        }
    }

    private fun downloadSingleThread(task: DownloadTask, headers: Map<String, String>) {
        val request = Request.Builder().url(task.url).apply {
            headers.forEach { (k, v) -> header(k, v) }
        }.build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                notifyStatus(task, DownloadStatus.FAILED)
                return
            }
            val file = File(task.filePath)
            file.outputStream().use { output ->
                response.body?.byteStream()?.use { input ->
                    val buffer = ByteArray(8192)
                    var read: Int
                    while (input.read(buffer).also { read = it } != -1) {
                        if (task.isCancelled.get()) break
                        while (task.isPaused.get() && !task.isCancelled.get()) Thread.sleep(100)
                        output.write(buffer, 0, read)
                        val downloaded = task.downloadedBytes.addAndGet(read.toLong())
                        notifyProgress(task, downloaded, task.totalBytes)
                    }
                }
            }
        }
        if (!task.isCancelled.get()) {
            task.isComplete.set(true)
            notifyStatus(task, DownloadStatus.COMPLETED)
        }
    }

    fun pauseDownload(id: String) {
        val task = downloads[id] ?: return
        task.isPaused.set(true)
        notifyStatus(task, DownloadStatus.PAUSED)
    }

    fun resumeDownload(id: String) {
        val task = downloads[id] ?: return
        if (task.isComplete.get()) return
        task.isPaused.set(false)
        notifyStatus(task, DownloadStatus.RUNNING)
    }

    fun cancelDownload(id: String) {
        val task = downloads[id] ?: return
        task.isCancelled.set(true)
        notifyStatus(task, DownloadStatus.CANCELLED)
    }

    fun deleteDownload(id: String) {
        val task = downloads[id] ?: return
        task.isCancelled.set(true)
        File(task.filePath).delete()
        downloads.remove(id)
    }

    fun getDownload(id: String): DownloadTask? = downloads[id]
    fun getAllDownloads(): List<DownloadTask> = downloads.values.toList()
    fun isPaused(id: String): Boolean = downloads[id]?.isPaused?.get() ?: false
    fun isComplete(id: String): Boolean = downloads[id]?.isComplete?.get() ?: false

    fun addProgressListener(id: String, listener: (Int, Long, Long) -> Unit) {
        downloads[id]?.progressListeners?.add(listener)
    }

    fun addStatusListener(id: String, listener: (DownloadStatus) -> Unit) {
        downloads[id]?.statusListeners?.add(listener)
    }

    private fun notifyProgress(task: DownloadTask, downloaded: Long, total: Long) {
        val progress = if (total > 0) ((downloaded * 100) / total).toInt() else 0
        handler.post { task.progressListeners.forEach { it(progress, downloaded, total) } }
    }

    private fun notifyStatus(task: DownloadTask, status: DownloadStatus) {
        handler.post { task.statusListeners.forEach { it(status) } }
    }

    fun shutdown() {
        executor.shutdown()
    }
}
