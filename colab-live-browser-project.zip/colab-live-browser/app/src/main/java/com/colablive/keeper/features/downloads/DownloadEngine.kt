package com.colablive.keeper.features.downloads

import android.content.Context
import com.colablive.keeper.core.DebugLog
import java.io.File
import java.io.RandomAccessFile
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

class DownloadEngine(private val context: Context) {
    private val executor = Executors.newFixedThreadPool(4)
    private val activeTasks = mutableMapOf<String, DownloadTask>()

    data class DownloadTask(
        val url: String,
        val fileName: String,
        val totalBytes: Long,
        val downloadedBytes: AtomicLong,
        val isPaused: AtomicBoolean,
        val isCancelled: AtomicBoolean,
        val onProgress: ((Int) -> Unit)? = null,
        val onComplete: ((File?) -> Unit)? = null
    )

    fun startDownload(url: String, fileName: String, threadCount: Int = 4) {
        val task = DownloadTask(
            url = url,
            fileName = fileName,
            totalBytes = getContentLength(url),
            downloadedBytes = AtomicLong(0),
            isPaused = AtomicBoolean(false),
            isCancelled = AtomicBoolean(false)
        )
        activeTasks[url] = task

        val file = File(context.getExternalFilesDir(null), "downloads/$fileName")
        file.parentFile?.mkdirs()

        if (task.totalBytes <= 0) {
            executor.execute { downloadChunk(task, 0, -1, file) }
            return
        }

        val chunkSize = task.totalBytes / threadCount
        for (i in 0 until threadCount) {
            val start = i * chunkSize
            val end = if (i == threadCount - 1) task.totalBytes - 1 else (i + 1) * chunkSize - 1
            executor.execute { downloadChunk(task, start, end, file) }
        }
    }

    private fun downloadChunk(task: DownloadTask, start: Long, end: Long, file: File) {
        try {
            val connection = URL(task.url).openConnection() as HttpURLConnection
            connection.setRequestProperty("Range", "bytes=$start-${if (end >= 0) end else ""}")
            connection.connectTimeout = 15000
            connection.readTimeout = 15000

            val raf = RandomAccessFile(file, "rw")
            raf.seek(start)

            connection.inputStream.use { input ->
                val buffer = ByteArray(8192)
                var read: Int
                while (input.read(buffer).also { read = it } != -1) {
                    if (task.isCancelled.get()) break
                    while (task.isPaused.get()) {
                        Thread.sleep(100)
                        if (task.isCancelled.get()) break
                    }
                    if (task.isCancelled.get()) break

                    raf.write(buffer, 0, read)
                    task.downloadedBytes.addAndGet(read.toLong())

                    val progress = ((task.downloadedBytes.get() * 100) / task.totalBytes).toInt()
                    task.onProgress?.invoke(progress)
                }
            }
            raf.close()

            if (task.downloadedBytes.get() >= task.totalBytes) {
                task.onComplete?.invoke(file)
                DebugLog.log("Download complete: ${task.fileName}")
            }
        } catch (e: Exception) {
            DebugLog.log("Download chunk error: ${e.message}")
            task.onComplete?.invoke(null)
        }
    }

    private fun getContentLength(url: String): Long {
        return try {
            val connection = URL(url).openConnection() as HttpURLConnection
            connection.requestMethod = "HEAD"
            val length = connection.contentLengthLong
            connection.disconnect()
            length
        } catch (e: Exception) { -1 }
    }

    fun pauseDownload(url: String) {
        activeTasks[url]?.isPaused?.set(true)
    }

    fun resumeDownload(url: String) {
        activeTasks[url]?.isPaused?.set(false)
    }

    fun cancelDownload(url: String) {
        activeTasks[url]?.isCancelled?.set(true)
        activeTasks.remove(url)
    }
}
