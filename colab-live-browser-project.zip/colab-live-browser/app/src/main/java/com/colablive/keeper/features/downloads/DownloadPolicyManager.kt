package com.colablive.keeper.features.downloads

import android.content.Context
import android.net.Uri
import com.colablive.keeper.core.AppPrefs
import com.colablive.keeper.core.DebugLog

/**
 * Quản lý chính sách download — Chặn/Hỏi/Cho phép tự động tải.
 * Hỗ trợ per-site rules và global settings.
 */
object DownloadPolicyManager {

    enum class Policy {
        ASK,        // Luôn hỏi trước khi tải
        ALLOW,      // Cho phép tự động tải
        BLOCK,      // Chặn hoàn toàn
        ALLOW_LIST, // Chỉ cho phép từ whitelist
        BLOCK_LIST  // Chặn từ blacklist
    }

    data class SiteRule(
        val domain: String,
        val policy: Policy,
        val autoSavePath: String? = null
    )

    // ===== Global Settings =====

    fun getGlobalPolicy(context: Context): Policy {
        val policyStr = AppPrefs.getString(context, -1, "download_global_policy", "ASK")
        return try {
            Policy.valueOf(policyStr)
        } catch (e: Exception) {
            Policy.ASK
        }
    }

    fun setGlobalPolicy(context: Context, policy: Policy) {
        AppPrefs.setString(context, -1, "download_global_policy", policy.name)
    }

    // ===== Per-Site Rules =====

    fun getSitePolicy(context: Context, url: String): Policy {
        val domain = extractDomain(url)
        val rules = getSiteRules(context)

        // Tìm rule khớp chính xác
        val exactMatch = rules.find { it.domain == domain }
        if (exactMatch != null) return exactMatch.policy

        // Tìm rule khớp wildcard (*.example.com)
        val wildcardMatch = rules.find { rule ->
            rule.domain.startsWith("*.") && domain.endsWith(rule.domain.removePrefix("*."))
        }
        if (wildcardMatch != null) return wildcardMatch.policy

        // Fallback to global
        return getGlobalPolicy(context)
    }

    fun setSiteRule(context: Context, domain: String, policy: Policy, autoSavePath: String? = null) {
        val key = "download_rule_${domain}"
        val value = "${policy.name}|${autoSavePath ?: ""}"
        AppPrefs.setString(context, -1, key, value)
    }

    fun removeSiteRule(context: Context, domain: String) {
        val key = "download_rule_${domain}"
        // Xóa khỏi prefs
        val prefs = context.getSharedPreferences("live_browser_prefs", Context.MODE_PRIVATE)
        prefs.edit().remove(key).apply()
    }

    fun getSiteRules(context: Context): List<SiteRule> {
        val prefs = context.getSharedPreferences("live_browser_prefs", Context.MODE_PRIVATE)
        return prefs.all.keys
            .filter { it.startsWith("download_rule_") }
            .map { key ->
                val domain = key.removePrefix("download_rule_")
                val value = prefs.getString(key, "ASK|") ?: "ASK|"
                val parts = value.split("|", limit = 2)
                val policy = try { Policy.valueOf(parts[0]) } catch (e: Exception) { Policy.ASK }
                val path = parts.getOrNull(1)?.takeIf { it.isNotEmpty() }
                SiteRule(domain, policy, path)
            }
    }

    // ===== Auto-download Detection =====

    /**
     * Kiểm tra xem download có phải auto-download từ trang web không.
     * Dựa trên: referrer, user gesture, content-type, v.v.
     */
    fun isAutoDownload(context: Context, url: String, referrer: String?, hasUserGesture: Boolean): Boolean {
        // Nếu không có user gesture → có thể là auto-download
        if (!hasUserGesture) {
            DebugLog.log("Auto-download detected (no user gesture): $url")
            return true
        }

        // Nếu là redirect từ trang khác → có thể là auto-download
        if (referrer != null && !url.contains(extractDomain(referrer))) {
            // Kiểm tra xem có phải file download không
            val ext = url.substringAfterLast(".", "").lowercase()
            if (ext in listOf("exe", "zip", "rar", "pdf", "apk", "msi", "dmg")) {
                DebugLog.log("Auto-download detected (cross-domain file): $url")
                return true
            }
        }

        return false
    }

    // ===== Save Location =====

    fun getDefaultSavePath(context: Context): String {
        return AppPrefs.getString(context, -1, "download_default_path", 
            context.getExternalFilesDir(null)?.absolutePath + "/downloads") ?: ""
    }

    fun setDefaultSavePath(context: Context, path: String) {
        AppPrefs.setString(context, -1, "download_default_path", path)
    }

    fun getSiteSavePath(context: Context, url: String): String? {
        val domain = extractDomain(url)
        val rules = getSiteRules(context)
        return rules.find { it.domain == domain || 
            (it.domain.startsWith("*.") && domain.endsWith(it.domain.removePrefix("*."))) }?.autoSavePath
    }

    // ===== Helper =====

    private fun extractDomain(url: String): String {
        return try {
            val uri = Uri.parse(url)
            uri.host ?: url
        } catch (e: Exception) {
            url
        }
    }

    /**
     * Kiểm tra xem URL có nên bị chặn không.
     */
    fun shouldBlockDownload(context: Context, url: String): Boolean {
        val policy = getSitePolicy(context, url)
        return when (policy) {
            Policy.BLOCK -> true
            Policy.BLOCK_LIST -> !isInAllowList(context, url)
            Policy.ALLOW_LIST -> !isInAllowList(context, url)
            else -> false
        }
    }

    private fun isInAllowList(context: Context, url: String): Boolean {
        // TODO: Implement allow list
        return false
    }
}
