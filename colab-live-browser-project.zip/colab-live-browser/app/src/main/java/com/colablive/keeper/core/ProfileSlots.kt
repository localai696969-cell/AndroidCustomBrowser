package com.colablive.keeper.core

import android.app.ActivityManager
import android.content.Context
import android.os.Process

object ProfileSlots {
    const val SLOT_COUNT = 4

    private const val PREFS_NAME = "profile_slots"
    private const val KEY_PROFILES = "profiles"
    private const val DELIM = "\u0001" // không dùng dấu phẩy — tên profile có thể chứa dấu phẩy
    private const val DEFAULT_PROFILE_NAME = "Mặc định"

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    /**
     * Tên class Activity/activity-alias tương ứng với khe — PHẢI khớp
     * chính xác với AndroidManifest.xml (khe 0 = MainActivity thật chạy
     * process chính, khe 1-3 = activity-alias .ProfileSlotN, mỗi cái có
     * android:process=":slotN" riêng). Dùng để build Intent mở đúng khe.
     */
    fun componentClassNameForSlot(slotIndex: Int): String {
        return when (slotIndex) {
            1 -> "com.colablive.keeper.ProfileSlot1"
            2 -> "com.colablive.keeper.ProfileSlot2"
            3 -> "com.colablive.keeper.ProfileSlot3"
            else -> "com.colablive.keeper.MainActivity"
        }
    }

    fun listProfiles(context: Context): List<String> {
        val raw = prefs(context).getString(KEY_PROFILES, null)
        val list = raw?.split(DELIM)?.filter { it.isNotEmpty() } ?: emptyList()
        return list.ifEmpty { listOf(DEFAULT_PROFILE_NAME) }
    }

    fun addProfile(context: Context, name: String) {
        val current = listProfiles(context).toMutableList()
        if (!current.contains(name)) {
            current.add(name)
            prefs(context).edit().putString(KEY_PROFILES, current.joinToString(DELIM)).apply()
        }
    }

    fun getSlotAssignment(context: Context, slotIndex: Int): String {
        return prefs(context).getString("slot_assignment_$slotIndex", null) ?: DEFAULT_PROFILE_NAME
    }

    fun setSlotAssignment(context: Context, slotIndex: Int, name: String) {
        prefs(context).edit().putString("slot_assignment_$slotIndex", name).apply()
    }

    fun getSlotIndexFromProcess(processName: String?): Int {
        if (processName == null) return 0
        return when {
            processName.endsWith(":slot1") -> 1
            processName.endsWith(":slot2") -> 2
            processName.endsWith(":slot3") -> 3
            else -> 0
        }
    }

    fun getCurrentSlotIndex(context: Context): Int {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val myPid = Process.myPid()
        am.runningAppProcesses?.forEach { process ->
            if (process.pid == myPid) {
                return getSlotIndexFromProcess(process.processName)
            }
        }
        return 0
    }

    fun getSlotName(slotIndex: Int): String {
        return when (slotIndex) {
            0 -> "Khe chính"
            1 -> "Khe 1"
            2 -> "Khe 2"
            3 -> "Khe 3"
            else -> "Khe $slotIndex"
        }
    }

    fun clearSlotData(context: Context, slotIndex: Int) {
        // Xóa SharedPreferences
        AppPrefs.clearSlot(context, slotIndex)
        // Xóa Gecko data directory
        GeckoRuntimeProvider.clearSlotData(context, slotIndex)
        DebugLog.log("Cleared all data for slot $slotIndex")
    }
}
