package com.colablive.keeper.core

import android.content.Context

/**
 * Hệ thống thống nhất: SLOT_COUNT khe tiến trình vật lý cố định (khai báo
 * trong Manifest, dùng ĐỒNG THỜI được), và số lượng KHÔNG GIỚI HẠN profile
 * (tên tài khoản tự đặt). Mỗi khe gán 1 profile bất kỳ — đổi gán chỉ khởi
 * động lại đúng khe đó, các khe khác không bị ảnh hưởng.
 *
 * Ví dụ 9 profile, 4 khe: gán khe 0-3 → "Profile 1..4" dùng đồng thời; muốn
 * dùng "Profile 5" thì đổi gán 1 khe, chỉ khe đó khởi động lại.
 */
object ProfileSlots {
    // Tăng số này + thêm activity-alias tương ứng trong Manifest nếu cần
    // nhiều khe đồng thời hơn. Mỗi khe chạy 1 tiến trình riêng, tốn thêm RAM
    // khi tất cả cùng mở — cân nhắc trước khi tăng quá cao.
    const val SLOT_COUNT = 4

    private const val PREFS = "profile_slots"
    private const val KEY_PROFILE_NAMES = "profile_names"
    private const val KEY_SLOT_PREFIX = "slot_assignment_"

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun listProfiles(context: Context): List<String> {
        val raw = prefs(context).getString(KEY_PROFILE_NAMES, "Profile 1") ?: "Profile 1"
        return raw.split("|").filter { it.isNotBlank() }
    }

    fun addProfile(context: Context, name: String) {
        val safe = name.trim()
        if (safe.isEmpty()) return
        val current = listProfiles(context).toMutableList()
        if (safe !in current) {
            current.add(safe)
            prefs(context).edit().putString(KEY_PROFILE_NAMES, current.joinToString("|")).apply()
        }
    }

    fun removeProfile(context: Context, name: String) {
        val current = listProfiles(context).toMutableList().apply { remove(name) }
        prefs(context).edit().putString(KEY_PROFILE_NAMES, current.joinToString("|")).apply()
    }

    fun getSlotAssignment(context: Context, slotIndex: Int): String {
        val fallback = listProfiles(context).getOrElse(slotIndex) { "Khe $slotIndex" }
        return prefs(context).getString("$KEY_SLOT_PREFIX$slotIndex", fallback) ?: fallback
    }

    fun setSlotAssignment(context: Context, slotIndex: Int, profileName: String) {
        prefs(context).edit().putString("$KEY_SLOT_PREFIX$slotIndex", profileName).apply()
    }

    fun profileToSuffix(name: String): String =
        "p_" + name.replace(Regex("[^a-zA-Z0-9_]"), "_")

    /** ":slot2" -> 2. Process chính (không có ":slotN") -> khe 0. */
    fun slotIndexFromProcessName(processName: String): Int {
        if (!processName.contains(":slot")) return 0
        return processName.substringAfterLast(":slot").toIntOrNull() ?: 0
    }

    fun currentProcessSlotIndex(context: Context): Int {
        val pid = android.os.Process.myPid()
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
        val processName = am.runningAppProcesses?.firstOrNull { it.pid == pid }?.processName ?: return 0
        return slotIndexFromProcessName(processName)
    }

    /** Tên component (activity/alias) tương ứng khe — dùng để mở đúng khe từ AccessibilityService. */
    fun componentClassNameForSlot(slotIndex: Int): String =
        if (slotIndex == 0) "com.colablive.keeper.MainActivity"
        else "com.colablive.keeper.ProfileSlot$slotIndex"
}
