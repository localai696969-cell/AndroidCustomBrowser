package com.colablive.keeper.core

import android.app.ActivityManager
import android.content.Context
import android.os.Process

object ProfileSlots {
    // 3 khe PHỤ thật sự có backing (MainActivitySlot1/2/3, xem AndroidManifest.xml)
    // + khe 0 (chính) = 4 khe chạy song song thật. Trước đây giá trị này là
    // 4 nhưng chỉ 3 khe phụ có Activity thật — khe thứ 4 (phantom) bấm vào
    // sẽ mở NHẦM về khe 0 (rơi vào nhánh else của componentClassNameForSlot).
    const val SLOT_COUNT = 3

    private const val PREFS_NAME = "profile_slots"
    private const val KEY_PROFILES = "profiles"
    private const val DELIM = "\u0001" // không dùng dấu phẩy — tên profile có thể chứa dấu phẩy

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    /** Namespace nội bộ RIÊNG BIỆT cho từng khe khi CHƯA gán hồ sơ nào — 
     * KHÔNG dùng 1 chuỗi mặc định DÙNG CHUNG cho mọi khe (bug thật đã sửa:
     * trước đây mọi khe chưa gán đều rơi về cùng 1 hằng số "Mặc định", nếu
     * dùng làm namespace lưu trữ sẽ khiến 4 khe GỘP CHUNG dữ liệu — ngược
     * hẳn với mục đích cô lập). */
    private fun defaultNamespaceForSlot(slotIndex: Int) = "__slot_default_$slotIndex"

    /**
     * Tên class Activity tương ứng với khe — PHẢI khớp chính xác với
     * AndroidManifest.xml (khe 0 = MainActivity chạy process chính, khe 1-3
     * = MainActivitySlot1/2/3, mỗi cái là 1 <activity> THẬT riêng — không
     * dùng activity-alias nữa vì alias không hỗ trợ taskAffinity, xem giải
     * thích trong AndroidManifest.xml). Dùng để build Intent mở đúng khe.
     */
    fun componentClassNameForSlot(slotIndex: Int): String {
        return when (slotIndex) {
            1 -> "com.colablive.keeper.MainActivitySlot1"
            2 -> "com.colablive.keeper.MainActivitySlot2"
            3 -> "com.colablive.keeper.MainActivitySlot3"
            else -> "com.colablive.keeper.MainActivity"
        }
    }

    fun listProfiles(context: Context): List<String> {
        val raw = prefs(context).getString(KEY_PROFILES, null)
        return raw?.split(DELIM)?.filter { it.isNotEmpty() } ?: emptyList()
    }

    fun addProfile(context: Context, name: String) {
        if (name.startsWith("__slot_default_")) return // tên dành riêng nội bộ, không cho trùng
        val current = listProfiles(context).toMutableList()
        if (!current.contains(name)) {
            current.add(name)
            prefs(context).edit().putString(KEY_PROFILES, current.joinToString(DELIM)).apply()
        }
    }

    /**
     * Tên hồ sơ ĐANG GÁN cho khe này — nếu chưa gán hồ sơ nào, trả về
     * namespace RIÊNG BIỆT của chính khe đó (không dùng chung cho khe khác).
     */
    fun getSlotAssignment(context: Context, slotIndex: Int): String {
        return prefs(context).getString("slot_assignment_$slotIndex", null) ?: defaultNamespaceForSlot(slotIndex)
    }

    /** Tên hiển thị TRONG UI cho phần gán của khe — khác `getSlotAssignment`
     * (namespace lưu trữ nội bộ) ở chỗ không lộ ra chuỗi `__slot_default_N`. */
    fun getSlotAssignmentDisplay(context: Context, slotIndex: Int): String {
        val raw = prefs(context).getString("slot_assignment_$slotIndex", null)
        return raw ?: "(chưa gán hồ sơ — dữ liệu riêng của ${getSlotName(slotIndex)})"
    }

    /**
     * BUG THẬT đã sửa: hàm này trước đây dùng `.apply()` (ghi đĩa BẤT ĐỒNG
     * BỘ, chạy nền). Với Khe 1/2/3 không sao vì tiến trình gọi hàm này
     * (ProfilePickerActivity, process mặc định) khác tiến trình bị khởi
     * động lại (":slot1/2/3") — process bị kill không ảnh hưởng gì tới việc
     * ghi đĩa đang chạy nền ở process gọi hàm.
     *
     * NHƯNG với Khe 0 (khe chính): `ProfilePickerActivity` chạy CHUNG process
     * mặc định với `MainActivity` (Khe 0) — và `restartSlot(0)` tự
     * `Runtime.getRuntime().exit(0)` NGAY LẬP TỨC sau khi gọi hàm này. Ghi
     * `.apply()` chưa kịp flush xuống đĩa (chạy nền, không đồng bộ) thì
     * process đã chết → gán bị MẤT, restart xong Khe 0 vẫn hiện "chưa gán
     * hồ sơ" y như cũ dù bạn vừa chọn xong. Đây đúng là bug bạn gặp trong
     * ảnh chụp màn hình. Sửa bằng `.commit()` — ghi đồng bộ, đảm bảo đã nằm
     * trên đĩa trước khi hàm return, an toàn dù process chết ngay sau đó.
     */
    fun setSlotAssignment(context: Context, slotIndex: Int, name: String) {
        prefs(context).edit().putString("slot_assignment_$slotIndex", name).commit()
    }

    /** Bỏ gán hồ sơ — khe quay về dùng namespace RIÊNG của chính nó, không
     * còn chung với bất kỳ hồ sơ nào khác. Dùng `.commit()` cùng lý do như
     * `setSlotAssignment` ở trên (Khe 0 tự kill process ngay sau khi gọi). */
    fun unassignSlot(context: Context, slotIndex: Int) {
        prefs(context).edit().remove("slot_assignment_$slotIndex").commit()
    }

    /** Khe khác (không phải `slotIndex`) đang được gán hồ sơ `profileName`
     * không — nếu có, trả về số khe đó; không thì trả về null. Dùng để
     * cảnh báo/khoá việc gán trùng 1 hồ sơ vào 2 khe CÙNG chạy song song. */
    fun findOtherSlotUsingProfile(context: Context, slotIndex: Int, profileName: String): Int? {
        for (other in 0..SLOT_COUNT) {
            if (other == slotIndex) continue
            if (prefs(context).getString("slot_assignment_$other", null) == profileName) return other
        }
        return null
    }

    /**
     * Đặt tên cho dữ liệu ĐANG CÓ SẴN trong 1 khe (khi khe đó CHƯA từng
     * gán hồ sơ nào — vẫn đang dùng namespace riêng `__slot_default_N`)
     * thành 1 hồ sơ có tên, để dùng lại/di động được như hồ sơ khác. Tính
     * năng này TRƯỚC ĐÂY CHƯA TỒN TẠI: "Thêm profile mới" chỉ thêm 1 TÊN
     * vào danh sách, không hề đụng tới dữ liệu đang chạy trong khe — nếu
     * gán tên mới đó vào khe qua "Đổi" thì Gecko sẽ tạo hồ sơ TRẮNG hoàn
     * toàn mới (tên namespace khác → thư mục khác, xem GeckoRuntimeProvider),
     * MẤT hết cookie/đăng nhập đang có trong khe.
     *
     * KHÔNG đổi tên thư mục hồ sơ Gecko trên đĩa NGAY tại đây — nếu Khe đó
     * đang có GeckoRuntime sống (rất có thể, vì bạn thường mở
     * ProfilePickerActivity ngay TỪ trong khe đang chạy) thì đổi tên thư
     * mục dưới chân 1 tiến trình Gecko đang sống là rủi ro thật (Gecko vẫn
     * nhớ đường dẫn CŨ để ghi file mới). Thay vào đó LƯU Ý ĐỊNH đổi tên rồi
     * khởi động lại đúng khe đó — khi tiến trình MỚI (sạch, chưa đụng
     * Gecko) khởi động, `LiveBrowserApp.onCreate()` sẽ áp dụng đổi tên thật
     * (đổi cả SharedPreferences lẫn thư mục trên đĩa) TRƯỚC KHI bất kỳ
     * GeckoRuntime nào được tạo — an toàn.
     */
    private const val PENDING_PROMOTE_PREFS = "pending_profile_promote"

    fun schedulePromoteSlotData(context: Context, slotIndex: Int, newProfileName: String) {
        val oldNamespace = getSlotAssignment(context, slotIndex)
        context.getSharedPreferences(PENDING_PROMOTE_PREFS, Context.MODE_PRIVATE).edit()
            .putInt("slot", slotIndex)
            .putString("old_ns", oldNamespace)
            .putString("new_name", newProfileName)
            .commit() // đồng bộ — Khe 0 có thể tự kill process ngay sau lệnh gọi hàm này
    }

    /** Gọi ở `LiveBrowserApp.onCreate()` — sớm nhất có thể trong vòng đời
     * tiến trình, TRƯỚC khi bất kỳ GeckoRuntime nào được tạo. Chỉ áp dụng
     * nếu lệnh đổi tên đang chờ ĐÚNG là dành cho khe của TIẾN TRÌNH hiện
     * tại (so `getCurrentSlotIndex`) — 1 tiến trình khác có thể đọc trúng
     * SharedPreferences này nhưng không phải khe được nhắm tới thì bỏ qua,
     * không tự xoá cờ (khe đúng sẽ tự đọc và xoá khi nó thật sự khởi động). */
    fun consumePendingPromoteForCurrentProcess(context: Context): Triple<Int, String, String>? {
        val p = context.getSharedPreferences(PENDING_PROMOTE_PREFS, Context.MODE_PRIVATE)
        val pendingSlot = p.getInt("slot", -1)
        if (pendingSlot == -1) return null
        if (pendingSlot != getCurrentSlotIndex(context)) return null
        val oldNs = p.getString("old_ns", null) ?: return null
        val newName = p.getString("new_name", null) ?: return null
        p.edit().clear().commit()
        return Triple(pendingSlot, oldNs, newName)
    }

    fun getSlotIndexFromProcess(processName: String?): Int {
        if (processName == null) return 0
        return when {
            processName.endsWith(":slot1") -> 1
            processName.endsWith(":slot2") -> 2
            processName.endsWith(":slot3") -> 3
            else -> 0
        }
    }

    fun getCurrentSlotIndex(context: Context): Int {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val myPid = Process.myPid()
        am.runningAppProcesses?.forEach { process ->
            if (process.pid == myPid) {
                return getSlotIndexFromProcess(process.processName)
            }
        }
        return 0
    }

    fun getSlotName(slotIndex: Int): String {
        return when (slotIndex) {
            0 -> "Khe chính"
            1 -> "Khe 1"
            2 -> "Khe 2"
            3 -> "Khe 3"
            else -> "Khe $slotIndex"
        }
    }

    /**
     * BUG THẬT đã sửa: nút "Tự động tìm proxy nhanh nhất" trước đây chọn
     * đúng 1 proxy nhanh nhất DUY NHẤT trong toàn danh sách cào được, không
     * biết gì về việc khe khác đã dùng proxy nào. 4 khe chạy song song,
     * cùng bấm nút gần nhau, cùng nguồn cào, cùng mạng máy → gần như chắc
     * chắn ra cùng 1 proxy nhanh nhất → 4 hồ sơ lộ ra CÙNG 1 IP, y hệt kiểu
     * leak lo ngại ban đầu (dù fingerprint/cookie mỗi hồ sơ vẫn cô lập).
     *
     * Trả về tập (host, port) đang được các khe KHÁC (không phải khe đang
     * gọi hàm) sử dụng — dùng để loại các proxy này khỏi danh sách ứng viên
     * trước khi tìm "nhanh nhất", tránh 2 khe trùng IP khi cùng tự động tìm.
     * Chỉ xét các khe vật lý đang tồn tại (0..SLOT_COUNT) vì đây là phạm vi
     * thật sự có thể chạy song song cùng lúc trên máy.
     */
    fun proxiesInUseByOtherSlots(context: Context, currentSlotIndex: Int): Set<Pair<String, Int>> {
        val result = mutableSetOf<Pair<String, Int>>()
        for (slot in 0..SLOT_COUNT) {
            if (slot == currentSlotIndex) continue
            val host = AppPrefs.getString(context, slot, "proxy_host", "")
            val portStr = AppPrefs.getString(context, slot, "proxy_port", "")
            val port = portStr.toIntOrNull() ?: continue
            if (host.isNotBlank()) {
                result.add(host to port)
            }
        }
        return result
    }

    /** Xoá dữ liệu của HỒ SƠ đang gán cho khe này (không phải "khe" — khe chỉ
     * là chỗ chạy, dữ liệu thuộc về hồ sơ, xem AppPrefs/GeckoRuntimeProvider). */
    fun clearSlotData(context: Context, slotIndex: Int) {
        AppPrefs.clearSlot(context, slotIndex)
        GeckoRuntimeProvider.clearSlotData(context, slotIndex)
        DebugLog.log("Cleared data for profile '${getSlotAssignment(context, slotIndex)}' (mounted in slot $slotIndex)")
    }
}
