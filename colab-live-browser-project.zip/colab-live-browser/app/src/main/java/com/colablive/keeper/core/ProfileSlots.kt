package com.colablive.keeper.core

import android.app.ActivityManager
import android.content.Context
import android.os.Process

object ProfileSlots {
    // 3 khe PHỤ thật sự có backing (MainActivitySlot1/2/3, xem AndroidManifest.xml)
    // + khe 0 (chính) = 4 khe chạy song song thật. Trước đây giá trị này là
    // 4 nhưng chỉ 3 khe phụ có Activity thật — khe thứ 4 (phantom) bấm vào
    // sẽ mở NHẦM về khe 0 (rơi vào nhánh else của componentClassNameForSlot).
    const val SLOT_COUNT = 3

    private const val PREFS_NAME = "profile_slots"
    private const val KEY_PROFILES = "profiles"
    private const val DELIM = "\u0001" // không dùng dấu phẩy — tên profile có thể chứa dấu phẩy

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    /** Namespace nội bộ RIÊNG BIỆT cho từng khe khi CHƯA gán hồ sơ nào — 
     * KHÔNG dùng 1 chuỗi mặc định DÙNG CHUNG cho mọi khe (bug thật đã sửa:
     * trước đây mọi khe chưa gán đều rơi về cùng 1 hằng số "Mặc định", nếu
     * dùng làm namespace lưu trữ sẽ khiến 4 khe GỘP CHUNG dữ liệu — ngược
     * hẳn với mục đích cô lập). */
    private fun defaultNamespaceForSlot(slotIndex: Int) = "__slot_default_$slotIndex"

    /**
     * Tên class Activity tương ứng với khe — PHẢI khớp chính xác với
     * AndroidManifest.xml (khe 0 = MainActivity chạy process chính, khe 1-3
     * = MainActivitySlot1/2/3, mỗi cái là 1 <activity> THẬT riêng — không
     * dùng activity-alias nữa vì alias không hỗ trợ taskAffinity, xem giải
     * thích trong AndroidManifest.xml). Dùng để build Intent mở đúng khe.
     */
    fun componentClassNameForSlot(slotIndex: Int): String {
        return when (slotIndex) {
            1 -> "com.colablive.keeper.MainActivitySlot1"
            2 -> "com.colablive.keeper.MainActivitySlot2"
            3 -> "com.colablive.keeper.MainActivitySlot3"
            else -> "com.colablive.keeper.MainActivity"
        }
    }

    fun listProfiles(context: Context): List<String> {
        val raw = prefs(context).getString(KEY_PROFILES, null)
        return raw?.split(DELIM)?.filter { it.isNotEmpty() } ?: emptyList()
    }

    fun addProfile(context: Context, name: String) {
        if (name.startsWith("__slot_default_")) return // tên dành riêng nội bộ, không cho trùng
        val current = listProfiles(context).toMutableList()
        if (!current.contains(name)) {
            current.add(name)
            prefs(context).edit().putString(KEY_PROFILES, current.joinToString(DELIM)).apply()
        }
    }

    /**
     * Tên hồ sơ ĐANG GÁN cho khe này — nếu chưa gán hồ sơ nào, trả về
     * namespace RIÊNG BIỆT của chính khe đó (không dùng chung cho khe khác).
     */
    fun getSlotAssignment(context: Context, slotIndex: Int): String {
        return prefs(context).getString("slot_assignment_$slotIndex", null) ?: defaultNamespaceForSlot(slotIndex)
    }

    /** Tên hiển thị TRONG UI cho phần gán của khe — khác `getSlotAssignment`
     * (namespace lưu trữ nội bộ) ở chỗ không lộ ra chuỗi `__slot_default_N`. */
    fun getSlotAssignmentDisplay(context: Context, slotIndex: Int): String {
        val raw = prefs(context).getString("slot_assignment_$slotIndex", null)
        return raw ?: "(chưa gán hồ sơ — dữ liệu riêng của ${getSlotName(slotIndex)})"
    }

    fun setSlotAssignment(context: Context, slotIndex: Int, name: String) {
        prefs(context).edit().putString("slot_assignment_$slotIndex", name).apply()
    }

    /** Bỏ gán hồ sơ — khe quay về dùng namespace RIÊNG của chính nó, không
     * còn chung với bất kỳ hồ sơ nào khác. */
    fun unassignSlot(context: Context, slotIndex: Int) {
        prefs(context).edit().remove("slot_assignment_$slotIndex").apply()
    }

    fun getSlotIndexFromProcess(processName: String?): Int {
        if (processName == null) return 0
        return when {
            processName.endsWith(":slot1") -> 1
            processName.endsWith(":slot2") -> 2
            processName.endsWith(":slot3") -> 3
            else -> 0
        }
    }

    fun getCurrentSlotIndex(context: Context): Int {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val myPid = Process.myPid()
        am.runningAppProcesses?.forEach { process ->
            if (process.pid == myPid) {
                return getSlotIndexFromProcess(process.processName)
            }
        }
        return 0
    }

    fun getSlotName(slotIndex: Int): String {
        return when (slotIndex) {
            0 -> "Khe chính"
            1 -> "Khe 1"
            2 -> "Khe 2"
            3 -> "Khe 3"
            else -> "Khe $slotIndex"
        }
    }

    /** Xoá dữ liệu của HỒ SƠ đang gán cho khe này (không phải "khe" — khe chỉ
     * là chỗ chạy, dữ liệu thuộc về hồ sơ, xem AppPrefs/GeckoRuntimeProvider). */
    fun clearSlotData(context: Context, slotIndex: Int) {
        AppPrefs.clearSlot(context, slotIndex)
        GeckoRuntimeProvider.clearSlotData(context, slotIndex)
        DebugLog.log("Cleared data for profile '${getSlotAssignment(context, slotIndex)}' (mounted in slot $slotIndex)")
    }
}
