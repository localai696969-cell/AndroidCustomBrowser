package com.colablive.keeper.core

import android.app.ActivityManager
import android.content.Context
import android.os.Process

object ProfileSlots {
    const val SLOT_COUNT = 4

    data class Profile(
        val id: String,
        val name: String,
        val slotIndex: Int
    )

    private val profiles = mutableListOf<Profile>()
    private val slotAssignments = mutableMapOf<Int, String>()

    init {
        profiles.add(Profile("default", "Mặc định", 0))
        profiles.add(Profile("profile1", "Profile 1", 1))
        profiles.add(Profile("profile2", "Profile 2", 2))
        profiles.add(Profile("profile3", "Profile 3", 3))
    }

    fun getSlotIndexFromProcess(processName: String?): Int {
        if (processName == null) return 0
        return when {
            processName.endsWith(":slot1") -> 1
            processName.endsWith(":slot2") -> 2
            processName.endsWith(":slot3") -> 3
            else -> 0
        }
    }

    fun getCurrentSlotIndex(context: Context): Int {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val myPid = Process.myPid()
        am.runningAppProcesses?.forEach { process ->
            if (process.pid == myPid) {
                return getSlotIndexFromProcess(process.processName)
            }
        }
        return 0
    }

    fun getSlotName(slotIndex: Int): String {
        return when (slotIndex) {
            0 -> "Khe chính"
            1 -> "Khe 1"
            2 -> "Khe 2"
            3 -> "Khe 3"
            else -> "Khe $slotIndex"
        }
    }

    fun listProfiles(): List<Profile> = profiles.toList()

    fun addProfile(name: String, slotIndex: Int): Profile {
        val id = "profile_${System.currentTimeMillis()}"
        val profile = Profile(id, name, slotIndex)
        profiles.add(profile)
        return profile
    }

    fun getSlotAssignment(slotIndex: Int): String? = slotAssignments[slotIndex]

    fun setSlotAssignment(slotIndex: Int, profileId: String) {
        slotAssignments[slotIndex] = profileId
    }

    fun componentClassNameForSlot(slotIndex: Int): String {
        return when (slotIndex) {
            0 -> "com.colablive.keeper.MainActivity"
            1 -> "com.colablive.keeper.ProfileSlot1"
            2 -> "com.colablive.keeper.ProfileSlot2"
            3 -> "com.colablive.keeper.ProfileSlot3"
            else -> "com.colablive.keeper.MainActivity"
        }
    }

    fun clearSlotData(context: Context, slotIndex: Int) {
        AppPrefs.clearSlot(context, slotIndex)
        GeckoRuntimeProvider.clearSlotData(context, slotIndex)
        DebugLog.log("Cleared all data for slot $slotIndex")
    }
}
