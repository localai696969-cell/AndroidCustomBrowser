package com.colablive.keeper.features.downloads

import android.content.Context
import com.colablive.keeper.core.AppPrefs
import com.colablive.keeper.core.DebugLog

/**
 * Quản lý chính sách download theo domain.
 */
class DownloadPolicy(private val context: Context) {

    enum class Policy {
        ASK, ALLOW, BLOCK, ALLOW_ALL
    }

    data class DomainRule(
        val domain: String,
        val policy: Policy,
        val description: String
    )

    private val defaultRules = listOf(
        DomainRule("colab.research.google.com", Policy.ALLOW, "Google Colab"),
        DomainRule("drive.google.com", Policy.ALLOW, "Google Drive"),
        DomainRule("github.com", Policy.ASK, "GitHub"),
        DomainRule("", Policy.ASK, "Mặc định")
    )

    fun checkPolicy(url: String): Boolean? {
        val domain = extractDomain(url)
        val globalPolicy = getGlobalPolicy()
        if (globalPolicy == Policy.ALLOW_ALL) {
            DebugLog.log("Download policy: ALLOW_ALL — $url")
            return true
        }
        val rule = getRules().find { domain.contains(it.domain) && it.domain.isNotEmpty() }
            ?: getRules().find { it.domain.isEmpty() }
        return when (rule?.policy) {
            Policy.ALLOW -> { DebugLog.log("Download policy: ALLOW — $domain"); true }
            Policy.BLOCK -> { DebugLog.log("Download policy: BLOCK — $domain"); false }
            else -> { DebugLog.log("Download policy: ASK — $domain"); null }
        }
    }

    fun addRule(domain: String, policy: Policy) {
        val rules = getRules().toMutableList()
        rules.removeAll { it.domain == domain }
        rules.add(DomainRule(domain, policy, "Custom rule"))
        saveRules(rules)
    }

    fun removeRule(domain: String) {
        val rules = getRules().toMutableList()
        rules.removeAll { it.domain == domain }
        saveRules(rules)
    }

    fun getGlobalPolicy(): Policy {
        val policyStr = AppPrefs.getString(context, 0, "download_global_policy", "ASK")
        return try { Policy.valueOf(policyStr) } catch (e: Exception) { Policy.ASK }
    }

    fun setGlobalPolicy(policy: Policy) {
        AppPrefs.setString(context, 0, "download_global_policy", policy.name)
    }

    private fun getRules(): List<DomainRule> = defaultRules
    private fun saveRules(rules: List<DomainRule>) {}

    private fun extractDomain(url: String): String {
        return try {
            val uri = java.net.URI(url)
            uri.host ?: ""
        } catch (e: Exception) { "" }
    }

    companion object {
        @JvmStatic
        fun isAllowed(context: Context, url: String): Boolean {
            val policy = DownloadPolicy(context)
            val result = policy.checkPolicy(url)
            return result ?: true
        }
    }
}
