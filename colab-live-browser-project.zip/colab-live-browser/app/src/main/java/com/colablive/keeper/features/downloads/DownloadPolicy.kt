package com.colablive.keeper.features.downloads

import android.content.Context
import com.colablive.keeper.core.AppPrefs
import com.colablive.keeper.core.DebugLog

/**
 * Quản lý chính sách download theo domain.
 * Các chế độ:
 * - ASK: Hỏi trước khi tải (mặc định cho trang lạ)
 * - ALLOW: Tự động tải (cho trang tin cậy như Colab)
 * - BLOCK: Chặn hoàn toàn (cho trang độc hại)
 * - ALLOW_ALL: Tự động tải tất cả (nguy hiểm)
 */
class DownloadPolicy(private val context: Context) {

    enum class Policy {
        ASK,      // Hỏi trước khi tải
        ALLOW,    // Tự động tải
        BLOCK,    // Chặn hoàn toàn
        ALLOW_ALL // Tự động tải tất cả (không khuyến khích)
    }

    data class DomainRule(
        val domain: String,
        val policy: Policy,
        val description: String
    )

    // Rules mặc định
    private val defaultRules = listOf(
        DomainRule("colab.research.google.com", Policy.ALLOW, "Google Colab — cho phép tự động tải"),
        DomainRule("drive.google.com", Policy.ALLOW, "Google Drive — cho phép tự động tải"),
        DomainRule("github.com", Policy.ASK, "GitHub — hỏi trước khi tải"),
        DomainRule("", Policy.ASK, "Mặc định — hỏi trước khi tải")
    )

    /**
     * Kiểm tra policy cho URL.
     * Trả về: true = cho phép tải, false = chặn, null = cần hỏi user
     */
    fun checkPolicy(url: String): Boolean? {
        val domain = extractDomain(url)
        val globalPolicy = getGlobalPolicy()

        // Nếu global = ALLOW_ALL → cho phép tất cả
        if (globalPolicy == Policy.ALLOW_ALL) {
            DebugLog.log("Download policy: ALLOW_ALL — $url")
            return true
        }

        // Tìm rule cho domain
        val rule = getRules().find { domain.contains(it.domain) && it.domain.isNotEmpty() }
            ?: getRules().find { it.domain.isEmpty() } // rule mặc định

        return when (rule?.policy) {
            Policy.ALLOW -> {
                DebugLog.log("Download policy: ALLOW — $domain")
                true
            }
            Policy.BLOCK -> {
                DebugLog.log("Download policy: BLOCK — $domain")
                false
            }
            else -> {
                DebugLog.log("Download policy: ASK — $domain")
                null // Cần hỏi user
            }
        }
    }

    /**
     * Thêm rule mới.
     */
    fun addRule(domain: String, policy: Policy) {
        val rules = getRules().toMutableList()
        rules.removeAll { it.domain == domain }
        rules.add(DomainRule(domain, policy, "Custom rule"))
        saveRules(rules)
    }

    /**
     * Xóa rule.
     */
    fun removeRule(domain: String) {
        val rules = getRules().toMutableList()
        rules.removeAll { it.domain == domain }
        saveRules(rules)
    }

    /**
     * Lấy global policy.
     */
    fun getGlobalPolicy(): Policy {
        val policyStr = AppPrefs.getString(context, 0, "download_global_policy", "ASK")
        return try {
            Policy.valueOf(policyStr)
        } catch (e: Exception) {
            Policy.ASK
        }
    }

    /**
     * Set global policy.
     */
    fun setGlobalPolicy(policy: Policy) {
        AppPrefs.setString(context, 0, "download_global_policy", policy.name)
    }

    fun getRules(): List<DomainRule> {
        // Tạm thời: dùng default rules
        // Có thể lưu vào SharedPreferences nếu cần
        return defaultRules
    }

    private fun saveRules(rules: List<DomainRule>) {
        // TODO: Lưu vào SharedPreferences
    }

    private fun extractDomain(url: String): String {
        return try {
            val uri = java.net.URI(url)
            uri.host ?: ""
        } catch (e: Exception) {
            ""
        }
    }
}
