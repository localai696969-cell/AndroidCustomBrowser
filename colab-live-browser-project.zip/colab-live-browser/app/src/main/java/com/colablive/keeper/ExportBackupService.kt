package com.colablive.keeper

import android.app.*
import android.content.*
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.colablive.keeper.core.DebugLog
import com.colablive.keeper.core.ProfileExportImport

/**
 * BUG THẬT (người dùng báo: "backup profile chỉ có 0B"): bản vá trước đó
 * (xem comment cũ ở `ProfilePickerActivity.onActivityResult`, nhánh
 * REQUEST_EXPORT) chỉ thêm PARTIAL_WAKE_LOCK chạy trên 1 `Thread` trần —
 * WakeLock chỉ chặn được CPU ngủ (Doze) khi tắt màn hình, KHÔNG chặn được
 * trường hợp Android chủ động GIẾT HẲN tiến trình app khi hệ thống thiếu
 * bộ nhớ hoặc coi app là "nền" sau khi người dùng chuyển sang app khác
 * (Doze không phải nguyên nhân duy nhất — process death là nguyên nhân
 * NẶNG HƠN, WakeLock hoàn toàn không phòng được, chính comment cũ đã tự
 * ghi rõ "CHƯA làm ở đây, cân nhắc nếu WakeLock không đủ" — nay xác nhận
 * đúng là không đủ). Hồ sơ càng nặng (cache video, lịch sử — đúng tình
 * huống thật), zip càng lâu, càng dễ bị hệ thống coi là ứng viên kill khi
 * app không hiển thị (người dùng tự nhiên sẽ tắt màn hình/chuyển app sau
 * khi chọn xong nơi lưu file).
 *
 * SỬA ĐÚNG GỐC: chạy việc nén zip bên trong 1 Foreground Service thật
 * (không phải Thread trần trong Activity) — Android KHÔNG được phép giết
 * tiến trình đang có foreground service hoạt động (trừ trường hợp cực
 * đoan: OOM toàn hệ thống), đúng cấp bảo vệ mà `KeepAliveService.kt` /
 * `MediaKeepAliveService.kt` đã dùng cho các tác vụ nền khác trong chính
 * project này — tái dùng lại pattern đã có, không phát minh cơ chế mới.
 *
 * KHÁC với `KeepAliveService`: đây là tác vụ 1 LẦN có điểm kết thúc rõ
 * ràng (zip xong là xong), không phải tác vụ chạy vô thời hạn — nên dùng
 * `START_NOT_STICKY` (không cần Android tự khởi động lại nếu bị giết —
 * khởi động lại giữa chừng sẽ ghi đè file zip dở dang, vô nghĩa) và tự
 * `stopSelf()` ngay khi xong việc.
 */
class ExportBackupService : Service() {

    companion object {
        const val CHANNEL_ID = "live_browser_export"
        const val NOTIFICATION_ID = 3000
        const val ACTION_START = "com.colablive.keeper.EXPORT_START"
        const val ACTION_EXPORT_DONE = "com.colablive.keeper.EXPORT_DONE"
        const val EXTRA_PROFILE_NAME = "profile_name"
        const val EXTRA_TARGET_URI = "target_uri"
        const val EXTRA_SUCCESS = "success"
        const val EXTRA_ERROR = "error"
        const val EXTRA_SKIPPED_FILES = "skipped_files"
        const val EXTRA_ENTRIES_WRITTEN = "entries_written"
        const val EXTRA_BYTES_WRITTEN = "bytes_written"

        fun start(context: Context, profileName: String, targetUri: Uri) {
            // FIX cùng loại với ImportBackupService.start() — xem chú thích
            // đầy đủ ở đó. Uri từ ACTION_CREATE_DOCUMENT chỉ được cấp quyền
            // GHI cho chính Activity đã nhận nó; Service nhận Uri qua
            // putExtra() thường KHÔNG tự động có quyền — phải khai báo
            // tường minh FLAG_GRANT_WRITE_URI_PERMISSION trên Intent khởi
            // động Service.
            val intent = Intent(context, ExportBackupService::class.java).apply {
                action = ACTION_START
                putExtra(EXTRA_PROFILE_NAME, profileName)
                putExtra(EXTRA_TARGET_URI, targetUri)
                addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            }
            try {
                context.grantUriPermission(context.packageName, targetUri, Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            } catch (e: SecurityException) {
                DebugLog.log("ExportBackupService.start(): grantUriPermission() lỗi (${e.message}) — vẫn tiếp tục, dựa vào cờ Intent")
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }
    }

    private var wakeLock: PowerManager.WakeLock? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val name = intent?.getStringExtra(EXTRA_PROFILE_NAME)
        val uri: Uri? = intent?.getParcelableExtra(EXTRA_TARGET_URI)
        if (intent?.action != ACTION_START || name == null || uri == null) {
            // Không có START_STICKY nên Android sẽ không tự gọi lại với
            // intent rỗng như KeepAliveService phải xử lý — nhưng vẫn thủ
            // chặn phòng hờ thay vì NPE nếu có đường gọi sai nào khác.
            DebugLog.log("ExportBackupService: thiếu action/extra hợp lệ (action=${intent?.action}, name=$name, uri=$uri) — dừng ngay")
            stopSelf(startId)
            return START_NOT_STICKY
        }

        startForeground(NOTIFICATION_ID, buildNotification(name))
        DebugLog.log("ExportBackupService: startForeground() ĐÃ GỌI XONG cho profile '$name' — process được bảo vệ khỏi bị hệ thống giết từ đây")

        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "LiveBrowser::ExportBackup").apply {
            setReferenceCounted(false)
            acquire(15 * 60 * 1000L) // tối đa 15 phút — đủ dư cho hồ sơ nặng, tự nhả nếu quên
        }
        DebugLog.log("ExportBackupService: WakeLock đã acquire (isHeld=${wakeLock?.isHeld})")

        Thread {
            DebugLog.log("ExportBackupService: Thread nền BẮT ĐẦU gọi exportProfile()")
            val result = try {
                ProfileExportImport.exportProfile(this, name, uri)
            } catch (e: Exception) {
                DebugLog.log("ExportBackupService: exportProfile() ném exception KHÔNG ĐƯỢC BẮT bên trong nó: ${e.javaClass.simpleName}: ${e.message}")
                Result.failure<ProfileExportImport.ExportSummary>(e)
            } finally {
                try { wakeLock?.let { if (it.isHeld) it.release() } } catch (e: Exception) { /* bỏ qua */ }
            }
            Handler(Looper.getMainLooper()).post {
                DebugLog.log("ExportBackupService: exportProfile() ĐÃ TRẢ VỀ (success=${result.isSuccess}, error=${result.exceptionOrNull()?.message}) — gửi broadcast, dừng foreground service ngay sau đây")
                sendBroadcast(Intent(ACTION_EXPORT_DONE).apply {
                    setPackage(packageName)
                    putExtra(EXTRA_PROFILE_NAME, name)
                    putExtra(EXTRA_SUCCESS, result.isSuccess)
                    putExtra(EXTRA_ERROR, result.exceptionOrNull()?.message)
                    // FIX MỚI (mục 12/15) — truyền TÊN file bị bỏ qua (mảng
                    // String), không chỉ số lượng, để UI hiện rõ CHÍNH XÁC
                    // file nào (theo đúng yêu cầu: "cái gì xuất thiếu, cái
                    // gì xuất rồi").
                    putExtra(EXTRA_SKIPPED_FILES, (result.getOrNull()?.skippedFiles ?: emptyList()).toTypedArray())
                    putExtra(EXTRA_ENTRIES_WRITTEN, result.getOrNull()?.entriesWritten ?: 0)
                    putExtra(EXTRA_BYTES_WRITTEN, result.getOrNull()?.bytesWritten ?: 0L)
                })
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf(startId)
            }
        }.start()

        return START_NOT_STICKY
    }

    private fun buildNotification(profileName: String): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("📦 Đang sao lưu hồ sơ '$profileName'...")
            .setContentText("Giữ ứng dụng chạy nền, không tắt để tránh file lỗi")
            .setSmallIcon(android.R.drawable.stat_sys_upload)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Sao lưu hồ sơ", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Hiện khi đang xuất/nén hồ sơ ra file zip"
                setShowBadge(false)
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        /**
         * FIX THIẾU LOG (đúng như người dùng chỉ ra): nếu service này bị hệ
         * thống giết GIỮA CHỪNG (trước khi Thread nền kịp gọi
         * `stopSelf()` ở trên) — đây chính là bằng chứng TRỰC TIẾP cho giả
         * thuyết gốc "process bị giết giữa lúc export" mà chưa từng có
         * cách xác nhận. Nếu log KHÔNG BAO GIỜ thấy dòng "exportProfile()
         * ĐÃ TRẢ VỀ" nhưng CÓ thấy dòng onDestroy() này ngay sau đó — xác
         * nhận chắc chắn 100% đúng giả thuyết, không cần đoán nữa.
         */
        DebugLog.log("ExportBackupService: onDestroy() được gọi (bình thường là do tự stopSelf() sau khi xong; nếu KHÔNG thấy dòng 'exportProfile() ĐÃ TRẢ VỀ' ngay trước đó — service đã bị HỆ THỐNG GIẾT GIỮA CHỪNG, xác nhận đúng giả thuyết gốc)")
        wakeLock?.let { if (it.isHeld) it.release() }
        super.onDestroy()
    }
}
