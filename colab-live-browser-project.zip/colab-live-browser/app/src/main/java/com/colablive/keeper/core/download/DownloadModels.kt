package com.colablive.keeper.core.download

import org.json.JSONArray
import org.json.JSONObject

enum class DownloadStatus { QUEUED, RUNNING, PAUSED, COMPLETED, FAILED, CANCELLED }

data class DownloadSegment(
    val index: Int,
    val startByte: Long,
    val endByte: Long, // inclusive; -1 nếu single-thread/không rõ kích thước
    var downloadedBytes: Long = 0L
)

data class DownloadTask(
    val id: String,
    val url: String,
    val fileName: String,
    val destinationPath: String,
    var totalBytes: Long = -1L,
    var supportsRange: Boolean = false,
    val segments: MutableList<DownloadSegment> = mutableListOf(),
    var status: DownloadStatus = DownloadStatus.QUEUED,
    val userAgent: String? = null,
    var errorMessage: String? = null
) {
    fun downloadedBytes(): Long = segments.sumOf { it.downloadedBytes }

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id); put("url", url); put("fileName", fileName)
        put("destinationPath", destinationPath); put("totalBytes", totalBytes)
        put("supportsRange", supportsRange); put("status", status.name)
        put("userAgent", userAgent ?: JSONObject.NULL)
        put("errorMessage", errorMessage ?: JSONObject.NULL)
        put("segments", JSONArray().apply {
            segments.forEach {
                put(JSONObject().apply {
                    put("index", it.index); put("startByte", it.startByte)
                    put("endByte", it.endByte); put("downloadedBytes", it.downloadedBytes)
                })
            }
        })
    }

    companion object {
        fun fromJson(obj: JSONObject): DownloadTask {
            val segmentsArray = obj.getJSONArray("segments")
            val segments = mutableListOf<DownloadSegment>()
            for (i in 0 until segmentsArray.length()) {
                val s = segmentsArray.getJSONObject(i)
                segments.add(
                    DownloadSegment(
                        index = s.getInt("index"),
                        startByte = s.getLong("startByte"),
                        endByte = s.getLong("endByte"),
                        downloadedBytes = s.getLong("downloadedBytes")
                    )
                )
            }
            return DownloadTask(
                id = obj.getString("id"), url = obj.getString("url"),
                fileName = obj.getString("fileName"), destinationPath = obj.getString("destinationPath"),
                totalBytes = obj.optLong("totalBytes", -1L), supportsRange = obj.optBoolean("supportsRange", false),
                segments = segments, status = DownloadStatus.valueOf(obj.getString("status")),
                userAgent = obj.optString("userAgent").takeIf { it.isNotEmpty() && it != "null" },
                errorMessage = obj.optString("errorMessage").takeIf { it.isNotEmpty() && it != "null" }
            )
        }
    }
}
