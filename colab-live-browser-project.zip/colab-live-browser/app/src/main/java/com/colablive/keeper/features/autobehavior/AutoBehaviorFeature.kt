package com.colablive.keeper.features.autobehavior

import android.content.Context
import android.view.View
import androidx.appcompat.widget.SwitchCompat
import com.colablive.keeper.core.AppPrefs
import com.colablive.keeper.core.BrowserFeature
import com.colablive.keeper.core.DebugLog

class AutoBehaviorFeature : BrowserFeature {

    override val id = "auto_behavior"
    override val displayName = "Auto Behavior"
    override val description = "Tu dong scroll, click ngau nhien de gia lap nguoi dung"

    companion object {
        private const val KEY_ENABLED = "enabled"
    }

    override fun isEnabled(context: Context, slotIndex: Int) =
        AppPrefs.getBoolean(context, slotIndex, id, KEY_ENABLED, false)

    override fun setEnabled(context: Context, slotIndex: Int, enabled: Boolean) =
        AppPrefs.setBoolean(context, slotIndex, id, KEY_ENABLED, enabled)

    override fun onPageLoaded(context: Context, slotIndex: Int, url: String) {}
    override fun onPageLoadError(context: Context, slotIndex: Int, url: String, errorCode: Int) {}
    override fun onDropFile(context: Context, slotIndex: Int, uri: android.net.Uri, mimeType: String?) {}

    override fun buildSettingsView(context: Context, slotIndex: Int): View {
        val switch = SwitchCompat(context)
        switch.text = displayName
        switch.isChecked = isEnabled(context, slotIndex)
        switch.setOnCheckedChangeListener { _, checked -> setEnabled(context, slotIndex, checked) }
        return switch
    }
}
