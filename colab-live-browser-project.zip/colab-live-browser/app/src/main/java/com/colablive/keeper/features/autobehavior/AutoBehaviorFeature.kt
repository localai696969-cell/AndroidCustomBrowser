package com.colablive.keeper.features.autobehavior

import android.content.Context
import android.view.View
import android.widget.LinearLayout
import android.widget.Switch
import com.colablive.keeper.core.AppPrefs
import com.colablive.keeper.core.BrowserFeature
import com.colablive.keeper.core.DebugLog

class AutoBehaviorFeature : BrowserFeature {

    override val id = "auto_behavior"
    override val displayName = "Auto Behavior"
    override val description = "Giả lập scroll/click ngẫu nhiên"

    private const val KEY_ENABLED = "enabled"

    override fun isEnabled(context: Context, slotIndex: Int) = 
        AppPrefs.getBoolean(context, slotIndex, id, KEY_ENABLED, false)

    override fun setEnabled(context: Context, slotIndex: Int, enabled: Boolean) =
        AppPrefs.setBoolean(context, slotIndex, id, KEY_ENABLED, enabled)

    override fun onPageLoaded(context: Context, slotIndex: Int, url: String) {
        if (isEnabled(context, slotIndex)) {
            DebugLog.log("AutoBehavior: Enabled for slot $slotIndex")
        }
    }

    override fun onPageLoadError(context: Context, slotIndex: Int, url: String, errorCode: Int) {}
    override fun onDropFile(context: Context, slotIndex: Int, uri: android.net.Uri, mimeType: String?) {}

    override fun buildSettingsView(context: Context, slotIndex: Int): View {
        return LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 16, 16, 16)
            addView(Switch(context).apply {
                text = "Bật Auto Behavior"
                isChecked = isEnabled(context, slotIndex)
                setOnCheckedChangeListener { _, checked -> setEnabled(context, slotIndex, checked) }
            })
        }
    }
}
