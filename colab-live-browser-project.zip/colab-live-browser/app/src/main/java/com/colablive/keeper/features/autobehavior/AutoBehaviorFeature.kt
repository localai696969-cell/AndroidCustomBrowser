package com.colablive.keeper.features.autobehavior

import android.content.Context
import android.view.View
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import com.colablive.keeper.core.BrowserFeature
import com.colablive.keeper.core.AppPrefs

class AutoBehaviorFeature : BrowserFeature {
    override val id = "auto_behavior"
    override val displayName = "Auto Behavior"

    override fun isEnabled(context: Context, slotIndex: Int): Boolean =
        AppPrefs.getBoolean(context, slotIndex, "auto_behavior_enabled", false)

    override fun setEnabled(context: Context, slotIndex: Int, enabled: Boolean) {
        AppPrefs.setBoolean(context, slotIndex, "auto_behavior_enabled", enabled)
    }

    override fun onPageLoaded(context: Context, slotIndex: Int, url: String) {
        if (!isEnabled(context, slotIndex)) return
        // Auto behavior sẽ được trigger từ MainActivity qua evaluateJs
    }

    override fun onPageLoadError(context: Context, slotIndex: Int, url: String, errorCode: Int) {}
    override fun onDropFile(context: Context, slotIndex: Int, uri: android.net.Uri, mimeType: String?) {}

    override fun buildSettingsView(context: Context, slotIndex: Int): View {
        return LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            addView(TextView(context).apply {
                text = "Giả lập hành vi người dùng tự động"
                textSize = 16f
                setPadding(32, 32, 32, 16)
            })
            addView(Switch(context).apply {
                text = "Bật Auto Behavior"
                isChecked = isEnabled(context, slotIndex)
                setOnCheckedChangeListener { _, checked ->
                    setEnabled(context, slotIndex, checked)
                }
                setPadding(32, 16, 32, 16)
            })
            addView(TextView(context).apply {
                text = "Khi bật: Tự động scroll, click ngẫu nhiên để giảm bot detection"
                textSize = 12f
                setPadding(32, 16, 32, 32)
            })
        }
    }

    // Script JS để giả lập hành vi
    fun getBehaviorScript(): String = """
        (function() {
            function randomScroll() {
                window.scrollBy(0, Math.random() * 300 + 100);
            }
            function randomClick() {
                var links = document.querySelectorAll('a, button');
                if (links.length > 0) {
                    var target = links[Math.floor(Math.random() * links.length)];
                    target.focus();
                }
            }
            setTimeout(randomScroll, 2000);
            setTimeout(randomClick, 5000);
            setTimeout(randomScroll, 8000);
            return "behavior_injected";
        })();
    """.trimIndent()
}
