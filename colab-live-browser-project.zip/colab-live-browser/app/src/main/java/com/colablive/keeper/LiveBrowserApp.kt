package com.colablive.keeper

import android.app.Application

/**
 * TODO (chưa làm, cố tình để sau theo đúng ưu tiên hiện tại — chỉ tập trung
 * cho Colab chạy được trên GeckoView trước): cô lập dữ liệu GeckoRuntime
 * riêng theo từng khe. Trước đây dùng WebView.setDataDirectorySuffix() cho
 * việc này — GeckoView có cơ chế tương đương riêng (cấu hình thư mục dữ liệu
 * qua GeckoRuntimeSettings), nhưng CHƯA tra cứu API chính xác nên chưa viết,
 * để tránh đoán bừa như đã từng mắc lỗi trước đó trong dự án này.
 *
 * Hệ quả hiện tại: mọi khe đang DÙNG CHUNG 1 GeckoRuntime data — nghĩa là
 * cookie/session KHÔNG cô lập giữa các khe cho tới khi việc này được làm.
 */
class LiveBrowserApp : Application()
