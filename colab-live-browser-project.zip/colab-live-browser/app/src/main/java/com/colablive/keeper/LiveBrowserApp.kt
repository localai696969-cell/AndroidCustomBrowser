package com.colablive.keeper

import android.app.Application
import android.content.Intent
import com.colablive.keeper.core.DebugLog
import com.colablive.keeper.core.ProfileSlots
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class LiveBrowserApp : Application() {
    override fun onCreate() {
        super.onCreate()
        DebugLog.init(this) // PHẢI gọi trước mọi DebugLog.log() khác trong toàn app
        val slotIndex = ProfileSlots.getCurrentSlotIndex(this)
        DebugLog.log("App init — slot=$slotIndex, version=${com.colablive.keeper.core.BuildMarker.VERSION}")
        installCrashHandler()
    }

    /**
     * Không có máy tính/adb thì không xem được logcat — cái này thay thế 1
     * phần: bắt exception Kotlin/Java chưa xử lý, LƯU RA FILE (sống sót qua
     * crash, xem lại được ở lần mở sau) và MỞ NGAY 1 màn hình hiển thị lỗi
     * (thay cho dialog "App đã dừng" mù thông tin của Android), có nút Sao
     * chép để gửi lại cho người hỗ trợ.
     *
     * ⚠️ GIỚI HẠN THẬT: đây là uncaught exception handler Ở TẦNG JVM
     * (Kotlin/Java) — KHÔNG bắt được crash NATIVE (vd libxul.so của chính
     * Gecko crash ở tầng C++, như rủi ro đã ghi ở GeckoRuntimeProvider về cờ
     * `-profile` chưa xác nhận). Native crash vẫn chỉ hiện dialog hệ thống
     * mù thông tin như cũ — cần logcat/bug report thật mới thấy được loại đó.
     */
    private fun installCrashHandler() {
        val previousHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                val sw = StringWriter()
                throwable.printStackTrace(PrintWriter(sw))
                val time = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
                val slotIndex = ProfileSlots.getCurrentSlotIndex(this)
                val recentLogs = DebugLog.readFullFile(this).lines().takeLast(60).joinToString("\n")
                val crashText = buildString {
                    append("Crash lúc $time — khe $slotIndex — thread ${thread.name}\n\n")
                    append(sw.toString())
                    append("\n\n--- 60 dòng log gần nhất trước crash (từ file) ---\n")
                    append(recentLogs)
                }
                File(filesDir, "last_crash.txt").writeText(crashText)

                val intent = Intent(applicationContext, CrashReportActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                    putExtra("crash_text", crashText)
                }
                applicationContext.startActivity(intent)
                Thread.sleep(300) // cho hệ thống kịp nhận Intent trước khi tiến trình này chết
            } catch (e: Throwable) {
                // Không để chính crash-handler crash tiếp — im lặng bỏ qua,
                // vẫn còn file last_crash.txt nếu ghi tới được bước đó.
            }
            android.os.Process.killProcess(android.os.Process.myPid())
            kotlin.system.exitProcess(1)
        }
    }
}
