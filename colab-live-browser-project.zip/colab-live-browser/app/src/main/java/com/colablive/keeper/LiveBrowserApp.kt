package com.colablive.keeper

import android.app.Application
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * TODO (chưa làm, cố tình để sau theo đúng ưu tiên hiện tại — chỉ tập trung
 * cho Colab chạy được trên GeckoView trước): cô lập dữ liệu GeckoRuntime
 * riêng theo từng khe. Trước đây dùng WebView.setDataDirectorySuffix() cho
 * việc này — GeckoView có cơ chế tương đương riêng (cấu hình thư mục dữ liệu
 * qua GeckoRuntimeSettings), nhưng CHƯA tra cứu API chính xác nên chưa viết,
 * để tránh đoán bừa như đã từng mắc lỗi trước đó trong dự án này.
 *
 * Hệ quả hiện tại: mọi khe đang DÙNG CHUNG 1 GeckoRuntime data — nghĩa là
 * cookie/session KHÔNG cô lập giữa các khe cho tới khi việc này được làm.
 */
class LiveBrowserApp : Application() {

    override fun onCreate() {
        super.onCreate()
        installCrashLogger()
    }

    /**
     * Không có PC/ADB thì không đọc được logcat hệ thống bình thường (Android
     * chặn app đọc log của app khác/toàn hệ thống từ Android 4.1+ trở đi, chỉ
     * ADB hoặc app có quyền hệ thống mới đọc được). Cách thực tế để lấy log
     * crash khi chỉ có điện thoại: tự bắt crash và ghi ra 1 file text trong
     * thư mục riêng của app — mở được bằng bất kỳ app quản lý file nào, không
     * cần quyền đặc biệt (Android/data/<package>/files/ là vùng riêng của app
     * nhưng vẫn duyệt được qua app Files/quản lý file thường trên hầu hết máy).
     */
    private fun installCrashLogger() {
        val previousHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                val logDir = getExternalFilesDir(null) ?: filesDir
                val logFile = File(logDir, "crash_log.txt")
                val sw = StringWriter()
                throwable.printStackTrace(PrintWriter(sw))
                val timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
                logFile.appendText("\n===== CRASH LÚC $timestamp =====\n$sw\n")
            } catch (e: Exception) {
                // Không để lỗi ghi log làm crash thêm lần nữa
            }
            previousHandler?.uncaughtException(thread, throwable)
        }
    }
}
