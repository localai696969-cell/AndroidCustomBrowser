package com.colablive.keeper

import android.app.Application
import com.colablive.keeper.core.DebugLog
import com.colablive.keeper.core.ProfileSlots

class LiveBrowserApp : Application() {
    override fun onCreate() {
        super.onCreate()
        val slotIndex = ProfileSlots.getCurrentSlotIndex(this)
        DebugLog.log("App init — slot=$slotIndex, version=${com.colablive.keeper.core.BuildMarker.VERSION}")
    }
}
