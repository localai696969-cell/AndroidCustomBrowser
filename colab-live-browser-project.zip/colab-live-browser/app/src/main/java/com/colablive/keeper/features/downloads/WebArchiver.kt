package com.colablive.keeper.features.downloads

import android.content.Context
import android.os.Handler
import android.os.Looper
import com.colablive.keeper.core.DebugLog
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.Executors

/**
 * Tải trang web như trên PC — lưu HTML + resources riêng biệt.
 */
class WebArchiver(private val context: Context) {

    private val client = OkHttpClient.Builder()
        .followRedirects(true)
        .build()
    private val executor = Executors.newFixedThreadPool(4)
    private val handler = Handler(Looper.getMainLooper())

    data class ArchiveResult(
        val success: Boolean,
        val path: String,
        val fileCount: Int,
        val totalSize: Long
    )

    /**
     * Tải toàn bộ trang web (đơn giản — chỉ HTML, không parse resources).
     */
    fun archivePage(url: String, pageTitle: String, callback: (ArchiveResult) -> Unit) {
        executor.execute {
            try {
                val safeName = pageTitle.replace(Regex("[\\/:*?\"<>|]"), "_").take(50)
                val baseDir = File(context.getExternalFilesDir(null), "WebArchives/$safeName")
                baseDir.mkdirs()

                // Tải HTML gốc
                val html = downloadText(url)
                if (html == null) {
                    handler.post {
                        callback(ArchiveResult(false, "", 0, 0))
                    }
                    return@execute
                }

                // Lưu HTML
                val indexFile = File(baseDir, "index.html")
                FileOutputStream(indexFile).use { out ->
                    out.write(html.toByteArray(Charsets.UTF_8))
                }

                val totalSize = html.length.toLong()

                handler.post {
                    callback(ArchiveResult(true, baseDir.absolutePath, 1, totalSize))
                }

            } catch (e: Exception) {
                DebugLog.log("Archive error: ${e.message}")
                handler.post {
                    callback(ArchiveResult(false, "", 0, 0))
                }
            }
        }
    }

    private fun downloadText(url: String): String? {
        var result: String? = null
        try {
            val request = Request.Builder().url(url).build()
            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    result = response.body?.string()
                }
            }
        } catch (e: Exception) {
            DebugLog.log("Download text error: ${e.message}")
        }
        return result
    }

    fun getArchivePreview(path: String): String {
        val dir = File(path)
        if (!dir.exists()) return ""

        val sb = StringBuilder()
        sb.appendLine("📁 ${dir.name}")
        sb.appendLine("   📄 index.html")

        File(dir, "css").listFiles()?.forEach { sb.appendLine("   🎨 css/${it.name}") }
        File(dir, "js").listFiles()?.forEach { sb.appendLine("   ⚡ js/${it.name}") }
        File(dir, "images").listFiles()?.forEach { sb.appendLine("   🖼️ images/${it.name}") }
        File(dir, "fonts").listFiles()?.forEach { sb.appendLine("   🔤 fonts/${it.name}") }

        return sb.toString()
    }
}
