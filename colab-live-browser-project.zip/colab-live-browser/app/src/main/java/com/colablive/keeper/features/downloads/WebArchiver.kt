package com.colablive.keeper.features.downloads

import android.content.Context
import com.colablive.keeper.core.DebugLog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.jsoup.Jsoup
import java.io.File
import java.net.URL

class WebArchiver(private val context: Context) {

suspend fun archivePage(url: String, outputDir: File? = null): ArchiveResult? = withContext(Dispatchers.IO) {
        try {
            val doc = Jsoup.connect(url).userAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36").get()
            val baseDir = outputDir ?: File(context.getExternalFilesDir(null), "archives/${System.currentTimeMillis()}")
            baseDir.mkdirs()

            val resourceDir = File(baseDir, "resources")
            resourceDir.mkdirs()

            var successCount = 0
            var totalCount = 0

            // Download CSS
            val cssLinks = doc.select("link[rel=stylesheet]")
            for (link in cssLinks) {
                val href = link.absUrl("href")
                if (href.isNotEmpty()) {
                    totalCount++
                    val fileName = "css_${System.currentTimeMillis()}_${successCount}.css"
                    if (downloadResource(href, File(resourceDir, fileName))) {
                        link.attr("href", "resources/$fileName")
                        successCount++
                    }
                }
            }

            // Download images
            val images = doc.select("img[src]")
            for (img in images) {
                val src = img.absUrl("src")
                if (src.isNotEmpty()) {
                    totalCount++
                    val ext = src.substringAfterLast(".", "jpg").take(4)
                    val fileName = "img_${System.currentTimeMillis()}_${successCount}.$ext"
                    if (downloadResource(src, File(resourceDir, fileName))) {
                        img.attr("src", "resources/$fileName")
                        successCount++
                    }
                }
            }

            // Download JS
            val scripts = doc.select("script[src]")
            for (script in scripts) {
                val src = script.absUrl("src")
                if (src.isNotEmpty()) {
                    totalCount++
                    val fileName = "js_${System.currentTimeMillis()}_${successCount}.js"
                    if (downloadResource(src, File(resourceDir, fileName))) {
                        script.attr("src", "resources/$fileName")
                        successCount++
                    }
                }
            }

            // Save modified HTML
            val htmlFile = File(baseDir, "index.html")
            htmlFile.writeText(doc.html())

            DebugLog.log("WebArchive: Saved to ${htmlFile.absolutePath} ($successCount/$totalCount resources)")
            ArchiveResult(success = true, filePath = htmlFile.absolutePath)
        } catch (e: Exception) {
            DebugLog.log("WebArchive error: ${e.message}")
            null
        }
    }

    private fun downloadResource(url: String, outputFile: File): Boolean {
        return try {
            URL(url).openStream().use { input ->
                outputFile.outputStream().use { output -> input.copyTo(output) }
            }
            true
        } catch (e: Exception) {
            false
        }
    }
}
