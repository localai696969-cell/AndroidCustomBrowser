package com.colablive.keeper.core.proxy

import com.colablive.keeper.core.DebugLog
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

data class ProxyCandidate(val type: String, val host: String, val port: Int)

/**
 * Cào danh sách proxy miễn phí công khai từ ProxyScrape (xác nhận hoạt động
 * thật qua tra cứu, có API documented: docs.proxyscrape.com). Định dạng trả
 * về "protocolipport" = mỗi dòng "protocol://ip:port" (vd "http://1.2.3.4:8080").
 *
 * CẢNH BÁO THẬT (từ chính tài liệu công khai của ngành proxy free): proxy
 * miễn phí có thể log traffic, chèn quảng cáo, hoặc là honeypot — KHÔNG gửi
 * dữ liệu nhạy cảm (mật khẩu, thông tin thanh toán) qua proxy loại này.
 */
object ProxyScraper {
    private const val API_URL =
        "https://api.proxyscrape.com/v4/free-proxy-list/get?request=display_proxies&proxy_format=protocolipport&format=text"

    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()

    /** Gọi trong background thread — có network call, không gọi từ main thread. */
    fun fetchCandidates(): List<ProxyCandidate> {
        return try {
            val request = Request.Builder().url(API_URL).build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    DebugLog.log("ProxyScraper: HTTP ${response.code} khi lấy danh sách proxy")
                    return emptyList()
                }
                val body = response.body?.string() ?: return emptyList()
                body.lines()
                    .mapNotNull { parseLine(it.trim()) }
                    .also { DebugLog.log("ProxyScraper: lấy được ${it.size} proxy ứng viên") }
            }
        } catch (e: Exception) {
            DebugLog.log("ProxyScraper: lỗi lấy danh sách — ${e.message}")
            emptyList()
        }
    }

    private fun parseLine(line: String): ProxyCandidate? {
        if (line.isEmpty()) return null
        // Định dạng: "http://1.2.3.4:8080" hoặc "socks5://1.2.3.4:1080"
        val match = Regex("""^(https?|socks[45]?)://([^:]+):(\d+)$""").find(line) ?: return null
        val (proto, host, portStr) = match.destructured
        val port = portStr.toIntOrNull() ?: return null
        // WebExtension Proxy API chỉ nhận "http" hoặc "socks" (SOCKS5) —
        // quy đổi socks4/socks5 về "socks" chung.
        val normalizedType = if (proto.startsWith("socks")) "socks" else "http"
        return ProxyCandidate(normalizedType, host, port)
    }
}
