package com.colablive.keeper.features.downloads

import com.colablive.keeper.core.DebugLog
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * BUG THẬT đã tìm ra (người dùng báo: "sniff media tải về file lỗi"): với
 * link kiểu HLS (`.m3u8`), `showSniffedLinksDialog()` (DownloadManagerFeature)
 * trước đây gọi thẳng `downloadEngine.startDownload(link.url, ...)` — đây
 * chỉ là 1 GET HTTP thường, nên file thật sự lưu về máy CHỈ LÀ file
 * PLAYLIST VĂN BẢN (m3u8 — vài trăm byte tới vài KB, liệt kê danh sách URL
 * segment .ts) — KHÔNG PHẢI video. Mở file đó bằng trình phát video sẽ báo
 * lỗi/không phát được — đúng triệu chứng người dùng mô tả. Không có chỗ
 * nào khác trong toàn bộ code dự án từng tải+ghép segment .ts thật.
 *
 * File này viết MỚI HOÀN TOÀN 1 bộ tải HLS tối thiểu nhưng ĐÚNG: đọc
 * manifest (có thể là master playlist trỏ tới nhiều chất lượng, hoặc thẳng
 * media playlist), chọn chất lượng cao nhất nếu là master, tải TUẦN TỰ
 * từng segment .ts rồi nối byte trực tiếp vào 1 file .ts duy nhất (nối
 * trực tiếp là hợp lệ với MPEG-TS không mã hoá — đây là cách chính các
 * công cụ tải HLS phổ biến làm cho trường hợp đơn giản, không cần thư viện
 * mux ngoài).
 *
 * GIỚI HẠN THẬT (nói rõ, không giả vờ hỗ trợ đủ mọi trường hợp):
 * - KHÔNG hỗ trợ segment mã hoá AES-128 (`#EXT-X-KEY` với METHOD khác
 *   NONE) — cần thêm thư viện/code giải mã riêng, chưa làm ở đây. Phát
 *   hiện được thì BÁO LỖI RÕ RÀNG cho người dùng, không âm thầm tải ra file
 *   hỏng (segment mã hoá nối trực tiếp sẽ ra file không phát được, TỆ HƠN
 *   cả bug gốc vì trông như tải xong nhưng vẫn hỏng).
 * - KHÔNG hỗ trợ stream LIVE (không có `#EXT-X-ENDLIST`) — 1 stream đang
 *   phát trực tiếp về bản chất không có "điểm kết thúc" để tải trọn vẹn.
 *   Phát hiện được thì báo lỗi rõ ràng, không tải dở dang rồi báo "xong".
 * - KHÔNG hỗ trợ MPEG-DASH (`.mpd`) — sniffer có phát hiện loại này riêng
 *   (`type="dash"`) nhưng file này chỉ xử lý HLS; DASH cần logic parse
 *   hoàn toàn khác (không dùng chung code này).
 */
object HlsDownloader {

    class HlsDownloadException(message: String) : Exception(message)

    data class Progress(val doneSegments: Int, val totalSegments: Int)

    /**
     * Tải trọn 1 stream HLS về `destFile` (ghi đè nếu đã tồn tại). Chạy
     * TRÊN THREAD GỌI HÀM NÀY (không tự tạo thread riêng) — người gọi tự
     * quyết định chạy nền ở đâu, để dễ kiểm soát/huỷ.
     *
     * Ném `HlsDownloadException` với thông báo tiếng Việt rõ ràng cho các
     * trường hợp không hỗ trợ (mã hoá, live) — người gọi nên hiển thị
     * thẳng `e.message` cho người dùng thay vì thông báo lỗi chung chung.
     */
    fun download(
        manifestUrl: String,
        destFile: File,
        onProgress: ((Progress) -> Unit)? = null,
        isCancelled: (() -> Boolean)? = null
    ) {
        val manifestText = fetchText(manifestUrl)
        val mediaPlaylistUrl = resolveMediaPlaylistUrl(manifestUrl, manifestText)
        val mediaPlaylistText = if (mediaPlaylistUrl == manifestUrl) manifestText else fetchText(mediaPlaylistUrl)

        if (!mediaPlaylistText.contains("#EXT-X-ENDLIST")) {
            throw HlsDownloadException(
                "Đây là stream LIVE (không có điểm kết thúc trong manifest) — " +
                "không thể tải trọn vẹn thành 1 file. Chỉ tải được video đã " +
                "phát xong (VOD)."
            )
        }

        val keyLine = mediaPlaylistText.lineSequence().firstOrNull { it.startsWith("#EXT-X-KEY") }
        if (keyLine != null && !keyLine.contains("METHOD=NONE")) {
            throw HlsDownloadException(
                "Video này có segment MÃ HOÁ (HLS AES-128) — phiên bản hiện " +
                "tại của tính năng tải chưa hỗ trợ giải mã, không thể tải " +
                "được. (Tránh tải ra file hỏng trông như thành công.)"
            )
        }

        val segmentUrls = mediaPlaylistText.lineSequence()
            .filter { it.isNotBlank() && !it.startsWith("#") }
            .map { resolveUrl(mediaPlaylistUrl, it.trim()) }
            .toList()

        if (segmentUrls.isEmpty()) {
            throw HlsDownloadException("Không đọc được segment nào từ manifest — có thể manifest sai định dạng hoặc trống.")
        }

        destFile.parentFile?.mkdirs()
        destFile.outputStream().use { out ->
            for ((index, segUrl) in segmentUrls.withIndex()) {
                if (isCancelled?.invoke() == true) {
                    throw HlsDownloadException("Đã huỷ tải giữa chừng (segment ${index + 1}/${segmentUrls.size}).")
                }
                var lastError: Exception? = null
                var success = false
                // Tự thử lại tối đa 3 lần mỗi segment — mạng chập chờn giữa
                // hàng chục/hàng trăm request nhỏ là chuyện thường, không
                // nên bỏ cuộc cả file chỉ vì 1 segment lỗi tạm thời.
                for (attempt in 1..3) {
                    try {
                        downloadSegmentInto(segUrl, out)
                        success = true
                        break
                    } catch (e: Exception) {
                        lastError = e
                        DebugLog.log("HlsDownloader: segment ${index + 1}/${segmentUrls.size} lỗi lần $attempt ($segUrl): ${e.message}")
                    }
                }
                if (!success) {
                    throw HlsDownloadException(
                        "Tải lỗi ở segment ${index + 1}/${segmentUrls.size} sau 3 lần thử: ${lastError?.message}"
                    )
                }
                onProgress?.invoke(Progress(index + 1, segmentUrls.size))
            }
        }
    }

    private fun downloadSegmentInto(url: String, out: java.io.OutputStream) {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 10000
        conn.readTimeout = 15000
        conn.instanceFollowRedirects = true
        try {
            if (conn.responseCode !in 200..299) {
                throw HlsDownloadException("HTTP ${conn.responseCode} khi tải segment")
            }
            conn.inputStream.use { input -> input.copyTo(out) }
        } finally {
            conn.disconnect()
        }
    }

    private fun fetchText(url: String): String {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 10000
        conn.readTimeout = 10000
        conn.instanceFollowRedirects = true
        try {
            if (conn.responseCode !in 200..299) {
                throw HlsDownloadException("Không tải được manifest (HTTP ${conn.responseCode}): $url")
            }
            return conn.inputStream.use { it.readBytes().toString(Charsets.UTF_8) }
        } finally {
            conn.disconnect()
        }
    }

    /**
     * Nếu `manifestText` là MASTER playlist (liệt kê nhiều chất lượng qua
     * `#EXT-X-STREAM-INF`), chọn chất lượng cao nhất (BANDWIDTH lớn nhất)
     * rồi trả về URL tuyệt đối của MEDIA playlist tương ứng. Nếu đã là
     * media playlist rồi (có `#EXTINF`, không có `#EXT-X-STREAM-INF`), trả
     * về nguyên `manifestUrl`.
     */
    private fun resolveMediaPlaylistUrl(manifestUrl: String, manifestText: String): String {
        val lines = manifestText.lines()
        var bestBandwidth = -1L
        var bestUri: String? = null
        for (i in lines.indices) {
            val line = lines[i].trim()
            if (line.startsWith("#EXT-X-STREAM-INF")) {
                val bandwidth = Regex("BANDWIDTH=(\\d+)").find(line)?.groupValues?.get(1)?.toLongOrNull() ?: 0L
                // Dòng URI của variant nằm ngay dòng kế tiếp không phải comment.
                var j = i + 1
                while (j < lines.size && (lines[j].isBlank() || lines[j].startsWith("#"))) j++
                val uriLine = lines.getOrNull(j)?.trim()
                if (!uriLine.isNullOrBlank() && bandwidth >= bestBandwidth) {
                    bestBandwidth = bandwidth
                    bestUri = uriLine
                }
            }
        }
        return if (bestUri != null) resolveUrl(manifestUrl, bestUri) else manifestUrl
    }

    private fun resolveUrl(baseUrl: String, maybeRelative: String): String {
        if (maybeRelative.startsWith("http://") || maybeRelative.startsWith("https://")) return maybeRelative
        return try {
            URL(URL(baseUrl), maybeRelative).toString()
        } catch (e: Exception) {
            maybeRelative
        }
    }
}
