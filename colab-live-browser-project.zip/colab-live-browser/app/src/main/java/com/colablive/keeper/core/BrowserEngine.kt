package com.colablive.keeper.core

/**
 * Lớp trừu tượng che giấu engine cụ thể (GeckoView) khỏi mọi feature.
 * Hỗ trợ multi-tab và drag-drop file.
 */
interface BrowserEngine {
    fun currentUrl(): String?
    fun evaluateJs(script: String, callback: ((String?) -> Unit)? = null)
    fun loadUrl(url: String)
    fun reload()
    fun goBack(): Boolean
    fun goForward(): Boolean
    fun canGoBack(): Boolean
    fun canGoForward(): Boolean

    // Multi-tab support
    fun createTab(url: String = "about:blank"): BrowserTab
    fun closeTab(tabId: String)
    fun switchToTab(tabId: String)
    fun getTabs(): List<BrowserTab>
    fun getActiveTab(): BrowserTab?

    // Drag & drop support
    fun handleDropUri(uri: android.net.Uri, mimeType: String? = null)
}

data class BrowserTab(
    val id: String,
    var url: String = "about:blank",
    var title: String = "",
    var isLoading: Boolean = false,
    var favicon: android.graphics.Bitmap? = null,
    // GeckoSession không có property canGoBack/canGoForward đọc đồng bộ được —
    // API thật chỉ đẩy thay đổi qua NavigationDelegate.onCanGoBack/onCanGoForward,
    // nên phải tự cache lại theo từng tab (xem GeckoViewEngine.createSession()).
    var canGoBack: Boolean = false,
    var canGoForward: Boolean = false
)
