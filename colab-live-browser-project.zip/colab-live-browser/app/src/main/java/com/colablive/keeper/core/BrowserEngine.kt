package com.colablive.keeper.core

/**
 * Lớp trừu tượng che giấu engine cụ thể (GeckoView) khỏi mọi feature.
 * Hỗ trợ multi-tab và drag-drop file.
 */
interface BrowserEngine {
    fun currentUrl(): String?
    fun evaluateJs(script: String, callback: ((String?) -> Unit)? = null)
    fun loadUrl(url: String)
    fun reload()
    fun goBack(): Boolean
    fun goForward(): Boolean
    fun canGoBack(): Boolean
    fun canGoForward(): Boolean

    // Multi-tab support
    fun createTab(url: String = "about:blank", isPrivate: Boolean = false): BrowserTab
    fun closeTab(tabId: String)
    fun switchToTab(tabId: String)
    fun getTabs(): List<BrowserTab>
    fun getActiveTab(): BrowserTab?
    // TÍNH NĂNG MỚI (người dùng yêu cầu) — kéo-thả đổi vị trí tab, giống
    // Chrome. Đổi vị trí `tabId` tới đúng `toIndex` trong `tabOrder` (0 =
    // đầu tiên). Không đổi tab đang active, chỉ đổi thứ tự hiển thị.
    fun moveTab(tabId: String, toIndex: Int)
    // TÍNH NĂNG MỚI (người dùng yêu cầu) — nhóm tab giống Chrome.
    fun createGroup(name: String, colorHex: String): TabGroup
    fun getGroups(): List<TabGroup>
    fun setTabGroup(tabId: String, groupId: String?)
    fun deleteGroup(groupId: String)

    // Drag & drop support
    fun handleDropUri(uri: android.net.Uri, mimeType: String? = null)

    // Media session — nút Play/Pause thật trên thông báo hệ thống, xem
    // GeckoViewEngine.createSession() (session.mediaSessionDelegate) và
    // BackgroundMediaFeature.
    fun getNativeMediaSessionToken(): android.media.session.MediaSession.Token
    var onMediaPlaybackStateListener: ((playing: Boolean) -> Unit)?

    // TÍNH NĂNG MỚI (người dùng yêu cầu) — Tìm trong trang, giống Ctrl+F
    // trên desktop. Dùng API native `GeckoSession.finder` (SessionFinder)
    // của GeckoView thay vì tự inject JS quét DOM — API native tìm/tô
    // sáng đúng NGAY TRONG lớp render thật của Gecko (Gecko compositor),
    // nên luôn khớp chính xác với những gì người dùng đang THẤY trên màn
    // hình (kể cả sau khi zoom/cuộn, kể cả text nằm trong iframe/shadow
    // DOM mà JS injection từ content script khó với tới đầy đủ).
    //
    // callback trả về (currentMatchIndex bắt đầu từ 1, totalMatches) mỗi
    // lần có kết quả tìm mới — dùng để cập nhật UI "3/12" trên thanh tìm
    // kiếm. Nếu totalMatches=0, không tìm thấy gì.
    fun findInPage(query: String, forward: Boolean = true, matchCase: Boolean = false, callback: ((current: Int, total: Int) -> Unit)? = null)
    // Xoá highlight tìm kiếm hiện tại (gọi khi đóng thanh tìm kiếm).
    fun clearFindInPage()
}

data class BrowserTab(
    val id: String,
    var url: String = "about:blank",
    var title: String = "",
    var isLoading: Boolean = false,
    var favicon: android.graphics.Bitmap? = null,
    // GeckoSession không có property canGoBack/canGoForward đọc đồng bộ được —
    // API thật chỉ đẩy thay đổi qua NavigationDelegate.onCanGoBack/onCanGoForward,
    // nên phải tự cache lại theo từng tab (xem GeckoViewEngine.createSession()).
    var canGoBack: Boolean = false,
    var canGoForward: Boolean = false,
    // Trạng thái ĐẦY ĐỦ của phiên (lịch sử back/forward, vị trí cuộn, dữ
    // liệu form) — chuỗi trả về từ GeckoSession.SessionState.toString(),
    // xem GeckoViewEngine.onSessionStateChange(). KHÁC với `url`/`title`
    // (chỉ đủ để mở lại đúng trang, không đủ để khôi phục lịch sử/cuộn/form).
    var savedState: String? = null,
    // LAZY RESTORE: tab được tạo metadata nhưng CHƯA load nội dung (xem
    // GeckoViewEngine.createTabLazy() và restoreTabsIfAny()). Session đã
    // open nhưng rỗng — chỉ load thật khi switchToTab() đụng tới lần đầu.
    var isUnloaded: Boolean = false,
    // Chế độ ẨN DANH — dùng đúng API thật của GeckoView
    // (`GeckoSessionSettings.Builder().usePrivateMode(true)`, xem
    // `GeckoViewEngine.createSession()`). Tab ẩn danh KHÔNG được lưu vào
    // lịch sử (`MainActivity` tự kiểm tra cờ này trước khi gọi
    // `recordHistoryVisit`/`updateLastHistoryTitle`) và KHÔNG được khôi
    // phục lại sau khi đóng app (`saveTabsState()` tự bỏ qua các tab có cờ
    // này) — đúng hành vi ẩn danh thật của Chrome.
    var openerTabId: String? = null,
    var isPrivate: Boolean = false,
    // TÍNH NĂNG MỚI (người dùng yêu cầu) — nhóm tab giống Chrome. `null` =
    // không thuộc nhóm nào. Xem `TabGroup` bên dưới cho tên/màu thật của
    // nhóm — chỉ lưu ID ở đây để nhiều tab dùng chung 1 nhóm mà không lặp
    // lại tên/màu.
    var groupId: String? = null
)

/**
 * TÍNH NĂNG MỚI (người dùng yêu cầu) — nhóm tab giống Chrome. CHỈ lưu
 * trong RAM (không lưu lại sau khi tắt app) — đủ dùng trong 1 phiên, có
 * thể mở rộng lưu bền sau nếu cần (xem `GeckoViewEngine.saveTabsState`/
 * `restoreTabsIfAny` để thêm phần lưu `tabGroups`+`groupId` từng tab nếu
 * muốn giữ qua lần khởi động sau).
 */
data class TabGroup(val id: String, var name: String, val colorHex: String)


