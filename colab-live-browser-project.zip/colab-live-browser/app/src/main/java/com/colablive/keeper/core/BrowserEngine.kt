package com.colablive.keeper.core

/**
 * Lớp trừu tượng che giấu engine cụ thể (GeckoView) khỏi mọi feature.
 * Hỗ trợ multi-tab và drag-drop file.
 */
interface BrowserEngine {
    fun currentUrl(): String?
    fun evaluateJs(script: String, callback: ((String?) -> Unit)? = null)
    fun loadUrl(url: String)
    fun reload()
    fun goBack(): Boolean
    fun goForward(): Boolean
    fun canGoBack(): Boolean
    fun canGoForward(): Boolean

    // Multi-tab support
    fun createTab(url: String = "about:blank", isPrivate: Boolean = false): BrowserTab
    fun closeTab(tabId: String)
    fun switchToTab(tabId: String)
    fun getTabs(): List<BrowserTab>
    fun getActiveTab(): BrowserTab?
    // TÍNH NĂNG MỚI (người dùng yêu cầu) — kéo-thả đổi vị trí tab, giống
    // Chrome. Đổi vị trí `tabId` tới đúng `toIndex` trong `tabOrder` (0 =
    // đầu tiên). Không đổi tab đang active, chỉ đổi thứ tự hiển thị.
    fun moveTab(tabId: String, toIndex: Int)

    // Drag & drop support
    fun handleDropUri(uri: android.net.Uri, mimeType: String? = null)

    // Media session — nút Play/Pause thật trên thông báo hệ thống, xem
    // GeckoViewEngine.createSession() (session.mediaSessionDelegate) và
    // BackgroundMediaFeature.
    fun getNativeMediaSessionToken(): android.media.session.MediaSession.Token
    var onMediaPlaybackStateListener: ((playing: Boolean) -> Unit)?
}

data class BrowserTab(
    val id: String,
    var url: String = "about:blank",
    var title: String = "",
    var isLoading: Boolean = false,
    var favicon: android.graphics.Bitmap? = null,
    // GeckoSession không có property canGoBack/canGoForward đọc đồng bộ được —
    // API thật chỉ đẩy thay đổi qua NavigationDelegate.onCanGoBack/onCanGoForward,
    // nên phải tự cache lại theo từng tab (xem GeckoViewEngine.createSession()).
    var canGoBack: Boolean = false,
    var canGoForward: Boolean = false,
    // Trạng thái ĐẦY ĐỦ của phiên (lịch sử back/forward, vị trí cuộn, dữ
    // liệu form) — chuỗi trả về từ GeckoSession.SessionState.toString(),
    // xem GeckoViewEngine.onSessionStateChange(). KHÁC với `url`/`title`
    // (chỉ đủ để mở lại đúng trang, không đủ để khôi phục lịch sử/cuộn/form).
    var savedState: String? = null,
    // LAZY RESTORE: tab được tạo metadata nhưng CHƯA load nội dung (xem
    // GeckoViewEngine.createTabLazy() và restoreTabsIfAny()). Session đã
    // open nhưng rỗng — chỉ load thật khi switchToTab() đụng tới lần đầu.
    var isUnloaded: Boolean = false,
    // Chế độ ẨN DANH — dùng đúng API thật của GeckoView
    // (`GeckoSessionSettings.Builder().usePrivateMode(true)`, xem
    // `GeckoViewEngine.createSession()`). Tab ẩn danh KHÔNG được lưu vào
    // lịch sử (`MainActivity` tự kiểm tra cờ này trước khi gọi
    // `recordHistoryVisit`/`updateLastHistoryTitle`) và KHÔNG được khôi
    // phục lại sau khi đóng app (`saveTabsState()` tự bỏ qua các tab có cờ
    // này) — đúng hành vi ẩn danh thật của Chrome.
    val isPrivate: Boolean = false,
    // FIX BUG THẬT (người dùng báo đúng): đóng tab popup (mở ra từ tab
    // khác qua `window.open()`/target="_blank") trước đây LUÔN quay về
    // `tabOrder.firstOrNull()` (tab đầu tiên/tab 0) — không hề nhớ tab nào
    // đã mở ra nó. Ghi lại `activeTabId` NGAY LÚC tạo popup (xem
    // `onNewSession` trong GeckoViewEngine) — khi đóng popup, nếu tab gốc
    // này VẪN CÒN tồn tại, quay lại đúng đó thay vì tab 0, giống hành vi
    // Chrome/Firefox thật.
    var openerTabId: String? = null
)

