package com.colablive.keeper.core

/**
 * Lớp trừu tượng che giấu WebView (hoặc sau này GeckoView) khỏi mọi feature.
 * Nếu sau này migrate sang GeckoView, chỉ cần viết thêm 1 class implement
 * interface này (vd GeckoViewEngine) — ColabLiveKeeperFeature,
 * DownloadManagerFeature, và mọi feature tương lai KHÔNG cần sửa 1 dòng nào.
 */
interface BrowserEngine {
    fun currentUrl(): String?
    fun evaluateJs(script: String, callback: ((String?) -> Unit)? = null)
    fun loadUrl(url: String)
}
