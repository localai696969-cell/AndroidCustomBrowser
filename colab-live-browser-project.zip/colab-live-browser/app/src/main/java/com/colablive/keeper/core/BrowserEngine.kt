package com.colablive.keeper.core

/**
 * Lớp trừu tượng che giấu engine cụ thể (GeckoView) khỏi mọi feature.
 * Hỗ trợ multi-tab và drag-drop file.
 */
interface BrowserEngine {
    fun currentUrl(): String?
    fun evaluateJs(script: String, callback: ((String?) -> Unit)? = null)
    fun loadUrl(url: String)
    fun reload()
    fun goBack(): Boolean
    fun goForward(): Boolean
    fun canGoBack(): Boolean
    fun canGoForward(): Boolean

    // Multi-tab support
    fun createTab(url: String = "about:blank", isPrivate: Boolean = false): BrowserTab
    fun closeTab(tabId: String)
    fun switchToTab(tabId: String)
    fun getTabs(): List<BrowserTab>
    fun getActiveTab(): BrowserTab?
    // TÍNH NĂNG MỚI (người dùng yêu cầu) — kéo-thả đổi vị trí tab, giống
    // Chrome. Đổi vị trí `tabId` tới đúng `toIndex` trong `tabOrder` (0 =
    // đầu tiên). Không đổi tab đang active, chỉ đổi thứ tự hiển thị.
    fun moveTab(tabId: String, toIndex: Int)
    // TÍNH NĂNG MỚI (người dùng yêu cầu) — nhóm tab giống Chrome.
    fun createGroup(name: String, colorHex: String): TabGroup
    fun getGroups(): List<TabGroup>
    fun setTabGroup(tabId: String, groupId: String?)
    fun deleteGroup(groupId: String)
    /**
     * FIX BUG THẬT (người dùng báo: "group tab trên thanh tab không kéo
     * di chuyển vị trí được như tab thường") — trước đây kéo-thả CHỈ hoạt
     * động cho TỪNG tab lẻ (xem `moveTab`); không có cách nào di chuyển
     * CẢ MỘT NHÓM như 1 khối. Di chuyển toàn bộ tab thuộc `groupId` (giữ
     * NGUYÊN thứ tự tương đối bên trong nhóm) tới ngay TRƯỚC
     * `beforeTabId` — nếu `beforeTabId == null`, đẩy cả nhóm xuống CUỐI
     * danh sách. Nếu `beforeTabId` chính là 1 thành viên của CÙNG nhóm
     * đang kéo, coi như không cần làm gì (thả lại đúng chỗ cũ).
     */
    fun moveGroup(groupId: String, beforeTabId: String?)

    // TÍNH NĂNG MỚI (người dùng yêu cầu) — "thẻ đã đóng gần đây, mở lại
    // vẫn còn lịch sử back/forward" — xem `ClosedTabEntry` để biết lưu gì.
    fun getRecentlyClosedTabs(): List<ClosedTabEntry>
    // Mở lại đúng tab đã đóng theo `entryId`, khôi phục ĐẦY ĐỦ lịch sử
    // back/forward (tái dùng `createTabWithState`) — trả `null` nếu
    // `entryId` không còn tồn tại (VD đã mở lại rồi, hoặc bị dọn do vượt
    // giới hạn số lượng lưu). Entry được XOÁ khỏi danh sách ngay khi mở lại
    // thành công (giống Chrome — mở lại rồi thì không còn nằm trong danh
    // sách "đã đóng" nữa, tránh mở trùng nếu bấm lại).
    fun reopenClosedTab(entryId: String): BrowserTab?

    // Drag & drop support
    fun handleDropUri(uri: android.net.Uri, mimeType: String? = null)

    // Media session — nút Play/Pause thật trên thông báo hệ thống, xem
    // GeckoViewEngine.createSession() (session.mediaSessionDelegate) và
    // BackgroundMediaFeature.
    fun getNativeMediaSessionToken(): android.media.session.MediaSession.Token
    var onMediaPlaybackStateListener: ((playing: Boolean) -> Unit)?

    // TÍNH NĂNG MỚI (người dùng yêu cầu) — Tìm trong trang, giống Ctrl+F
    // trên desktop. Dùng API native `GeckoSession.finder` (SessionFinder)
    // của GeckoView thay vì tự inject JS quét DOM — API native tìm/tô
    // sáng đúng NGAY TRONG lớp render thật của Gecko (Gecko compositor),
    // nên luôn khớp chính xác với những gì người dùng đang THẤY trên màn
    // hình (kể cả sau khi zoom/cuộn, kể cả text nằm trong iframe/shadow
    // DOM mà JS injection từ content script khó với tới đầy đủ).
    //
    // callback trả về (currentMatchIndex bắt đầu từ 1, totalMatches) mỗi
    // lần có kết quả tìm mới — dùng để cập nhật UI "3/12" trên thanh tìm
    // kiếm. Nếu totalMatches=0, không tìm thấy gì.
    fun findInPage(query: String, forward: Boolean = true, matchCase: Boolean = false, callback: ((current: Int, total: Int) -> Unit)? = null)
    // TÍNH NĂNG MỚI (người dùng báo bug thật: upload Drive bị "ngủ" khi
    // tắt màn hình dù đã ghim chạy nền) — xem chú thích đầy đủ ở
    // GeckoViewEngine.applyBackgroundPriorityForActiveTabIfExempt(). Gọi
    // từ MainActivity.onPause() (bao trùm cả "tắt màn hình" lẫn "chuyển
    // sang app khác" — 2 kịch bản Android đều gọi onPause() giống nhau,
    // không phân biệt được ở tầng Activity).
    fun applyBackgroundPriorityForActiveTabIfExempt()

    // Xoá highlight tìm kiếm hiện tại (gọi khi đóng thanh tìm kiếm).
    fun clearFindInPage()
}

data class BrowserTab(
    val id: String,
    var url: String = "about:blank",
    var title: String = "",
    var isLoading: Boolean = false,
    var favicon: android.graphics.Bitmap? = null,
    // GeckoSession không có property canGoBack/canGoForward đọc đồng bộ được —
    // API thật chỉ đẩy thay đổi qua NavigationDelegate.onCanGoBack/onCanGoForward,
    // nên phải tự cache lại theo từng tab (xem GeckoViewEngine.createSession()).
    var canGoBack: Boolean = false,
    var canGoForward: Boolean = false,
    // Trạng thái ĐẦY ĐỦ của phiên (lịch sử back/forward, vị trí cuộn, dữ
    // liệu form) — chuỗi trả về từ GeckoSession.SessionState.toString(),
    // xem GeckoViewEngine.onSessionStateChange(). KHÁC với `url`/`title`
    // (chỉ đủ để mở lại đúng trang, không đủ để khôi phục lịch sử/cuộn/form).
    var savedState: String? = null,
    // LAZY RESTORE: tab được tạo metadata nhưng CHƯA load nội dung (xem
    // GeckoViewEngine.createTabLazy() và restoreTabsIfAny()). Session đã
    // open nhưng rỗng — chỉ load thật khi switchToTab() đụng tới lần đầu.
    var isUnloaded: Boolean = false,
    // Chế độ ẨN DANH — dùng đúng API thật của GeckoView
    // (`GeckoSessionSettings.Builder().usePrivateMode(true)`, xem
    // `GeckoViewEngine.createSession()`). Tab ẩn danh KHÔNG được lưu vào
    // lịch sử (`MainActivity` tự kiểm tra cờ này trước khi gọi
    // `recordHistoryVisit`/`updateLastHistoryTitle`) và KHÔNG được khôi
    // phục lại sau khi đóng app (`saveTabsState()` tự bỏ qua các tab có cờ
    // này) — đúng hành vi ẩn danh thật của Chrome.
    var openerTabId: String? = null,
    var isPrivate: Boolean = false,
    // TÍNH NĂNG MỚI (người dùng yêu cầu) — nhóm tab giống Chrome. `null` =
    // không thuộc nhóm nào. Xem `TabGroup` bên dưới cho tên/màu thật của
    // nhóm — chỉ lưu ID ở đây để nhiều tab dùng chung 1 nhóm mà không lặp
    // lại tên/màu.
    var groupId: String? = null
)

/**
 * TÍNH NĂNG MỚI (người dùng yêu cầu) — nhóm tab giống Chrome.
 *
 * BUG THẬT ĐÃ SỬA (người dùng báo: "vuốt tắt app trong Recent Apps thì
 * group tab biến mất luôn", không chỉ "không export/import được"):
 * TRƯỚC ĐÂY danh sách nhóm này CHỈ tồn tại trong RAM (`mutableMapOf` ở
 * `GeckoViewEngine`, không hề có file backing), còn `saveTabsState()`
 * (hàm DUY NHẤT ghi tab xuống đĩa) cũng CHƯA BAO GIỜ ghi kèm `groupId`
 * của từng tab. Hệ quả: bất kỳ lúc nào tiến trình bị hệ thống giết (vuốt
 * tắt Recent Apps là 1 trong số đó, không phải trường hợp duy nhất — mất
 * điện thoại RAM thấp, "buộc dừng" trong Cài đặt... đều gây y hệt), toàn
 * bộ nhóm biến mất ngay lập tức — kể cả khi TAB vẫn được khôi phục lại
 * đúng (vì tab CÓ được lưu file), tab đó khôi phục xong sẽ không thuộc
 * nhóm nào nữa vì thông tin nhóm chưa từng được lưu để khôi phục lại.
 *
 * Đã sửa: `GeckoViewEngine.saveTabsState()` giờ lưu kèm `groupId` của
 * từng tab (nếu có) VÀ toàn bộ danh sách `groups` (id/name/colorHex) vào
 * cùng file `saved_tabs.json` (đổi từ JSONArray trần sang JSONObject bọc
 * `{"tabs": [...], "groups": [...]}`, có fallback đọc được cả file cũ
 * kiểu JSONArray trần để không hỏng dữ liệu tab đã lưu từ bản trước).
 * `restoreTabsIfAny()` khôi phục `groups` TRƯỚC, rồi gán lại `groupId`
 * cho từng tab SAU khi tạo — nhóm giờ sống sót qua mọi lần tắt/mở app,
 * y như tab thường.
 */
data class TabGroup(val id: String, var name: String, val colorHex: String)

/**
 * TÍNH NĂNG MỚI (người dùng yêu cầu): "thẻ đã đóng gần đây, khi mở lại vẫn
 * còn lịch sử back/forward đằng sau nó" — trước đây `closeTab()` xoá thẳng
 * `tabMeta` (bao gồm `savedState`) mà không lưu lại đâu cả, đóng xong là
 * MẤT VĨNH VIỄN, không có cách nào lấy lại. `savedState` ở đây CHÍNH LÀ
 * chuỗi `GeckoSession.SessionState` đầy đủ (đã có sẵn cơ chế cập nhật liên
 * tục qua `onSessionStateChange`, dùng cho tính năng khôi phục tab lúc mở
 * lại app) — tái dùng ĐÚNG cơ chế đó cho tab vừa đóng, không cần xây lại
 * từ đầu. Chỉ giữ trong RAM (mất khi tắt hẳn app) — xem giải thích phạm vi
 * ở PROJECT_STATUS.md mục 73.
 */
data class ClosedTabEntry(
    val entryId: String,
    val url: String,
    val title: String,
    val savedState: String?,
    val closedAtMillis: Long
)


