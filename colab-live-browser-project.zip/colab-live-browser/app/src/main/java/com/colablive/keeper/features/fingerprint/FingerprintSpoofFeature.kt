package com.colablive.keeper.features.fingerprint

import android.content.Context
import android.content.ComponentName
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.widget.*
import com.colablive.keeper.core.*
import com.colablive.keeper.core.proxy.ProxyHealthChecker
import com.colablive.keeper.core.proxy.ProxyScraper

/**
 * Feature cấu hình fingerprint spoof + proxy + auto behavior per slot.
 */
object FingerprintSpoofFeature : BrowserFeature {
    override val id = "fingerprint_spoof"
    override val displayName = "🎭 Fingerprint Spoof"
    override val description = "Giả lập thông số phần cứng, proxy, timezone, và vân tay trình duyệt"

    override fun isEnabled(context: Context, slotIndex: Int): Boolean =
        AppPrefs.getBoolean(context, slotIndex, id, "enabled", false)

    override fun setEnabled(context: Context, slotIndex: Int, enabled: Boolean) =
        AppPrefs.setBoolean(context, slotIndex, id, "enabled", enabled)

    /**
     * BUG THẬT (người dùng phản ánh — chụp màn hình cho thấy các đoạn giải
     * thích dài tràn lan khắp màn hình cài đặt): các TextView giải thích dài
     * trước đây hiển thị LUÔN, không ẩn được — người dùng đã yêu cầu việc
     * này TRƯỚC ĐÓ ("mấy cái giải thích sao ko để nó ẩn đi trong cái dấu
     * chấm hỏi Icon") nhưng chưa từng được làm. Thay toàn bộ đoạn giải thích
     * dài bằng 1 dòng "ℹ️ ... (chạm để xem)" ngắn, bấm vào mới hiện full text
     * qua AlertDialog.
     */
    private fun addHelpRow(context: Context, layout: LinearLayout, shortLabel: String, fullText: String) {
        layout.addView(TextView(context).apply {
            text = "ℹ️ $shortLabel (chạm để xem giải thích)"
            textSize = 12f
            setTextColor(android.graphics.Color.parseColor("#1976D2"))
            setPadding(0, 8, 0, 8)
            setOnClickListener {
                android.app.AlertDialog.Builder(context)
                    .setTitle(shortLabel)
                    .setMessage(fullText)
                    .setPositiveButton("Đã hiểu", null)
                    .show()
            }
        })
    }

    override fun buildSettingsView(context: Context, slotIndex: Int): android.view.View {
        val scroll = ScrollView(context)
        val layout = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 32, 32, 32)
        }

        // --- Fingerprint Toggle ---
        val enabledSwitch = Switch(context).apply {
            text = "Bật Fingerprint Spoof"
            isChecked = isEnabled(context, slotIndex)
            setOnCheckedChangeListener { _, checked ->
                setEnabled(context, slotIndex, checked)
                android.widget.Toast.makeText(
                    context,
                    "⚠️ Đã lưu — nhưng KHÔNG áp dụng cho tab đang mở sẵn. UA/fingerprint " +
                        "được gán CỐ ĐỊNH lúc tạo tab, không đổi được giữa chừng. Đóng " +
                        "HẲN và mở lại khe này (không phải chỉ mở tab mới) để có tác dụng.",
                    android.widget.Toast.LENGTH_LONG
                ).show()
            }
        }
        layout.addView(enabledSwitch)

        // --- Lock Mode ---
        // BUG THẬT (lịch sử phiên trước KỂ LẠI là đã xoá `fp_lock` vì công tắc
        // này chỉ được LƯU, KHÔNG hề được đọc/dùng ở bất kỳ đâu khác trong
        // code — thuần trang trí, gây hiểu lầm là "khoá cứng theo slot" trong
        // khi bản chất `AppPrefs` luôn khoá theo TÊN HỒ SƠ cho mọi key kể cả
        // key này — nhưng việc xoá đó KHÔNG hề có trong code thật, chỉ có
        // trong lời kể. Xoá đúng lại lần này, thay bằng dòng chữ giải thích
        // sự thật, đúng như đã xác nhận trước đó (KHÔNG đoán lại từ đầu).
        layout.addView(TextView(context).apply {
            text = "ℹ️ Khoá vân tay hoạt động theo HỒ SƠ (Hardware Profile) đã " +
                "chọn ở trên — cùng hồ sơ luôn ra cùng 1 fingerprint, không " +
                "phụ thuộc số khe. Muốn đổi ngẫu nhiên, dùng công tắc " +
                "\"Đổi mới mỗi lần mở\" bên dưới."
            textSize = 12f
            setPadding(0, 8, 0, 8)
        })
        // --- Fresh Mode ---
        val freshSwitch = Switch(context).apply {
            text = "⚠️ Đổi mới mỗi lần mở (CÓ THỂ GÂY NGHI NGỜ)"
            isChecked = AppPrefs.getBoolean(context, slotIndex, "fp_fresh", false)
            setTextColor(android.graphics.Color.RED)
            setOnCheckedChangeListener { _, checked ->
                AppPrefs.setBoolean(context, slotIndex, "fp_fresh", checked)
            }
        }
        layout.addView(freshSwitch)

        // --- Auto Behavior ---
        val behaviorSwitch = Switch(context).apply {
            text = "🤖 Auto Behavior (giả lập người dùng)"
            isChecked = AppPrefs.getBoolean(context, slotIndex, "auto_behavior", false)
            setOnCheckedChangeListener { _, checked ->
                AppPrefs.setBoolean(context, slotIndex, "auto_behavior", checked)
            }
        }
        layout.addView(behaviorSwitch)

        // --- Hardware Preset ---
        layout.addView(TextView(context).apply { text = "Hardware Profile:"; textSize = 16f })
        addHelpRow(
            context, layout, "Hồ sơ desktop hoạt động thế nào?",
            "Hồ sơ desktop dùng chế độ Desktop Site THẬT của GeckoView " +
                "(viewport CSS 980px, giống 'Yêu cầu trang web dành cho máy tính' trên " +
                "trình duyệt di động thật) — layout trang RENDER THẬT theo desktop, không " +
                "chỉ nói dối 1 con số JS. Nhưng KHÔNG hoàn hảo: 980px CSS vẫn khác đúng " +
                "1920/2560 của hồ sơ đã chọn, và pixel vật lý hiển thị ra vẫn là màn hình " +
                "điện thoại — đây là giới hạn của việc dùng 1 thiết bị thật để giả nhiều " +
                "loại máy, không sửa hết bằng code được."
        )
        val hwSpinner = Spinner(context).apply {
            val profiles = DeviceProfiles.hardwareProfiles
            adapter = ArrayAdapter(context, android.R.layout.simple_spinner_item, profiles.map { it.name }).apply {
                setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            }
            val profileName = ProfileSlots.getSlotAssignment(context, slotIndex)
            setSelection(AppPrefs.getInt(context, slotIndex, "fp_hw_idx", DeviceProfiles.defaultHwIndexForProfile(profileName)))
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                    AppPrefs.setInt(context, slotIndex, "fp_hw_idx", position)
                }
                override fun onNothingSelected(parent: AdapterView<*>?) {}
            }
        }
        layout.addView(hwSpinner)

        // --- Ngoại lệ: giữ layout mobile CHO 1 SỐ TÊN MIỀN CỤ THỂ ---
        // Người dùng chủ đích yêu cầu: mặc định VẪN giữ fingerprint nhất
        // quán ở MỌI trang (không đầu voi đuôi chuột) — ngoại lệ chỉ áp
        // dụng cho ĐÚNG tên miền người dùng tự liệt kê (VD trang phát
        // nhạc/video), không ảnh hưởng các trang khác trong cùng khe.
        layout.addView(TextView(context).apply {
            text = "⚠️ Ngoại lệ layout mobile (cho tên miền cụ thể)"
            textSize = 13f
            setTextColor(android.graphics.Color.parseColor("#F57C00"))
            setPadding(0, 8, 0, 0)
        })
        addHelpRow(
            context, layout, "Ngoại lệ layout mobile hoạt động thế nào?",
            "Giữ layout MOBILE (dù hồ sơ đang chọn là desktop) — CHỈ áp dụng " +
                "cho tên miền liệt kê dưới đây, mỗi dòng/phẩy 1 tên miền (VD: " +
                "youtube.com). Các trang KHÁC vẫn ép desktop đầy đủ như bình " +
                "thường — không đổi. Mục đích: trang vẫn chọn PLAYER kiểu " +
                "desktop (VD YouTube không tự tắt nhạc khi ẩn trang) nhưng bố " +
                "cục hiện mobile dễ dùng. ĐÁNH ĐỔI: riêng tên miền này, UA " +
                "khai desktop mà layout hiện mobile là 1 điểm BẤT NHẤT có thể " +
                "bị soi — người dùng tự chịu rủi ro CÓ CHỦ ĐÍCH, chỉ cho tên " +
                "miền đã liệt kê."
        )
        val domainExceptionInput = EditText(context).apply {
            hint = "youtube.com, m.youtube.com"
            setText(AppPrefs.getString(context, slotIndex, "fp_desktop_skip_viewport_domains", ""))
            setSingleLine(false)
        }
        layout.addView(domainExceptionInput)
        layout.addView(android.widget.Button(context).apply {
            text = "Lưu danh sách ngoại lệ"
            setOnClickListener {
                AppPrefs.setString(context, slotIndex, "fp_desktop_skip_viewport_domains", domainExceptionInput.text.toString())
                // Áp dụng lại NGAY cho tab đang mở — không đợi lần điều
                // hướng tiếp theo mới có tác dụng (xem
                // `applyExceptionAndReloadActiveTab()` trong GeckoViewEngine).
                com.colablive.keeper.core.GeckoViewEngine.forSlot(slotIndex)?.applyExceptionAndReloadActiveTab()
            }
        })

        // --- Locale Preset ---
        layout.addView(TextView(context).apply { text = "Locale Profile:"; textSize = 16f })
        val localeSpinner = Spinner(context).apply {
            val profiles = DeviceProfiles.localeProfiles
            adapter = ArrayAdapter(context, android.R.layout.simple_spinner_item, profiles.map { it.name }).apply {
                setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            }
            val profileNameForLocale = ProfileSlots.getSlotAssignment(context, slotIndex)
            setSelection(AppPrefs.getInt(context, slotIndex, "fp_locale_idx", DeviceProfiles.defaultLocaleIndexForProfile(profileNameForLocale)))
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                    AppPrefs.setInt(context, slotIndex, "fp_locale_idx", position)
                    // Tự động set timezone từ locale
                    val tz = DeviceProfiles.localeProfiles.getOrNull(position)?.timezone ?: "UTC"
                    AppPrefs.setString(context, slotIndex, "fp_timezone", tz)
                }
                override fun onNothingSelected(parent: AdapterView<*>?) {}
            }
        }
        layout.addView(localeSpinner)

        // --- Từng kỹ thuật giả lập (bật/tắt riêng) ---
        layout.addView(TextView(context).apply {
            text = "\nKỹ thuật giả lập (bật/tắt riêng từng cái):"
            textSize = 16f
        })
        val techniqueKeys = listOf(
            "fp_t_canvas" to "Canvas fingerprint (thêm nhiễu ảnh canvas)",
            "fp_t_audio" to "Audio fingerprint (thêm nhiễu AudioContext)",
            "fp_t_font" to "Font enumeration (giả danh sách font hệ thống)",
            "fp_t_webrtc" to "Chặn WebRTC (chống lộ IP thật qua STUN)"
        )
        addHelpRow(
            context, layout, "Vì sao không tắt riêng User-Agent được?",
            "User-Agent LUÔN đồng bộ theo Hardware Profile ở trên — không cho " +
                "tắt riêng, vì Platform+GPU giả nhưng UA thật là mâu thuẫn dễ bị " +
                "phát hiện nhất, không có tổ hợp nào hợp lệ khi tách 2 cái này ra."
        )
        techniqueKeys.forEach { (key, label) ->
            layout.addView(Switch(context).apply {
                text = label
                isChecked = AppPrefs.getBoolean(context, slotIndex, key, true)
                setOnCheckedChangeListener { _, checked ->
                    AppPrefs.setBoolean(context, slotIndex, key, checked)
                }
            })
        }

        // --- Proxy Config ---
        layout.addView(TextView(context).apply {
            text = "\nProxy per Slot (đổi IP):"
            textSize = 18f
            setTextColor(android.graphics.Color.parseColor("#FF6B00"))
        })

        layout.addView(TextView(context).apply {
            text = "⚠️ Proxy miễn phí có RỦI RO — không dùng để đăng nhập tài khoản quan trọng"
            setTextColor(android.graphics.Color.parseColor("#D32F2F"))
            textSize = 12f
            setPadding(0, 8, 0, 0)
        })
        addHelpRow(
            context, layout, "Chi tiết Proxy per Slot",
            "Đã hỗ trợ thật qua WebExtension Proxy API (browser.proxy.onRequest) — " +
                "khác cách cũ (GeckoRuntimeSettings.arguments()) đã xác nhận không hoạt động. " +
                "Cần khởi động lại khe để áp dụng.\n\n" +
                "Rủi ro thật với proxy miễn phí (cào tự động bên dưới): có thể log lại " +
                "traffic, chèn quảng cáo, hoặc là honeypot — không dùng để đăng nhập tài khoản " +
                "quan trọng hay gửi dữ liệu nhạy cảm qua proxy loại này."
        )

        val proxyTypeSpinner = Spinner(context).apply {
            val types = listOf("Direct (không proxy)", "HTTP Proxy", "SOCKS5 Proxy")
            adapter = ArrayAdapter(context, android.R.layout.simple_spinner_item, types).apply {
                setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            }
            setSelection(AppPrefs.getInt(context, slotIndex, "proxy_type", 0))
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                    AppPrefs.setInt(context, slotIndex, "proxy_type", position)
                }
                override fun onNothingSelected(parent: AdapterView<*>?) {}
            }
        }
        layout.addView(proxyTypeSpinner)

        val proxyHost = EditText(context).apply {
            hint = "Proxy Host (vd: 192.168.1.1)"
            setText(AppPrefs.getString(context, slotIndex, "proxy_host", ""))
        }
        layout.addView(proxyHost)

        val proxyPort = EditText(context).apply {
            hint = "Proxy Port (vd: 8080)"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setText(AppPrefs.getString(context, slotIndex, "proxy_port", ""))
        }
        layout.addView(proxyPort)

        val proxyUser = EditText(context).apply {
            hint = "Proxy Username (nếu có)"
            setText(AppPrefs.getString(context, slotIndex, "proxy_user", ""))
        }
        layout.addView(proxyUser)

        val proxyPass = EditText(context).apply {
            hint = "Proxy Password (nếu có)"
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(AppPrefs.getString(context, slotIndex, "proxy_pass", ""))
        }
        layout.addView(proxyPass)

        val saveProxyBtn = Button(context).apply {
            text = "Lưu Proxy Config"
            setOnClickListener {
                AppPrefs.setString(context, slotIndex, "proxy_host", proxyHost.text.toString())
                AppPrefs.setString(context, slotIndex, "proxy_port", proxyPort.text.toString())
                AppPrefs.setString(context, slotIndex, "proxy_user", proxyUser.text.toString())
                AppPrefs.setString(context, slotIndex, "proxy_pass", proxyPass.text.toString())
                android.widget.Toast.makeText(context, "Proxy đã lưu!", android.widget.Toast.LENGTH_SHORT).show()
            }
        }
        layout.addView(saveProxyBtn)

        // --- Tự động tìm proxy miễn phí nhanh nhất còn sống ---
        val autoFindStatus = TextView(context).apply {
            text = ""
            setPadding(0, 4, 0, 4)
        }
        val autoFindBtn = Button(context).apply {
            text = "🔍 Tự động tìm proxy nhanh nhất"
            setOnClickListener {
                isEnabled = false
                autoFindStatus.text = "Đang cào danh sách proxy..."
                Thread {
                    val allCandidates = ProxyScraper.fetchCandidates()
                    val mainHandler = Handler(Looper.getMainLooper())
                    if (allCandidates.isEmpty()) {
                        mainHandler.post {
                            autoFindStatus.text = "❌ Không lấy được danh sách proxy (kiểm tra mạng, xem Debug Log)"
                            isEnabled = true
                        }
                        return@Thread
                    }
                    // Loại các proxy đang bị KHE KHÁC dùng trước khi tìm nhanh
                    // nhất — nếu không, 4 khe cùng bấm nút gần nhau rất dễ
                    // trùng ra cùng 1 IP (xem ProfileSlots.proxiesInUseByOtherSlots).
                    val takenByOthers = ProfileSlots.proxiesInUseByOtherSlots(context, slotIndex)
                    val filtered = allCandidates.filter { (it.host to it.port) !in takenByOthers }
                    val excludedCount = allCandidates.size - filtered.size
                    // Mọi ứng viên đều đã bị khe khác chiếm (danh sách cào được
                    // quá ngắn so với số khe) — thà vẫn tìm trong toàn bộ danh
                    // sách (chấp nhận rủi ro trùng) còn hơn báo lỗi không tìm
                    // được gì, nhưng phải CẢNH BÁO rõ cho người dùng biết.
                    val usedFallback = filtered.isEmpty() && excludedCount > 0
                    val candidates = if (filtered.isEmpty()) allCandidates else filtered
                    mainHandler.post {
                        autoFindStatus.text = when {
                            usedFallback -> "⚠️ Cả ${excludedCount} proxy cào được đều đang bị khe khác dùng — " +
                                "vẫn tìm trong toàn bộ danh sách nhưng CÓ THỂ trùng IP với khe khác. " +
                                "Đang kiểm tra ${candidates.size} proxy..."
                            excludedCount > 0 -> "Đang kiểm tra ${candidates.size} proxy (đã loại $excludedCount proxy khe khác đang dùng) — có thể mất 1-2 phút..."
                            else -> "Đang kiểm tra ${candidates.size} proxy — có thể mất 1-2 phút..."
                        }
                    }
                    val best = ProxyHealthChecker.findFastestAlive(candidates) { checked, total ->
                        mainHandler.post {
                            autoFindStatus.text = "Đang kiểm tra... $checked/$total"
                        }
                    }
                    mainHandler.post {
                        isEnabled = true
                        if (best == null) {
                            autoFindStatus.text = "❌ Không tìm được proxy nào còn sống trong danh sách cào được — thử lại sau (danh sách proxy free thường đổi liên tục)"
                        } else {
                            val c = best.candidate
                            proxyHost.setText(c.host)
                            proxyPort.setText(c.port.toString())
                            AppPrefs.setString(context, slotIndex, "proxy_host", c.host)
                            AppPrefs.setString(context, slotIndex, "proxy_port", c.port.toString())
                            AppPrefs.setInt(context, slotIndex, "proxy_type", if (c.type == "socks") 2 else 1)
                            if (usedFallback) {
                                Toast.makeText(context, "⚠️ Lưu ý: proxy này CÓ THỂ trùng với khe khác (không đủ proxy dự phòng lúc tìm)", Toast.LENGTH_LONG).show()
                            }
                            autoFindStatus.text = "✅ Đã chọn ${c.host}:${c.port} (${c.type}, ${best.latencyMs}ms) — đã tự lưu, cần khởi động lại khe để áp dụng"
                            Toast.makeText(context, "Đã tìm và lưu proxy nhanh nhất: ${c.host}:${c.port}", Toast.LENGTH_LONG).show()
                        }
                    }
                }.start()
            }
        }
        layout.addView(autoFindBtn)
        layout.addView(autoFindStatus)

        // --- Apply Button ---
        val applyBtn = Button(context).apply {
            text = "Áp dụng Fingerprint (tự khởi động lại khe)"
            setOnClickListener {
                applyFingerprint(context, slotIndex)
                restartThisSlot(context, slotIndex)
            }
        }
        layout.addView(applyBtn)

        scroll.addView(layout)
        return scroll
    }

    /**
     * Đóng hẳn tiến trình khe này rồi mở lại — cách DUY NHẤT chắc chắn áp
     * dụng fingerprint/UA mới (xem giải thích ở PROJECT_STATUS.md mục
     * "Lượt 13": cấu hình được gán cố định lúc tạo GeckoSession, không đổi
     * được giữa chừng dù đổi setting hay tải lại trang).
     */
    private fun restartThisSlot(context: Context, slotIndex: Int) {
        val className = ProfileSlots.componentClassNameForSlot(slotIndex)
        val intent = Intent().apply {
            component = ComponentName(context.packageName, className)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        }
        Toast.makeText(context, "Đang khởi động lại khe $slotIndex để áp dụng fingerprint mới...", Toast.LENGTH_SHORT).show()
        context.startActivity(intent)
        // Đợi 1 chút để hệ thống kịp nhận Intent trước khi tự kết liễu tiến
        // trình hiện tại — giống hệt cách ProfilePickerActivity.restartSlot()
        // đã làm cho khe 0.
        Handler(Looper.getMainLooper()).postDelayed({
            Runtime.getRuntime().exit(0)
        }, 300)
    }

    private fun applyFingerprint(context: Context, slotIndex: Int) {
        val profileName = ProfileSlots.getSlotAssignment(context, slotIndex)
        val hwIdx = AppPrefs.getInt(context, slotIndex, "fp_hw_idx", DeviceProfiles.defaultHwIndexForProfile(profileName))
        val localeIdx = AppPrefs.getInt(context, slotIndex, "fp_locale_idx", DeviceProfiles.defaultLocaleIndexForProfile(profileName))
        val hw = DeviceProfiles.hardwareProfiles.getOrNull(hwIdx) ?: DeviceProfiles.hardwareProfiles.first()
        val locale = DeviceProfiles.localeProfiles.getOrNull(localeIdx) ?: DeviceProfiles.localeProfiles.first()

        // Tự động sync timezone với locale
        AppPrefs.setString(context, slotIndex, "fp_timezone", locale.timezone)

        DebugLog.log("Slot $slotIndex fingerprint: ${hw.name} + ${locale.name} (tz=${locale.timezone})")
        android.widget.Toast.makeText(
            context,
            "Đã lưu: ${hw.name} + ${locale.name}",
            android.widget.Toast.LENGTH_SHORT
        ).show()
    }

}
