package com.colablive.keeper.features.fingerprint

import android.content.Context
import android.view.View
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import com.colablive.keeper.core.AppPrefs
import com.colablive.keeper.core.BrowserEngine
import com.colablive.keeper.core.BrowserFeature
import org.json.JSONObject

/**
 * Giả canvas/WebGL/hardwareConcurrency/deviceMemory. Nhận cấu hình THẬT (đã
 * chọn từng tín hiệu bật/tắt gì, chế độ Random/Chỉ định) qua native port —
 * xem GeckoViewEngine.kt (pushFingerprintConfig) và assets/fingerprint_spoof/.
 *
 * QUAN TRỌNG: đổi cài đặt CẦN KHỞI ĐỘNG LẠI khe này mới có hiệu lực đầy đủ —
 * vì extension chỉ được đăng ký (hoặc không) 1 lần lúc GeckoRuntime khởi tạo
 * (xem GeckoRuntimeProvider.kt).
 */
object FingerprintSpoofFeature : BrowserFeature {

    override val id = "fingerprint_spoof"
    override val displayName = "Fingerprint Spoof"
    override val description =
        "Giả canvas/WebGL/hardwareConcurrency/deviceMemory để giảm liên kết đa tài khoản giữa các khe. " +
            "CHƯA che: rò IP qua WebRTC, audio fingerprint, font cài sẵn, timezone/locale."

    const val MODE_RANDOM = "random"
    const val MODE_MANUAL = "manual"

    private const val KEY_ENABLED = "enabled"
    private const val KEY_MODE = "mode"
    private const val KEY_SPOOF_CANVAS = "spoof_canvas"
    private const val KEY_SPOOF_WEBGL = "spoof_webgl"
    private const val KEY_SPOOF_HWC = "spoof_hwc"
    private const val KEY_SPOOF_MEM = "spoof_mem"
    private const val KEY_SEED = "seed"
    private const val KEY_MANUAL_WEBGL_INDEX = "manual_webgl_index"
    private const val KEY_MANUAL_HWC_INDEX = "manual_hwc_index"
    private const val KEY_MANUAL_MEM_INDEX = "manual_mem_index"

    // Danh sách preset — chọn từ đây (Chỉ định) thay vì gõ tự do, tránh giá
    // trị vô nghĩa/dễ bị phát hiện hơn cả việc không giả (vd renderer lạ đời).
    val WEBGL_PRESETS = listOf(
        "Intel Inc." to "Intel Iris OpenGL Engine",
        "NVIDIA Corporation" to "NVIDIA GeForce GTX 1660/PCIe/SSE2",
        "AMD" to "AMD Radeon RX 580 Series",
        "Google Inc. (Intel)" to "ANGLE (Intel, Intel(R) UHD Graphics 620, OpenGL 4.5)",
        "Apple Inc." to "Apple M1"
    )
    val HWC_PRESETS = listOf(2, 4, 6, 8, 12, 16)
    val MEM_PRESETS = listOf(2, 4, 8, 16)

    override fun isEnabled(context: Context, slotIndex: Int): Boolean =
        AppPrefs.getBoolean(context, slotIndex, id, KEY_ENABLED, true)

    override fun setEnabled(context: Context, slotIndex: Int, enabled: Boolean) {
        AppPrefs.setBoolean(context, slotIndex, id, KEY_ENABLED, enabled)
    }

    override fun matchesUrl(url: String?): Boolean = true
    override fun onPageFinished(context: Context, slotIndex: Int, engine: BrowserEngine, url: String?) {}
    override fun onTick(context: Context, slotIndex: Int, engine: BrowserEngine, url: String?) {}

    /** Seed riêng BỀN VỮNG theo từng khe — sinh 1 lần, lưu lại, dùng cho chế độ Random. */
    private fun getOrCreateSeed(context: Context, slotIndex: Int): Int {
        val existing = AppPrefs.getInt(context, slotIndex, id, KEY_SEED, -1)
        if (existing != -1) return existing
        val newSeed = (0..999_999).random()
        AppPrefs.setInt(context, slotIndex, id, KEY_SEED, newSeed)
        return newSeed
    }

    /**
     * Tính cấu hình THẬT để gửi xuống content script qua port — gọi từ
     * GeckoViewEngine lúc port fingerprint_spoof vừa connect.
     */
    fun buildConfigJson(context: Context, slotIndex: Int): JSONObject {
        val mode = AppPrefs.getString(context, slotIndex, id, KEY_MODE, MODE_RANDOM)
        val rnd = java.util.Random(getOrCreateSeed(context, slotIndex).toLong())

        val webglIndex: Int
        val hwcIndex: Int
        val memIndex: Int
        if (mode == MODE_MANUAL) {
            webglIndex = AppPrefs.getInt(context, slotIndex, id, KEY_MANUAL_WEBGL_INDEX, 0)
            hwcIndex = AppPrefs.getInt(context, slotIndex, id, KEY_MANUAL_HWC_INDEX, 1)
            memIndex = AppPrefs.getInt(context, slotIndex, id, KEY_MANUAL_MEM_INDEX, 1)
        } else {
            // Random nhưng ỔN ĐỊNH theo seed riêng khe — cùng 1 khe luôn ra
            // cùng giá trị qua các lần mở lại (không đổi liên tục gây bất
            // thường), nhưng KHÁC giữa các khe khác nhau.
            webglIndex = rnd.nextInt(WEBGL_PRESETS.size)
            hwcIndex = rnd.nextInt(HWC_PRESETS.size)
            memIndex = rnd.nextInt(MEM_PRESETS.size)
        }

        val webgl = WEBGL_PRESETS[webglIndex.coerceIn(WEBGL_PRESETS.indices)]
        return JSONObject().apply {
            put("canvas", AppPrefs.getBoolean(context, slotIndex, id, KEY_SPOOF_CANVAS, true))
            put("webgl", AppPrefs.getBoolean(context, slotIndex, id, KEY_SPOOF_WEBGL, true))
            put("webglVendor", webgl.first)
            put("webglRenderer", webgl.second)
            put("hardwareConcurrency", AppPrefs.getBoolean(context, slotIndex, id, KEY_SPOOF_HWC, true))
            put("hardwareConcurrencyValue", HWC_PRESETS[hwcIndex.coerceIn(HWC_PRESETS.indices)])
            put("deviceMemory", AppPrefs.getBoolean(context, slotIndex, id, KEY_SPOOF_MEM, true))
            put("deviceMemoryValue", MEM_PRESETS[memIndex.coerceIn(MEM_PRESETS.indices)])
        }
    }

    override fun buildSettingsView(context: Context, slotIndex: Int): View {
        val padding = (16 * context.resources.displayMetrics.density).toInt()
        // QUAN TRỌNG: không dùng "id" trực tiếp bên trong các khối
        // Xxx(context).apply { ... } bên dưới — "id" ở đó bị Kotlin hiểu
        // nhầm thành View.id (Int, thuộc tính có sẵn của Android View) do
        // "apply" đổi receiver, không phải FingerprintSpoofFeature.id
        // (String) như ý muốn. Gán ra biến riêng để tránh mơ hồ hoàn toàn.
        val featureId = id

        val enableSwitch = Switch(context).apply {
            text = "Bật $displayName"
            isChecked = isEnabled(context, slotIndex)
            setOnCheckedChangeListener { _, checked -> setEnabled(context, slotIndex, checked) }
        }

        val canvasSwitch = Switch(context).apply {
            text = "Giả canvas fingerprint"
            isChecked = AppPrefs.getBoolean(context, slotIndex, featureId, KEY_SPOOF_CANVAS, true)
            setOnCheckedChangeListener { _, c -> AppPrefs.setBoolean(context, slotIndex, featureId, KEY_SPOOF_CANVAS, c) }
        }
        val webglSwitch = Switch(context).apply {
            text = "Giả WebGL vendor/renderer"
            isChecked = AppPrefs.getBoolean(context, slotIndex, featureId, KEY_SPOOF_WEBGL, true)
            setOnCheckedChangeListener { _, c -> AppPrefs.setBoolean(context, slotIndex, featureId, KEY_SPOOF_WEBGL, c) }
        }
        val hwcSwitch = Switch(context).apply {
            text = "Giả số nhân CPU (hardwareConcurrency)"
            isChecked = AppPrefs.getBoolean(context, slotIndex, featureId, KEY_SPOOF_HWC, true)
            setOnCheckedChangeListener { _, c -> AppPrefs.setBoolean(context, slotIndex, featureId, KEY_SPOOF_HWC, c) }
        }
        val memSwitch = Switch(context).apply {
            text = "Giả dung lượng RAM (deviceMemory)"
            isChecked = AppPrefs.getBoolean(context, slotIndex, featureId, KEY_SPOOF_MEM, true)
            setOnCheckedChangeListener { _, c -> AppPrefs.setBoolean(context, slotIndex, featureId, KEY_SPOOF_MEM, c) }
        }

        val currentMode = AppPrefs.getString(context, slotIndex, featureId, KEY_MODE, MODE_RANDOM)
        val modeGroup = RadioGroup(context).apply { orientation = RadioGroup.VERTICAL }
        val randomRadio = RadioButton(context).apply {
            id = 3001
            text = "Ngẫu nhiên — cố định riêng theo khe này (khác khe khác, không đổi qua các lần mở lại)"
        }
        val manualRadio = RadioButton(context).apply {
            id = 3002
            text = "Chỉ định cụ thể — tự chọn từ danh sách bên dưới"
        }
        modeGroup.addView(randomRadio)
        modeGroup.addView(manualRadio)
        modeGroup.check(if (currentMode == MODE_MANUAL) 3002 else 3001)

        val webglSpinner = Spinner(context).apply {
            adapter = ArrayAdapter(
                context, android.R.layout.simple_spinner_dropdown_item,
                WEBGL_PRESETS.map { "${it.first} — ${it.second}" }
            )
            setSelection(AppPrefs.getInt(context, slotIndex, featureId, KEY_MANUAL_WEBGL_INDEX, 0))
        }
        val hwcSpinner = Spinner(context).apply {
            adapter = ArrayAdapter(
                context, android.R.layout.simple_spinner_dropdown_item,
                HWC_PRESETS.map { "$it nhân" }
            )
            setSelection(AppPrefs.getInt(context, slotIndex, featureId, KEY_MANUAL_HWC_INDEX, 1))
        }
        val memSpinner = Spinner(context).apply {
            adapter = ArrayAdapter(
                context, android.R.layout.simple_spinner_dropdown_item,
                MEM_PRESETS.map { "$it GB" }
            )
            setSelection(AppPrefs.getInt(context, slotIndex, featureId, KEY_MANUAL_MEM_INDEX, 1))
        }

        val saveButton = android.widget.Button(context).apply {
            text = "Lưu"
            setOnClickListener {
                val mode = if (modeGroup.checkedRadioButtonId == 3002) MODE_MANUAL else MODE_RANDOM
                AppPrefs.setString(context, slotIndex, featureId, KEY_MODE, mode)
                AppPrefs.setInt(context, slotIndex, featureId, KEY_MANUAL_WEBGL_INDEX, webglSpinner.selectedItemPosition)
                AppPrefs.setInt(context, slotIndex, featureId, KEY_MANUAL_HWC_INDEX, hwcSpinner.selectedItemPosition)
                AppPrefs.setInt(context, slotIndex, featureId, KEY_MANUAL_MEM_INDEX, memSpinner.selectedItemPosition)
                Toast.makeText(
                    context,
                    "Đã lưu — khởi động lại app để áp dụng (đóng hẳn app rồi mở lại)",
                    Toast.LENGTH_LONG
                ).show()
            }
        }

        val restartNote = TextView(context).apply {
            text = "⚠ Mọi thay đổi ở màn hình này CẦN khởi động lại khe (đóng hẳn app, mở lại) " +
                "mới có hiệu lực — không áp dụng ngay giữa phiên."
        }

        return LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(padding, padding, padding, padding)
            addView(TextView(context).apply { text = description })
            addView(enableSwitch)
            addView(TextView(context).apply { text = "\nTín hiệu muốn giả:" })
            addView(canvasSwitch)
            addView(webglSwitch)
            addView(hwcSwitch)
            addView(memSwitch)
            addView(TextView(context).apply { text = "\nChế độ:" })
            addView(modeGroup)
            addView(TextView(context).apply { text = "\nGiá trị dùng khi chọn \"Chỉ định cụ thể\":" })
            addView(TextView(context).apply { text = "WebGL vendor/renderer:" })
            addView(webglSpinner)
            addView(TextView(context).apply { text = "Số nhân CPU:" })
            addView(hwcSpinner)
            addView(TextView(context).apply { text = "Dung lượng RAM:" })
            addView(memSpinner)
            addView(saveButton)
            addView(restartNote)
        }
    }
}
