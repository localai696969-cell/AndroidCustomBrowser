package com.colablive.keeper.features.fingerprint

import android.content.Context
import android.view.View
import android.widget.*
import com.colablive.keeper.core.AppPrefs
import com.colablive.keeper.core.BrowserFeature
import com.colablive.keeper.core.DebugLog

class FingerprintSpoofFeature : BrowserFeature {

    override val id = "fingerprint_spoof"
    override val displayName = "Fingerprint Spoof"
    override val description = "Gia lap thong tin thiet bi de tranh tracking"

    companion object {
        private const val KEY_ENABLED = "enabled"
        private const val KEY_HW_PROFILE = "hw_profile"
        private const val KEY_LOCALE_PROFILE = "locale_profile"
    }

    override fun isEnabled(context: Context, slotIndex: Int) =
        AppPrefs.getBoolean(context, slotIndex, id, KEY_ENABLED, false)

    override fun setEnabled(context: Context, slotIndex: Int, enabled: Boolean) =
        AppPrefs.setBoolean(context, slotIndex, id, KEY_ENABLED, enabled)

    fun getHardwareProfile(context: Context, slotIndex: Int): String =
        AppPrefs.getString(context, slotIndex, id, KEY_HW_PROFILE, "default")

    fun setHardwareProfile(context: Context, slotIndex: Int, profile: String) =
        AppPrefs.setString(context, slotIndex, id, KEY_HW_PROFILE, profile)

    fun getLocaleProfile(context: Context, slotIndex: Int): String =
        AppPrefs.getString(context, slotIndex, id, KEY_LOCALE_PROFILE, "default")

    fun setLocaleProfile(context: Context, slotIndex: Int, profile: String) =
        AppPrefs.setString(context, slotIndex, id, KEY_LOCALE_PROFILE, profile)

    override fun onPageLoaded(context: Context, slotIndex: Int, url: String) {
        if (!isEnabled(context, slotIndex)) return
        val hwProfile = getHardwareProfile(context, slotIndex)
        val localeProfile = getLocaleProfile(context, slotIndex)
        DebugLog.log("Fingerprint spoof: hw=$hwProfile, locale=$localeProfile for slot $slotIndex")
    }

    override fun onPageLoadError(context: Context, slotIndex: Int, url: String, errorCode: Int) {}
    override fun onDropFile(context: Context, slotIndex: Int, uri: android.net.Uri, mimeType: String?) {}

    override fun buildSettingsView(context: Context, slotIndex: Int): View {
        val container = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 16, 16, 16)
        }

        val switch = Switch(context)
        switch.text = "Bat Fingerprint Spoof"
        switch.isChecked = isEnabled(context, slotIndex)
        switch.setOnCheckedChangeListener { _, checked -> setEnabled(context, slotIndex, checked) }
        container.addView(switch)

        val hwLabel = TextView(context)
        hwLabel.text = "Hardware Profile:"
        hwLabel.textSize = 16f
        container.addView(hwLabel)

        val hwSpinner = Spinner(context)
        val hwProfiles = DeviceProfiles.hardwareProfiles.map { it.name }
        val hwAdapter = ArrayAdapter(context, android.R.layout.simple_spinner_item, hwProfiles)
        hwAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        hwSpinner.adapter = hwAdapter
        hwSpinner.setSelection(hwProfiles.indexOf(getHardwareProfile(context, slotIndex)).coerceAtLeast(0))
        hwSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                setHardwareProfile(context, slotIndex, hwProfiles[position])
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        container.addView(hwSpinner)

        val localeLabel = TextView(context)
        localeLabel.text = "Locale Profile:"
        localeLabel.textSize = 16f
        container.addView(localeLabel)

        val localeSpinner = Spinner(context)
        val localeProfiles = DeviceProfiles.localeProfiles.map { it.name }
        val localeAdapter = ArrayAdapter(context, android.R.layout.simple_spinner_item, localeProfiles)
        localeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        localeSpinner.adapter = localeAdapter
        localeSpinner.setSelection(localeProfiles.indexOf(getLocaleProfile(context, slotIndex)).coerceAtLeast(0))
        localeSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                setLocaleProfile(context, slotIndex, localeProfiles[position])
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        container.addView(localeSpinner)

        return container
    }
}
