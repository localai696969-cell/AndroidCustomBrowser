package com.colablive.keeper.features.fingerprint

import android.content.Context
import android.widget.*
import com.colablive.keeper.core.*

/**
 * Feature cấu hình fingerprint spoof + proxy + auto behavior per slot.
 */
class FingerprintSpoofFeature : BrowserFeature {
    override val id = "fingerprint_spoof"
    override val displayName = "Fingerprint Spoof"

    override fun buildSettingsView(context: Context, slotIndex: Int): android.view.View {
        val scroll = ScrollView(context)
        val layout = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 32, 32, 32)
        }

        // --- Fingerprint Toggle ---
        val enabledSwitch = Switch(context).apply {
            text = "Bật Fingerprint Spoof"
            isChecked = AppPrefs.getBoolean(context, slotIndex, "fp_enabled", false)
            setOnCheckedChangeListener { _, checked ->
                AppPrefs.setBoolean(context, slotIndex, "fp_enabled", checked)
            }
        }
        layout.addView(enabledSwitch)

        // --- Hardware Profile Spinner ---
        layout.addView(TextView(context).apply { text = "Hardware Profile:" })
        val hwSpinner = Spinner(context)
        val hwAdapter = ArrayAdapter(context, android.R.layout.simple_spinner_item, DeviceProfiles.hardwarePresets.map { it.name })
        hwAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        hwSpinner.adapter = hwAdapter
        hwSpinner.setSelection(AppPrefs.getInt(context, slotIndex, "fp_hw_index", 0))
        layout.addView(hwSpinner)

        // --- Locale Profile Spinner ---
        layout.addView(TextView(context).apply { text = "Locale Profile:" })
        val locSpinner = Spinner(context)
        val locAdapter = ArrayAdapter(context, android.R.layout.simple_spinner_item, DeviceProfiles.localePresets.map { it.name })
        locAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        locSpinner.adapter = locAdapter
        locSpinner.setSelection(AppPrefs.getInt(context, slotIndex, "fp_loc_index", 0))
        layout.addView(locSpinner)

        // --- Proxy Config ---
        layout.addView(TextView(context).apply {
            text = "Proxy Config (HTTP/SOCKS5):"
            setPadding(0, 16, 0, 8)
        })

        val proxyHost = EditText(context).apply {
            hint = "Proxy Host"
            setText(AppPrefs.getString(context, slotIndex, "proxy_host", ""))
        }
        layout.addView(proxyHost)

        val proxyPort = EditText(context).apply {
            hint = "Port"
            setText(AppPrefs.getString(context, slotIndex, "proxy_port", ""))
        }
        layout.addView(proxyPort)

        // --- Save Button ---
        val saveBtn = Button(context).apply {
            text = "Lưu Cấu Hình"
            setOnClickListener {
                AppPrefs.setInt(context, slotIndex, "fp_hw_index", hwSpinner.selectedItemPosition)
                AppPrefs.setInt(context, slotIndex, "fp_loc_index", locSpinner.selectedItemPosition)
                AppPrefs.setString(context, slotIndex, "proxy_host", proxyHost.text.toString())
                AppPrefs.setString(context, slotIndex, "proxy_port", proxyPort.text.toString())
                Toast.makeText(context, "Đã lưu!", Toast.LENGTH_SHORT).show()
            }
        }
        layout.addView(saveBtn)

        scroll.addView(layout)
        return scroll
    }

    override fun isEnabled(context: Context, slotIndex: Int): Boolean {
        return AppPrefs.getBoolean(context, slotIndex, "fp_enabled", false)
    }

    override fun setEnabled(context: Context, slotIndex: Int, enabled: Boolean) {
        AppPrefs.setBoolean(context, slotIndex, "fp_enabled", enabled)
    }

    override fun onPageLoaded(context: Context, slotIndex: Int, url: String) {
        // Tự động áp dụng fingerprint khi trang load
    }

    override fun onPageLoadError(context: Context, slotIndex: Int, url: String, errorCode: Int) {}

    override fun onDropFile(context: Context, slotIndex: Int, uri: android.net.Uri, mimeType: String?) {}
}
