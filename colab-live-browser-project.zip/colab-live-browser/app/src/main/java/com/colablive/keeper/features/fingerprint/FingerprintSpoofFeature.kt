package com.colablive.keeper.features.fingerprint

import android.content.Context
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import com.colablive.keeper.core.AppPrefs
import com.colablive.keeper.core.BrowserEngine
import com.colablive.keeper.core.BrowserFeature
import org.json.JSONObject

/**
 * Giả fingerprint bằng HỒ SƠ TRỌN GÓI (xem DeviceProfiles.kt) — không cho
 * chỉnh từng thông số rời để tránh tạo ra tổ hợp không nhất quán (vd Windows
 * platform + Apple GPU). Random/Manual đều chọn CẢ hồ sơ.
 *
 * QUAN TRỌNG: đổi cài đặt CẦN KHỞI ĐỘNG LẠI khe này mới có hiệu lực đầy đủ.
 */
object FingerprintSpoofFeature : BrowserFeature {

    override val id = "fingerprint_spoof"
    override val displayName = "Fingerprint Spoof"
    override val description =
        "Giả fingerprint bằng hồ sơ thiết bị TRỌN GÓI (platform+WebGL+CPU+RAM đi cùng nhau, " +
            "timezone+ngôn ngữ đi cùng nhau) để đảm bảo nhất quán — không cho chỉnh rời từng " +
            "thông số vì dễ tạo tổ hợp vô lý (vd Windows + GPU Apple) còn dễ bị phát hiện hơn " +
            "cả không giả gì. CHƯA che: audio fingerprint, font cài sẵn, IP thật (ngoài WebRTC)."

    const val MODE_RANDOM = "random"
    const val MODE_MANUAL = "manual"

    private const val KEY_ENABLED = "enabled"
    private const val KEY_MODE = "mode"
    private const val KEY_SPOOF_CANVAS = "spoof_canvas"
    private const val KEY_SPOOF_HW_PROFILE = "spoof_hw_profile"
    private const val KEY_SPOOF_LOCALE = "spoof_locale"
    private const val KEY_BLOCK_WEBRTC = "block_webrtc"
    private const val KEY_SEED = "seed"
    private const val KEY_MANUAL_HW_INDEX = "manual_hw_index"
    private const val KEY_MANUAL_LOCALE_INDEX = "manual_locale_index"

    override fun isEnabled(context: Context, slotIndex: Int): Boolean =
        AppPrefs.getBoolean(context, slotIndex, id, KEY_ENABLED, true)

    override fun setEnabled(context: Context, slotIndex: Int, enabled: Boolean) {
        AppPrefs.setBoolean(context, slotIndex, id, KEY_ENABLED, enabled)
    }

    override fun matchesUrl(url: String?): Boolean = true
    override fun onPageFinished(context: Context, slotIndex: Int, engine: BrowserEngine, url: String?) {}
    override fun onTick(context: Context, slotIndex: Int, engine: BrowserEngine, url: String?) {}

    /** Seed riêng BỀN VỮNG theo từng khe — sinh 1 lần, lưu lại, dùng cho chế độ Random. */
    private fun getOrCreateSeed(context: Context, slotIndex: Int): Int {
        val existing = AppPrefs.getInt(context, slotIndex, id, KEY_SEED, -1)
        if (existing != -1) return existing
        val newSeed = (0..999_999).random()
        AppPrefs.setInt(context, slotIndex, id, KEY_SEED, newSeed)
        return newSeed
    }

    /** Gọi từ GeckoViewEngine lúc port fingerprint_spoof vừa connect. */
    fun buildConfigJson(context: Context, slotIndex: Int): JSONObject {
        val mode = AppPrefs.getString(context, slotIndex, id, KEY_MODE, MODE_RANDOM)
        val rnd = java.util.Random(getOrCreateSeed(context, slotIndex).toLong())

        val hwIndex: Int
        val localeIndex: Int
        if (mode == MODE_MANUAL) {
            hwIndex = AppPrefs.getInt(context, slotIndex, id, KEY_MANUAL_HW_INDEX, 0)
            localeIndex = AppPrefs.getInt(context, slotIndex, id, KEY_MANUAL_LOCALE_INDEX, 0)
        } else {
            // Random nhưng ỔN ĐỊNH theo seed riêng khe — mỗi khe khác nhau,
            // nhưng cùng 1 khe luôn ra cùng hồ sơ qua các lần mở lại.
            hwIndex = rnd.nextInt(DeviceProfiles.HARDWARE.size)
            localeIndex = rnd.nextInt(DeviceProfiles.LOCALE.size)
        }

        val hw = DeviceProfiles.HARDWARE[hwIndex.coerceIn(DeviceProfiles.HARDWARE.indices)]
        val locale = DeviceProfiles.LOCALE[localeIndex.coerceIn(DeviceProfiles.LOCALE.indices)]

        return JSONObject().apply {
            put("canvas", AppPrefs.getBoolean(context, slotIndex, id, KEY_SPOOF_CANVAS, true))

            put("hwProfile", AppPrefs.getBoolean(context, slotIndex, id, KEY_SPOOF_HW_PROFILE, true))
            put("platform", hw.platform)
            put("webglVendor", hw.webglVendor)
            put("webglRenderer", hw.webglRenderer)
            put("hardwareConcurrencyValue", hw.hardwareConcurrency)
            put("deviceMemoryValue", hw.deviceMemory)

            put("locale", AppPrefs.getBoolean(context, slotIndex, id, KEY_SPOOF_LOCALE, true))
            put("timezoneName", locale.timezoneName)
            put("timezoneOffsetMinutes", locale.timezoneOffsetMinutes)
            put("languageValue", locale.language)

            put("blockWebrtc", AppPrefs.getBoolean(context, slotIndex, id, KEY_BLOCK_WEBRTC, true))
        }
    }

    override fun buildSettingsView(context: Context, slotIndex: Int): View {
        val padding = (16 * context.resources.displayMetrics.density).toInt()
        // Không dùng "id" trực tiếp bên trong các khối Xxx(context).apply{}
        // bên dưới — bị Kotlin hiểu nhầm thành View.id (Int). Gán ra biến
        // riêng để tránh mơ hồ hoàn toàn.
        val featureId = id

        val enableSwitch = Switch(context).apply {
            text = "Bật $displayName"
            isChecked = isEnabled(context, slotIndex)
            setOnCheckedChangeListener { _, checked -> setEnabled(context, slotIndex, checked) }
        }
        val canvasSwitch = Switch(context).apply {
            text = "Giả canvas fingerprint"
            isChecked = AppPrefs.getBoolean(context, slotIndex, featureId, KEY_SPOOF_CANVAS, true)
            setOnCheckedChangeListener { _, c -> AppPrefs.setBoolean(context, slotIndex, featureId, KEY_SPOOF_CANVAS, c) }
        }
        val hwProfileSwitch = Switch(context).apply {
            text = "Giả Hardware Profile (platform+WebGL+CPU+RAM)"
            isChecked = AppPrefs.getBoolean(context, slotIndex, featureId, KEY_SPOOF_HW_PROFILE, true)
            setOnCheckedChangeListener { _, c -> AppPrefs.setBoolean(context, slotIndex, featureId, KEY_SPOOF_HW_PROFILE, c) }
        }
        val localeSwitch = Switch(context).apply {
            text = "Giả Locale Profile (timezone+ngôn ngữ)"
            isChecked = AppPrefs.getBoolean(context, slotIndex, featureId, KEY_SPOOF_LOCALE, true)
            setOnCheckedChangeListener { _, c -> AppPrefs.setBoolean(context, slotIndex, featureId, KEY_SPOOF_LOCALE, c) }
        }
        val webrtcSwitch = Switch(context).apply {
            text = "Chặn rò IP qua WebRTC"
            isChecked = AppPrefs.getBoolean(context, slotIndex, featureId, KEY_BLOCK_WEBRTC, true)
            setOnCheckedChangeListener { _, c -> AppPrefs.setBoolean(context, slotIndex, featureId, KEY_BLOCK_WEBRTC, c) }
        }

        val currentMode = AppPrefs.getString(context, slotIndex, featureId, KEY_MODE, MODE_RANDOM)
        val modeGroup = RadioGroup(context).apply { orientation = RadioGroup.VERTICAL }
        val randomRadio = RadioButton(context).apply {
            id = 3001
            text = "Ngẫu nhiên — hồ sơ cố định riêng theo khe này (khác khe khác, ổn định qua các lần mở lại)"
        }
        val manualRadio = RadioButton(context).apply {
            id = 3002
            text = "Chỉ định — tự chọn cả hồ sơ bên dưới (không chỉnh từng thông số rời)"
        }
        modeGroup.addView(randomRadio)
        modeGroup.addView(manualRadio)
        modeGroup.check(if (currentMode == MODE_MANUAL) 3002 else 3001)

        val hwSpinner = Spinner(context).apply {
            adapter = ArrayAdapter(
                context, android.R.layout.simple_spinner_dropdown_item,
                DeviceProfiles.HARDWARE.map { "${it.label} (${it.hardwareConcurrency} nhân, ${it.deviceMemory}GB)" }
            )
            setSelection(AppPrefs.getInt(context, slotIndex, featureId, KEY_MANUAL_HW_INDEX, 0))
        }
        val localeSpinner = Spinner(context).apply {
            adapter = ArrayAdapter(
                context, android.R.layout.simple_spinner_dropdown_item,
                DeviceProfiles.LOCALE.map { "${it.label} (${it.timezoneName})" }
            )
            setSelection(AppPrefs.getInt(context, slotIndex, featureId, KEY_MANUAL_LOCALE_INDEX, 0))
        }

        val saveButton = Button(context).apply {
            text = "Lưu"
            setOnClickListener {
                val mode = if (modeGroup.checkedRadioButtonId == 3002) MODE_MANUAL else MODE_RANDOM
                AppPrefs.setString(context, slotIndex, featureId, KEY_MODE, mode)
                AppPrefs.setInt(context, slotIndex, featureId, KEY_MANUAL_HW_INDEX, hwSpinner.selectedItemPosition)
                AppPrefs.setInt(context, slotIndex, featureId, KEY_MANUAL_LOCALE_INDEX, localeSpinner.selectedItemPosition)
                Toast.makeText(
                    context,
                    "Đã lưu — khởi động lại app để áp dụng (đóng hẳn app rồi mở lại)",
                    Toast.LENGTH_LONG
                ).show()
            }
        }

        val restartNote = TextView(context).apply {
            text = "⚠ Mọi thay đổi ở màn hình này CẦN khởi động lại khe (đóng hẳn app, mở lại) " +
                "mới có hiệu lực — không áp dụng ngay giữa phiên."
        }

        return LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(padding, padding, padding, padding)
            addView(TextView(context).apply { text = description })
            addView(enableSwitch)
            addView(TextView(context).apply { text = "\nNhóm muốn giả:" })
            addView(canvasSwitch)
            addView(hwProfileSwitch)
            addView(localeSwitch)
            addView(webrtcSwitch)
            addView(TextView(context).apply { text = "\nChế độ:" })
            addView(modeGroup)
            addView(TextView(context).apply { text = "\nHồ sơ dùng khi chọn \"Chỉ định\":" })
            addView(TextView(context).apply { text = "Hardware Profile:" })
            addView(hwSpinner)
            addView(TextView(context).apply { text = "Locale Profile:" })
            addView(localeSpinner)
            addView(saveButton)
            addView(restartNote)
        }
    }
}
