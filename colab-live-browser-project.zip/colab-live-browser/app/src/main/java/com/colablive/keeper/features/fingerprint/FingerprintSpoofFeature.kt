package com.colablive.keeper.features.fingerprint

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.*
import com.colablive.keeper.core.*
import com.colablive.keeper.core.proxy.ProxyHealthChecker
import com.colablive.keeper.core.proxy.ProxyScraper

/**
 * Feature cấu hình fingerprint spoof + proxy + auto behavior per slot.
 */
object FingerprintSpoofFeature : BrowserFeature {
    override val id = "fingerprint_spoof"
    override val displayName = "🎭 Fingerprint Spoof"
    override val description = "Giả lập thông số phần cứng, proxy, timezone, và vân tay trình duyệt"

    override fun isEnabled(context: Context, slotIndex: Int): Boolean =
        AppPrefs.getBoolean(context, slotIndex, id, "enabled", false)

    override fun setEnabled(context: Context, slotIndex: Int, enabled: Boolean) =
        AppPrefs.setBoolean(context, slotIndex, id, "enabled", enabled)

    override fun buildSettingsView(context: Context, slotIndex: Int): android.view.View {
        val scroll = ScrollView(context)
        val layout = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 32, 32, 32)
        }

        // --- Fingerprint Toggle ---
        val enabledSwitch = Switch(context).apply {
            text = "Bật Fingerprint Spoof"
            isChecked = isEnabled(context, slotIndex)
            setOnCheckedChangeListener { _, checked ->
                setEnabled(context, slotIndex, checked)
            }
        }
        layout.addView(enabledSwitch)

        // --- Lock Mode ---
        val lockSwitch = Switch(context).apply {
            text = "Khoá cứng (cùng slot = cùng fingerprint)"
            isChecked = AppPrefs.getBoolean(context, slotIndex, "fp_lock", true)
            setOnCheckedChangeListener { _, checked ->
                AppPrefs.setBoolean(context, slotIndex, "fp_lock", checked)
            }
        }
        layout.addView(lockSwitch)

        // --- Fresh Mode ---
        val freshSwitch = Switch(context).apply {
            text = "⚠️ Đổi mới mỗi lần mở (CÓ THỂ GÂY NGHI NGỜ)"
            isChecked = AppPrefs.getBoolean(context, slotIndex, "fp_fresh", false)
            setTextColor(android.graphics.Color.RED)
            setOnCheckedChangeListener { _, checked ->
                AppPrefs.setBoolean(context, slotIndex, "fp_fresh", checked)
            }
        }
        layout.addView(freshSwitch)

        // --- Auto Behavior ---
        val behaviorSwitch = Switch(context).apply {
            text = "🤖 Auto Behavior (giả lập người dùng)"
            isChecked = AppPrefs.getBoolean(context, slotIndex, "auto_behavior", false)
            setOnCheckedChangeListener { _, checked ->
                AppPrefs.setBoolean(context, slotIndex, "auto_behavior", checked)
            }
        }
        layout.addView(behaviorSwitch)

        // --- Hardware Preset ---
        layout.addView(TextView(context).apply { text = "Hardware Profile:"; textSize = 16f })
        layout.addView(TextView(context).apply {
            text = "ℹ️ Hồ sơ desktop dùng chế độ Desktop Site THẬT của GeckoView " +
                "(viewport CSS 980px, giống 'Yêu cầu trang web dành cho máy tính' trên " +
                "trình duyệt di động thật) — layout trang RENDER THẬT theo desktop, không " +
                "chỉ nói dối 1 con số JS. Nhưng KHÔNG hoàn hảo: 980px CSS vẫn khác đúng " +
                "1920/2560 của hồ sơ đã chọn, và pixel vật lý hiển thị ra vẫn là màn hình " +
                "điện thoại — đây là giới hạn của việc dùng 1 thiết bị thật để giả nhiều " +
                "loại máy, không sửa hết bằng code được."
            textSize = 12f
            setTextColor(android.graphics.Color.GRAY)
        })
        val hwSpinner = Spinner(context).apply {
            val profiles = DeviceProfiles.hardwareProfiles
            adapter = ArrayAdapter(context, android.R.layout.simple_spinner_item, profiles.map { it.name }).apply {
                setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            }
            setSelection(AppPrefs.getInt(context, slotIndex, "fp_hw_idx", 0))
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                    AppPrefs.setInt(context, slotIndex, "fp_hw_idx", position)
                }
                override fun onNothingSelected(parent: AdapterView<*>?) {}
            }
        }
        layout.addView(hwSpinner)

        // --- Locale Preset ---
        layout.addView(TextView(context).apply { text = "Locale Profile:"; textSize = 16f })
        val localeSpinner = Spinner(context).apply {
            val profiles = DeviceProfiles.localeProfiles
            adapter = ArrayAdapter(context, android.R.layout.simple_spinner_item, profiles.map { it.name }).apply {
                setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            }
            setSelection(AppPrefs.getInt(context, slotIndex, "fp_locale_idx", 0))
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                    AppPrefs.setInt(context, slotIndex, "fp_locale_idx", position)
                    // Tự động set timezone từ locale
                    val tz = DeviceProfiles.localeProfiles.getOrNull(position)?.timezone ?: "UTC"
                    AppPrefs.setString(context, slotIndex, "fp_timezone", tz)
                }
                override fun onNothingSelected(parent: AdapterView<*>?) {}
            }
        }
        layout.addView(localeSpinner)

        // --- Từng kỹ thuật giả lập (bật/tắt riêng) ---
        layout.addView(TextView(context).apply {
            text = "\nKỹ thuật giả lập (bật/tắt riêng từng cái):"
            textSize = 16f
        })
        val techniqueKeys = listOf(
            "fp_t_canvas" to "Canvas fingerprint (thêm nhiễu ảnh canvas)",
            "fp_t_audio" to "Audio fingerprint (thêm nhiễu AudioContext)",
            "fp_t_font" to "Font enumeration (giả danh sách font hệ thống)",
            "fp_t_webrtc" to "Chặn WebRTC (chống lộ IP thật qua STUN)"
        )
        layout.addView(TextView(context).apply {
            text = "(User-Agent LUÔN đồng bộ theo Hardware Profile ở trên — không cho " +
                "tắt riêng, vì Platform+GPU giả nhưng UA thật là mâu thuẫn dễ bị phát hiện " +
                "nhất, không có tổ hợp nào hợp lệ khi tách 2 cái này ra)"
            textSize = 12f
            setTextColor(android.graphics.Color.GRAY)
        })
        techniqueKeys.forEach { (key, label) ->
            layout.addView(Switch(context).apply {
                text = label
                isChecked = AppPrefs.getBoolean(context, slotIndex, key, true)
                setOnCheckedChangeListener { _, checked ->
                    AppPrefs.setBoolean(context, slotIndex, key, checked)
                }
            })
        }

        // --- Proxy Config ---
        layout.addView(TextView(context).apply {
            text = "\nProxy per Slot (đổi IP):"
            textSize = 18f
            setTextColor(android.graphics.Color.parseColor("#FF6B00"))
        })

        layout.addView(TextView(context).apply {
            text = "✅ Đã hỗ trợ thật qua WebExtension Proxy API (browser.proxy.onRequest) — " +
                "khác cách cũ (GeckoRuntimeSettings.arguments()) đã xác nhận không hoạt động. " +
                "Cần khởi động lại khe để áp dụng.\n\n" +
                "⚠️ RỦI RO THẬT với proxy miễn phí (cào tự động bên dưới): có thể log lại " +
                "traffic, chèn quảng cáo, hoặc là honeypot — KHÔNG dùng để đăng nhập tài khoản " +
                "quan trọng hay gửi dữ liệu nhạy cảm qua proxy loại này."
            setTextColor(android.graphics.Color.parseColor("#D32F2F"))
            setPadding(0, 8, 0, 16)
        })

        val proxyTypeSpinner = Spinner(context).apply {
            val types = listOf("Direct (không proxy)", "HTTP Proxy", "SOCKS5 Proxy")
            adapter = ArrayAdapter(context, android.R.layout.simple_spinner_item, types).apply {
                setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            }
            setSelection(AppPrefs.getInt(context, slotIndex, "proxy_type", 0))
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                    AppPrefs.setInt(context, slotIndex, "proxy_type", position)
                }
                override fun onNothingSelected(parent: AdapterView<*>?) {}
            }
        }
        layout.addView(proxyTypeSpinner)

        val proxyHost = EditText(context).apply {
            hint = "Proxy Host (vd: 192.168.1.1)"
            setText(AppPrefs.getString(context, slotIndex, "proxy_host", ""))
        }
        layout.addView(proxyHost)

        val proxyPort = EditText(context).apply {
            hint = "Proxy Port (vd: 8080)"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setText(AppPrefs.getString(context, slotIndex, "proxy_port", ""))
        }
        layout.addView(proxyPort)

        val proxyUser = EditText(context).apply {
            hint = "Proxy Username (nếu có)"
            setText(AppPrefs.getString(context, slotIndex, "proxy_user", ""))
        }
        layout.addView(proxyUser)

        val proxyPass = EditText(context).apply {
            hint = "Proxy Password (nếu có)"
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(AppPrefs.getString(context, slotIndex, "proxy_pass", ""))
        }
        layout.addView(proxyPass)

        val saveProxyBtn = Button(context).apply {
            text = "Lưu Proxy Config"
            setOnClickListener {
                AppPrefs.setString(context, slotIndex, "proxy_host", proxyHost.text.toString())
                AppPrefs.setString(context, slotIndex, "proxy_port", proxyPort.text.toString())
                AppPrefs.setString(context, slotIndex, "proxy_user", proxyUser.text.toString())
                AppPrefs.setString(context, slotIndex, "proxy_pass", proxyPass.text.toString())
                android.widget.Toast.makeText(context, "Proxy đã lưu!", android.widget.Toast.LENGTH_SHORT).show()
            }
        }
        layout.addView(saveProxyBtn)

        // --- Tự động tìm proxy miễn phí nhanh nhất còn sống ---
        val autoFindStatus = TextView(context).apply {
            text = ""
            setPadding(0, 4, 0, 4)
        }
        val autoFindBtn = Button(context).apply {
            text = "🔍 Tự động tìm proxy nhanh nhất"
            setOnClickListener {
                isEnabled = false
                autoFindStatus.text = "Đang cào danh sách proxy..."
                Thread {
                    val candidates = ProxyScraper.fetchCandidates()
                    val mainHandler = Handler(Looper.getMainLooper())
                    if (candidates.isEmpty()) {
                        mainHandler.post {
                            autoFindStatus.text = "❌ Không lấy được danh sách proxy (kiểm tra mạng, xem Debug Log)"
                            isEnabled = true
                        }
                        return@Thread
                    }
                    mainHandler.post {
                        autoFindStatus.text = "Đang kiểm tra ${candidates.size} proxy — có thể mất 1-2 phút..."
                    }
                    val best = ProxyHealthChecker.findFastestAlive(candidates) { checked, total ->
                        mainHandler.post {
                            autoFindStatus.text = "Đang kiểm tra... $checked/$total"
                        }
                    }
                    mainHandler.post {
                        isEnabled = true
                        if (best == null) {
                            autoFindStatus.text = "❌ Không tìm được proxy nào còn sống trong danh sách cào được — thử lại sau (danh sách proxy free thường đổi liên tục)"
                        } else {
                            val c = best.candidate
                            proxyHost.setText(c.host)
                            proxyPort.setText(c.port.toString())
                            AppPrefs.setString(context, slotIndex, "proxy_host", c.host)
                            AppPrefs.setString(context, slotIndex, "proxy_port", c.port.toString())
                            AppPrefs.setInt(context, slotIndex, "proxy_type", if (c.type == "socks") 2 else 1)
                            autoFindStatus.text = "✅ Đã chọn ${c.host}:${c.port} (${c.type}, ${best.latencyMs}ms) — đã tự lưu, cần khởi động lại khe để áp dụng"
                            Toast.makeText(context, "Đã tìm và lưu proxy nhanh nhất: ${c.host}:${c.port}", Toast.LENGTH_LONG).show()
                        }
                    }
                }.start()
            }
        }
        layout.addView(autoFindBtn)
        layout.addView(autoFindStatus)

        // --- Apply Button ---
        val applyBtn = Button(context).apply {
            text = "Áp dụng Fingerprint"
            setOnClickListener {
                applyFingerprint(context, slotIndex)
            }
        }
        layout.addView(applyBtn)

        scroll.addView(layout)
        return scroll
    }

    private fun applyFingerprint(context: Context, slotIndex: Int) {
        val hwIdx = AppPrefs.getInt(context, slotIndex, "fp_hw_idx", 0)
        val localeIdx = AppPrefs.getInt(context, slotIndex, "fp_locale_idx", 0)
        val hw = DeviceProfiles.hardwareProfiles.getOrNull(hwIdx) ?: DeviceProfiles.hardwareProfiles.first()
        val locale = DeviceProfiles.localeProfiles.getOrNull(localeIdx) ?: DeviceProfiles.localeProfiles.first()

        // Tự động sync timezone với locale
        AppPrefs.setString(context, slotIndex, "fp_timezone", locale.timezone)

        DebugLog.log("Slot $slotIndex fingerprint: ${hw.name} + ${locale.name} (tz=${locale.timezone})")
        android.widget.Toast.makeText(context, "Đã áp dụng: ${hw.name} + ${locale.name}", android.widget.Toast.LENGTH_SHORT).show()
    }

}
