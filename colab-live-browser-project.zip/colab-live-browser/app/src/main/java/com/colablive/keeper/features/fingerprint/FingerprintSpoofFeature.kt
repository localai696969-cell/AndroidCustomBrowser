package com.colablive.keeper.features.fingerprint

import android.content.Context
import android.view.View
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import com.colablive.keeper.core.AppPrefs
import com.colablive.keeper.core.BrowserEngine
import com.colablive.keeper.core.BrowserFeature

/**
 * Giả canvas/WebGL/hardwareConcurrency/deviceMemory fingerprint để giảm khả
 * năng các nền tảng liên kết nhiều "trình duyệt con" (profile/khe) về cùng
 * 1 thiết bị vật lý dù cookie/IP đã tách riêng.
 *
 * QUAN TRỌNG — khác cơ chế với ColabLiveKeeperFeature: việc bật/tắt tính
 * năng này KHÔNG áp dụng ngay lập tức giữa phiên (mid-session) — vì cơ chế
 * bảo vệ thật (content.js trong assets/fingerprint_spoof/) phải chạy ở
 * "document_start", SỚM hơn cả lúc app kịp hỏi Kotlin xem có nên chạy hay
 * không. Cách duy nhất để có được bảo vệ TIN CẬY (không có khoảng hở thời
 * gian bị trang đọc được giá trị thật): đăng ký/không đăng ký cả
 * WebExtension này lúc khởi động GeckoRuntime (xem GeckoRuntimeProvider.kt).
 * => Đổi cài đặt này CẦN KHỞI ĐỘNG LẠI APP mới có hiệu lực, không phải
 * thay đổi tức thời như DOM/Accessibility mode của Colab.
 */
object FingerprintSpoofFeature : BrowserFeature {

    override val id = "fingerprint_spoof"
    override val displayName = "Fingerprint Spoof"
    override val description =
        "Giả canvas/WebGL/hardwareConcurrency/deviceMemory để giảm liên kết đa tài khoản giữa các khe. " +
            "CHƯA che: rò IP qua WebRTC, audio fingerprint, font cài sẵn, timezone/locale. " +
            "Giá trị giả hiện CỐ ĐỊNH GIỐNG NHAU cho mọi khe (chưa có seed riêng từng khe)."

    private const val KEY_ENABLED = "enabled"

    override fun isEnabled(context: Context, slotIndex: Int): Boolean =
        AppPrefs.getBoolean(context, slotIndex, id, KEY_ENABLED, true) // mặc định bật

    override fun setEnabled(context: Context, slotIndex: Int, enabled: Boolean) {
        AppPrefs.setBoolean(context, slotIndex, id, KEY_ENABLED, enabled)
    }

    // Áp dụng toàn cục (mọi trang), không giới hạn domain như Colab.
    override fun matchesUrl(url: String?): Boolean = true

    // Không cần làm gì ở đây — cơ chế bảo vệ thật chạy độc lập qua
    // WebExtension riêng (assets/fingerprint_spoof/), đăng ký lúc khởi động
    // GeckoRuntime, không qua đường onPageFinished/onTick như eval bridge.
    override fun onPageFinished(context: Context, slotIndex: Int, engine: BrowserEngine, url: String?) {}
    override fun onTick(context: Context, slotIndex: Int, engine: BrowserEngine, url: String?) {}

    override fun buildSettingsView(context: Context, slotIndex: Int): View {
        val padding = (16 * context.resources.displayMetrics.density).toInt()

        val enableSwitch = Switch(context).apply {
            text = "Bật $displayName"
            isChecked = isEnabled(context, slotIndex)
            setOnCheckedChangeListener { _, checked -> setEnabled(context, slotIndex, checked) }
        }

        val restartNote = TextView(context).apply {
            text = "⚠ Cần khởi động lại khe này (đóng app hẳn rồi mở lại) để thay đổi có hiệu lực " +
                "— khác với Colab Live Keeper, cài đặt này không áp dụng ngay giữa phiên."
        }

        return LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(padding, padding, padding, padding)
            addView(TextView(context).apply { text = description })
            addView(enableSwitch)
            addView(restartNote)
        }
    }
}
