package com.colablive.keeper.features.fingerprint

import android.content.Context
import android.widget.*
import com.colablive.keeper.core.*

/**
 * Feature cấu hình fingerprint spoof + proxy + auto behavior per slot.
 */
class FingerprintSpoofFeature : BrowserFeature {
    override val id = "fingerprint_spoof"
    override val displayName = "Fingerprint Spoof"
    override val id = "fingerprint_spoof"
    override val displayName = "Fingerprint Spoof"

    override fun buildSettingsView(context: Context, slotIndex: Int): android.view.View {
        val scroll = ScrollView(context)
        val layout = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 32, 32, 32)
        }

        // --- Fingerprint Toggle ---
        val enabledSwitch = Switch(context).apply {
            text = "Bật Fingerprint Spoof"
            isChecked = AppPrefs.getBoolean(context, slotIndex, "fp_enabled", false)
            setOnCheckedChangeListener { _, checked ->
                AppPrefs.setBoolean(context, slotIndex, "fp_enabled", checked)
            }
        }
        layout.addView(enabledSwitch)

        // --- Lock Mode ---
        val lockSwitch = Switch(context).apply {
            text = "Khoá cứng (cùng slot = cùng fingerprint)"
            isChecked = AppPrefs.getBoolean(context, slotIndex, "fp_lock", true)
            setOnCheckedChangeListener { _, checked ->
                AppPrefs.setBoolean(context, slotIndex, "fp_lock", checked)
            }
        }
        layout.addView(lockSwitch)

        // --- Fresh Mode ---
        val freshSwitch = Switch(context).apply {
            text = "⚠️ Đổi mới mỗi lần mở (CÓ THỂ GÂY NGHI NGỜ)"
            isChecked = AppPrefs.getBoolean(context, slotIndex, "fp_fresh", false)
            setTextColor(android.graphics.Color.RED)
            setOnCheckedChangeListener { _, checked ->
                AppPrefs.setBoolean(context, slotIndex, "fp_fresh", checked)
            }
        }
        layout.addView(freshSwitch)

        // --- Auto Behavior ---
        val behaviorSwitch = Switch(context).apply {
            text = "🤖 Auto Behavior (giả lập người dùng)"
            isChecked = AppPrefs.getBoolean(context, slotIndex, "auto_behavior", false)
            setOnCheckedChangeListener { _, checked ->
                AppPrefs.setBoolean(context, slotIndex, "auto_behavior", checked)
            }
        }
        layout.addView(behaviorSwitch)

        // --- Hardware Preset ---
        layout.addView(TextView(context).apply { text = "Hardware Profile:"; textSize = 16f })
        val hwSpinner = Spinner(context).apply {
            val profiles = DeviceProfiles.hardwareProfiles
            adapter = ArrayAdapter(context, android.R.layout.simple_spinner_item, profiles.map { it.name }).apply {
                setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            }
            setSelection(AppPrefs.getInt(context, slotIndex, "fp_hw_idx", 0))
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                    AppPrefs.setInt(context, slotIndex, "fp_hw_idx", position)
                }
                override fun onNothingSelected(parent: AdapterView<*>?) {}
            }
        }
        layout.addView(hwSpinner)

        // --- Locale Preset ---
        layout.addView(TextView(context).apply { text = "Locale Profile:"; textSize = 16f })
        val localeSpinner = Spinner(context).apply {
            val profiles = DeviceProfiles.localeProfiles
            adapter = ArrayAdapter(context, android.R.layout.simple_spinner_item, profiles.map { it.name }).apply {
                setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            }
            setSelection(AppPrefs.getInt(context, slotIndex, "fp_locale_idx", 0))
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                    AppPrefs.setInt(context, slotIndex, "fp_locale_idx", position)
                    // Tự động set timezone từ locale
                    val tz = DeviceProfiles.localeProfiles.getOrNull(position)?.timezone ?: "UTC"
                    AppPrefs.setString(context, slotIndex, "fp_timezone", tz)
                }
                override fun onNothingSelected(parent: AdapterView<*>?) {}
            }
        }
        layout.addView(localeSpinner)

        // --- Proxy Config ---
        layout.addView(TextView(context).apply {
            text = "\nProxy per Slot (đổi IP):"
            textSize = 18f
            setTextColor(android.graphics.Color.parseColor("#FF6B00"))
        })

        val proxyTypeSpinner = Spinner(context).apply {
            val types = listOf("Direct (không proxy)", "HTTP Proxy", "SOCKS5 Proxy")
            adapter = ArrayAdapter(context, android.R.layout.simple_spinner_item, types).apply {
                setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            }
            setSelection(AppPrefs.getInt(context, slotIndex, "proxy_type", 0))
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                    AppPrefs.setInt(context, slotIndex, "proxy_type", position)
                }
                override fun onNothingSelected(parent: AdapterView<*>?) {}
            }
        }
        layout.addView(proxyTypeSpinner)

        val proxyHost = EditText(context).apply {
            hint = "Proxy Host (vd: 192.168.1.1)"
            setText(AppPrefs.getString(context, slotIndex, "proxy_host", ""))
        }
        layout.addView(proxyHost)

        val proxyPort = EditText(context).apply {
            hint = "Proxy Port (vd: 8080)"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setText(AppPrefs.getString(context, slotIndex, "proxy_port", ""))
        }
        layout.addView(proxyPort)

        val proxyUser = EditText(context).apply {
            hint = "Proxy Username (nếu có)"
            setText(AppPrefs.getString(context, slotIndex, "proxy_user", ""))
        }
        layout.addView(proxyUser)

        val proxyPass = EditText(context).apply {
            hint = "Proxy Password (nếu có)"
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(AppPrefs.getString(context, slotIndex, "proxy_pass", ""))
        }
        layout.addView(proxyPass)

        val saveProxyBtn = Button(context).apply {
            text = "Lưu Proxy Config"
            setOnClickListener {
                AppPrefs.setString(context, slotIndex, "proxy_host", proxyHost.text.toString())
                AppPrefs.setString(context, slotIndex, "proxy_port", proxyPort.text.toString())
                AppPrefs.setString(context, slotIndex, "proxy_user", proxyUser.text.toString())
                AppPrefs.setString(context, slotIndex, "proxy_pass", proxyPass.text.toString())
                android.widget.Toast.makeText(context, "Proxy đã lưu!", android.widget.Toast.LENGTH_SHORT).show()
            }
        }
        layout.addView(saveProxyBtn)

        // --- Apply Button ---
        val applyBtn = Button(context).apply {
            text = "Áp dụng Fingerprint"
            setOnClickListener {
                applyFingerprint(context, slotIndex)
            }
        }
        layout.addView(applyBtn)

        scroll.addView(layout)
        return scroll
    }

    private fun applyFingerprint(context: Context, slotIndex: Int) {
        val hwIdx = AppPrefs.getInt(context, slotIndex, "fp_hw_idx", 0)
        val localeIdx = AppPrefs.getInt(context, slotIndex, "fp_locale_idx", 0)
        val hw = DeviceProfiles.hardwareProfiles.getOrNull(hwIdx) ?: DeviceProfiles.hardwareProfiles.first()
        val locale = DeviceProfiles.localeProfiles.getOrNull(localeIdx) ?: DeviceProfiles.localeProfiles.first()

        // Tự động sync timezone với locale
        AppPrefs.setString(context, slotIndex, "fp_timezone", locale.timezone)

        DebugLog.log("Slot $slotIndex fingerprint: ${hw.name} + ${locale.name} (tz=${locale.timezone})")
        android.widget.Toast.makeText(context, "Đã áp dụng: ${hw.name} + ${locale.name}", android.widget.Toast.LENGTH_SHORT).show()
    }


    override fun isEnabled(context: Context, slotIndex: Int): Boolean {
        return AppPrefs.getBoolean(context, slotIndex, "fp_enabled", false)
    }

    override fun setEnabled(context: Context, slotIndex: Int, enabled: Boolean) {
        AppPrefs.setBoolean(context, slotIndex, "fp_enabled", enabled)
    }

    override fun onPageLoaded(context: Context, slotIndex: Int, url: String) {
        // Tự động áp dụng fingerprint khi trang load
    }

    override fun onPageLoadError(context: Context, slotIndex: Int, url: String, errorCode: Int) {}

    override fun onDropFile(context: Context, slotIndex: Int, uri: android.net.Uri, mimeType: String?) {}



}
