package com.colablive.keeper.core

import android.content.Context
import android.content.SharedPreferences

object AppPrefs {
    private const val PREFS_NAME = "live_browser_prefs"

    private fun prefs(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    fun getString(context: Context?, slotIndex: Int, key: String, default: String): String {
        val ctx = context ?: return default
        return prefs(ctx).getString("${slotIndex}_$key", default) ?: default
    }

    fun getString(context: Context?, slotIndex: Int, featureId: String, key: String, default: String): String =
        getString(context, slotIndex, "$featureId:$key", default)

    fun setString(context: Context, slotIndex: Int, key: String, value: String) {
        prefs(context).edit().putString("${slotIndex}_$key", value).apply()
    }

    fun setString(context: Context, slotIndex: Int, featureId: String, key: String, value: String) =
        setString(context, slotIndex, "$featureId:$key", value)

    fun getInt(context: Context?, slotIndex: Int, key: String, default: Int): Int {
        val ctx = context ?: return default
        return prefs(ctx).getInt("${slotIndex}_$key", default)
    }

    fun getInt(context: Context?, slotIndex: Int, featureId: String, key: String, default: Int): Int =
        getInt(context, slotIndex, "$featureId:$key", default)

    fun setInt(context: Context, slotIndex: Int, key: String, value: Int) {
        prefs(context).edit().putInt("${slotIndex}_$key", value).apply()
    }

    fun setInt(context: Context, slotIndex: Int, featureId: String, key: String, value: Int) =
        setInt(context, slotIndex, "$featureId:$key", value)

    fun getBoolean(context: Context, slotIndex: Int, key: String, default: Boolean): Boolean {
        return prefs(context).getBoolean("${slotIndex}_$key", default)
    }

    fun getBoolean(context: Context, slotIndex: Int, featureId: String, key: String, default: Boolean): Boolean =
        getBoolean(context, slotIndex, "$featureId:$key", default)

    fun setBoolean(context: Context, slotIndex: Int, key: String, value: Boolean) {
        prefs(context).edit().putBoolean("${slotIndex}_$key", value).apply()
    }

    fun setBoolean(context: Context, slotIndex: Int, featureId: String, key: String, value: Boolean) =
        setBoolean(context, slotIndex, "$featureId:$key", value)

    fun clearSlot(context: Context, slotIndex: Int) {
        val editor = prefs(context).edit()
        prefs(context).all.keys.filter { it.startsWith("${slotIndex}_") }.forEach { key ->
            editor.remove(key)
        }
        editor.apply()
    }
}
