package com.colablive.keeper.core

import android.content.Context
import android.content.SharedPreferences

object AppPrefs {
    private const val PREFS_NAME = "live_browser_prefs"

    private fun prefs(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    // === Overloaded with featureId (5 params) ===
    fun getString(context: Context?, slotIndex: Int, featureId: String, key: String, default: String): String {
        val ctx = context ?: return default
        return prefs(ctx).getString("${slotIndex}_${featureId}_$key", default) ?: default
    }

    fun setString(context: Context, slotIndex: Int, featureId: String, key: String, value: String) {
        prefs(context).edit().putString("${slotIndex}_${featureId}_$key", value).apply()
    }

    fun getInt(context: Context?, slotIndex: Int, featureId: String, key: String, default: Int): Int {
        val ctx = context ?: return default
        return prefs(ctx).getInt("${slotIndex}_${featureId}_$key", default)
    }

    fun setInt(context: Context, slotIndex: Int, featureId: String, key: String, value: Int) {
        prefs(context).edit().putInt("${slotIndex}_${featureId}_$key", value).apply()
    }

    fun getBoolean(context: Context, slotIndex: Int, featureId: String, key: String, default: Boolean): Boolean {
        return prefs(context).getBoolean("${slotIndex}_${featureId}_$key", default)
    }

    fun setBoolean(context: Context, slotIndex: Int, featureId: String, key: String, value: Boolean) {
        prefs(context).edit().putBoolean("${slotIndex}_${featureId}_$key", value).apply()
    }

    // === Overloaded without featureId (4 params) - backward compatible ===
    fun getString(context: Context?, slotIndex: Int, key: String, default: String): String {
        val ctx = context ?: return default
        return prefs(ctx).getString("${slotIndex}_$key", default) ?: default
    }

    fun setString(context: Context, slotIndex: Int, key: String, value: String) {
        prefs(context).edit().putString("${slotIndex}_$key", value).apply()
    }

    fun getInt(context: Context?, slotIndex: Int, key: String, default: Int): Int {
        val ctx = context ?: return default
        return prefs(ctx).getInt("${slotIndex}_$key", default)
    }

    fun setInt(context: Context, slotIndex: Int, key: String, value: Int) {
        prefs(context).edit().putInt("${slotIndex}_$key", value).apply()
    }

    fun getBoolean(context: Context, slotIndex: Int, key: String, default: Boolean): Boolean {
        return prefs(context).getBoolean("${slotIndex}_$key", default)
    }

    fun setBoolean(context: Context, slotIndex: Int, key: String, value: Boolean) {
        prefs(context).edit().putBoolean("${slotIndex}_$key", value).apply()
    }

    fun clearSlot(context: Context, slotIndex: Int) {
        val editor = prefs(context).edit()
        prefs(context).all.keys.filter { it.startsWith("${slotIndex}_") }.forEach { key ->
            editor.remove(key)
        }
        editor.apply()
    }
}
