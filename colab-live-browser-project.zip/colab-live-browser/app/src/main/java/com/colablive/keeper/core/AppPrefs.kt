package com.colablive.keeper.core

import android.content.Context

/**
 * Lưu trữ key-value RIÊNG THEO TỪNG KHE (slotIndex) — mỗi khe có 1 file
 * SharedPreferences vật lý khác nhau, nên bật/tắt feature ở Khe 1 KHÔNG ảnh
 * hưởng Khe 2/3/4. slotIndex luôn truyền tường minh (không suy luận từ
 * "process đang chạy") để AutoClickAccessibilityService (luôn chạy ở khe 0)
 * vẫn đọc đúng cấu hình của khe đang thực sự active — file được lưu ở bộ nhớ
 * chung của app (cùng UID) nên đọc chéo qua tên file vẫn hợp lệ dù khác
 * process.
 */
object AppPrefs {
    private fun prefs(context: Context, slotIndex: Int) =
        context.getSharedPreferences("browser_prefs_slot$slotIndex", Context.MODE_PRIVATE)

    fun getString(context: Context, slotIndex: Int, featureId: String, key: String, default: String): String =
        prefs(context, slotIndex).getString("$featureId.$key", default) ?: default

    fun setString(context: Context, slotIndex: Int, featureId: String, key: String, value: String) {
        prefs(context, slotIndex).edit().putString("$featureId.$key", value).apply()
    }

    fun getInt(context: Context, slotIndex: Int, featureId: String, key: String, default: Int): Int =
        prefs(context, slotIndex).getInt("$featureId.$key", default)

    fun setInt(context: Context, slotIndex: Int, featureId: String, key: String, value: Int) {
        prefs(context, slotIndex).edit().putInt("$featureId.$key", value).apply()
    }

    fun getBoolean(context: Context, slotIndex: Int, featureId: String, key: String, default: Boolean): Boolean =
        prefs(context, slotIndex).getBoolean("$featureId.$key", default)

    fun setBoolean(context: Context, slotIndex: Int, featureId: String, key: String, value: Boolean) {
        prefs(context, slotIndex).edit().putBoolean("$featureId.$key", value).apply()
    }
}
