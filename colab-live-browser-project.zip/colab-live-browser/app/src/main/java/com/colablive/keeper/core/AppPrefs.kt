package com.colablive.keeper.core

import android.content.Context
import android.content.SharedPreferences

/**
 * QUAN TRỌNG — namespace lưu trữ theo HỒ SƠ, không theo SỐ KHE:
 * Trước đây mọi key được đặt tên "${slotIndex}_$key" — nghĩa là dữ liệu gắn
 * cứng vào SỐ KHE cố định (0-3), không phải vào 1 "hồ sơ" độc lập di động
 * được như hồ sơ trình duyệt trên PC — ĐÚNG NHƯ TÀI LIỆU GỐC (mục 2.4) đã
 * yêu cầu "gán profile (tên tự đặt, không giới hạn số lượng) vào khe" chứ
 * không phải cấu hình dính chết vào khe.
 *
 * Sửa: mọi key giờ đặt tên theo "${ProfileSlots.getSlotAssignment(context,
 * slotIndex)}_$key" — tức TÊN HỒ SƠ đang được gán cho khe đó tại thời điểm
 * gọi, không phải bản thân số khe. Nếu khe chưa gán hồ sơ nào, tự động dùng
 * 1 namespace RIÊNG BIỆT của chính khe đó (không dùng chung với khe khác —
 * xem `ProfileSlots.defaultNamespaceForSlot`) nên hành vi mặc định (chưa ai
 * đặt tên gì) giữ NGUYÊN như trước: 4 khe vẫn cô lập nhau hoàn toàn.
 *
 * Vì đây là 1 điểm trung tâm duy nhất, MỌI nơi khác trong app gọi
 * AppPrefs.getXxx/setXxx(context, slotIndex, ...) đều tự động chuyển sang
 * cô lập-theo-hồ-sơ mà KHÔNG cần sửa gì thêm ở nơi gọi.
 */
object AppPrefs {
    private const val PREFS_NAME = "live_browser_prefs"

    private fun prefs(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    /** "Số khe" -> "tên hồ sơ đang gán cho khe đó" — đây là bước dịch DUY
     * NHẤT cần thêm để biến cô lập-theo-khe thành cô lập-theo-hồ-sơ thật. */
    private fun namespace(context: Context, slotIndex: Int): String =
        ProfileSlots.getSlotAssignment(context, slotIndex)

    fun getString(context: Context?, slotIndex: Int, key: String, default: String): String {
        val ctx = context ?: return default
        return prefs(ctx).getString("${namespace(ctx, slotIndex)}_$key", default) ?: default
    }

    fun getString(context: Context?, slotIndex: Int, featureId: String, key: String, default: String): String =
        getString(context, slotIndex, "$featureId:$key", default)

    fun setString(context: Context, slotIndex: Int, key: String, value: String) {
        prefs(context).edit().putString("${namespace(context, slotIndex)}_$key", value).apply()
    }

    fun setString(context: Context, slotIndex: Int, featureId: String, key: String, value: String) =
        setString(context, slotIndex, "$featureId:$key", value)

    fun getInt(context: Context?, slotIndex: Int, key: String, default: Int): Int {
        val ctx = context ?: return default
        return prefs(ctx).getInt("${namespace(ctx, slotIndex)}_$key", default)
    }

    fun getInt(context: Context?, slotIndex: Int, featureId: String, key: String, default: Int): Int =
        getInt(context, slotIndex, "$featureId:$key", default)

    fun setInt(context: Context, slotIndex: Int, key: String, value: Int) {
        prefs(context).edit().putInt("${namespace(context, slotIndex)}_$key", value).apply()
    }

    fun setInt(context: Context, slotIndex: Int, featureId: String, key: String, value: Int) =
        setInt(context, slotIndex, "$featureId:$key", value)

    fun getBoolean(context: Context, slotIndex: Int, key: String, default: Boolean): Boolean {
        return prefs(context).getBoolean("${namespace(context, slotIndex)}_$key", default)
    }

    fun getBoolean(context: Context, slotIndex: Int, featureId: String, key: String, default: Boolean): Boolean =
        getBoolean(context, slotIndex, "$featureId:$key", default)

    fun setBoolean(context: Context, slotIndex: Int, key: String, value: Boolean) {
        prefs(context).edit().putBoolean("${namespace(context, slotIndex)}_$key", value).apply()
    }

    fun setBoolean(context: Context, slotIndex: Int, featureId: String, key: String, value: Boolean) =
        setBoolean(context, slotIndex, "$featureId:$key", value)

    /** Xoá dữ liệu của HỒ SƠ đang gán cho khe này (không xoá theo số khe). */
    fun clearSlot(context: Context, slotIndex: Int) {
        val ns = namespace(context, slotIndex)
        val editor = prefs(context).edit()
        prefs(context).all.keys.filter { it.startsWith("${ns}_") }.forEach { key ->
            editor.remove(key)
        }
        editor.apply()
    }
}
