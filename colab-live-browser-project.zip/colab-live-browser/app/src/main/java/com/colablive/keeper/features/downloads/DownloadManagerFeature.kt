package com.colablive.keeper.features.downloads

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AlertDialog
import com.colablive.keeper.core.AppPrefs
import com.colablive.keeper.core.BrowserFeature
import com.colablive.keeper.core.DebugLog
// import org.schabi.newpipe.extractor.ServiceList
// import org.schabi.newpipe.extractor.stream.StreamInfo
// import org.schabi.newpipe.extractor.playlist.PlaylistInfo
import java.util.concurrent.Executors
import android.webkit.URLUtil
import com.colablive.keeper.features.downloads.StreamSniffer


/**
 * Download Manager v3.0 — UI giống IDM với multi-thread + pause/resume.
 */
class DownloadManagerFeature : BrowserFeature {

    override val id = "download_manager"
    override val displayName = "📥 Download Manager"

    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var downloadEngine: DownloadEngine
    private val handler = Handler(Looper.getMainLooper())

    override fun isEnabled(context: Context, slotIndex: Int): Boolean {
        return AppPrefs.getBoolean(context, slotIndex, "$id:enabled", true)
    }

    override fun setEnabled(context: Context, slotIndex: Int, enabled: Boolean) {
        AppPrefs.setBoolean(context, slotIndex, "$id:enabled", enabled)
    }

    override fun onPageLoaded(context: Context, slotIndex: Int, url: String) {}
    override fun onPageLoadError(context: Context, slotIndex: Int, url: String, errorCode: Int) {}
    override fun onDropFile(context: Context, slotIndex: Int, uri: Uri, mimeType: String?) {}

    fun initEngine(context: Context) {
        if (!::downloadEngine.isInitialized) {
            downloadEngine = DownloadEngine(context)
        }
    }

    fun catchDownload(context: Context, url: String, fileName: String? = null) {
        initEngine(context)
        val actualFileName = fileName ?: url.substringAfterLast("/").takeIf { it.isNotEmpty() } ?: "download"

        if (isYouTubeUrl(url)) {
            if (isYouTubePlaylist(url)) {
                downloadYouTubePlaylist(context, url)
            } else {
                downloadYouTube(context, url)
            }
        } else {
            downloadEngine.startDownload(url, actualFileName)
        }
        DebugLog.log("Download caught: $actualFileName")
    }

    private fun isYouTubeUrl(url: String) = url.contains("youtube.com") || url.contains("youtu.be")
    private fun isYouTubePlaylist(url: String) = url.contains("playlist?list=")

    // NewPipeExtractor commented - // NewPipeExtractor commented - // NewPipeExtractor commented - fun downloadYouTube(context: Context, videoUrl: String) {
    //     //     //         initEngine(context)
        executor.execute {
            try {
                val service = ServiceList.YouTube
                val streamInfo = StreamInfo.getInfo(service, videoUrl)
                val bestVideo = streamInfo.videoStreams.maxByOrNull { it.resolution?.replace("p", "")?.toIntOrNull() ?: 0 }
                val bestAudio = streamInfo.audioStreams.maxByOrNull { it.averageBitrate }
                val downloadUrl = bestVideo?.url ?: bestAudio?.url
                val fileName = "${streamInfo.name}.mp4".replace(Regex("[\\/:*?\"<>|]"), "_")

                if (downloadUrl != null) {
                    downloadEngine.startDownload(downloadUrl, fileName)
                    DebugLog.log("YouTube: ${streamInfo.name} (${bestVideo?.resolution ?: "audio"})")
                }
            } catch (e: Exception) {
                DebugLog.log("YouTube error: ${e.message}")
            }
        }
    }

    // NewPipeExtractor commented - // NewPipeExtractor commented - // NewPipeExtractor commented - fun downloadYouTubePlaylist(context: Context, playlistUrl: String) {
    //     //     //         initEngine(context)
        executor.execute {
            try {
                val playlistInfo = PlaylistInfo.getInfo(ServiceList.YouTube, playlistUrl)
                DebugLog.log("Playlist: ${playlistInfo.name} — ${playlistInfo.streamCount} videos")
                playlistInfo.relatedItems?.forEach { item ->
                    item.url?.let { downloadYouTube(context, it) }
                }
            } catch (e: Exception) {
                DebugLog.log("Playlist error: ${e.message}")
            }
        }
    }

    override fun buildSettingsView(context: Context, slotIndex: Int): View {
        initEngine(context)
        val scrollView = ScrollView(context)
        val container = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 16, 16, 16)
        }

        container.addView(Switch(context).apply {
            text = "Bật Download Manager"
            isChecked = isEnabled(context, slotIndex)
            setOnCheckedChangeListener { _, checked -> setEnabled(context, slotIndex, checked) }
        })

        container.addView(Switch(context).apply {
            text = "Hỗ trợ YouTube"
            isChecked = AppPrefs.getBoolean(context, slotIndex, "$id:youtube", true)
            setOnCheckedChangeListener { _, checked ->
                AppPrefs.setBoolean(context, slotIndex, "$id:youtube", checked)
            }
        })

        container.addView(Switch(context).apply {
            text = "Hỗ trợ Playlist"
            isChecked = AppPrefs.getBoolean(context, slotIndex, "$id:playlist", false)
            setOnCheckedChangeListener { _, checked ->
                AppPrefs.setBoolean(context, slotIndex, "$id:playlist", checked)
            }
        })

        container.addView(Button(context).apply {
            text = "📋 Xem danh sách download"
            setOnClickListener { showDownloadList(context) }
        })

        container.addView(Button(context).apply {
            text = "🧪 Test tải YouTube"
            setOnClickListener {
                val editText = EditText(context).apply {
                    hint = "URL YouTube"
                    setText("https://www.youtube.com/watch?v=dQw4w9WgXcQ")
                }
                AlertDialog.Builder(context)
                    .setTitle("Tải YouTube")
                    .setView(editText)
                    .setPositiveButton("Tải") { _, _ ->
                        val url = editText.text.toString()
                        if (url.contains("playlist")) downloadYouTubePlaylist(context, url)
                        else downloadYouTube(context, url)
                    }
                    .setNegativeButton("Huỷ", null)
                    .show()
            }
        })

        scrollView.addView(container)
        return scrollView
    }

    private fun showDownloadList(context: Context) {
        val downloads = downloadEngine.getAllDownloads()
        if (downloads.isEmpty()) {
            AlertDialog.Builder(context)
                .setTitle("Downloads")
                .setMessage("Chưa có download nào")
                .setPositiveButton("Đóng", null)
                .show()
            return
        }

        val scrollView = ScrollView(context)
        val container = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 16, 16, 16)
        }

        downloads.forEach { task ->
            container.addView(createDownloadItemView(context, task))
        }

        scrollView.addView(container)
        AlertDialog.Builder(context)
            .setTitle("Downloads (${downloads.size})")
            .setView(scrollView)
            .setPositiveButton("Đóng", null)
            .show()
    }

    private fun createDownloadItemView(context: Context, task: DownloadEngine.DownloadTask): View {
        val card = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 12, 16, 12)
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                setMargins(0, 8, 0, 8)
            }
            setBackgroundColor(android.graphics.Color.parseColor("#F5F5F5"))
        }

        val nameText = TextView(context).apply {
            text = task.fileName
            textSize = 14f
            setTextColor(android.graphics.Color.BLACK)
            maxLines = 1
        }
        card.addView(nameText)

        val progressBar = ProgressBar(context, null, android.R.attr.progressBarStyleHorizontal).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 8).apply { setMargins(0, 8, 0, 8) }
            max = 100
            progress = 0
        }
        card.addView(progressBar)

        val statusText = TextView(context).apply {
            text = "Đang chờ..."
            textSize = 12f
            setTextColor(android.graphics.Color.GRAY)
        }
        card.addView(statusText)

        val buttonRow = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
        val pauseBtn = Button(context).apply {
            text = "⏸️"
            setOnClickListener {
                if (downloadEngine.isPaused(task.id)) {
                    downloadEngine.resumeDownload(task.id)
                    text = "⏸️"
                } else {
                    downloadEngine.pauseDownload(task.id)
                    text = "▶️"
                }
            }
        }
        val cancelBtn = Button(context).apply {
            text = "❌"
            setOnClickListener {
                downloadEngine.cancelDownload(task.id)
                statusText.text = "Đã huỷ"
            }
        }
        buttonRow.addView(pauseBtn)
        buttonRow.addView(cancelBtn)
        card.addView(buttonRow)

        downloadEngine.addProgressListener(task.id) { progress, downloaded, total ->
            handler.post {
                progressBar.progress = progress
                val dlMB = downloaded / (1024 * 1024)
                val totalMB = if (total > 0) total / (1024 * 1024) else 0
                statusText.text = "$progress% — ${dlMB}MB / ${totalMB}MB"
            }
        }

        downloadEngine.addStatusListener(task.id) { status ->
            handler.post {
                statusText.text = when (status) {
                    DownloadEngine.DownloadStatus.PENDING -> "⏳ Chờ"
                    DownloadEngine.DownloadStatus.RUNNING -> "⏳ Đang tải"
                    DownloadEngine.DownloadStatus.PAUSED -> "⏸️ Tạm dừng"
                    DownloadEngine.DownloadStatus.COMPLETED -> "✅ Xong"
                    DownloadEngine.DownloadStatus.FAILED -> "❌ Lỗi"
                    DownloadEngine.DownloadStatus.CANCELLED -> "🚫 Huỷ"
                }
            }
        }

        return card
    }

    fun release() {
        if (::downloadEngine.isInitialized) downloadEngine.shutdown()
        executor.shutdown()
    }

    // ===== YouTube Audio Download (MP3) =====

    // NewPipeExtractor commented - // NewPipeExtractor commented - // NewPipeExtractor commented - fun downloadYouTubeAudio(context: Context, videoUrl: String) {
    //     //     //         initEngine(context)
        executor.execute {
            try {
                val service = ServiceList.YouTube
                val streamInfo = StreamInfo.getInfo(service, videoUrl)

                // Chỉ lấy audio stream tốt nhất
                val bestAudio = streamInfo.audioStreams.maxByOrNull { it.averageBitrate }
                val downloadUrl = bestAudio?.url

                // Đổi tên file thành .mp3
                val fileName = "${streamInfo.name}.mp3".replace(Regex("[\\/:*?"<>|]"), "_")

                if (downloadUrl != null) {
                    downloadEngine.startDownload(downloadUrl, fileName)
                    DebugLog.log("YouTube Audio: ${streamInfo.name} (${bestAudio?.averageBitrate}bps)")
                } else {
                    DebugLog.log("YouTube Audio: Không tìm thấy audio stream")
                }
            } catch (e: Exception) {
                DebugLog.log("YouTube Audio error: ${e.message}")
            }
        }
    }

    // ===== Playlist UI — Chọn video để tải =====

    fun showPlaylistDialog(context: Context, playlistUrl: String) {
        initEngine(context)
        executor.execute {
            try {
                val playlistInfo = PlaylistInfo.getInfo(ServiceList.YouTube, playlistUrl)
                val items = playlistInfo.relatedItems?.take(50) ?: emptyList()

                handler.post {
                    val scrollView = ScrollView(context)
                    val container = LinearLayout(context).apply {
                        orientation = LinearLayout.VERTICAL
                        setPadding(16, 16, 16, 16)
                    }

                    container.addView(TextView(context).apply {
                        text = "${playlistInfo.name} — ${items.size} videos"
                        textSize = 18f
                        setTextColor(android.graphics.Color.BLACK)
                        setPadding(0, 0, 0, 16)
                    })

                    // Nút tải tất cả
                    container.addView(Button(context).apply {
                        text = "⬇️ Tải TẤT CẢ (Audio MP3)"
                        setOnClickListener {
                            items.forEach { item ->
                                item.url?.let { downloadYouTubeAudio(context, it) }
                            }
                            Toast.makeText(context, "Đang tải ${items.size} video...", Toast.LENGTH_SHORT).show()
                        }
                    })

                    // Danh sách từng video
                    items.forEachIndexed { index, item ->
                        val itemLayout = LinearLayout(context).apply {
                            orientation = LinearLayout.HORIZONTAL
                            setPadding(8, 8, 8, 8)
                            gravity = android.view.Gravity.CENTER_VERTICAL
                        }

                        val infoText = TextView(context).apply {
                            text = "${index + 1}. ${item.name}"
                            textSize = 14f
                            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                            maxLines = 2
                        }

                        val videoBtn = Button(context).apply {
                            text = "🎬"
                            textSize = 12f
                            setOnClickListener {
                                item.url?.let { downloadYouTube(context, it) }
                            }
                        }

                        val audioBtn = Button(context).apply {
                            text = "🎵"
                            textSize = 12f
                            setOnClickListener {
                                item.url?.let { downloadYouTubeAudio(context, it) }
                            }
                        }

                        itemLayout.addView(infoText)
                        itemLayout.addView(videoBtn)
                        itemLayout.addView(audioBtn)
                        container.addView(itemLayout)
                    }

                    scrollView.addView(container)
                    AlertDialog.Builder(context)
                        .setTitle("Playlist YouTube")
                        .setView(scrollView)
                        .setPositiveButton("Đóng", null)
                        .show()
                }
            } catch (e: Exception) {
                DebugLog.log("Playlist UI error: ${e.message}")
                handler.post {
                    Toast.makeText(context, "Lỗi playlist: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    // ===== Test Leak UI =====

    fun showLeakTestDialog(context: Context, slotIndex: Int, engine: GeckoViewEngine) {
        val detector = CookieLeakDetector(context)

        AlertDialog.Builder(context)
            .setTitle("🔍 Test Cookie Leak")
            .setMessage("Slot $slotIndex sẽ được kiểm tra xem có thấy cookie của slot khác không.")
            .setPositiveButton("Chạy test") { _, _ ->
                Toast.makeText(context, "Đang chạy test...", Toast.LENGTH_SHORT).show()

                detector.runFullTest(slotIndex, engine) { isLeak, detail ->
                    handler.post {
                        val message = if (isLeak) {
                            "⚠️ PHÁT HIỆN LEAK!\n$detail\n\ncontextId KHÔNG hoạt động đúng."
                        } else {
                            "✅ KHÔNG phát hiện leak.\n$detail\n\ncontextId hoạt động bình thường."
                        }

                        AlertDialog.Builder(context)
                            .setTitle("Kết quả test")
                            .setMessage(message)
                            .setPositiveButton("OK", null)
                            .show()
                    }
                }
            }
            .setNegativeButton("Huỷ", null)
            .show()
    }

    // ===== IDM-like UI =====

    fun showIDMDialog(context: Context) {
        initEngine(context)
        IDMDownloadDialog(context, downloadEngine).show()
    }

    // ===== Auto Sniff from Web Page =====

    private var streamSniffer: StreamSniffer? = null

    fun sniffPage(context: Context, html: String, baseUrl: String): List<StreamSniffer.StreamLink> {
        if (streamSniffer == null) {
            streamSniffer = StreamSniffer(context)
        }
        return streamSniffer!!.sniffFromHtml(html, baseUrl)
    }

    fun showSniffedLinksDialog(context: Context, links: List<StreamSniffer.StreamLink>) {
        if (links.isEmpty()) {
            Toast.makeText(context, "Không tìm thấy link media nào.", Toast.LENGTH_SHORT).show()
            return
        }

        val scrollView = ScrollView(context)
        val container = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 16, 16, 16)
        }

        container.addView(TextView(context).apply {
            text = "Tìm thấy ${links.size} link media"
            textSize = 18f
            setTextColor(android.graphics.Color.BLACK)
            setPadding(0, 0, 0, 16)
        })

        links.forEachIndexed { index, link ->
            val itemLayout = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(8, 8, 8, 8)
                gravity = android.view.Gravity.CENTER_VERTICAL
            }

            val infoText = TextView(context).apply {
                text = "${index + 1}. [${link.type.uppercase()}] ${link.title}\n${link.quality}"
                textSize = 13f
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                maxLines = 2
            }

            val downloadBtn = Button(context).apply {
                text = "⬇️"
                textSize = 12f
                setOnClickListener {
                    val fileName = URLUtil.guessFileName(link.url, null, null)
                    startDownload(context, link.url, fileName)
                    Toast.makeText(context, "Đang tải: ${link.title}", Toast.LENGTH_SHORT).show()
                }
            }

            itemLayout.addView(infoText)
            itemLayout.addView(downloadBtn)
            container.addView(itemLayout)
        }

        scrollView.addView(container)
        AlertDialog.Builder(context)
            .setTitle("🔗 Media Links Found")
            .setView(scrollView)
            .setPositiveButton("Đóng", null)
            .show()
    }


    // ===== Web Archive & Page Converter =====

    fun showWebArchiveDialog(context: Context, url: String, title: String, geckoView: org.mozilla.geckoview.GeckoView) {
        WebArchiveDialog(context, url, title, geckoView).show()
    }

    fun archivePage(context: Context, url: String, title: String, callback: (WebArchiver.ArchiveResult) -> Unit) {
        val archiver = WebArchiver(context)
        archiver.archivePage(url, title, callback)
    }

    fun convertToPdf(context: Context, url: String, fileName: String, callback: (PageConverter.ConvertResult) -> Unit) {
        val converter = PageConverter(context)
        converter.convertToPdf(url, fileName, callback)
    }

    fun convertToEpub(context: Context, title: String, author: String, html: String, callback: (PageConverter.ConvertResult) -> Unit) {
        val converter = PageConverter(context)
        converter.convertToEpub(title, author, html, callback)
    }


    // ===== Download Policy + Save Location =====

    private var downloadPolicy: DownloadPolicy? = null
    private var saveLocationDialog: SaveLocationDialog? = null

    /**
     * Kiểm tra policy trước khi tải.
     * Trả về: true = tải ngay, false = chặn, null = cần hỏi user
     */
    fun checkDownloadPolicy(context: Context, url: String): Boolean? {
        if (downloadPolicy == null) {
            downloadPolicy = DownloadPolicy(context)
        }
        return downloadPolicy!!.checkPolicy(url)
    }

    /**
     * Tải file với policy check + hỏi lưu ở đâu.
     */
    fun startDownloadWithPolicy(context: Context, url: String, suggestedFileName: String) {
        val policy = checkDownloadPolicy(context, url)

        when (policy) {
            true -> {
                // ALLOW — tải ngay
                startDownload(context, url, suggestedFileName)
                Toast.makeText(context, "Đang tải: $suggestedFileName", Toast.LENGTH_SHORT).show()
            }
            false -> {
                // BLOCK — chặn
                Toast.makeText(context, "⛔ Download bị chặn theo chính sách", Toast.LENGTH_SHORT).show()
                DebugLog.log("Download blocked by policy: $url")
            }
            null -> {
                // ASK — hỏi user
                if (saveLocationDialog == null) {
                    saveLocationDialog = SaveLocationDialog(context)
                }
                saveLocationDialog!!.show(url, suggestedFileName) { result ->
                    if (result.confirmed) {
                        // Tạo thư mục nếu chưa có
                        File(result.directory).mkdirs()
                        // Tải file
                        val downloadFeature = FeatureRegistry.all().filterIsInstance<DownloadManagerFeature>().firstOrNull()
                        downloadFeature?.initEngine(context)
                        downloadFeature?.downloadEngine?.startDownload(url, result.fileName)
                        Toast.makeText(context, "Đang tải: ${result.fileName}\nLưu vào: ${result.directory}", Toast.LENGTH_LONG).show()
                    } else if (result.directory == "BLOCK_DOMAIN") {
                        // Chặn domain
                        val domain = extractDomain(url)
                        downloadPolicy?.addRule(domain, DownloadPolicy.Policy.BLOCK)
                        Toast.makeText(context, "Đã chặn domain: $domain", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(context, "Đã huỷ tải", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }

    private fun extractDomain(url: String): String {
        return try {
            val uri = java.net.URI(url)
            uri.host ?: ""
        } catch (e: Exception) {
            ""
        }
    }

    /**
     * Hiển thị dialog cài đặt policy.
     */
    fun showPolicySettings(context: Context) {
        if (downloadPolicy == null) {
            downloadPolicy = DownloadPolicy(context)
        }

        val scrollView = ScrollView(context)
        val container = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
        }

        // Global policy
        container.addView(TextView(context).apply {
            text = "🌐 Chính sách toàn cục:"
            textSize = 16f
            setTextColor(Color.BLACK)
            setPadding(0, 0, 0, 16)
        })

        val globalGroup = RadioGroup(context).apply {
            orientation = RadioGroup.VERTICAL
        }

        val policies = listOf(
            DownloadPolicy.Policy.ASK to "❓ Hỏi trước khi tải (khuyến nghị)",
            DownloadPolicy.Policy.ALLOW_ALL to "✅ Tự động tải TẤT CẢ (nguy hiểm)",
            DownloadPolicy.Policy.BLOCK to "⛔ Chặn TẤT CẢ download"
        )

        val currentPolicy = downloadPolicy!!.getGlobalPolicy()
        policies.forEachIndexed { index, (policy, label) ->
            globalGroup.addView(RadioButton(context).apply {
                text = label
                id = index
                isChecked = policy == currentPolicy
            })
        }
        container.addView(globalGroup)

        // Domain rules
        container.addView(TextView(context).apply {
            text = "\n📋 Rules theo domain:"
            textSize = 16f
            setTextColor(Color.BLACK)
            setPadding(0, 16, 0, 16)
        })

        val rules = downloadPolicy!!.getRules()
        rules.forEach { rule ->
            val ruleText = when (rule.policy) {
                DownloadPolicy.Policy.ALLOW -> "✅"
                DownloadPolicy.Policy.BLOCK -> "⛔"
                else -> "❓"
            } + " ${rule.domain.ifEmpty { "(mặc định)" }} — ${rule.description}"

            container.addView(TextView(context).apply {
                text = ruleText
                textSize = 13f
                setTextColor(Color.DKGRAY)
                setPadding(16, 4, 16, 4)
            })
        }

        scrollView.addView(container)

        AlertDialog.Builder(context)
            .setTitle("⚙️ Cài đặt Download")
            .setView(scrollView)
            .setPositiveButton("Lưu") { _, _ ->
                val selected = policies[globalGroup.checkedRadioButtonId].first
                downloadPolicy!!.setGlobalPolicy(selected)
                Toast.makeText(context, "Đã lưu: ${selected.name}", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Huỷ", null)
            .show()
    }

}
