package com.colablive.keeper.features.downloads

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import com.colablive.keeper.core.AppPrefs
import com.colablive.keeper.core.BrowserFeature
import com.colablive.keeper.core.DebugLog

class DownloadManagerFeature : BrowserFeature {

    override val id = "download_manager"
    override val displayName = "📥 Download Manager"
    override val description = "Quản lý tải file với Android DownloadManager"

    private val activeDownloads = mutableMapOf<Long, String>()

    override fun isEnabled(context: Context, slotIndex: Int): Boolean = 
        AppPrefs.getBoolean(context, slotIndex, id, "enabled", true)

    override fun setEnabled(context: Context, slotIndex: Int, enabled: Boolean) =
        AppPrefs.setBoolean(context, slotIndex, id, "enabled", enabled)

    override fun onPageLoaded(context: Context, slotIndex: Int, url: String) {}
    override fun onPageLoadError(context: Context, slotIndex: Int, url: String, errorCode: Int) {}
    override fun onDropFile(context: Context, slotIndex: Int, uri: android.net.Uri, mimeType: String?) {}

    fun catchDownload(context: Context, url: String, fileName: String? = null) {
        val actualFileName = fileName ?: url.substringAfterLast("/").takeIf { it.isNotEmpty() } ?: "download"

        if (!DownloadPolicy.isAllowed(context, url)) {
            DebugLog.log("Download blocked by policy: $url")
            return
        }

        if (AppPrefs.getBoolean(context, 0, "download_ask_location", false)) {
            DownloadLocationPicker.show(context) { location ->
                startDownload(context, url, actualFileName, location)
            }
        } else {
            startDownload(context, url, actualFileName, Environment.DIRECTORY_DOWNLOADS)
        }
    }

    private fun startDownload(context: Context, url: String, fileName: String, location: String) {
        try {
            val request = DownloadManager.Request(Uri.parse(url)).apply {
                setTitle(fileName)
                setDescription("Đang tải...")
                setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                setDestinationInExternalPublicDir(location, fileName)
                allowScanningByMediaScanner()
            }

            val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            val downloadId = dm.enqueue(request)
            activeDownloads[downloadId] = fileName

            DebugLog.log("Download started: $fileName (ID: $downloadId)")
        } catch (e: Exception) {
            DebugLog.log("Download error: ${e.message}")
            Toast.makeText(context, "Lỗi tải: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    fun showDownloadList(context: Context) {
        val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        val query = DownloadManager.Query().setFilterByStatus(
            DownloadManager.STATUS_PENDING or DownloadManager.STATUS_RUNNING or DownloadManager.STATUS_PAUSED
        )
        val cursor = dm.query(query)

        val items = mutableListOf<String>()
        if (cursor.moveToFirst()) {
            do {
                val titleIdx = cursor.getColumnIndex(DownloadManager.COLUMN_TITLE)
                val statusIdx = cursor.getColumnIndex(DownloadManager.COLUMN_STATUS)
                val title = if (titleIdx >= 0) cursor.getString(titleIdx) else "Unknown"
                val status = if (statusIdx >= 0) cursor.getInt(statusIdx) else 0
                val statusText = when (status) {
                    DownloadManager.STATUS_PENDING -> "⏳ Chờ"
                    DownloadManager.STATUS_RUNNING -> "⏳ Đang tải"
                    DownloadManager.STATUS_PAUSED -> "⏸ Tạm dừng"
                    DownloadManager.STATUS_SUCCESSFUL -> "✅ Xong"
                    DownloadManager.STATUS_FAILED -> "❌ Lỗi"
                    else -> "?"
                }
                items.add("$title — $statusText")
            } while (cursor.moveToNext())
        }
        cursor.close()

        AlertDialog.Builder(context)
            .setTitle("Danh sách download")
            .setItems(items.toTypedArray(), null)
            .setPositiveButton("Đóng", null)
            .show()
    }

    override fun buildSettingsView(context: Context, slotIndex: Int): View {
        val container = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 16, 16, 16)
        }

        container.addView(Switch(context).apply {
            text = "Bật Download Manager"
            isChecked = isEnabled(context, slotIndex)
            setOnCheckedChangeListener { _, checked -> setEnabled(context, slotIndex, checked) }
        })

        container.addView(Switch(context).apply {
            text = "Hỏi vị trí lưu mỗi lần tải"
            isChecked = AppPrefs.getBoolean(context, 0, "download_ask_location", false)
            setOnCheckedChangeListener { _, checked ->
                AppPrefs.setBoolean(context, 0, "download_ask_location", checked)
            }
        })

        container.addView(Button(context).apply {
            text = "📋 Xem danh sách download"
            setOnClickListener { showDownloadList(context) }
        })

        container.addView(Button(context).apply {
            text = "🗑 Xóa lịch sử download"
            setOnClickListener {
                activeDownloads.clear()
                Toast.makeText(context, "Đã xóa", Toast.LENGTH_SHORT).show()
            }
        })

        return container
    }
}
