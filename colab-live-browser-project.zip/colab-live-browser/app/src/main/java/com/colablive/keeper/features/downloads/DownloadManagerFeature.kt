package com.colablive.keeper.features.downloads

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import android.view.View
import android.webkit.URLUtil
import com.colablive.keeper.core.BrowserEngine
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import com.colablive.keeper.core.AppPrefs
import com.colablive.keeper.core.BrowserFeature

/**
 * Tải file media trực tiếp (mp4/webm/mp3/jpg/pdf...) từ các trang web thường —
 * dùng android.app.DownloadManager, cách chuẩn của hệ thống, không cần quyền
 * WRITE_EXTERNAL_STORAGE trên Android 10+ (scoped storage tự xử lý).
 *
 * KHÔNG hỗ trợ tải YouTube — YouTube không phục vụ link trực tiếp, cố tình mã
 * hoá/phân mảnh stream để chặn đúng kiểu tải này. Xem README để biết hướng
 * tích hợp yt-dlp riêng cho trường hợp đó.
 */
object DownloadManagerFeature : BrowserFeature {

    override val id = "download_manager"
    override val displayName = "Download Manager"
    override val description =
        "Tự động bắt link tải file media trực tiếp (video/audio/ảnh/pdf) từ trang web thường. Không hỗ trợ YouTube (xem ghi chú riêng)."

    private const val KEY_ENABLED = "enabled"

    override fun isEnabled(context: Context, slotIndex: Int) = AppPrefs.getBoolean(context, slotIndex, id, KEY_ENABLED, true)
    override fun setEnabled(context: Context, slotIndex: Int, enabled: Boolean) =
        AppPrefs.setBoolean(context, slotIndex, id, KEY_ENABLED, enabled)

    // Áp dụng cho mọi trang, trừ chính YouTube (để tránh gây hiểu lầm là hỗ trợ tải YT)
    override fun matchesUrl(url: String?): Boolean =
        url != null && !url.contains("youtube.com") && !url.contains("youtu.be")

    /**
     * Gọi từ WebView.setDownloadListener khi trình duyệt gặp 1 link mà hệ
     * thống nhận diện là file cần tải (Content-Disposition: attachment, hoặc
     * mimetype không render được như video/mp4, audio/mpeg...).
     */
    fun enqueueDownload(
        context: Context,
        slotIndex: Int,
        url: String,
        userAgent: String?,
        contentDisposition: String?,
        mimeType: String?
    ) {
        try {
            val fileName = URLUtil.guessFileName(url, contentDisposition, mimeType)
            val request = DownloadManager.Request(Uri.parse(url)).apply {
                setMimeType(mimeType)
                addRequestHeader("User-Agent", userAgent)
                setDescription("Đang tải qua Live Browser")
                setTitle(fileName)
                setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName)
            }
            val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            dm.enqueue(request)
            Toast.makeText(context, "Đang tải: $fileName", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(context, "Không tải được: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    // Quét thẻ <video>/<source> trên trang, log ra Logcat để tham khảo — việc
    // tải thực tế chủ yếu qua setDownloadListener (đáng tin cậy hơn quét DOM
    // vì DOM có thể không phản ánh đúng URL stream thật).
    override fun onPageFinished(context: Context, slotIndex: Int, engine: BrowserEngine, url: String?) {
        if (!isEnabled(context, slotIndex)) return
        engine.evaluateJs(
            """
            (function() {
                var urls = [];
                document.querySelectorAll('video, source').forEach(function(el) {
                    if (el.src) urls.push(el.src);
                });
                return JSON.stringify(urls);
            })();
            """.trimIndent()
        )
    }

    override fun buildSettingsView(context: Context, slotIndex: Int): View {
        val padding = (16 * context.resources.displayMetrics.density).toInt()

        val enableSwitch = Switch(context).apply {
            text = "Bật $displayName"
            isChecked = isEnabled(context, slotIndex)
            setOnCheckedChangeListener { _, checked -> setEnabled(context, slotIndex, checked) }
        }

        val openDownloadsButton = Button(context).apply {
            text = "Mở danh sách file đã tải"
            setOnClickListener {
                context.startActivity(
                    Intent(DownloadManager.ACTION_VIEW_DOWNLOADS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }
        }

        val youtubeNote = TextView(context).apply {
            text = "Lưu ý: KHÔNG hỗ trợ tải video YouTube (kể cả playlist) qua cơ chế " +
                "này — YouTube cố tình mã hoá/chia nhỏ stream để chặn tải trực tiếp, " +
                "và ToS của họ cấm việc này. Xem README của project để biết hướng tích " +
                "hợp yt-dlp riêng nếu thực sự cần."
        }

        return LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(padding, padding, padding, padding)
            addView(TextView(context).apply { text = description })
            addView(enableSwitch)
            addView(openDownloadsButton)
            addView(youtubeNote)
        }
    }
}
