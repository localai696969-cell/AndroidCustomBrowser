package com.colablive.keeper.features.downloads

import android.content.Context
import android.net.Uri
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AlertDialog
import com.colablive.keeper.core.AppPrefs
import com.colablive.keeper.core.BrowserFeature
import com.colablive.keeper.core.DebugLog
import com.colablive.keeper.core.FeatureRegistry
import com.colablive.keeper.core.GeckoViewEngine
import com.colablive.keeper.core.CookieLeakDetector
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.playlist.PlaylistInfo
import java.util.concurrent.Executors
import android.webkit.URLUtil
import com.colablive.keeper.features.downloads.StreamSniffer
import java.io.File
import java.util.UUID


/**
 * Download Manager v3.0 — UI giống IDM với multi-thread + pause/resume.
 */
object DownloadManagerFeature : BrowserFeature {

    override val id = "download_manager"
    override val displayName = "📥 Download Manager"

    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var downloadEngine: DownloadEngine
    private val handler = Handler(Looper.getMainLooper())

    override fun isEnabled(context: Context, slotIndex: Int): Boolean {
        return AppPrefs.getBoolean(context, slotIndex, "$id:enabled", true)
    }

    override fun setEnabled(context: Context, slotIndex: Int, enabled: Boolean) {
        AppPrefs.setBoolean(context, slotIndex, "$id:enabled", enabled)
    }

    override fun onPageLoaded(context: Context, slotIndex: Int, url: String) {}
    override fun onPageLoadError(context: Context, slotIndex: Int, url: String, errorCode: Int) {}
    override fun onDropFile(context: Context, slotIndex: Int, uri: Uri, mimeType: String?) {}

    private var newPipeInited = false

    /**
     * BUG GỐC (xem chi tiết ở `NewPipeDownloaderImpl.kt`): `NewPipe.init()`
     * chưa từng được gọi ở bất kỳ đâu trong project trước phiên này — mọi
     * lệnh `StreamInfo.getInfo()`/`PlaylistInfo.getInfo()` chắc chắn lỗi.
     * Init 1 LẦN duy nhất mỗi tiến trình (mỗi khe là 1 tiến trình riêng,
     * `android:process=":slotN"` — nên đặt ở `initEngine()`, hàm luôn được
     * gọi trước khi bất kỳ chức năng download nào của khe đó chạy, thay vì
     * 1 nơi cố định — không có Application class riêng trong project này).
     */
    fun initEngine(context: Context) {
        if (!::downloadEngine.isInitialized) {
            downloadEngine = DownloadEngine(context)
        }
        if (!newPipeInited) {
            try {
                NewPipe.init(NewPipeDownloaderImpl.instance)
                newPipeInited = true
                DebugLog.log("NewPipeExtractor: init xong — trước đây CHƯA TỪNG được gọi (lý do gốc khiến tải YouTube luôn lỗi)")
            } catch (e: Exception) {
                DebugLog.log("NewPipeExtractor init lỗi: ${e.message}")
            }
        }
    }

    /**
     * Tải trực tiếp, không qua DownloadPolicy (dùng cho nút tải nhanh: link
     * sniff được, dialog tải đơn giản...). Muốn có bước hỏi/chặn theo policy,
     * dùng `startDownloadWithPolicy` thay vào đây.
     */
    fun startDownload(context: Context, url: String, fileName: String) {
        initEngine(context)
        downloadEngine.startDownload(url, fileName)
        DebugLog.log("Download started (no policy check): $fileName")
    }

    /**
     * Wrapper cho `DownloadEngine.startDownloadFromLocalFile()` — xem chú
     * thích gốc ở `GeckoViewEngine.onDownloadBodyReadyListener` (bản sửa
     * cho bug "download kẹt vài trăm byte" với file cần đăng nhập).
     */
    fun startDownloadFromLocalFile(context: Context, sourceFile: java.io.File, fileName: String) {
        initEngine(context)
        downloadEngine.startDownloadFromLocalFile(sourceFile, fileName)
        DebugLog.log("Download từ file cục bộ đã drain sẵn (có cookie thật): $fileName")
    }

    fun catchDownload(context: Context, url: String, fileName: String? = null, onYouTubeFailure: (() -> Unit)? = null) {
        initEngine(context)
        val actualFileName = fileName ?: url.substringAfterLast("/").takeIf { it.isNotEmpty() } ?: "download"

        if (isYouTubeUrl(url)) {
            if (isYouTubePlaylist(url)) {
                downloadYouTubePlaylist(context, url)
            } else {
                downloadYouTube(context, url, onYouTubeFailure)
            }
        } else {
            downloadEngine.startDownload(url, actualFileName)
        }
        DebugLog.log("Download caught: $actualFileName")
    }

    private fun isYouTubeUrl(url: String) = url.contains("youtube.com") || url.contains("youtu.be")
    private fun isYouTubePlaylist(url: String) = url.contains("playlist?list=")

    /**
     * BUG THẬT đã tra ra (log: "YouTube error: URL not accepted:
     * .../watch?v=X&list=RD...&start_radio=1&pp=..."): NewPipeExtractor có
     * xử lý ĐẶC BIỆT cho URL "Mix"/"Radio" tự động của YouTube
     * (`list=RD...`) — `StreamLinkHandlerFactory.acceptUrl()` TỪ CHỐI
     * thẳng URL dạng này vì nhận diện đó là link thuộc loại Mix/Radio
     * playlist, không phải video đơn thuần — dù ý định thật của người
     * dùng là tải ĐÚNG 1 video đang xem (không phải cả mix ngẫu nhiên vô
     * hạn của YouTube). `isYouTubePlaylist()` không bắt được trường hợp
     * này vì URL vẫn là `/watch?v=...`, không phải `/playlist?list=...`.
     *
     * Sửa: chuẩn hoá về ĐÚNG URL video sạch (`watch?v=ID`), bỏ hết
     * `list=`/`start_radio=`/`pp=`/các tham số theo dõi khác — trước khi
     * đưa cho NewPipeExtractor. Áp dụng ở TẤT CẢ nơi gọi `downloadYouTube`
     * (không chỉ `catchDownload`), vì menu "Tải video YouTube đang xem"
     * cũng lấy thẳng `engine.currentUrl()` — dính y hệt lỗi nếu người dùng
     * đang xem 1 video ra từ mix/radio tự động.
     */
    private fun normalizeYouTubeVideoUrl(url: String): String {
        val match = Regex("[?&]v=([a-zA-Z0-9_-]{11})").find(url)
        val videoId = match?.groupValues?.get(1)
        return if (videoId != null) "https://www.youtube.com/watch?v=$videoId" else url
    }

    /**
     * Ghép tên file tải xuống từ tiêu đề trang (đã có sẵn, đẹp) + đuôi file đoán
     * đúng — KHÔNG dùng URLUtil.guessFileName(link.url) làm tên chính, vì URL CDN
     * video thật (token/chữ ký dài) khiến hàm đó ra tên rác/vô nghĩa.
     */
    private fun buildFileNameFromLink(title: String, url: String, type: String): String {
        val ext = guessExtension(url, type)
        val sanitizedTitle = title.trim()
            .ifBlank { "download" }
            .replace(Regex("[\\\\/:*?\"<>|]"), "_")
            .take(120)
        return if (sanitizedTitle.endsWith(".$ext", ignoreCase = true)) sanitizedTitle else "$sanitizedTitle.$ext"
    }

    private fun guessExtension(url: String, type: String): String {
        val pathPart = url.substringBefore("?").substringAfterLast("/")
        val dotIndex = pathPart.lastIndexOf('.')
        if (dotIndex > 0) {
            val candidate = pathPart.substring(dotIndex + 1).lowercase()
            val knownExts = setOf(
                "mp4", "webm", "mkv", "avi", "mov", "flv", "m3u8", "mpd",
                "mp3", "aac", "ogg", "wav", "flac", "m4a"
            )
            if (candidate in knownExts) return candidate
        }
        return when (type) {
            "video" -> "mp4"
            "audio" -> "mp3"
            "hls" -> "m3u8"
            "dash" -> "mpd"
            else -> "bin"
        }
    }

    /**
     * BUG THẬT (người dùng báo "IDM không cho đổi tên khi tải" — đúng
     * nguyên nhân): hàm này trước đây gọi THẲNG `startDownload()` với tên
     * tự sinh, hoàn toàn bỏ qua `SaveLocationDialog` (dialog DUY NHẤT trong
     * app có ô đổi tên + chọn nơi lưu) — dialog đó chỉ được nối dây cho 1
     * luồng tải khác (`onDownloadRequestedListener`), không phải luồng
     * YouTube này. Sửa: lấy thông tin video xong (nền), quay lại main
     * thread hiện `SaveLocationDialog` với tên gợi ý = tên video thật, để
     * người dùng tự đổi tên/chọn nơi lưu trước khi tải, đúng như luồng tải
     * file thường.
     *
     * `onFailure` (MỚI): người dùng nhớ đúng — có bàn tới hướng "NewPipe
     * lỗi thì fallback sang Sniff Media" nhưng LÚC ĐÓ CHƯA THỰC SỰ NỐI DÂY
     * (người dùng chọn giữ NewPipe làm chính, không yêu cầu fallback tự
     * động ngay lúc đó) — đây là nguyên nhân thật của "bấm Sniff Media thủ
     * công trên trang YouTube không ra gì" (StreamSniffer chỉ regex tĩnh
     * trên HTML, không đọc được dữ liệu video YouTube vốn render bằng JS).
     * Giờ nối đúng: khi `StreamInfo.getInfo()` lỗi, gọi `onFailure` (nếu
     * có) THAY VÌ chỉ hiện Toast lỗi — để nơi gọi (MainActivity, có sẵn
     * `engine` để lấy HTML trang đang mở) tự kích hoạt Sniff Media làm
     * phương án 2. Hàm này (`DownloadManagerFeature`) không tự làm được vì
     * không có tham chiếu `engine` của khe hiện tại.
     */
    fun downloadYouTube(context: Context, videoUrl: String, onFailure: (() -> Unit)? = null) {
        initEngine(context)
        val mainHandler = Handler(Looper.getMainLooper())
        executor.execute {
            try {
                val service = ServiceList.YouTube
                val streamInfo = StreamInfo.getInfo(service, normalizeYouTubeVideoUrl(videoUrl))
                val bestVideo = streamInfo.videoStreams.maxByOrNull { it.resolution?.replace("p", "")?.toIntOrNull() ?: 0 }
                val bestAudio = streamInfo.audioStreams.maxByOrNull { it.averageBitrate }
                val downloadUrl = bestVideo?.url ?: bestAudio?.url
                val suggestedName = "${streamInfo.name}.mp4".replace(Regex("[\\\\/:*?\"<>|]"), "_")

                if (downloadUrl != null) {
                    mainHandler.post {
                        SaveLocationDialog(context).show(downloadUrl, suggestedName) { result ->
                            if (result.confirmed) {
                                downloadEngine.startDownload(
                                    downloadUrl, result.fileName,
                                    saveLocation = result.locationType,
                                    customPath = if (result.locationType == "custom") result.directory else null
                                )
                                DebugLog.log("YouTube: ${streamInfo.name} (${bestVideo?.resolution ?: "audio"})")
                            }
                        }
                    }
                } else {
                    mainHandler.post {
                        Toast.makeText(context, "NewPipeExtractor không tìm thấy luồng nào — thử phương án 2 (Sniff Media)...", Toast.LENGTH_SHORT).show()
                        if (onFailure != null) onFailure() else Toast.makeText(context, "Không có phương án dự phòng", Toast.LENGTH_SHORT).show()
                    }
                }
            } catch (e: Exception) {
                DebugLog.log("YouTube error: ${e.message}")
                mainHandler.post {
                    Toast.makeText(context, "NewPipeExtractor lỗi (${e.message}) — thử phương án 2 (Sniff Media, KHÔNG đảm bảo tìm được, vì trang YouTube dùng JS phức tạp)...", Toast.LENGTH_LONG).show()
                    if (onFailure != null) onFailure() else Toast.makeText(context, "Không có phương án dự phòng", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    /**
     * BUG THẬT đã sửa (tự phát hiện khi nối `downloadYouTube()` qua
     * `SaveLocationDialog` ở phần trước — hàm này gọi `downloadYouTube()`
     * cho TỪNG video trong playlist, nghĩa là playlist 20 video sẽ bật ra
     * 20 dialog SaveLocationDialog xếp chồng, không dùng được).
     *
     * Sửa đúng theo yêu cầu người dùng: lấy DANH SÁCH tiêu đề+URL trước
     * (việc NHẸ, NewPipeExtractor làm ổn định — chỉ đọc danh sách, không
     * cần giải mã cipher như lúc trích xuất stream thật), hiện hộp thoại
     * CHECKBOX cho người dùng tự chọn video nào muốn tải + chọn định dạng
     * (video/chỉ âm thanh) MỘT LẦN cho cả lô — đúng cách IDM PC làm, không
     * hỏi từng file một.
     */
    fun downloadYouTubePlaylist(context: Context, playlistUrl: String) {
        initEngine(context)
        val mainHandler = Handler(Looper.getMainLooper())
        executor.execute {
            try {
                val playlistInfo = PlaylistInfo.getInfo(ServiceList.YouTube, playlistUrl)
                val items = playlistInfo.relatedItems?.filter { it.url != null } ?: emptyList()
                DebugLog.log("Playlist: ${playlistInfo.name} — ${items.size} video")
                if (items.isEmpty()) {
                    mainHandler.post { Toast.makeText(context, "Playlist rỗng hoặc không đọc được danh sách", Toast.LENGTH_LONG).show() }
                    return@execute
                }
                mainHandler.post { showPlaylistSelectionDialog(context, playlistInfo.name ?: "Playlist", items) }
            } catch (e: Exception) {
                DebugLog.log("Playlist error: ${e.message}")
                mainHandler.post { Toast.makeText(context, "Lỗi đọc playlist: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }
    }

    private fun showPlaylistSelectionDialog(context: Context, playlistName: String, items: List<org.schabi.newpipe.extractor.InfoItem>) {
        val container = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 16, 32, 16)
        }

        val audioOnlySwitch = Switch(context).apply {
            text = "🎵 Chỉ tải âm thanh (áp dụng cho toàn bộ các video đã chọn)"
        }
        container.addView(audioOnlySwitch)

        val selectAllBtn = Button(context).apply { text = "Chọn tất cả" }
        val selectNoneBtn = Button(context).apply { text = "Bỏ chọn tất cả" }
        val selectRow = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
        selectRow.addView(selectAllBtn)
        selectRow.addView(selectNoneBtn)
        container.addView(selectRow)

        val scrollView = ScrollView(context)
        val checklistLayout = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
        val checkboxes = mutableListOf<CheckBox>()
        items.forEach { item ->
            val cb = CheckBox(context).apply {
                text = item.name ?: item.url ?: "?"
                isChecked = true // mặc định chọn hết — người dùng tự bỏ bớt, giống IDM PC
            }
            checkboxes.add(cb)
            checklistLayout.addView(cb)
        }
        scrollView.addView(checklistLayout)
        scrollView.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 800)
        container.addView(scrollView)

        selectAllBtn.setOnClickListener { checkboxes.forEach { it.isChecked = true } }
        selectNoneBtn.setOnClickListener { checkboxes.forEach { it.isChecked = false } }

        AlertDialog.Builder(context)
            .setTitle("Chọn video muốn tải — $playlistName")
            .setView(container)
            .setPositiveButton("Tải") { _, _ ->
                val selected = items.filterIndexed { i, _ -> checkboxes[i].isChecked }
                if (selected.isEmpty()) {
                    Toast.makeText(context, "Chưa chọn video nào", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(context, "Đang tải ${selected.size} video — theo dõi tiến trình ở IDM Downloads", Toast.LENGTH_LONG).show()
                    downloadPlaylistItemsBatch(context, selected, audioOnlySwitch.isChecked)
                }
            }
            .setNegativeButton("Huỷ", null)
            .show()
    }

    /**
     * Tải hàng loạt KHÔNG hỏi tên/nơi lưu từng file (khác hẳn tải 1 video
     * đơn — hỏi từng cái là phi thực tế với playlist nhiều chục video,
     * đúng cách IDM PC/mọi tool tải playlist khác đều làm) — tự đặt tên
     * theo tiêu đề thật, lưu cố định vào Downloads. Chạy TUẦN TỰ (không
     * song song) để không làm quá tải executor 1 luồng dùng chung với các
     * tác vụ khác của DownloadManagerFeature.
     */
    private fun downloadPlaylistItemsBatch(context: Context, items: List<org.schabi.newpipe.extractor.InfoItem>, audioOnly: Boolean) {
        executor.execute {
            items.forEach { item ->
                val url = item.url ?: return@forEach
                try {
                    val streamInfo = StreamInfo.getInfo(ServiceList.YouTube, normalizeYouTubeVideoUrl(url))
                    val safeTitle = streamInfo.name.replace(Regex("[\\\\/:*?\"<>|]"), "_")
                    if (audioOnly) {
                        val bestAudio = streamInfo.audioStreams.maxByOrNull { it.averageBitrate }
                        val audioUrl = bestAudio?.url
                        if (audioUrl != null) {
                            val ext = when (bestAudio.format?.name?.uppercase()) {
                                "M4A", "AAC" -> "m4a"
                                "WEBMA", "OPUS", "WEBM" -> "opus"
                                "MP3" -> "mp3"
                                else -> "m4a"
                            }
                            downloadEngine.startDownload(audioUrl, "$safeTitle.$ext")
                        } else {
                            // Không có audio riêng — bỏ qua trong chế độ hàng
                            // loạt (KHÔNG tự ý chạy FFmpeg cho từng video
                            // playlist, quá chậm/tốn pin nếu nhiều video thiếu
                            // audio riêng cùng lúc — chỉ dùng FFmpeg cho tải
                            // đơn lẻ, người dùng chủ động chờ).
                            DebugLog.log("Playlist batch: '$safeTitle' không có audio riêng, bỏ qua (dùng tải audio đơn lẻ nếu cần FFmpeg)")
                        }
                    } else {
                        val bestVideo = streamInfo.videoStreams.maxByOrNull { it.resolution?.replace("p", "")?.toIntOrNull() ?: 0 }
                        val videoUrl = bestVideo?.url
                        if (videoUrl != null) {
                            downloadEngine.startDownload(videoUrl, "$safeTitle.mp4")
                        }
                    }
                } catch (e: Exception) {
                    DebugLog.log("Playlist batch lỗi cho $url: ${e.message}")
                }
            }
        }
    }

    override fun buildSettingsView(context: Context, slotIndex: Int): View {
        initEngine(context)
        val scrollView = ScrollView(context)
        val container = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 16, 16, 16)
        }

        container.addView(Switch(context).apply {
            text = "Bật Download Manager"
            isChecked = isEnabled(context, slotIndex)
            setOnCheckedChangeListener { _, checked -> setEnabled(context, slotIndex, checked) }
        })

        container.addView(Switch(context).apply {
            text = "Hỗ trợ YouTube"
            isChecked = AppPrefs.getBoolean(context, slotIndex, "$id:youtube", true)
            setOnCheckedChangeListener { _, checked ->
                AppPrefs.setBoolean(context, slotIndex, "$id:youtube", checked)
            }
        })

        container.addView(Switch(context).apply {
            text = "Hỗ trợ Playlist"
            isChecked = AppPrefs.getBoolean(context, slotIndex, "$id:playlist", false)
            setOnCheckedChangeListener { _, checked ->
                AppPrefs.setBoolean(context, slotIndex, "$id:playlist", checked)
            }
        })

        container.addView(Button(context).apply {
            text = "📋 Xem danh sách download"
            setOnClickListener { showDownloadList(context) }
        })

        container.addView(Button(context).apply {
            text = "🧪 Test tải YouTube"
            setOnClickListener {
                val editText = EditText(context).apply {
                    hint = "URL YouTube"
                    setText("https://www.youtube.com/watch?v=dQw4w9WgXcQ")
                }
                AlertDialog.Builder(context)
                    .setTitle("Tải YouTube")
                    .setView(editText)
                    .setPositiveButton("Tải") { _, _ ->
                        val url = editText.text.toString()
                        if (url.contains("playlist")) downloadYouTubePlaylist(context, url)
                        else downloadYouTube(context, url)
                    }
                    .setNegativeButton("Huỷ", null)
                    .show()
            }
        })

        scrollView.addView(container)
        return scrollView
    }

    private fun showDownloadList(context: Context) {
        val downloads = downloadEngine.getAllDownloads()
        if (downloads.isEmpty()) {
            AlertDialog.Builder(context)
                .setTitle("Downloads")
                .setMessage("Chưa có download nào")
                .setPositiveButton("Đóng", null)
                .show()
            return
        }

        val scrollView = ScrollView(context)
        val container = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 16, 16, 16)
        }

        downloads.forEach { task ->
            container.addView(createDownloadItemView(context, task))
        }

        scrollView.addView(container)
        AlertDialog.Builder(context)
            .setTitle("Downloads (${downloads.size})")
            .setView(scrollView)
            .setPositiveButton("Đóng", null)
            .show()
    }

    private fun createDownloadItemView(context: Context, task: DownloadEngine.DownloadTask): View {
        val card = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 12, 16, 12)
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                setMargins(0, 8, 0, 8)
            }
            setBackgroundColor(android.graphics.Color.parseColor("#F5F5F5"))
        }

        val nameText = TextView(context).apply {
            text = task.fileName
            textSize = 14f
            setTextColor(android.graphics.Color.BLACK)
            maxLines = 1
        }
        card.addView(nameText)

        val progressBar = ProgressBar(context, null, android.R.attr.progressBarStyleHorizontal).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 8).apply { setMargins(0, 8, 0, 8) }
            max = 100
            progress = 0
        }
        card.addView(progressBar)

        val statusText = TextView(context).apply {
            // BUG THẬT tìm được (người dùng chỉ đúng: đây là lỗi hệ thống,
            // không phải lỗi riêng của claude.ai hay Google Drive — xảy ra
            // với MỌI download, đúng như ảnh chụp màn hình cho thấy cả
            // config.json lẫn EbookLeechFeature.zip đều bị kẹt như nhau):
            // text trước đây gán CỨNG "Đang chờ..." mỗi lần dialog này được
            // vẽ, bất kể trạng thái THẬT của task lúc đó. addStatusListener()
            // phía dưới chỉ cập nhật khi có SỰ KIỆN ĐỔI TRẠNG THÁI MỚI xảy
            // ra SAU KHI dialog mở — nếu file đã tải xong hoặc đang tải dở
            // TRƯỚC KHI người dùng mở lại dialog "Xem danh sách download",
            // không còn sự kiện nào bắn ra nữa (trạng thái đã ổn định), nên
            // text bị kẹt ở "Đang chờ..." MÃI MÃI dù thực tế download có
            // thể đã xong hoặc đang chạy bình thường — đúng khớp ảnh chụp
            // "Downloads (4)" toàn bộ hiện "Đang chờ...".
            //
            // Sửa: tính text/progress BAN ĐẦU trực tiếp từ trạng thái THẬT
            // đang có sẵn trên chính object `task` (isComplete/isCancelled/
            // isPaused/downloadedBytes — đều đọc được đồng bộ ngay lúc vẽ
            // dialog, không cần đợi listener), thay vì gán cứng.
            val initialProgress = if (task.totalBytes > 0)
                ((task.downloadedBytes.get() * 100) / task.totalBytes).toInt().coerceIn(0, 100)
            else 0
            text = when {
                task.isCancelled.get() -> "🚫 Huỷ"
                task.isComplete.get() -> "✅ Xong"
                task.isPaused.get() -> "⏸️ Tạm dừng"
                task.downloadedBytes.get() > 0 -> "⏳ Đang tải — $initialProgress%"
                else -> "⏳ Chờ"
            }
            textSize = 12f
            setTextColor(android.graphics.Color.GRAY)
        }
        card.addView(statusText)
        // Đồng bộ luôn thanh tiến trình ban đầu theo state thật, KHÔNG chỉ
        // riêng chữ trạng thái — trước đây `progress = 0` cố định phía trên
        // cũng mắc lỗi y hệt.
        run {
            val initialProgress = if (task.totalBytes > 0)
                ((task.downloadedBytes.get() * 100) / task.totalBytes).toInt().coerceIn(0, 100)
            else 0
            progressBar.progress = initialProgress
        }

        val buttonRow = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
        val pauseBtn = Button(context).apply {
            text = "⏸️"
            setOnClickListener {
                if (downloadEngine.isPaused(task.id)) {
                    downloadEngine.resumeDownload(task.id)
                    text = "⏸️"
                } else {
                    downloadEngine.pauseDownload(task.id)
                    text = "▶️"
                }
            }
        }
        val cancelBtn = Button(context).apply {
            text = "❌"
            setOnClickListener {
                downloadEngine.cancelDownload(task.id)
                statusText.text = "Đã huỷ"
            }
        }
        buttonRow.addView(pauseBtn)
        buttonRow.addView(cancelBtn)
        card.addView(buttonRow)

        downloadEngine.addProgressListener(task.id) { progress, downloaded, total ->
            handler.post {
                progressBar.progress = progress
                val dlMB = downloaded / (1024 * 1024)
                val totalMB = if (total > 0) total / (1024 * 1024) else 0
                statusText.text = "$progress% — ${dlMB}MB / ${totalMB}MB"
            }
        }

        downloadEngine.addStatusListener(task.id) { status ->
            handler.post {
                statusText.text = when (status) {
                    DownloadEngine.DownloadStatus.PENDING -> "⏳ Chờ"
                    DownloadEngine.DownloadStatus.RUNNING -> "⏳ Đang tải"
                    DownloadEngine.DownloadStatus.PAUSED -> "⏸️ Tạm dừng"
                    DownloadEngine.DownloadStatus.COMPLETED -> "✅ Xong"
                    DownloadEngine.DownloadStatus.FAILED -> "❌ Lỗi"
                    DownloadEngine.DownloadStatus.CANCELLED -> "🚫 Huỷ"
                }
            }
        }

        return card
    }

    fun release() {
        if (::downloadEngine.isInitialized) downloadEngine.shutdown()
        executor.shutdown()
    }

    // ===== YouTube Audio Download (MP3) =====

    /**
     * Tải AUDIO-ONLY. Ưu tiên dùng audio stream RIÊNG mà chính YouTube
     * cung cấp qua NewPipeExtractor (nhẹ, nhanh, đa số video có sẵn). CHỈ
     * khi KHÔNG có audio stream riêng nào (hiếm nhưng có thật) mới
     * fallback: tải video đầy đủ vào cache tạm rồi dùng FFmpeg tách audio
     * cục bộ, xoá NGAY video tạm sau đó — đúng yêu cầu người dùng "chỉ
     * nặng APK, không để rác phình bộ nhớ" (xem AudioExtractor.kt).
     */
    fun downloadYouTubeAudio(context: Context, videoUrl: String) {
        initEngine(context)
        val mainHandler = Handler(Looper.getMainLooper())
        executor.execute {
            try {
                val streamInfo = StreamInfo.getInfo(ServiceList.YouTube, normalizeYouTubeVideoUrl(videoUrl))
                val bestAudio = streamInfo.audioStreams.maxByOrNull { it.averageBitrate }
                val audioUrl = bestAudio?.url
                val safeTitle = streamInfo.name.replace(Regex("[\\\\/:*?\"<>|]"), "_")

                if (audioUrl != null) {
                    // Đường CHÍNH: có sẵn audio stream riêng — dùng đúng
                    // đuôi file theo format THẬT (BUG CŨ đã sửa: trước đây
                    // luôn đặt cứng ".mp3" dù bên trong thực chất là AAC
                    // hoặc Opus — sai định dạng thật, chỉ đúng tên phần mở
                    // rộng chứ nội dung không phải mp3).
                    val ext = when (bestAudio.format?.name?.uppercase()) {
                        "M4A", "AAC" -> "m4a"
                        "WEBMA", "OPUS", "WEBM" -> "opus"
                        "MP3" -> "mp3"
                        else -> "m4a" // phổ biến nhất cho audio YouTube — an toàn nhất khi không rõ format
                    }
                    val suggestedName = "$safeTitle.$ext"
                    mainHandler.post {
                        SaveLocationDialog(context).show(audioUrl, suggestedName) { result ->
                            if (result.confirmed) {
                                downloadEngine.startDownload(
                                    audioUrl, result.fileName,
                                    saveLocation = result.locationType,
                                    customPath = if (result.locationType == "custom") result.directory else null
                                )
                                DebugLog.log("YouTube Audio (stream riêng, không cần FFmpeg): $safeTitle (${bestAudio.averageBitrate}bps, .$ext)")
                            }
                        }
                    }
                    return@execute
                }

                // FALLBACK — không có audio stream riêng, tải tạm video rồi tách bằng FFmpeg.
                val bestVideo = streamInfo.videoStreams.maxByOrNull { it.resolution?.replace("p", "")?.toIntOrNull() ?: 0 }
                val videoUrl = bestVideo?.url
                if (videoUrl == null) {
                    mainHandler.post { Toast.makeText(context, "Không tìm thấy audio lẫn video nào để tách", Toast.LENGTH_LONG).show() }
                    return@execute
                }
                DebugLog.log("YouTube Audio: video này KHÔNG có audio stream riêng — fallback tải tạm + FFmpeg tách (chậm hơn đường chính)")
                mainHandler.post { Toast.makeText(context, "Video này không có audio riêng — đang tải tạm để tách bằng FFmpeg...", Toast.LENGTH_LONG).show() }

                val tempVideoFile = File(context.cacheDir, "yt_audio_src_${UUID.randomUUID()}.mp4")
                val ok = downloadEngine.downloadFileBlocking(videoUrl, tempVideoFile)
                if (!ok) {
                    tempVideoFile.delete()
                    mainHandler.post { Toast.makeText(context, "Tải video tạm để tách audio thất bại", Toast.LENGTH_LONG).show() }
                    return@execute
                }

                mainHandler.post {
                    SaveLocationDialog(context).show(videoUrl, "$safeTitle.m4a") { result ->
                        if (result.confirmed) {
                            executor.execute {
                                val destTemp = File(context.cacheDir, "yt_audio_out_${UUID.randomUUID()}.m4a")
                                AudioExtractor.extractAudio(context, tempVideoFile, destTemp) { success, error ->
                                    try {
                                        if (success) {
                                            downloadEngine.finalizeLocalFile(
                                                destTemp, result.fileName, result.locationType,
                                                if (result.locationType == "custom") result.directory else null
                                            )
                                            mainHandler.post { Toast.makeText(context, "Đã tách xong: ${result.fileName}", Toast.LENGTH_SHORT).show() }
                                        } else {
                                            mainHandler.post { Toast.makeText(context, "Tách audio thất bại: $error", Toast.LENGTH_LONG).show() }
                                        }
                                    } finally {
                                        destTemp.delete() // đã copy sang đích thật (nếu thành công) — file tạm này không cần giữ nữa
                                    }
                                }
                            }
                        } else {
                            tempVideoFile.delete() // người dùng huỷ dialog — dọn ngay, không để rác
                        }
                    }
                }
            } catch (e: Exception) {
                DebugLog.log("YouTube Audio error: ${e.message}")
                mainHandler.post { Toast.makeText(context, "Lỗi tải audio YouTube: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }
    }

    // ===== Playlist UI — Chọn video để tải =====

    fun showPlaylistDialog(context: Context, playlistUrl: String) {
        initEngine(context)
        executor.execute {
            try {
                val playlistInfo = PlaylistInfo.getInfo(ServiceList.YouTube, playlistUrl)
                val items = playlistInfo.relatedItems?.take(50) ?: emptyList()

                handler.post {
                    val scrollView = ScrollView(context)
                    val container = LinearLayout(context).apply {
                        orientation = LinearLayout.VERTICAL
                        setPadding(16, 16, 16, 16)
                    }

                    container.addView(TextView(context).apply {
                        text = "${playlistInfo.name} — ${items.size} videos"
                        textSize = 18f
                        setTextColor(android.graphics.Color.BLACK)
                        setPadding(0, 0, 0, 16)
                    })

                    // Nút tải tất cả
                    container.addView(Button(context).apply {
                        text = "⬇️ Tải TẤT CẢ (Audio MP3)"
                        setOnClickListener {
                            items.forEach { item ->
                                item.url?.let { downloadYouTubeAudio(context, it) }
                            }
                            Toast.makeText(context, "Đang tải ${items.size} video...", Toast.LENGTH_SHORT).show()
                        }
                    })

                    // Danh sách từng video
                    items.forEachIndexed { index, item ->
                        val itemLayout = LinearLayout(context).apply {
                            orientation = LinearLayout.HORIZONTAL
                            setPadding(8, 8, 8, 8)
                            gravity = android.view.Gravity.CENTER_VERTICAL
                        }

                        val infoText = TextView(context).apply {
                            text = "${index + 1}. ${item.name}"
                            textSize = 14f
                            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                            maxLines = 2
                        }

                        val videoBtn = Button(context).apply {
                            text = "🎬"
                            textSize = 12f
                            setOnClickListener {
                                item.url?.let { downloadYouTube(context, it) }
                            }
                        }

                        val audioBtn = Button(context).apply {
                            text = "🎵"
                            textSize = 12f
                            setOnClickListener {
                                item.url?.let { downloadYouTubeAudio(context, it) }
                            }
                        }

                        itemLayout.addView(infoText)
                        itemLayout.addView(videoBtn)
                        itemLayout.addView(audioBtn)
                        container.addView(itemLayout)
                    }

                    scrollView.addView(container)
                    AlertDialog.Builder(context)
                        .setTitle("Playlist YouTube")
                        .setView(scrollView)
                        .setPositiveButton("Đóng", null)
                        .show()
                }
            } catch (e: Exception) {
                DebugLog.log("Playlist UI error: ${e.message}")
                handler.post {
                    Toast.makeText(context, "Lỗi playlist: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    // ===== Test Leak UI =====

    fun showLeakTestDialog(context: Context, slotIndex: Int, engine: GeckoViewEngine) {
        val detector = CookieLeakDetector(context)

        AlertDialog.Builder(context)
            .setTitle("🔍 Test Cookie Leak")
            .setMessage("Slot $slotIndex sẽ được kiểm tra xem có thấy cookie của slot khác không.")
            .setPositiveButton("Chạy test") { _, _ ->
                Toast.makeText(context, "Đang chạy test...", Toast.LENGTH_SHORT).show()

                detector.runFullTest(slotIndex, engine) { isLeak, detail ->
                    handler.post {
                        val message = if (isLeak) {
                            "⚠️ PHÁT HIỆN LEAK!\n$detail\n\ncontextId KHÔNG hoạt động đúng."
                        } else {
                            "✅ KHÔNG phát hiện leak.\n$detail\n\ncontextId hoạt động bình thường."
                        }

                        AlertDialog.Builder(context)
                            .setTitle("Kết quả test")
                            .setMessage(message)
                            .setPositiveButton("OK", null)
                            .show()
                    }
                }
            }
            .setNegativeButton("Huỷ", null)
            .show()
    }

    // ===== IDM-like UI =====

    fun showIDMDialog(context: Context) {
        initEngine(context)
        IDMDownloadDialog(context, downloadEngine).show()
    }

    // ===== Auto Sniff from Web Page =====

    private var streamSniffer: StreamSniffer? = null

    fun sniffPage(context: Context, html: String, baseUrl: String): List<StreamSniffer.StreamLink> {
        if (streamSniffer == null) {
            streamSniffer = StreamSniffer(context)
        }
        return streamSniffer!!.sniffFromHtml(html, baseUrl)
    }

    fun showSniffedLinksDialog(context: Context, links: List<StreamSniffer.StreamLink>) {
        if (links.isEmpty()) {
            Toast.makeText(context, "Không tìm thấy link media nào.", Toast.LENGTH_SHORT).show()
            return
        }

        val scrollView = ScrollView(context)
        val container = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 16, 16, 16)
        }

        container.addView(TextView(context).apply {
            text = "Tìm thấy ${links.size} link media"
            textSize = 18f
            setTextColor(android.graphics.Color.BLACK)
            setPadding(0, 0, 0, 16)
        })

        links.forEachIndexed { index, link ->
            val itemLayout = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(8, 8, 8, 8)
                gravity = android.view.Gravity.CENTER_VERTICAL
            }

            val infoText = TextView(context).apply {
                text = "${index + 1}. [${link.type.uppercase()}] ${link.title}\n${link.quality}"
                textSize = 13f
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                maxLines = 2
            }

            val downloadBtn = Button(context).apply {
                text = "⬇️"
                textSize = 12f
                setOnClickListener {
                    val suggestedName = buildFileNameFromLink(link.title, link.url, link.type)
                    // BUG THẬT (cùng nguyên nhân với downloadYouTube — xem
                    // chú thích ở đó): trước đây gọi thẳng startDownload(),
                    // bỏ qua SaveLocationDialog, không cho đổi tên/chọn nơi
                    // lưu. Sửa giống hệt cách đã sửa cho YouTube.
                    SaveLocationDialog(context).show(link.url, suggestedName) { result ->
                        if (result.confirmed) {
                            initEngine(context)
                            downloadEngine.startDownload(
                                link.url, result.fileName,
                                saveLocation = result.locationType,
                                customPath = if (result.locationType == "custom") result.directory else null
                            )
                            Toast.makeText(context, "Đang tải: ${result.fileName}", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            }

            itemLayout.addView(infoText)
            itemLayout.addView(downloadBtn)
            container.addView(itemLayout)
        }

        scrollView.addView(container)
        AlertDialog.Builder(context)
            .setTitle("🔗 Media Links Found")
            .setView(scrollView)
            .setPositiveButton("Đóng", null)
            .show()
    }


    // ===== Web Archive & Page Converter =====

    fun showWebArchiveDialog(context: Context, url: String, title: String, geckoView: org.mozilla.geckoview.GeckoView) {
        WebArchiveDialog(context, url, title, geckoView).show()
    }

    fun archivePage(context: Context, url: String, title: String, callback: (WebArchiver.ArchiveResult) -> Unit) {
        val archiver = WebArchiver(context)
        archiver.archivePage(url, title, callback)
    }

    fun convertToPdf(context: Context, url: String, fileName: String, callback: (PageConverter.ConvertResult) -> Unit) {
        val converter = PageConverter(context)
        converter.convertToPdf(url, fileName, callback)
    }

    fun convertToEpub(context: Context, title: String, author: String, html: String, callback: (PageConverter.ConvertResult) -> Unit) {
        val converter = PageConverter(context)
        converter.convertToEpub(title, author, html, callback)
    }


    // ===== Download Policy + Save Location =====

    private var downloadPolicy: DownloadPolicy? = null
    private var saveLocationDialog: SaveLocationDialog? = null

    /**
     * Kiểm tra policy trước khi tải.
     * Trả về: true = tải ngay, false = chặn, null = cần hỏi user
     */
    fun checkDownloadPolicy(context: Context, url: String): Boolean? {
        if (downloadPolicy == null) {
            downloadPolicy = DownloadPolicy(context)
        }
        return downloadPolicy!!.checkPolicy(url)
    }

    /**
     * Tải file với policy check + hỏi lưu ở đâu.
     */
    fun startDownloadWithPolicy(context: Context, url: String, suggestedFileName: String) {
        val policy = checkDownloadPolicy(context, url)

        when (policy) {
            true -> {
                // ALLOW — tải ngay
                startDownload(context, url, suggestedFileName)
                Toast.makeText(context, "Đang tải: $suggestedFileName", Toast.LENGTH_SHORT).show()
            }
            false -> {
                // BLOCK — chặn
                Toast.makeText(context, "⛔ Download bị chặn theo chính sách", Toast.LENGTH_SHORT).show()
                DebugLog.log("Download blocked by policy: $url")
            }
            null -> {
                // ASK — hỏi user
                if (saveLocationDialog == null) {
                    saveLocationDialog = SaveLocationDialog(context)
                }
                saveLocationDialog!!.show(url, suggestedFileName) { result ->
                    if (result.confirmed) {
                        // Tạo thư mục nếu chưa có
                        File(result.directory).mkdirs()
                        // Tải file
                        val downloadFeature = FeatureRegistry.all().filterIsInstance<DownloadManagerFeature>().firstOrNull()
                        downloadFeature?.initEngine(context)
                        val customPath = if (result.locationType == "custom") result.directory else null
                        downloadFeature?.downloadEngine?.startDownload(
                            url, result.fileName,
                            saveLocation = result.locationType,
                            customPath = customPath
                        )
                        Toast.makeText(context, "Đang tải: ${result.fileName}\nLưu vào: ${result.directory}", Toast.LENGTH_LONG).show()
                    } else if (result.directory == "BLOCK_DOMAIN") {
                        // Chặn domain
                        val domain = extractDomain(url)
                        downloadPolicy?.addRule(domain, DownloadPolicy.Policy.BLOCK)
                        Toast.makeText(context, "Đã chặn domain: $domain", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(context, "Đã huỷ tải", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }

    private fun extractDomain(url: String): String {
        return try {
            val uri = java.net.URI(url)
            uri.host ?: ""
        } catch (e: Exception) {
            ""
        }
    }

    /**
     * Hiển thị dialog cài đặt policy.
     */
    fun showPolicySettings(context: Context) {
        if (downloadPolicy == null) {
            downloadPolicy = DownloadPolicy(context)
        }

        val scrollView = ScrollView(context)
        val container = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
        }

        // Global policy
        container.addView(TextView(context).apply {
            text = "🌐 Chính sách toàn cục:"
            textSize = 16f
            setTextColor(Color.BLACK)
            setPadding(0, 0, 0, 16)
        })

        val globalGroup = RadioGroup(context).apply {
            orientation = RadioGroup.VERTICAL
        }

        val policies = listOf(
            DownloadPolicy.Policy.ASK to "❓ Hỏi trước khi tải (khuyến nghị)",
            DownloadPolicy.Policy.ALLOW_ALL to "✅ Tự động tải TẤT CẢ (nguy hiểm)",
            DownloadPolicy.Policy.BLOCK to "⛔ Chặn TẤT CẢ download"
        )

        val currentPolicy = downloadPolicy!!.getGlobalPolicy()
        policies.forEachIndexed { index, (policy, label) ->
            globalGroup.addView(RadioButton(context).apply {
                text = label
                id = index
                isChecked = policy == currentPolicy
            })
        }
        container.addView(globalGroup)

        // Domain rules
        container.addView(TextView(context).apply {
            text = "\n📋 Rules theo domain:"
            textSize = 16f
            setTextColor(Color.BLACK)
            setPadding(0, 16, 0, 16)
        })

        val rules = downloadPolicy!!.getRules()
        rules.forEach { rule ->
            val ruleText = when (rule.policy) {
                DownloadPolicy.Policy.ALLOW -> "✅"
                DownloadPolicy.Policy.BLOCK -> "⛔"
                else -> "❓"
            } + " ${rule.domain.ifEmpty { "(mặc định)" }} — ${rule.description}"

            container.addView(TextView(context).apply {
                text = ruleText
                textSize = 13f
                setTextColor(Color.DKGRAY)
                setPadding(16, 4, 16, 4)
            })
        }

        scrollView.addView(container)

        AlertDialog.Builder(context)
            .setTitle("⚙️ Cài đặt Download")
            .setView(scrollView)
            .setPositiveButton("Lưu") { _, _ ->
                val selected = policies[globalGroup.checkedRadioButtonId].first
                downloadPolicy!!.setGlobalPolicy(selected)
                Toast.makeText(context, "Đã lưu: ${selected.name}", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Huỷ", null)
            .show()
    }

}
