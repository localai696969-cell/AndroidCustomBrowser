package com.colablive.keeper.core

object BuildMarker {
    // BUG QUY TRÌNH đã tự nhận ra và sửa: suốt nhiều lượt sửa code trước
    // (icon Recent Apps, gán/bỏ gán hồ sơ, nút media 5-nút), VERSION này
    // chưa từng được tăng lên — khiến log debug trên máy thật KHÔNG THỂ
    // dùng để phân biệt "bản mới đã build/cài" hay "vẫn là bản cũ" (đúng
    // tình huống người dùng gặp: ảnh chụp mới cho thấy TẤT CẢ các sửa đổi
    // đều "như chưa từng được chỉnh sửa" — nút media vẫn 3 nút thay vì 5,
    // icon vẫn y hệt cũ — bằng chứng mạnh nhất là APK trên máy CHƯA được
    // build lại từ code mới, không phải code sai). Từ nay MỖI LẦN sửa
    // xong 1 lượt, PHẢI tăng version + cập nhật MARKER liệt kê đúng các
    // sửa đổi của lượt đó, để log `App init — slot=$slotIndex,
    // version=$VERSION` tự xác nhận được bản đang chạy là bản nào.
    const val VERSION = "6.6-shadowDomPasteFix-pinnedShortcuts"
    const val MARKER = "GeckoView + AutoBehavior + DNS + TimezoneSync + CookieLeakTest + IDM + StreamSniffer + WebArchive + PageConverter + DownloadPolicy + TaskIconBitmapFix + ReassignPendingFix + Media5Buttons + RelinquishTaskIdentityRemoved + AddonDialogSplit + ImportOverwriteAtomicFix + ExportSkippedFilesWarning + MediaCustomActionFix(Android13+) + SelfDiagnosticLogging + ImportForegroundServiceFix + MediaDiagnosticTabIdFix + MultiFileDragDropAndPickerFix + ImportExportUriGrantFlagFix + GeckoShutdownRaceDefensiveCatch + CrashBreadcrumbDiagnostic + PostAckSettleDelay + DeleteProfileFeature + ExportSafPickerBeforeCloseSlot + ExportNoCloseSlotRevert + ImportOverwriteDeleteCheckRetry + WalSafeExportConfirmed + LongerDeleteDelayForGeckoDir + ExportSummaryWithFilenames + PopupTabOpenerTracking + TabDragReorder + DetailedCrashBreadcrumb + RestartSlotBreadcrumb + TabThumbnails + TabGroups + OverwriteLongerDelay(4000ms) + MonacoDirectPasteTrigger(mục86.1, bỏ ClipboardEvent cho Monaco) + PasteDiagViaKotlinFollowup(khôngConsoleLog) + LargePasteBeforeinputDataTransferFix(mục86.2, event.dataTransfer thay vì event.data) + ChromeStyleNewTabPage(mục88, NewTabPage.kt + assets/new_tab, thay google.com) + HistoryExcludeFileScheme(mục88, tránh rác lịch sử từ trang Tab mới) + NewTabResourceSchemeFix(mục89, resource://android/assets/ thay file:///android_asset/ — GeckoView không hỗ trợ quy ước WebView) + PasteMonacoDetectionDiag(mục89, log typeof window.monaco + activeElement để biết vì sao Colab vẫn rơi về nhánh cũ) + IMEInsertTextBypassFix(mục90, beforeinput bắt thêm insertText/insertCompositionText — bàn phím ảo commitText không ra inputType insertFromPaste) + DragDropEntryDiag(mục90, log webkitGetAsEntry() từng item — rút lại kết luận mục86.3, kiểm chứng nghi vấn File System Entries API thay vì isTrusted chung chung) + ShadowDomPasteFix(mục91, xuyên shadow root lấy đúng activeElement thật — log xác nhận Colab đặt editor trong shadow-root-host) + PinnedShortcuts(mục91, dấu + ở Tab mới tự ghim/xoá shortcut, colablive:// scheme chặn ở onLoadRequest)"
    const val BUILD_DATE = "2026-09-26"
}
