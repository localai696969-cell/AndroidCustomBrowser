package com.colablive.keeper.core

/**
 * Đánh dấu bản build — MỖI LẦN Claude sửa code, phải đổi giá trị này. Dòng
 * này tự ghi vào Debug Log ngay lúc app mở (xem MainActivity.onCreate) —
 * mở app, vào Debug Log, xem dòng ĐẦU TIÊN (mới nhất) khớp đúng giá trị này
 * để BIẾT CHẮC đang chạy đúng bản mới, không cần đoán qua việc "có thấy
 * dòng log X hay không" (cách cũ dễ nhầm — nếu quên 1 log cụ thể, không có
 * nghĩa là toàn bộ code khác cũng cũ).
 */
object BuildMarker {
    const val LABEL = "BUILD-2026-07-19-a: guard onFilePrompt + mimeType fix"
}
