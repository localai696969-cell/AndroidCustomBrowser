package com.colablive.keeper.core

object BuildMarker {
    // BUG QUY TRÌNH đã tự nhận ra và sửa: suốt nhiều lượt sửa code trước
    // (icon Recent Apps, gán/bỏ gán hồ sơ, nút media 5-nút), VERSION này
    // chưa từng được tăng lên — khiến log debug trên máy thật KHÔNG THỂ
    // dùng để phân biệt "bản mới đã build/cài" hay "vẫn là bản cũ" (đúng
    // tình huống người dùng gặp: ảnh chụp mới cho thấy TẤT CẢ các sửa đổi
    // đều "như chưa từng được chỉnh sửa" — nút media vẫn 3 nút thay vì 5,
    // icon vẫn y hệt cũ — bằng chứng mạnh nhất là APK trên máy CHƯA được
    // build lại từ code mới, không phải code sai). Từ nay MỖI LẦN sửa
    // xong 1 lượt, PHẢI tăng version + cập nhật MARKER liệt kê đúng các
    // sửa đổi của lượt đó, để log `App init — slot=$slotIndex,
    // version=$VERSION` tự xác nhận được bản đang chạy là bản nào.
    const val VERSION = "5.1-multifile-fix"
    const val MARKER = "GeckoView + AutoBehavior + DNS + TimezoneSync + CookieLeakTest + IDM + StreamSniffer + WebArchive + PageConverter + DownloadPolicy + TaskIconBitmapFix + ReassignPendingFix + Media5Buttons + RelinquishTaskIdentityRemoved + AddonDialogSplit + ImportOverwriteAtomicFix + ExportSkippedFilesWarning + MediaCustomActionFix(Android13+) + SelfDiagnosticLogging + ImportForegroundServiceFix + MediaDiagnosticTabIdFix + MultiFileDragDropAndPickerFix"
    const val BUILD_DATE = "2026-09-01"
}
