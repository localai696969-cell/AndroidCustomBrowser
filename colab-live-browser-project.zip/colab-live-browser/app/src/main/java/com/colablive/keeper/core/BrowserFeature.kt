package com.colablive.keeper.core

import android.content.Context
import android.view.View

/**
 * Hợp đồng chung cho mọi tiện ích — mọi hàm đều nhận slotIndex tường minh,
 * để cấu hình (bật/tắt, chu kỳ, chế độ) độc lập thật sự theo từng khe, không
 * còn dùng chung 1 cấu hình cho cả app.
 */
interface BrowserFeature {
    val id: String
    val displayName: String
    val description: String

    fun isEnabled(context: Context, slotIndex: Int): Boolean
    fun setEnabled(context: Context, slotIndex: Int, enabled: Boolean)

    fun matchesUrl(url: String?): Boolean

    fun onPageFinished(context: Context, slotIndex: Int, engine: BrowserEngine, url: String?) {}
    fun onTick(context: Context, slotIndex: Int, engine: BrowserEngine, url: String?) {}

    fun accessibilityTargetTexts(context: Context, slotIndex: Int): List<String> = emptyList()
    fun intervalMinutes(context: Context, slotIndex: Int): Int = 20

    fun buildSettingsView(context: Context, slotIndex: Int): View
}
