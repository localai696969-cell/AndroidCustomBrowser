package com.colablive.keeper.core

import android.content.Context
import android.view.View

/**
 * Interface chung cho mọi tiện ích (feature) của trình duyệt.
 * Mỗi feature implement interface này, đăng ký vào FeatureRegistry.
 * Không đụng MainActivity hay engine cụ thể.
 */
interface BrowserFeature {
    /** ID duy nhất, dùng làm key SharedPreferences */
    val id: String

    /** Tên hiển thị trong UI */
    val displayName: String

    /** Kiểm tra feature có bật cho khe này không */
    fun isEnabled(context: Context, slotIndex: Int): Boolean

    /** Bật/tắt feature cho khe này */
    fun setEnabled(context: Context, slotIndex: Int, enabled: Boolean)

    /** 
     * Xử lý sự kiện từ engine (navigation, load, etc.)
     * Được gọi bởi MainActivity khi có sự kiện liên quan.
     */
    fun onPageLoaded(context: Context, slotIndex: Int, url: String)
    fun onPageLoadError(context: Context, slotIndex: Int, url: String, errorCode: Int)

    /** Xử lý khi user drop file vào browser (drag & drop) */
    fun onDropFile(context: Context, slotIndex: Int, uri: android.net.Uri, mimeType: String?)

    /** Xây dựng UI cấu hình cho feature này */
    fun buildSettingsView(context: Context, slotIndex: Int): View
}
