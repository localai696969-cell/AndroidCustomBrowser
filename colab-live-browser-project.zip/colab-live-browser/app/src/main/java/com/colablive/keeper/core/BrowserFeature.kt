package com.colablive.keeper.core

import android.content.Context
import android.view.View

interface BrowserFeature {
    val id: String
    val displayName: String
    val description: String get() = ""

    fun isEnabled(context: Context, slotIndex: Int): Boolean
    fun setEnabled(context: Context, slotIndex: Int, enabled: Boolean)

    fun onPageLoaded(context: Context, slotIndex: Int, url: String)
    fun onPageLoadError(context: Context, slotIndex: Int, url: String, errorCode: Int)
    fun onDropFile(context: Context, slotIndex: Int, uri: android.net.Uri, mimeType: String?)

    fun onTick(context: Context, slotIndex: Int) {}
    fun matchesUrl(url: String): Boolean = true
    fun accessibilityTargetTexts(context: Context, slotIndex: Int): List<String> = emptyList()
    fun intervalMinutes(context: Context, slotIndex: Int): Int = 20

    fun buildSettingsView(context: Context, slotIndex: Int): View
}
