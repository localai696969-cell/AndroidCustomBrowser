package com.colablive.keeper.features.media

import android.content.Context
import android.view.View
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import com.colablive.keeper.core.AppPrefs
import com.colablive.keeper.core.BrowserEngine
import com.colablive.keeper.core.BrowserFeature

/**
 * Giữ media (YouTube, v.v.) tiếp tục phát khi tắt màn hình hoặc chuyển
 * sang app khác.
 *
 * NGUYÊN NHÂN THẬT (đã kiểm tra code, không phải Android tự "kill" app):
 * hầu hết trình phát video web, kể cả YouTube, tự lắng nghe sự kiện
 * `visibilitychange` của trang và CHỦ ĐỘNG gọi `pause()` khi
 * `document.hidden` chuyển thành `true` — đây là hành vi JS của chính
 * trang web, không phải do GeckoView hay Android chặn phát media nền.
 *
 * App này đã có SẴN đúng kỹ thuật vá lỗi này — `ColabLiveKeeperFeature`
 * ghi đè `document.hidden`/`visibilityState` để luôn báo "visible" — nhưng
 * trước đây feature đó CHỈ áp dụng cho colab.research.google.com
 * (`matchesUrl`), không áp dụng cho trang nào khác. Feature này tổng quát
 * hoá đúng kỹ thuật đó cho MỌI trang, để dùng chung cho YouTube và các
 * trình phát media khác.
 */
object BackgroundMediaFeature : BrowserFeature {

    override val id = "background_media"
    override val displayName = "Phát media nền (giữ YouTube/video không tắt khi chuyển app)"
    override val description =
        "Chặn trang web tự tạm dừng video/audio khi tắt màn hình hoặc chuyển " +
        "sang app khác — bằng cách báo cho trang biết là vẫn đang \"hiển thị\" " +
        "(cùng kỹ thuật với Colab Live Keeper, nhưng áp dụng cho mọi trang " +
        "thay vì chỉ Colab)."

    private val keepPlayingScript = """
        (function() {
            if (window.__bgMediaPatched) {
                try {
                    document.dispatchEvent(new Event('visibilitychange'));
                    window.dispatchEvent(new Event('focus'));
                } catch (e) {}
                return;
            }
            window.__bgMediaPatched = true;
            try {
                Object.defineProperty(document, 'hidden', { get: function() { return false; }, configurable: true });
                Object.defineProperty(document, 'visibilityState', { get: function() { return 'visible'; }, configurable: true });
                document.hasFocus = function() { return true; };
            } catch (e) {}
            // 1 số trình phát (kể cả YouTube) tự pause khi nhận trực tiếp sự
            // kiện visibilitychange/blur/pagehide GỐC (không chỉ đọc thuộc
            // tính document.hidden) — chặn ở giai đoạn capture để JS của
            // trang không nhận được sự kiện gốc đó nữa.
            ['visibilitychange', 'blur', 'pagehide'].forEach(function(type) {
                document.addEventListener(type, function(e) { e.stopImmediatePropagation(); }, true);
                window.addEventListener(type, function(e) { e.stopImmediatePropagation(); }, true);
            });
            try {
                document.dispatchEvent(new Event('visibilitychange'));
                window.dispatchEvent(new Event('focus'));
            } catch (e) {}
        })();
    """.trimIndent()

    override fun isEnabled(context: Context, slotIndex: Int) =
        AppPrefs.getBoolean(context, slotIndex, id, "enabled", false)

    override fun setEnabled(context: Context, slotIndex: Int, enabled: Boolean) =
        AppPrefs.setBoolean(context, slotIndex, id, "enabled", enabled)

    // Khác ColabLiveKeeperFeature (chỉ khớp 1 domain) — feature này áp dụng
    // cho MỌI trang, vì video có thể ở bất kỳ site nào (YouTube, v.v.).
    override fun matchesUrl(url: String?): Boolean = !url.isNullOrBlank()

    override fun onPageFinished(context: Context, slotIndex: Int, engine: BrowserEngine, url: String?) {
        if (!isEnabled(context, slotIndex) || !matchesUrl(url)) return
        engine.evaluateJs(keepPlayingScript)
    }

    override fun onTick(context: Context, slotIndex: Int, engine: BrowserEngine, url: String?) {
        // An toàn thêm: YouTube điều hướng kiểu SPA (đổi video không load
        // lại document) đôi khi tự gắn lại listener riêng — chạy lại định
        // kỳ (mỗi lần tick, ~60s, xem MainActivity.featureTickRunnable) để
        // đảm bảo vẫn còn hiệu lực. window.__bgMediaPatched khiến phần vá
        // document.hidden không phải chạy lại (đã vá rồi), chỉ fire lại
        // sự kiện để "đánh thức" listener nào mới gắn thêm.
        if (!isEnabled(context, slotIndex) || !matchesUrl(url)) return
        engine.evaluateJs(keepPlayingScript)
    }

    override fun buildSettingsView(context: Context, slotIndex: Int): View {
        val padding = (16 * context.resources.displayMetrics.density).toInt()
        val enableSwitch = Switch(context).apply {
            text = "Bật $displayName"
            isChecked = isEnabled(context, slotIndex)
            setOnCheckedChangeListener { _, checked -> setEnabled(context, slotIndex, checked) }
        }
        return LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(padding, padding, padding, padding)
            addView(TextView(context).apply { text = description })
            addView(enableSwitch)
            addView(TextView(context).apply {
                text = "\n⚠️ Lưu ý: cái này chỉ chặn việc TRANG WEB tự dừng video " +
                    "theo sự kiện visibilitychange. Nếu bật rồi mà vẫn tắt tiếng, " +
                    "khả năng cao là do tiết kiệm pin của chính điện thoại (Cài " +
                    "đặt > Pin > cho phép app này chạy nền không giới hạn) — " +
                    "không phải lỗi trong app."
                textSize = 12f
                setTextColor(android.graphics.Color.GRAY)
            })
        }
    }
}
