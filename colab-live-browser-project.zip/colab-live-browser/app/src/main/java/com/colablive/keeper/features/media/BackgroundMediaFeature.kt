package com.colablive.keeper.features.media

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.colablive.keeper.core.AppPrefs
import com.colablive.keeper.core.BrowserEngine
import com.colablive.keeper.core.BrowserFeature

/**
 * Giữ media (YouTube, v.v.) tiếp tục phát khi tắt màn hình hoặc chuyển
 * sang app khác, và hiện trạng thái đang phát ở thanh thông báo.
 *
 * NGUYÊN NHÂN THẬT khiến video tự tắt (đã kiểm tra code, không phải Android
 * "kill" app): hầu hết trình phát video web, kể cả YouTube, tự lắng nghe
 * sự kiện `visibilitychange` và CHỦ ĐỘNG gọi `pause()` khi `document.hidden`
 * chuyển thành `true` — hành vi JS của chính trang web. App đã có sẵn kỹ
 * thuật vá lỗi này cho Colab (`ColabLiveKeeperFeature`), feature này tổng
 * quát hoá cho MỌI trang.
 *
 * THANH THÔNG BÁO: khác các trình duyệt lớn (Chrome/Firefox), thanh thông
 * báo ở đây KHÔNG dùng `android.media.session.MediaSession` /
 * `GeckoSession.MediaSession.Delegate` của GeckoView — API đó chưa được
 * xác minh (không có mạng để tra đúng chữ ký hàm lúc viết, đoán sai dễ gãy
 * build). Thay vào đó dùng cách chắc chắn compile được: định kỳ chạy JS
 * (`evaluateJs`, API đã dùng ổn định ở nhiều chỗ khác trong app) hỏi trang
 * có <video>/<audio> nào đang phát không, rồi cập nhật 1
 * `NotificationCompat` bình thường. Vì vậy thông báo hiện đúng "đang phát
 * gì" nhưng CHƯA có nút Play/Pause bấm trực tiếp trên thông báo (bấm vào
 * thông báo chỉ mở lại app) — làm nút điều khiển thật cần định tuyến lệnh
 * qua đúng process của khe đang chạy (mỗi khe 1 process riêng), phức tạp
 * hơn và nên làm riêng 1 lượt sau nếu cần.
 */
object BackgroundMediaFeature : BrowserFeature {

    override val id = "background_media"
    override val displayName = "Phát media nền (giữ YouTube/video không tắt khi chuyển app)"
    override val description =
        "Chặn trang web tự tạm dừng video/audio khi tắt màn hình hoặc chuyển " +
        "sang app khác, và hiện trạng thái đang phát ở thanh thông báo. Mặc " +
        "định BẬT SẴN cho mọi khe."

    private const val NOTIF_CHANNEL_ID = "media_status"
    private const val POLL_INTERVAL_MS = 4000L

    private val keepPlayingScript = """
        (function() {
            if (window.__bgMediaPatched) {
                try {
                    document.dispatchEvent(new Event('visibilitychange'));
                    window.dispatchEvent(new Event('focus'));
                } catch (e) {}
                return;
            }
            window.__bgMediaPatched = true;
            try {
                Object.defineProperty(document, 'hidden', { get: function() { return false; }, configurable: true });
                Object.defineProperty(document, 'visibilityState', { get: function() { return 'visible'; }, configurable: true });
                document.hasFocus = function() { return true; };
            } catch (e) {}
            ['visibilitychange', 'blur', 'pagehide'].forEach(function(type) {
                document.addEventListener(type, function(e) { e.stopImmediatePropagation(); }, true);
                window.addEventListener(type, function(e) { e.stopImmediatePropagation(); }, true);
            });
            try {
                document.dispatchEvent(new Event('visibilitychange'));
                window.dispatchEvent(new Event('focus'));
            } catch (e) {}
        })();
    """.trimIndent()

    // Trả về "1|<tiêu đề trang>" nếu có video/audio đang phát, "0|" nếu không.
    // Dùng cùng kiểu "trả chuỗi qua dấu |" như CookieLeakDetector đã dùng ổn định.
    private val checkPlayingScript = """
        (function() {
            try {
                var els = document.querySelectorAll('video, audio');
                var playing = false;
                for (var i = 0; i < els.length; i++) {
                    if (!els[i].paused && !els[i].ended) { playing = true; break; }
                }
                return (playing ? '1|' : '0|') + (document.title || '');
            } catch (e) { return '0|'; }
        })()
    """.trimIndent()

    // 1 Handler dùng chung cho vòng lặp poll — đủ vì mỗi khe là 1 process
    // Android riêng (xem ProfileSlots), nên object này không bị 4 khe
    // tranh nhau chạy chung 1 vòng lặp.
    private var pollHandler: Handler? = null
    private var pollRunnable: Runnable? = null

    override fun isEnabled(context: Context, slotIndex: Int) =
        AppPrefs.getBoolean(context, slotIndex, id, "enabled", true)

    override fun setEnabled(context: Context, slotIndex: Int, enabled: Boolean) =
        AppPrefs.setBoolean(context, slotIndex, id, "enabled", enabled)

    // Khác ColabLiveKeeperFeature (chỉ khớp 1 domain) — feature này áp dụng
    // cho MỌI trang, vì video có thể ở bất kỳ site nào (YouTube, v.v.).
    override fun matchesUrl(url: String?): Boolean = !url.isNullOrBlank()

    override fun onPageFinished(context: Context, slotIndex: Int, engine: BrowserEngine, url: String?) {
        if (!isEnabled(context, slotIndex) || !matchesUrl(url)) {
            cancelNotification(context, slotIndex)
            return
        }
        engine.evaluateJs(keepPlayingScript)
        startPolling(context, slotIndex, engine)
    }

    override fun onTick(context: Context, slotIndex: Int, engine: BrowserEngine, url: String?) {
        if (!isEnabled(context, slotIndex) || !matchesUrl(url)) {
            cancelNotification(context, slotIndex)
            return
        }
        engine.evaluateJs(keepPlayingScript)
        // Đề phòng vòng poll bị dừng (ví dụ do tắt/bật feature giữa chừng) —
        // gọi lại mỗi tick (~60s) để tự khởi động lại nếu cần, rẻ vì
        // startPolling tự huỷ Runnable cũ trước khi đặt lại.
        startPolling(context, slotIndex, engine)
    }

    private fun startPolling(context: Context, slotIndex: Int, engine: BrowserEngine) {
        val handler = pollHandler ?: Handler(Looper.getMainLooper()).also { pollHandler = it }
        pollRunnable?.let { handler.removeCallbacks(it) }
        val appContext = context.applicationContext
        lateinit var runnable: Runnable
        runnable = Runnable {
            if (!isEnabled(appContext, slotIndex)) {
                cancelNotification(appContext, slotIndex)
                return@Runnable
            }
            engine.evaluateJs(checkPlayingScript) { result ->
                val playing = result?.startsWith("1|") == true
                val title = result?.substringAfter('|', "")?.trim().orEmpty()
                updateNotification(appContext, slotIndex, playing, title)
            }
            handler.postDelayed(runnable, POLL_INTERVAL_MS)
        }
        pollRunnable = runnable
        handler.post(runnable)
    }

    private fun ensureChannel(context: Context) {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (nm.getNotificationChannel(NOTIF_CHANNEL_ID) == null) {
            nm.createNotificationChannel(
                NotificationChannel(NOTIF_CHANNEL_ID, "Đang phát media nền", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun notifId(slotIndex: Int) = 9000 + slotIndex

    private fun cancelNotification(context: Context, slotIndex: Int) {
        (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(notifId(slotIndex))
    }

    private fun updateNotification(context: Context, slotIndex: Int, playing: Boolean, title: String) {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (!playing) {
            nm.cancel(notifId(slotIndex))
            return
        }
        ensureChannel(context)
        val notif = NotificationCompat.Builder(context, NOTIF_CHANNEL_ID)
            .setContentTitle("Đang phát — Khe $slotIndex")
            .setContentText(title.ifBlank { "..." })
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
        nm.notify(notifId(slotIndex), notif)
    }

    override fun buildSettingsView(context: Context, slotIndex: Int): View {
        val padding = (16 * context.resources.displayMetrics.density).toInt()
        val enableSwitch = Switch(context).apply {
            text = "Bật $displayName"
            isChecked = isEnabled(context, slotIndex)
            setOnCheckedChangeListener { _, checked ->
                setEnabled(context, slotIndex, checked)
                if (!checked) cancelNotification(context, slotIndex)
            }
        }
        return LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(padding, padding, padding, padding)
            addView(TextView(context).apply { text = description })
            addView(enableSwitch)
            addView(TextView(context).apply {
                text = "\n⚠️ Lưu ý: thông báo hiện trạng thái đang phát, nhưng CHƯA " +
                    "có nút Play/Pause bấm trực tiếp trên thông báo (bấm vào chỉ " +
                    "mở lại app) — cần làm thêm nếu muốn điều khiển từ thông báo. " +
                    "Nếu bật rồi mà vẫn tắt tiếng, khả năng cao là do tiết kiệm " +
                    "pin của chính điện thoại (Cài đặt > Pin > cho phép app này " +
                    "chạy nền không giới hạn) — không phải lỗi trong app."
                textSize = 12f
                setTextColor(android.graphics.Color.GRAY)
            })
        }
    }
}
