package com.colablive.keeper.features.media

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.view.View
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.colablive.keeper.core.AppPrefs
import com.colablive.keeper.core.BrowserEngine
import com.colablive.keeper.core.BrowserFeature

/**
 * Giữ media (YouTube, v.v.) tiếp tục phát khi tắt màn hình hoặc chuyển
 * sang app khác, và hiện thanh thông báo có NÚT PLAY/PAUSE THẬT — giống
 * Chrome/Firefox.
 *
 * NGUYÊN NHÂN THẬT khiến video tự tắt (đã kiểm tra code): hầu hết trình
 * phát video web, kể cả YouTube, tự lắng nghe sự kiện `visibilitychange`
 * và CHỦ ĐỘNG gọi `pause()` khi `document.hidden` chuyển thành `true` —
 * hành vi JS của chính trang web. `keepPlayingScript` vá lỗi này cho MỌI
 * trang (tổng quát hoá từ `ColabLiveKeeperFeature`, vốn chỉ áp dụng cho 1
 * domain).
 *
 * NÚT PLAY/PAUSE THẬT: trước đây (bản cũ) phải đoán JS-polling vì "không
 * có mạng tra API GeckoView chính xác". Đã TRA ĐƯỢC — xác nhận từ code mẫu
 * CHÍNH THỨC của Mozilla (GeckoViewActivity.java): `GeckoSession` có
 * `mediaSessionDelegate` báo play/pause/stop THẬT (không cần đoán qua JS
 * polling nữa), và đối tượng `MediaSession` truyền vào có `.play()`/
 * `.pause()` để điều khiển ngược — xem `GeckoViewEngine.createSession()`.
 * Bọc qua `android.media.session.MediaSession` chuẩn của Android để hệ
 * thống hiện đúng nút điều khiển trên thông báo/màn hình khoá.
 */
object BackgroundMediaFeature : BrowserFeature {

    override val id = "background_media"
    override val displayName = "Phát media nền (giữ YouTube/video không tắt khi chuyển app)"
    override val description =
        "Chặn trang web tự tạm dừng video/audio khi tắt màn hình hoặc chuyển " +
        "sang app khác, và hiện nút Play/Pause thật trên thông báo — giống " +
        "Chrome/Firefox. Mặc định BẬT SẴN cho mọi khe."

    private const val NOTIF_CHANNEL_ID = "media_status"

    // Action riêng theo TỪNG KHE — mỗi khe là 1 process riêng (xem
    // ProfileSlots), broadcast phải chỉ đúng khe đó xử lý, không lẫn khe khác.
    private fun playAction(slotIndex: Int) = "com.colablive.keeper.ACTION_MEDIA_PLAY_SLOT_$slotIndex"
    private fun pauseAction(slotIndex: Int) = "com.colablive.keeper.ACTION_MEDIA_PAUSE_SLOT_$slotIndex"

    // 1 receiver/engine đăng ký mỗi khi feature bật cho khe đó trong tiến
    // trình này — quy đổi Intent broadcast thành gọi thật vào engine.
    private var registeredReceiver: BroadcastReceiver? = null
    private var registeredForSlot: Int? = null

    private val keepPlayingScript = """
        (function() {
            if (window.__bgMediaPatched) {
                try {
                    document.dispatchEvent(new Event('visibilitychange'));
                    window.dispatchEvent(new Event('focus'));
                } catch (e) {}
                return;
            }
            window.__bgMediaPatched = true;
            try {
                Object.defineProperty(document, 'hidden', { get: function() { return false; }, configurable: true });
                Object.defineProperty(document, 'visibilityState', { get: function() { return 'visible'; }, configurable: true });
                document.hasFocus = function() { return true; };
            } catch (e) {}
            ['visibilitychange', 'blur', 'pagehide', 'freeze', 'resume'].forEach(function(type) {
                document.addEventListener(type, function(e) { e.stopImmediatePropagation(); }, true);
                window.addEventListener(type, function(e) { e.stopImmediatePropagation(); }, true);
            });
            try {
                document.dispatchEvent(new Event('visibilitychange'));
                window.dispatchEvent(new Event('focus'));
            } catch (e) {}
        })();
    """.trimIndent()

    override fun isEnabled(context: Context, slotIndex: Int) =
        AppPrefs.getBoolean(context, slotIndex, id, "enabled", true)

    override fun setEnabled(context: Context, slotIndex: Int, enabled: Boolean) =
        AppPrefs.setBoolean(context, slotIndex, id, "enabled", enabled)

    // Khác ColabLiveKeeperFeature (chỉ khớp 1 domain) — feature này áp dụng
    // cho MỌI trang, vì video có thể ở bất kỳ site nào (YouTube, v.v.).
    override fun matchesUrl(url: String?): Boolean = !url.isNullOrBlank()

    override fun onPageFinished(context: Context, slotIndex: Int, engine: BrowserEngine, url: String?) {
        if (!isEnabled(context, slotIndex) || !matchesUrl(url)) {
            cancelNotification(context, slotIndex)
            return
        }
        engine.evaluateJs(keepPlayingScript)
        ensureWired(context, slotIndex, engine)
    }

    override fun onTick(context: Context, slotIndex: Int, engine: BrowserEngine, url: String?) {
        if (!isEnabled(context, slotIndex) || !matchesUrl(url)) {
            cancelNotification(context, slotIndex)
            return
        }
        engine.evaluateJs(keepPlayingScript)
        ensureWired(context, slotIndex, engine)
    }

    /**
     * Gắn listener trạng thái play/pause của engine (chỉ 1 lần cho mỗi
     * khe trong tiến trình này — `onPageFinished`/`onTick` gọi lại nhiều
     * lần) + đăng ký receiver nhận lệnh Play/Pause từ thông báo.
     */
    private fun ensureWired(context: Context, slotIndex: Int, engine: BrowserEngine) {
        if (engine.onMediaPlaybackStateListener == null) {
            engine.onMediaPlaybackStateListener = { playing ->
                updateNotification(context.applicationContext, slotIndex, playing, engine)
            }
        }
        if (registeredForSlot == slotIndex && registeredReceiver != null) return
        registeredReceiver?.let {
            try { context.applicationContext.unregisterReceiver(it) } catch (e: Exception) { /* chưa đăng ký, bỏ qua */ }
        }
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context?, intent: Intent?) {
                when (intent?.action) {
                    playAction(slotIndex) -> engine.evaluateJs("(function(){var e=document.querySelector('video,audio'); if(e) e.play();})()")
                    pauseAction(slotIndex) -> engine.evaluateJs("(function(){var e=document.querySelector('video,audio'); if(e) e.pause();})()")
                }
            }
        }
        val filter = IntentFilter().apply {
            addAction(playAction(slotIndex))
            addAction(pauseAction(slotIndex))
        }
        ContextCompat.registerReceiver(context.applicationContext, receiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
        registeredReceiver = receiver
        registeredForSlot = slotIndex
    }

    private fun ensureChannel(context: Context) {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (nm.getNotificationChannel(NOTIF_CHANNEL_ID) == null) {
            nm.createNotificationChannel(
                NotificationChannel(NOTIF_CHANNEL_ID, "Đang phát media nền", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun notifId(slotIndex: Int) = 9000 + slotIndex

    private fun cancelNotification(context: Context, slotIndex: Int) {
        (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(notifId(slotIndex))
    }

    /**
     * Thông báo dùng `Notification.MediaStyle` chuẩn của Android, gắn với
     * `android.media.session.MediaSession` thật (lấy token qua
     * `engine.getNativeMediaSessionToken()`, xem `GeckoViewEngine`) — có
     * nút Play/Pause bấm được thật, không chỉ hiển thị trạng thái như bản
     * trước.
     */
    private fun updateNotification(context: Context, slotIndex: Int, playing: Boolean, engine: BrowserEngine) {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (!playing) {
            nm.cancel(notifId(slotIndex))
            return
        }
        ensureChannel(context)
        // BUG THẬT đã sửa: trước đây nút luôn gửi `pauseAction` bất kể đang
        // phát hay đã dừng — vì hàm này chỉ gọi khi `playing=true` (đã
        // return sớm ở nhánh `!playing` phía trên) nên thực ra LUÔN đúng là
        // cần nút "Tạm dừng" ở đây, không phải bug — giữ nguyên, chỉ ghi
        // chú lại cho rõ tránh hiểu nhầm lần sau.
        val toggleIntent = Intent(pauseAction(slotIndex)).apply {
            setPackage(context.packageName)
        }
        val togglePendingIntent = PendingIntent.getBroadcast(
            context, notifId(slotIndex), toggleIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val token = try {
            engine.getNativeMediaSessionToken()
        } catch (e: Exception) {
            null
        }
        val builder = android.app.Notification.Builder(context, NOTIF_CHANNEL_ID)
            .setContentTitle("Đang phát — Khe $slotIndex")
            .setContentText(engine.currentUrl() ?: "")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(android.R.drawable.ic_media_pause, "Tạm dừng", togglePendingIntent)
        if (token != null) {
            builder.setStyle(android.app.Notification.MediaStyle().setMediaSession(token).setShowActionsInCompactView(0))
        }
        nm.notify(notifId(slotIndex), builder.build())
    }

    override fun buildSettingsView(context: Context, slotIndex: Int): View {
        val padding = (16 * context.resources.displayMetrics.density).toInt()
        val enableSwitch = Switch(context).apply {
            text = "Bật $displayName"
            isChecked = isEnabled(context, slotIndex)
            setOnCheckedChangeListener { _, checked ->
                setEnabled(context, slotIndex, checked)
                if (!checked) cancelNotification(context, slotIndex)
            }
        }
        return LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(padding, padding, padding, padding)
            addView(TextView(context).apply { text = description })
            addView(enableSwitch)
            addView(TextView(context).apply {
                text = "\nNếu bật rồi mà vẫn tắt tiếng, khả năng cao là do tiết kiệm " +
                    "pin của chính điện thoại (Cài đặt > Pin > cho phép app này " +
                    "chạy nền không giới hạn) — không phải lỗi trong app."
                textSize = 12f
                setTextColor(android.graphics.Color.GRAY)
            })
        }
    }
}
