package com.colablive.keeper.features.media

import android.content.Context
import android.view.View
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import com.colablive.keeper.core.AppPrefs
import com.colablive.keeper.core.BrowserEngine
import com.colablive.keeper.core.BrowserFeature

/**
 * Giữ media (YouTube, v.v.) tiếp tục phát khi tắt màn hình hoặc chuyển
 * sang app khác — bằng cách vá JS để trang KHÔNG tự gọi `pause()` khi
 * `document.hidden` chuyển thành `true`.
 *
 * NGUYÊN NHÂN THẬT khiến video tự tắt (đã kiểm tra code): hầu hết trình
 * phát video web, kể cả YouTube, tự lắng nghe sự kiện `visibilitychange`
 * và CHỦ ĐỘNG gọi `pause()` khi `document.hidden` chuyển thành `true` —
 * hành vi JS của chính trang web. `keepPlayingScript` vá lỗi này cho MỌI
 * trang (tổng quát hoá từ `ColabLiveKeeperFeature`, vốn chỉ áp dụng cho 1
 * domain).
 *
 * DỌN DẸP mã dư thừa (KHÔNG PHẢI "bug đã xác nhận" — xem
 * PROJECT_STATUS.md TRƯỚC khi tin điều này, đọc mục 8zw để biết nguyên
 * nhân THẬT SỰ đã được người dùng xác nhận qua test thật nhiều lần):
 * nguyên nhân THẬT của việc nhạc nền dừng khi xuống nền là
 * `m.youtube.com` (bản mobile) có JS CHỦ ĐỘNG tự `pause()` khi trang bị
 * ẩn (thiết kế có chủ đích của YouTube, tiết kiệm pin) — KHÔNG liên quan
 * gì đến notification của app. Giải pháp CHÍNH THỨC đã chốt: "Xem bằng
 * máy tính" (`toggleDesktopMode()` / danh sách ngoại lệ tên miền).
 *
 * Việc dọn ở đây CHỈ là quan sát code thật (không suy đoán): file này
 * TỪNG tự dựng 1 notification `MediaStyle` RIÊNG (`updateNotification()`,
 * id `9000+slot`) trong khi `GeckoViewEngine.postMediaNotification()`
 * CŨNG tự dựng 1 notification KHÁC (id `2000+slot`) cho CÙNG 1 sự kiện
 * play/pause — đây LÀ sự thật đọc thấy trong code, 2 đường code riêng
 * biệt cùng chạy. Nhưng việc quy kết "đây là nguyên nhân gây nhảy
 * Play/Pause trong log2.txt" là suy đoán CHƯA CÓ BẰNG CHỨNG — không có
 * gì trong log cho thấy 2 notification này đá nhau, và tài liệu dự án đã
 * có lời giải thích khác, ĐƯỢC XÁC NHẬN, cho hiện tượng media pause/play
 * trong log (xem trên). Giữ lại việc xoá notification dư thừa ở đây vì
 * đó là dọn code trùng lặp hợp lý (không cần 2 notification cho 1 sự
 * kiện), KHÔNG PHẢI vì nó "sửa" hiện tượng trong log — 2 việc khác nhau,
 * không nên gộp lại như lần trước.
 */
object BackgroundMediaFeature : BrowserFeature {

    override val id = "background_media"
    override val displayName = "Phát media nền (giữ YouTube/video không tắt khi chuyển app)"
    override val description =
        "Chặn trang web tự tạm dừng video/audio khi tắt màn hình hoặc chuyển " +
        "sang app khác. Nút Play/Pause thật trên thông báo do chính engine " +
        "trình duyệt hiển thị (không phải tính năng này). Mặc định BẬT SẴN " +
        "cho mọi khe."

    private val keepPlayingScript = """
        (function() {
            if (window.__bgMediaPatched) {
                try {
                    document.dispatchEvent(new Event('visibilitychange'));
                    window.dispatchEvent(new Event('focus'));
                } catch (e) {}
                return 'already-patched, document.hidden=' + document.hidden;
            }
            window.__bgMediaPatched = true;
            try {
                Object.defineProperty(document, 'hidden', { get: function() { return false; }, configurable: true });
                Object.defineProperty(document, 'visibilityState', { get: function() { return 'visible'; }, configurable: true });
                document.hasFocus = function() { return true; };
            } catch (e) {
                return 'defineProperty LOI: ' + e.message;
            }
            ['visibilitychange', 'blur', 'pagehide', 'freeze', 'resume'].forEach(function(type) {
                document.addEventListener(type, function(e) { e.stopImmediatePropagation(); }, true);
                window.addEventListener(type, function(e) { e.stopImmediatePropagation(); }, true);
            });
            try {
                document.dispatchEvent(new Event('visibilitychange'));
                window.dispatchEvent(new Event('focus'));
            } catch (e) {}
            return 'vua patch xong, document.hidden=' + document.hidden + ', url=' + location.href;
        })();
    """.trimIndent()

    override fun isEnabled(context: Context, slotIndex: Int) =
        AppPrefs.getBoolean(context, slotIndex, id, "enabled", true)

    override fun setEnabled(context: Context, slotIndex: Int, enabled: Boolean) =
        AppPrefs.setBoolean(context, slotIndex, id, "enabled", enabled)

    // Khác ColabLiveKeeperFeature (chỉ khớp 1 domain) — feature này áp dụng
    // cho MỌI trang, vì video có thể ở bất kỳ site nào (YouTube, v.v.).
    override fun matchesUrl(url: String?): Boolean = !url.isNullOrBlank()

    override fun onPageFinished(context: Context, slotIndex: Int, engine: BrowserEngine, url: String?) {
        if (!isEnabled(context, slotIndex) || !matchesUrl(url)) return
        engine.evaluateJs(keepPlayingScript)
    }

    override fun onTick(context: Context, slotIndex: Int, engine: BrowserEngine, url: String?) {
        if (!isEnabled(context, slotIndex) || !matchesUrl(url)) return
        engine.evaluateJs(keepPlayingScript)
    }

    override fun buildSettingsView(context: Context, slotIndex: Int): View {
        val padding = (16 * context.resources.displayMetrics.density).toInt()
        val enableSwitch = Switch(context).apply {
            text = "Bật $displayName"
            isChecked = isEnabled(context, slotIndex)
            setOnCheckedChangeListener { _, checked -> setEnabled(context, slotIndex, checked) }
        }
        return LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(padding, padding, padding, padding)
            addView(TextView(context).apply { text = description })
            addView(enableSwitch)
            addView(TextView(context).apply {
                text = "\nNếu bật rồi mà vẫn tắt tiếng, khả năng cao là do tiết kiệm " +
                    "pin của chính điện thoại (Cài đặt > Pin > cho phép app này " +
                    "chạy nền không giới hạn) — không phải lỗi trong app."
                textSize = 12f
                setTextColor(android.graphics.Color.GRAY)
            })
        }
    }
}
