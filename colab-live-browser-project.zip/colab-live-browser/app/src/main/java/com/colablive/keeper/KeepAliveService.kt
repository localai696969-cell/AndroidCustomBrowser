package com.colablive.keeper

import android.app.*
import android.content.*
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.colablive.keeper.core.DebugLog

/**
 * Foreground Service + WakeLock + JobScheduler backup.
 * Giữ app sống khi chuyển app hoặc tắt màn hình.
 */
class KeepAliveService : Service() {

    companion object {
        const val CHANNEL_ID = "live_browser_keepalive"
        const val NOTIFICATION_ID = 1
        const val JOB_ID = 1001
        const val ACTION_START = "com.colablive.keeper.KEEPALIVE_START"
        const val ACTION_STOP = "com.colablive.keeper.KEEPALIVE_STOP"
        // Broadcast NỘI BỘ (khác ACTION_STOP — đó là action gửi TỚI
        // service để ra lệnh dừng; cái này là service tự phát ra SAU KHI
        // đã dừng xong, để MainActivity nghe và đồng bộ lại nút UI).
        const val ACTION_STOPPED_FROM_NOTIFICATION = "com.colablive.keeper.KEEPALIVE_STOPPED_FROM_NOTIFICATION"

        // companion object = sống qua việc Service bị huỷ/tạo lại nhiều lần
        // (khác biến instance thường — mỗi lần service start lại là 1
        // instance MỚI, biến instance sẽ mất giá trị, không chặn được lặp).
        @Volatile private var lastScheduleTime = 0L

        /**
         * BUG chẩn đoán (người dùng báo: bấm "Dừng" trên thông báo xong vẫn
         * tự khởi động lại — đã rà soát TOÀN BỘ code, chỉ tìm thấy 2 nơi TỰ
         * ĐỘNG gọi start() (initServices lúc mở app, JobService định kỳ —
         * cả 2 ĐÃ gate theo cờ ở các lượt sửa trước) + 1 nơi CHỦ Ý do người
         * dùng bấm nút toolbar — không tìm thêm được nguồn nào khác qua đọc
         * code tĩnh). Vấn đề thật: TRƯỚC ĐÂY mọi nguồn đều in chung 1 dòng
         * log "KeepAliveService started" — không cách nào biết chính xác
         * LẦN NÀY do ai gọi. Thêm `reason` bắt buộc mọi lệnh gọi phải tự
         * khai báo nguồn gốc — lần tới nếu vẫn còn hiện tượng này, log sẽ
         * chỉ thẳng đúng thủ phạm, không cần đoán/rà lại từ đầu.
         */
        fun start(context: Context, reason: String) {
            val intent = Intent(context, KeepAliveService::class.java).apply {
                action = ACTION_START
                putExtra("reason", reason)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, KeepAliveService::class.java))
        }
    }

    private var wakeLock: PowerManager.WakeLock? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startKeepAlive(intent.getStringExtra("reason") ?: "ACTION_START (thiếu extra reason — có nơi gọi companion fun start() không đúng chữ ký mới)")
            ACTION_STOP -> {
                /**
                 * BUG THẬT (người dùng chỉ đúng qua trải nghiệm thật: bấm
                 * "Dừng" trên thanh thông báo KHÔNG đồng bộ với nút "Colab
                 * Live" trong trình duyệt): trước đây chỉ gọi `stopSelf()`
                 * — dừng ĐÚNG service/WakeLock, nhưng KHÔNG hề đụng tới cờ
                 * `colablive_keepalive_on` (AppPrefs) mà nút trong toolbar
                 * đọc để quyết định hiện chữ/màu gì — nút trong app vẫn
                 * đọc cờ CŨ (còn true), hiện sai trạng thái "đang chạy"
                 * dù thực tế service đã chết từ khi bấm nút trên thông báo.
                 *
                 * Sửa: (1) tự tính đúng `slotIndex` của CHÍNH tiến trình
                 * đang chạy service này (mỗi khe là 1 tiến trình riêng,
                 * dùng lại đúng hàm `ProfileSlots.getCurrentSlotIndex()`
                 * mà `LiveBrowserApp.onCreate()` đã dùng — không đoán lại
                 * logic mới, tái dùng nguồn xác định slot duy nhất của cả
                 * app). (2) cập nhật cờ AppPrefs đúng ngay tại đây. (3) gửi
                 * broadcast nội bộ để MainActivity (nếu đang hiển thị) cập
                 * nhật lại nút NGAY LẬP TỨC, không cần đợi người dùng tự
                 * điều hướng/mở lại app mới thấy đúng trạng thái.
                 */
                val slotIndex = com.colablive.keeper.core.ProfileSlots.getCurrentSlotIndex(this)
                com.colablive.keeper.core.AppPrefs.setBoolean(this, slotIndex, "colablive_keepalive_on", false)
                sendBroadcast(Intent(ACTION_STOPPED_FROM_NOTIFICATION).apply {
                    setPackage(packageName)
                    putExtra("slot_index", slotIndex)
                })
                stopSelf()
            }
            else -> {
                /**
                 * BUG THẬT đã tìm ra (người dùng báo: "colab die khi tắt màn
                 * hình" — tức KeepAliveService chết hẳn, không tự hồi lại,
                 * đặc biệt hay xảy ra khi màn hình tắt): hàm này trả về
                 * `START_STICKY` — nghĩa là NẾU Android giết tiến trình này
                 * (dễ xảy ra hơn khi tắt màn hình, do OS siết bộ nhớ nền
                 * mạnh hơn), hệ thống sẽ TỰ khởi động lại service, NHƯNG với
                 * Intent RỖNG (`intent == null`, không có action nào) — đây
                 * là hành vi CHUẨN của `START_STICKY`, có ghi rõ trong tài
                 * liệu chính thức Android (`Service.START_STICKY`: "the
                 * system will attempt to recreate the service... with a
                 * null intent"). Nhánh `when` trước đây KHÔNG xử lý case
                 * `intent?.action == null` — rơi vào im lặng không làm gì,
                 * nghĩa là `startForeground()` KHÔNG được gọi lại. Trên
                 * Android 8+ (Oreo), service được khởi động qua
                 * `startForegroundService()` mà không gọi `startForeground()`
                 * kịp trong vài giây SẼ bị hệ thống ném
                 * `RemoteServiceException` — CRASH LUÔN chính service đó
                 * (đôi khi kéo theo cả app) — khớp chính xác triệu chứng
                 * "chết hẳn, không tự hồi".
                 *
                 * Sửa: khi nhận Intent rỗng/không rõ action (tức đây là 1
                 * lần Android TỰ restart, không phải người dùng/code chủ
                 * động gọi), kiểm tra lại cờ `colablive_keepalive_on` đã lưu
                 * — nếu người dùng TRƯỚC ĐÓ thật sự đang bật tính năng này
                 * (không phải do lỗi khác), gọi lại `startKeepAlive()` ngay
                 * để khôi phục đúng trạng thái foreground + tránh crash.
                 * Nếu cờ đang tắt (VD người dùng đã chủ động tắt trước khi
                 * bị giết), không làm gì — đúng ý người dùng, không tự ý
                 * bật lại tính năng họ không yêu cầu.
                 */
                val slotIndex = com.colablive.keeper.core.ProfileSlots.getCurrentSlotIndex(this)
                val shouldBeRunning = com.colablive.keeper.core.AppPrefs.getBoolean(this, slotIndex, "colablive_keepalive_on", false)
                DebugLog.log("KeepAliveService: onStartCommand nhận Intent rỗng/không rõ action (khả năng Android tự restart sau khi bị giết) — cờ đã lưu=$shouldBeRunning, ${if (shouldBeRunning) "gọi lại startKeepAlive() để tránh crash do thiếu startForeground()" else "không làm gì, cờ đang tắt"}")
                if (shouldBeRunning) {
                    startKeepAlive("Android tự restart sau khi service bị giết (intent rỗng, START_STICKY)")
                }
            }
        }
        return START_STICKY
    }

    private fun startKeepAlive(reason: String) {
        // BUG THẬT/TÍNH NĂNG THIẾU (người dùng yêu cầu): thông báo trước đây
        // chỉ có dòng chữ TĨNH "Đang giữ phiên làm việc..." — không có cách
        // nào nhìn thoáng qua để biết service có ĐANG THẬT SỰ CHẠY hay đã
        // chết âm thầm (bị Android/OEM kill mà không báo), và không có nút
        // tắt nhanh ngay trên thông báo. Thêm:
        // - setUsesChronometer(true) + setWhen(startTime): thanh thông báo tự
        //   hiện đồng hồ đếm "00:15", "01:32:07"... tăng dần — nếu đồng hồ
        //   dừng tăng hoặc thông báo biến mất, người dùng biết ngay service
        //   đã chết mà không cần mở app kiểm tra.
        // - addAction("Dừng", ...): dừng KeepAliveService trực tiếp từ thanh
        //   thông báo, không cần mở lại app.
        // - setContentIntent(...): nhấn vào thông báo mở lại đúng app.
        val startTime = System.currentTimeMillis()
        val launchIntent = packageManager.getLaunchIntentForPackage(packageName)
        val contentPendingIntent = if (launchIntent != null) {
            PendingIntent.getActivity(
                this, 0, launchIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        } else null
        val stopPendingIntent = PendingIntent.getService(
            this, 0,
            Intent(this, KeepAliveService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("🔴 Colab Live — Đang giữ kết nối")
            .setContentText("Nhấn để quay lại trình duyệt")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setUsesChronometer(true)
            .setWhen(startTime)
            .setChronometerCountDown(false)
            .apply { if (contentPendingIntent != null) setContentIntent(contentPendingIntent) }
            .addAction(android.R.drawable.ic_media_pause, "Dừng", stopPendingIntent)
            .build()

        startForeground(NOTIFICATION_ID, notification)

        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        // BUG THẬT (người dùng báo Colab tự ngắt kết nối không rõ lý do khi
        // tắt màn hình): WakeLock trước đây chỉ giữ 10 phút
        // (`10 * 60 * 1000L`) nhưng job làm mới lại (`scheduleKeepAliveJob`)
        // chỉ chạy lại mỗi 15 phút (`setPeriodic(15 * 60 * 1000L)`) — có ít
        // nhất ~5 phút mỗi chu kỳ CPU KHÔNG được giữ thức, thiết bị được
        // phép vào Doze sâu, khiến kết nối mạng nền (kể cả WebSocket của
        // Colab tới backend) bị hệ thống treo/ngắt. Sửa: giữ WakeLock LÂU
        // HƠN chu kỳ job (17 phút > 15 phút), có dư 2 phút để chịu được độ
        // trễ thật tế của JobScheduler (job định kỳ trên Android thường
        // không chạy đúng giờ tuyệt đối, nhất là khi đã ở trong Doze).
        if (wakeLock?.isHeld == true) wakeLock?.release()
        wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "LiveBrowser::KeepAlive").apply {
            setReferenceCounted(false)
            acquire(17 * 60 * 1000L)
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            scheduleKeepAliveJob()
        }

        DebugLog.log("KeepAliveService started — nguồn gọi: $reason")
    }

    private fun scheduleKeepAliveJob() {
        val jobScheduler = getSystemService(Context.JOB_SCHEDULER_SERVICE) as android.app.job.JobScheduler

        // Lá chắn 1 (nguyên nhân gốc của vòng lặp): job này đã được lên lịch
        // (pending) từ trước rồi thì KHÔNG schedule lại. Trước đây gọi
        // schedule() vô điều kiện MỖI LẦN service start — kể cả khi chính
        // service được job khởi động lại → job tự lên lịch lại chính nó →
        // kích hoạt lại gần như ngay lập tức → lặp hàng trăm lần/phút → vượt
        // giới hạn 250 lần/60s của Android → toàn app crash (đã xác nhận
        // đúng bằng log crash thật).
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            if (jobScheduler.getPendingJob(JOB_ID) != null) {
                DebugLog.log("KeepAliveJob đã pending sẵn — bỏ qua, không schedule lại")
                return
            }
        }

        // Lá chắn 2 (phòng thêm — không phụ thuộc hoàn toàn lá chắn 1, vì
        // hành vi getPendingJob có thể khác nhau giữa các OEM/bản Android):
        // không schedule lại nếu vừa schedule cách đây chưa tới 60s.
        val now = System.currentTimeMillis()
        if (now - lastScheduleTime < 60_000L) {
            DebugLog.log("KeepAliveJob vừa schedule <60s trước — bỏ qua để tránh lặp")
            return
        }
        lastScheduleTime = now

        val componentName = android.content.ComponentName(this, KeepAliveJobService::class.java)
        val jobInfo = android.app.job.JobInfo.Builder(JOB_ID, componentName)
            .setRequiredNetworkType(android.app.job.JobInfo.NETWORK_TYPE_ANY)
            .setPeriodic(15 * 60 * 1000L)
            .setPersisted(true)
            .setRequiresCharging(false)
            .setRequiresDeviceIdle(false)
            .build()
        try {
            jobScheduler.schedule(jobInfo)
            DebugLog.log("KeepAliveJob scheduled")
        } catch (e: IllegalStateException) {
            // Lưới an toàn cuối — nếu vì lý do nào khác (thiết bị/OEM cụ thể)
            // 2 lá chắn trên vẫn không đủ chặn, ít nhất KHÔNG để lỗi này kéo
            // sập cả app: bỏ qua lần schedule này, service vẫn chạy bình
            // thường (job định kỳ có thể tạm thời không hoạt động, không
            // nghiêm trọng bằng việc crash toàn app).
            DebugLog.log("KeepAliveJob schedule() bị chặn rate-limit (${e.message}) — bỏ qua, KHÔNG crash app")
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Keep Alive", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Giữ phiên trình duyệt không bị ngắt"
                setShowBadge(false)
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        wakeLock?.let { if (it.isHeld) it.release() }
        DebugLog.log("KeepAliveService stopped")
        super.onDestroy()
    }
}

class KeepAliveJobService : android.app.job.JobService() {
    /**
     * BUG THẬT GỐC đã bỏ sót ở các lượt sửa trước (người dùng chỉ đúng:
     * "thông báo colab live liên tục tự bật dù không bật bên trong trang
     * colab, hay đã tắt rồi"): job này lên lịch CHẠY LẶP LẠI mỗi 15 phút
     * (`setPeriodic`), `setPersisted(true)` (sống qua cả khởi động lại máy)
     * — và gọi `KeepAliveService.start(this)` HOÀN TOÀN VÔ ĐIỀU KIỆN, không
     * hề kiểm tra cờ `colablive_keepalive_on`. Các lượt sửa trước CHỈ sửa
     * chỗ gọi lúc mở app (`MainActivity.initServices()`) và chỗ Android tự
     * restart do START_STICKY (`KeepAliveService.onStartCommand` nhánh
     * intent rỗng) — HOÀN TOÀN BỎ SÓT job định kỳ RIÊNG BIỆT này, vốn chạy
     * ĐỘC LẬP với cả 2 chỗ kia, kể cả khi app đã bị đóng hẳn hoặc máy vừa
     * khởi động lại.
     * SỬA: kiểm tra đúng cờ đã lưu trước khi khởi động lại service. Nếu cờ
     * đang tắt, KHÔNG khởi động service — VÀ HUỶ LUÔN job định kỳ này
     * (`jobScheduler.cancel`) để không tiếp tục lãng phí đánh thức máy mỗi
     * 15 phút cho một tính năng người dùng đã tắt (job sẽ được lên lịch lại
     * từ đầu ở lần tới người dùng thật sự bật Colab Live, qua
     * `scheduleKeepAliveJob()`).
     */
    override fun onStartJob(params: android.app.job.JobParameters?): Boolean {
        val slotIndex = com.colablive.keeper.core.ProfileSlots.getCurrentSlotIndex(this)
        val shouldBeRunning = com.colablive.keeper.core.AppPrefs.getBoolean(this, slotIndex, "colablive_keepalive_on", false)
        DebugLog.log("KeepAliveJob triggered — cờ colablive_keepalive_on đã lưu=$shouldBeRunning, ${if (shouldBeRunning) "khởi động lại service" else "KHÔNG khởi động, huỷ luôn job định kỳ này"}")
        if (shouldBeRunning) {
            KeepAliveService.start(this, "KeepAliveJobService định kỳ 15 phút (cờ colablive_keepalive_on=true)")
        } else {
            try {
                val jobScheduler = getSystemService(Context.JOB_SCHEDULER_SERVICE) as android.app.job.JobScheduler
                jobScheduler.cancel(KeepAliveService.JOB_ID)
            } catch (e: Exception) {
                DebugLog.log("KeepAliveJob: huỷ job lỗi (không nghiêm trọng): ${e.message}")
            }
        }
        return false
    }
    override fun onStopJob(params: android.app.job.JobParameters?): Boolean = false
}
