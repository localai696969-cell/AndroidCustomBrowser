package com.colablive.keeper

import android.app.*
import android.content.*
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.colablive.keeper.core.DebugLog

/**
 * Foreground Service + WakeLock + JobScheduler backup.
 * Giữ app sống khi chuyển app hoặc tắt màn hình.
 */
open class KeepAliveService : Service() {

    companion object {
        const val CHANNEL_ID = "live_browser_keepalive"
        const val NOTIFICATION_ID = 1
        const val ACTION_START = "com.colablive.keeper.KEEPALIVE_START"
        const val ACTION_STOP = "com.colablive.keeper.KEEPALIVE_STOP"
        // Broadcast NỘI BỘ (khác ACTION_STOP — đó là action gửi TỚI
        // service để ra lệnh dừng; cái này là service tự phát ra SAU KHI
        // đã dừng xong, để MainActivity nghe và đồng bộ lại nút UI).
        const val ACTION_STOPPED_FROM_NOTIFICATION = "com.colablive.keeper.KEEPALIVE_STOPPED_FROM_NOTIFICATION"

        // companion object = sống qua việc Service bị huỷ/tạo lại nhiều lần
        // (khác biến instance thường — mỗi lần service start lại là 1
        // instance MỚI, biến instance sẽ mất giá trị, không chặn được lặp).
        // KHÔNG cần đổi thành Map theo slotIndex: sau bản vá dưới đây, mỗi
        // khe chạy `KeepAliveServiceSlotN` ở 1 TIẾN TRÌNH riêng
        // (`android:process=":slotN"`) — companion object vốn dĩ KHÔNG chia
        // sẻ qua tiến trình (mỗi tiến trình có bản sao JVM/Dalvik riêng), tự
        // động đã đúng phạm vi theo khe mà không cần thêm code.
        @Volatile private var lastScheduleTime = 0L

        /**
         * FIX BUG NGHIÊM TRỌNG (người dùng hỏi đúng trọng tâm: "tại sao chỉ
         * Khe 1 bị Android tự thu hồi Activity mà Khe 0 thì không, chả lẽ 4
         * khe là các trình duyệt khác nhau, không kế thừa cái chung?"). Trả
         * lời: ĐÚNG là 4 khe chạy chung 1 bộ code/APK (không phải trình
         * duyệt khác nhau), nhưng đây LÀ 4 TIẾN TRÌNH ANDROID RIÊNG BIỆT
         * (`android:process=":slot1/2/3"` cho 3 activity, khe 0 dùng tiến
         * trình mặc định) — Android quyết định tiến trình nào bị thu hồi
         * dựa trên ĐỘ QUAN TRỌNG (oom_adj) của CHÍNH tiến trình đó, tính
         * riêng cho từng tiến trình, không liên quan gì tới 3 tiến trình
         * còn lại.
         *
         * Tìm ra ĐÚNG lý do khe 0 "được ưu ái" hơn hẳn: `KeepAliveService`
         * (foreground service giữ phiên Colab/web sống ở nền) trước đây
         * KHÔNG có bản sao riêng theo khe như `MediaKeepAliveService` đã
         * làm đúng (xem `MediaKeepAliveServiceSlot1/2/3`) — nghĩa là DÙ khe
         * nào gọi `KeepAliveService.start()`, Intent luôn nhắm vào
         * `KeepAliveService::class.java` — theo đúng khai báo Manifest
         * (KHÔNG có `android:process` riêng), Android LUÔN khởi động service
         * đó ở TIẾN TRÌNH MẶC ĐỊNH (chính là tiến trình của Khe 0), bất kể
         * Activity nào gọi. Hệ quả: tiến trình Khe 0 vô tình được 1
         * foreground service bảo vệ liên tục (oom_adj thấp, khó bị thu hồi)
         * mỗi khi tính năng Colab Live được dùng ở BẤT KỲ khe nào — còn
         * tiến trình Khe 1/2/3 không có gì bảo vệ tương tự, dễ bị Android
         * thu hồi Activity nền hơn hẳn — khớp CHÍNH XÁC hiện tượng người
         * dùng quan sát được.
         *
         * Sửa: nhân bản đúng pattern `MediaKeepAliveService` đã dùng —
         * `serviceClassFor(slotIndex)` chọn đúng subclass theo khe, mỗi
         * subclass khai báo `android:process` riêng trong Manifest.
         */
        fun serviceClassFor(slotIndex: Int): Class<out Service> = when (slotIndex) {
            1 -> KeepAliveServiceSlot1::class.java
            2 -> KeepAliveServiceSlot2::class.java
            3 -> KeepAliveServiceSlot3::class.java
            else -> KeepAliveService::class.java
        }

        fun jobIdFor(slotIndex: Int): Int = 1001 + slotIndex

        fun jobServiceClassFor(slotIndex: Int): Class<*> = when (slotIndex) {
            1 -> KeepAliveJobServiceSlot1::class.java
            2 -> KeepAliveJobServiceSlot2::class.java
            3 -> KeepAliveJobServiceSlot3::class.java
            else -> KeepAliveJobService::class.java
        }

        /**
         * BUG chẩn đoán (người dùng báo: bấm "Dừng" trên thông báo xong vẫn
         * tự khởi động lại — đã rà soát TOÀN BỘ code, chỉ tìm thấy 2 nơi TỰ
         * ĐỘNG gọi start() (initServices lúc mở app, JobService định kỳ —
         * cả 2 ĐÃ gate theo cờ ở các lượt sửa trước) + 1 nơi CHỦ Ý do người
         * dùng bấm nút toolbar — không tìm thêm được nguồn nào khác qua đọc
         * code tĩnh). Vấn đề thật: TRƯỚC ĐÂY mọi nguồn đều in chung 1 dòng
         * log "KeepAliveService started" — không cách nào biết chính xác
         * LẦN NÀY do ai gọi. Thêm `reason` bắt buộc mọi lệnh gọi phải tự
         * khai báo nguồn gốc — lần tới nếu vẫn còn hiện tượng này, log sẽ
         * chỉ thẳng đúng thủ phạm, không cần đoán/rà lại từ đầu.
         */
        fun start(context: Context, slotIndex: Int, reason: String) {
            val intent = Intent(context, serviceClassFor(slotIndex)).apply {
                action = ACTION_START
                putExtra("reason", reason)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context, slotIndex: Int) {
            context.stopService(Intent(context, serviceClassFor(slotIndex)))
        }
    }

    private var wakeLock: PowerManager.WakeLock? = null
    // SỬA BUG THẬT (người dùng báo: KHÔNG bấm nút Colab Live, chỉ load
    // trang Colab bình thường, mà thông báo "🔴 Colab Live — Đang giữ kết
    // nối" cứ liên tục hiện lại suốt nhiều giờ). Nguyên nhân xác nhận qua
    // đọc code: đây KHÔNG phải cơ chế `colablive_keepalive_on` (nút bấm
    // trong toolbar, đúng như người dùng nói không hề đụng tới) — mà là
    // nhánh HOÀN TOÀN KHÁC, tự động: `MainActivity.refreshKeepAliveServiceState()`
    // gọi `KeepAliveService.start()` mỗi khi có tab ghim chạy nền, và hàm
    // này được gọi lại ở CẢ `onPause()` LẪN `onResume()` — tức là MỖI LẦN
    // người dùng tắt/mở màn hình (rất thường xuyên qua nhiều giờ dùng máy
    // bình thường), `startKeepAlive()` chạy lại TỪ ĐẦU: `startTime =
    // System.currentTimeMillis()` tính lại mốc 0 mới, build 1
    // `Notification` HOÀN TOÀN MỚI (đồng hồ đếm giờ reset về 00:00) rồi
    // `startForeground()` lại — Android coi đây là cập nhật/đăng thông báo
    // mới mỗi lần, đúng khớp triệu chứng "liên tục hiện lại" dù người dùng
    // không thao tác gì, vì bản thân vòng đời onPause/onResume tự nhiên
    // (khoá/mở màn hình) đã đủ kích hoạt liên tục trong nhiều giờ.
    //
    // Sửa: thêm cờ `isForegroundActive` cấp INSTANCE (đủ dùng — mỗi lần
    // service bị hệ thống giết thật sự thì instance mất, cờ tự về false
    // đúng ý, không cần cờ bền vững qua AppPrefs) — nếu foreground service
    // ĐÃ ĐANG chạy đúng (`startForeground()` đã gọi thành công ở lần
    // trước, instance chưa bị giết), các lần gọi `startKeepAlive()` tiếp
    // theo CHỈ gia hạn WakeLock + JobScheduler (vẫn cần, tránh hết hạn
    // giữa chừng — đúng mục đích gốc của việc gọi lại ở onPause/onResume),
    // KHÔNG build lại Notification/gọi lại startForeground() — giữ nguyên
    // đúng 1 thông báo, đồng hồ đếm giờ chạy liên tục đúng từ lúc bắt đầu
    // thật, không reset/hiện lại.
    private var isForegroundActive = false

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startKeepAlive(intent.getStringExtra("reason") ?: "ACTION_START (thiếu extra reason — có nơi gọi companion fun start() không đúng chữ ký mới)")
            ACTION_STOP -> {
                /**
                 * BUG THẬT (người dùng chỉ đúng qua trải nghiệm thật: bấm
                 * "Dừng" trên thanh thông báo KHÔNG đồng bộ với nút "Colab
                 * Live" trong trình duyệt): trước đây chỉ gọi `stopSelf()`
                 * — dừng ĐÚNG service/WakeLock, nhưng KHÔNG hề đụng tới cờ
                 * `colablive_keepalive_on` (AppPrefs) mà nút trong toolbar
                 * đọc để quyết định hiện chữ/màu gì — nút trong app vẫn
                 * đọc cờ CŨ (còn true), hiện sai trạng thái "đang chạy"
                 * dù thực tế service đã chết từ khi bấm nút trên thông báo.
                 *
                 * Sửa: (1) tự tính đúng `slotIndex` của CHÍNH tiến trình
                 * đang chạy service này (mỗi khe là 1 tiến trình riêng,
                 * dùng lại đúng hàm `ProfileSlots.getCurrentSlotIndex()`
                 * mà `LiveBrowserApp.onCreate()` đã dùng — không đoán lại
                 * logic mới, tái dùng nguồn xác định slot duy nhất của cả
                 * app). (2) cập nhật cờ AppPrefs đúng ngay tại đây. (3) gửi
                 * broadcast nội bộ để MainActivity (nếu đang hiển thị) cập
                 * nhật lại nút NGAY LẬP TỨC, không cần đợi người dùng tự
                 * điều hướng/mở lại app mới thấy đúng trạng thái.
                 */
                val slotIndex = com.colablive.keeper.core.ProfileSlots.getCurrentSlotIndex(this)
                com.colablive.keeper.core.AppPrefs.setBoolean(this, slotIndex, "colablive_keepalive_on", false)
                sendBroadcast(Intent(ACTION_STOPPED_FROM_NOTIFICATION).apply {
                    setPackage(packageName)
                    putExtra("slot_index", slotIndex)
                })
                stopSelf()
            }
            else -> {
                /**
                 * BUG THẬT đã tìm ra (người dùng báo: "colab die khi tắt màn
                 * hình" — tức KeepAliveService chết hẳn, không tự hồi lại,
                 * đặc biệt hay xảy ra khi màn hình tắt): hàm này trả về
                 * `START_STICKY` — nghĩa là NẾU Android giết tiến trình này
                 * (dễ xảy ra hơn khi tắt màn hình, do OS siết bộ nhớ nền
                 * mạnh hơn), hệ thống sẽ TỰ khởi động lại service, NHƯNG với
                 * Intent RỖNG (`intent == null`, không có action nào) — đây
                 * là hành vi CHUẨN của `START_STICKY`, có ghi rõ trong tài
                 * liệu chính thức Android (`Service.START_STICKY`: "the
                 * system will attempt to recreate the service... with a
                 * null intent"). Nhánh `when` trước đây KHÔNG xử lý case
                 * `intent?.action == null` — rơi vào im lặng không làm gì,
                 * nghĩa là `startForeground()` KHÔNG được gọi lại. Trên
                 * Android 8+ (Oreo), service được khởi động qua
                 * `startForegroundService()` mà không gọi `startForeground()`
                 * kịp trong vài giây SẼ bị hệ thống ném
                 * `RemoteServiceException` — CRASH LUÔN chính service đó
                 * (đôi khi kéo theo cả app) — khớp chính xác triệu chứng
                 * "chết hẳn, không tự hồi".
                 *
                 * Sửa: khi nhận Intent rỗng/không rõ action (tức đây là 1
                 * lần Android TỰ restart, không phải người dùng/code chủ
                 * động gọi), kiểm tra lại cờ `colablive_keepalive_on` đã lưu
                 * — nếu người dùng TRƯỚC ĐÓ thật sự đang bật tính năng này
                 * (không phải do lỗi khác), gọi lại `startKeepAlive()` ngay
                 * để khôi phục đúng trạng thái foreground + tránh crash.
                 * Nếu cờ đang tắt (VD người dùng đã chủ động tắt trước khi
                 * bị giết), không làm gì — đúng ý người dùng, không tự ý
                 * bật lại tính năng họ không yêu cầu.
                 */
                val slotIndex = com.colablive.keeper.core.ProfileSlots.getCurrentSlotIndex(this)
                val shouldBeRunning = com.colablive.keeper.core.AppPrefs.getBoolean(this, slotIndex, "colablive_keepalive_on", false)
                DebugLog.log("KeepAliveService: onStartCommand nhận Intent rỗng/không rõ action (khả năng Android tự restart sau khi bị giết) — cờ đã lưu=$shouldBeRunning, ${if (shouldBeRunning) "gọi lại startKeepAlive() để tránh crash do thiếu startForeground()" else "không làm gì, cờ đang tắt"}")
                if (shouldBeRunning) {
                    startKeepAlive("Android tự restart sau khi service bị giết (intent rỗng, START_STICKY)")
                }
            }
        }
        return START_STICKY
    }

    private fun startKeepAlive(reason: String) {
        if (isForegroundActive) {
            // Đã chạy đúng rồi (từ lần gọi trước, instance service này
            // chưa bị hệ thống giết) — chỉ gia hạn WakeLock/JobScheduler
            // bên dưới, KHÔNG build/đăng lại Notification, tránh đúng bug
            // "thông báo liên tục hiện lại" đã xác nhận ở trên.
            renewWakeLockAndJob()
            DebugLog.log("KeepAliveService: đã đang chạy (isForegroundActive=true) — chỉ gia hạn WakeLock/Job, KHÔNG đăng lại thông báo. nguồn gọi lần này: $reason")
            return
        }
        // BUG THẬT/TÍNH NĂNG THIẾU (người dùng yêu cầu): thông báo trước đây
        // chỉ có dòng chữ TĨNH "Đang giữ phiên làm việc..." — không có cách
        // nào nhìn thoáng qua để biết service có ĐANG THẬT SỰ CHẠY hay đã
        // chết âm thầm (bị Android/OEM kill mà không báo), và không có nút
        // tắt nhanh ngay trên thông báo. Thêm:
        // - setUsesChronometer(true) + setWhen(startTime): thanh thông báo tự
        //   hiện đồng hồ đếm "00:15", "01:32:07"... tăng dần — nếu đồng hồ
        //   dừng tăng hoặc thông báo biến mất, người dùng biết ngay service
        //   đã chết mà không cần mở app kiểm tra.
        // - addAction("Dừng", ...): dừng KeepAliveService trực tiếp từ thanh
        //   thông báo, không cần mở lại app.
        // - setContentIntent(...): nhấn vào thông báo mở lại đúng app.
        val startTime = System.currentTimeMillis()
        val launchIntent = packageManager.getLaunchIntentForPackage(packageName)
        val contentPendingIntent = if (launchIntent != null) {
            PendingIntent.getActivity(
                this, 0, launchIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        } else null
        val stopPendingIntent = PendingIntent.getService(
            this, 0,
            // FIX BUG THẬT (hệ quả của bản vá per-slot ở trên): trước đây
            // hard-code `KeepAliveService::class.java` — nếu instance THẬT
            // đang chạy là `KeepAliveServiceSlot1` (tiến trình :slot1), Intent
            // này vẫn cứ nhắm vào class GỐC (tiến trình mặc định/Khe 0) theo
            // đúng khai báo Manifest của nó — bấm "Dừng" trên thông báo của
            // Khe 1 sẽ dừng NHẦM service đang chạy ở Khe 0 (nếu có), còn
            // service THẬT của Khe 1 vẫn sống nguyên. Dùng `this::class.java`
            // — luôn đúng CHÍNH XÁC subclass đang chạy thật sự.
            Intent(this, this::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("🔴 Colab Live — Đang giữ kết nối")
            .setContentText("Nhấn để quay lại trình duyệt")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setUsesChronometer(true)
            .setWhen(startTime)
            .setChronometerCountDown(false)
            .apply { if (contentPendingIntent != null) setContentIntent(contentPendingIntent) }
            .addAction(android.R.drawable.ic_media_pause, "Dừng", stopPendingIntent)
            .build()

        // FIX BUG THẬT (hệ quả của bản vá per-slot): trước đây `NOTIFICATION_ID`
        // là 1 hằng số DUY NHẤT dùng chung mọi khe — nếu 2 khe cùng bật
        // Colab Live, Android's NotificationManager định danh thông báo qua
        // (package, id) KHÔNG phân biệt theo tiến trình gửi, nên 2 thông báo
        // "Đang giữ kết nối" sẽ ĐÈ LÊN NHAU thay vì hiện riêng biệt — bấm
        // "Dừng" trên thông báo hiển thị (khe X) có thể vô tình dừng nhầm
        // service của khe Y nếu bị đè. Cộng thêm slotIndex (khác dải với
        // `2000+slotIndex` mà MediaKeepAliveService đã dùng, tránh trùng).
        startForeground(1000 + com.colablive.keeper.core.ProfileSlots.getCurrentSlotIndex(this), notification)
        isForegroundActive = true

        renewWakeLockAndJob()

        DebugLog.log("KeepAliveService started — nguồn gọi: $reason")
    }

    private fun renewWakeLockAndJob() {
        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        // BUG THẬT (người dùng báo Colab tự ngắt kết nối không rõ lý do khi
        // tắt màn hình): WakeLock trước đây chỉ giữ 10 phút
        // (`10 * 60 * 1000L`) nhưng job làm mới lại (`scheduleKeepAliveJob`)
        // chỉ chạy lại mỗi 15 phút (`setPeriodic(15 * 60 * 1000L)`) — có ít
        // nhất ~5 phút mỗi chu kỳ CPU KHÔNG được giữ thức, thiết bị được
        // phép vào Doze sâu, khiến kết nối mạng nền (kể cả WebSocket của
        // Colab tới backend) bị hệ thống treo/ngắt. Sửa: giữ WakeLock LÂU
        // HƠN chu kỳ job (17 phút > 15 phút), có dư 2 phút để chịu được độ
        // trễ thật tế của JobScheduler (job định kỳ trên Android thường
        // không chạy đúng giờ tuyệt đối, nhất là khi đã ở trong Doze).
        if (wakeLock?.isHeld == true) wakeLock?.release()
        wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "LiveBrowser::KeepAlive").apply {
            setReferenceCounted(false)
            acquire(17 * 60 * 1000L)
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            scheduleKeepAliveJob()
        }
    }

    private fun scheduleKeepAliveJob() {
        val slotIndex = com.colablive.keeper.core.ProfileSlots.getCurrentSlotIndex(this)
        val jobId = jobIdFor(slotIndex)
        val jobScheduler = getSystemService(Context.JOB_SCHEDULER_SERVICE) as android.app.job.JobScheduler

        // Lá chắn 1 (nguyên nhân gốc của vòng lặp): job này đã được lên lịch
        // (pending) từ trước rồi thì KHÔNG schedule lại. Trước đây gọi
        // schedule() vô điều kiện MỖI LẦN service start — kể cả khi chính
        // service được job khởi động lại → job tự lên lịch lại chính nó →
        // kích hoạt lại gần như ngay lập tức → lặp hàng trăm lần/phút → vượt
        // giới hạn 250 lần/60s của Android → toàn app crash (đã xác nhận
        // đúng bằng log crash thật).
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            if (jobScheduler.getPendingJob(jobId) != null) {
                DebugLog.log("KeepAliveJob (khe $slotIndex) đã pending sẵn — bỏ qua, không schedule lại")
                return
            }
        }

        // Lá chắn 2 (phòng thêm — không phụ thuộc hoàn toàn lá chắn 1, vì
        // hành vi getPendingJob có thể khác nhau giữa các OEM/bản Android):
        // không schedule lại nếu vừa schedule cách đây chưa tới 60s.
        val now = System.currentTimeMillis()
        if (now - lastScheduleTime < 60_000L) {
            DebugLog.log("KeepAliveJob vừa schedule <60s trước — bỏ qua để tránh lặp")
            return
        }
        lastScheduleTime = now

        // FIX BUG THẬT (hệ quả của bản vá per-slot ở trên): JobScheduler
        // định danh job qua (packageName, jobId) — KHÔNG phân biệt theo tiến
        // trình gọi. Trước đây `JOB_ID` là 1 hằng số DUY NHẤT (1001) dùng
        // chung cho mọi khe — nếu Khe 0 và Khe 1 cùng bật Colab Live, lệnh
        // schedule() của khe gọi SAU sẽ ĐÈ MẤT job của khe gọi TRƯỚC (cùng
        // jobId), chỉ 1 trong 2 khe thật sự có job định kỳ chạy. Dùng
        // `jobIdFor(slotIndex)` (1001+slotIndex) để mỗi khe có 1 job ĐỘC LẬP,
        // và dispatch đúng class `KeepAliveJobServiceSlotN` (tiến trình riêng
        // của khe N) thay vì luôn nhắm vào class gốc (tiến trình Khe 0).
        val componentName = android.content.ComponentName(this, jobServiceClassFor(slotIndex))
        val jobInfo = android.app.job.JobInfo.Builder(jobId, componentName)
            .setRequiredNetworkType(android.app.job.JobInfo.NETWORK_TYPE_ANY)
            .setPeriodic(15 * 60 * 1000L)
            .setPersisted(true)
            .setRequiresCharging(false)
            .setRequiresDeviceIdle(false)
            .build()
        try {
            jobScheduler.schedule(jobInfo)
            DebugLog.log("KeepAliveJob (khe $slotIndex, jobId=$jobId) scheduled")
        } catch (e: IllegalStateException) {
            // Lưới an toàn cuối — nếu vì lý do nào khác (thiết bị/OEM cụ thể)
            // 2 lá chắn trên vẫn không đủ chặn, ít nhất KHÔNG để lỗi này kéo
            // sập cả app: bỏ qua lần schedule này, service vẫn chạy bình
            // thường (job định kỳ có thể tạm thời không hoạt động, không
            // nghiêm trọng bằng việc crash toàn app).
            DebugLog.log("KeepAliveJob schedule() bị chặn rate-limit (${e.message}) — bỏ qua, KHÔNG crash app")
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Keep Alive", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Giữ phiên trình duyệt không bị ngắt"
                setShowBadge(false)
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        wakeLock?.let { if (it.isHeld) it.release() }
        // Reset cờ khi service THẬT SỰ dừng (dù do ACTION_STOP hay bị hệ
        // thống giết) — Android luôn gọi onDestroy() cuối cùng trong mọi
        // trường hợp dừng, nên đây là đúng 1 chỗ duy nhất cần reset, đảm
        // bảo lần khởi động thật tiếp theo build lại đúng Notification mới
        // (không giữ cờ "đang chạy" ảo sau khi service đã chết thật).
        isForegroundActive = false
        DebugLog.log("KeepAliveService stopped")
        super.onDestroy()
    }
}

open class KeepAliveJobService : android.app.job.JobService() {
    /**
     * BUG THẬT GỐC đã bỏ sót ở các lượt sửa trước (người dùng chỉ đúng:
     * "thông báo colab live liên tục tự bật dù không bật bên trong trang
     * colab, hay đã tắt rồi"): job này lên lịch CHẠY LẶP LẠI mỗi 15 phút
     * (`setPeriodic`), `setPersisted(true)` (sống qua cả khởi động lại máy)
     * — và gọi `KeepAliveService.start(this)` HOÀN TOÀN VÔ ĐIỀU KIỆN, không
     * hề kiểm tra cờ `colablive_keepalive_on`. Các lượt sửa trước CHỈ sửa
     * chỗ gọi lúc mở app (`MainActivity.initServices()`) và chỗ Android tự
     * restart do START_STICKY (`KeepAliveService.onStartCommand` nhánh
     * intent rỗng) — HOÀN TOÀN BỎ SÓT job định kỳ RIÊNG BIỆT này, vốn chạy
     * ĐỘC LẬP với cả 2 chỗ kia, kể cả khi app đã bị đóng hẳn hoặc máy vừa
     * khởi động lại.
     * SỬA: kiểm tra đúng cờ đã lưu trước khi khởi động lại service. Nếu cờ
     * đang tắt, KHÔNG khởi động service — VÀ HUỶ LUÔN job định kỳ này
     * (`jobScheduler.cancel`) để không tiếp tục lãng phí đánh thức máy mỗi
     * 15 phút cho một tính năng người dùng đã tắt (job sẽ được lên lịch lại
     * từ đầu ở lần tới người dùng thật sự bật Colab Live, qua
     * `scheduleKeepAliveJob()`).
     */
    override fun onStartJob(params: android.app.job.JobParameters?): Boolean {
        val slotIndex = com.colablive.keeper.core.ProfileSlots.getCurrentSlotIndex(this)
        val shouldBeRunning = com.colablive.keeper.core.AppPrefs.getBoolean(this, slotIndex, "colablive_keepalive_on", false)
        DebugLog.log("KeepAliveJob triggered (khe $slotIndex) — cờ colablive_keepalive_on đã lưu=$shouldBeRunning, ${if (shouldBeRunning) "khởi động lại service" else "KHÔNG khởi động, huỷ luôn job định kỳ này"}")
        if (shouldBeRunning) {
            KeepAliveService.start(this, slotIndex, "KeepAliveJobService định kỳ 15 phút (khe $slotIndex, cờ colablive_keepalive_on=true)")
        } else {
            try {
                val jobScheduler = getSystemService(Context.JOB_SCHEDULER_SERVICE) as android.app.job.JobScheduler
                jobScheduler.cancel(KeepAliveService.jobIdFor(slotIndex))
            } catch (e: Exception) {
                DebugLog.log("KeepAliveJob: huỷ job lỗi (không nghiêm trọng): ${e.message}")
            }
        }
        return false
    }
    override fun onStopJob(params: android.app.job.JobParameters?): Boolean = false
}

// FIX BUG NGHIÊM TRỌNG (xem giải thích đầy đủ ở `KeepAliveService.
// serviceClassFor()`) — mỗi khe cần 1 process riêng để `ProfileSlots.
// getCurrentSlotIndex()` bên trong đọc đúng slot, và để tiến trình của
// CHÍNH khe đó (không phải luôn luôn khe 0) được foreground service bảo
// vệ khỏi bị Android thu hồi Activity nền.
class KeepAliveServiceSlot1 : KeepAliveService()
class KeepAliveServiceSlot2 : KeepAliveService()
class KeepAliveServiceSlot3 : KeepAliveService()

class KeepAliveJobServiceSlot1 : KeepAliveJobService()
class KeepAliveJobServiceSlot2 : KeepAliveJobService()
class KeepAliveJobServiceSlot3 : KeepAliveJobService()
