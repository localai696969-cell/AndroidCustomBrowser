package com.colablive.keeper

import android.app.*
import android.content.*
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.colablive.keeper.core.DebugLog

/**
 * Foreground Service + WakeLock + JobScheduler backup.
 * Giữ app sống khi chuyển app hoặc tắt màn hình.
 */
class KeepAliveService : Service() {

    companion object {
        const val CHANNEL_ID = "live_browser_keepalive"
        const val NOTIFICATION_ID = 1
        const val JOB_ID = 1001
        const val ACTION_START = "com.colablive.keeper.KEEPALIVE_START"
        const val ACTION_STOP = "com.colablive.keeper.KEEPALIVE_STOP"
        // Broadcast NỘI BỘ (khác ACTION_STOP — đó là action gửi TỚI
        // service để ra lệnh dừng; cái này là service tự phát ra SAU KHI
        // đã dừng xong, để MainActivity nghe và đồng bộ lại nút UI).
        const val ACTION_STOPPED_FROM_NOTIFICATION = "com.colablive.keeper.KEEPALIVE_STOPPED_FROM_NOTIFICATION"

        // companion object = sống qua việc Service bị huỷ/tạo lại nhiều lần
        // (khác biến instance thường — mỗi lần service start lại là 1
        // instance MỚI, biến instance sẽ mất giá trị, không chặn được lặp).
        @Volatile private var lastScheduleTime = 0L

        fun start(context: Context) {
            val intent = Intent(context, KeepAliveService::class.java).apply {
                action = ACTION_START
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, KeepAliveService::class.java))
        }
    }

    private var wakeLock: PowerManager.WakeLock? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startKeepAlive()
            ACTION_STOP -> {
                /**
                 * BUG THẬT (người dùng chỉ đúng qua trải nghiệm thật: bấm
                 * "Dừng" trên thanh thông báo KHÔNG đồng bộ với nút "Colab
                 * Live" trong trình duyệt): trước đây chỉ gọi `stopSelf()`
                 * — dừng ĐÚNG service/WakeLock, nhưng KHÔNG hề đụng tới cờ
                 * `colablive_keepalive_on` (AppPrefs) mà nút trong toolbar
                 * đọc để quyết định hiện chữ/màu gì — nút trong app vẫn
                 * đọc cờ CŨ (còn true), hiện sai trạng thái "đang chạy"
                 * dù thực tế service đã chết từ khi bấm nút trên thông báo.
                 *
                 * Sửa: (1) tự tính đúng `slotIndex` của CHÍNH tiến trình
                 * đang chạy service này (mỗi khe là 1 tiến trình riêng,
                 * dùng lại đúng hàm `ProfileSlots.getCurrentSlotIndex()`
                 * mà `LiveBrowserApp.onCreate()` đã dùng — không đoán lại
                 * logic mới, tái dùng nguồn xác định slot duy nhất của cả
                 * app). (2) cập nhật cờ AppPrefs đúng ngay tại đây. (3) gửi
                 * broadcast nội bộ để MainActivity (nếu đang hiển thị) cập
                 * nhật lại nút NGAY LẬP TỨC, không cần đợi người dùng tự
                 * điều hướng/mở lại app mới thấy đúng trạng thái.
                 */
                val slotIndex = com.colablive.keeper.core.ProfileSlots.getCurrentSlotIndex(this)
                com.colablive.keeper.core.AppPrefs.setBoolean(this, slotIndex, "colablive_keepalive_on", false)
                sendBroadcast(Intent(ACTION_STOPPED_FROM_NOTIFICATION).apply {
                    setPackage(packageName)
                    putExtra("slot_index", slotIndex)
                })
                stopSelf()
            }
        }
        return START_STICKY
    }

    private fun startKeepAlive() {
        // BUG THẬT/TÍNH NĂNG THIẾU (người dùng yêu cầu): thông báo trước đây
        // chỉ có dòng chữ TĨNH "Đang giữ phiên làm việc..." — không có cách
        // nào nhìn thoáng qua để biết service có ĐANG THẬT SỰ CHẠY hay đã
        // chết âm thầm (bị Android/OEM kill mà không báo), và không có nút
        // tắt nhanh ngay trên thông báo. Thêm:
        // - setUsesChronometer(true) + setWhen(startTime): thanh thông báo tự
        //   hiện đồng hồ đếm "00:15", "01:32:07"... tăng dần — nếu đồng hồ
        //   dừng tăng hoặc thông báo biến mất, người dùng biết ngay service
        //   đã chết mà không cần mở app kiểm tra.
        // - addAction("Dừng", ...): dừng KeepAliveService trực tiếp từ thanh
        //   thông báo, không cần mở lại app.
        // - setContentIntent(...): nhấn vào thông báo mở lại đúng app.
        val startTime = System.currentTimeMillis()
        val launchIntent = packageManager.getLaunchIntentForPackage(packageName)
        val contentPendingIntent = if (launchIntent != null) {
            PendingIntent.getActivity(
                this, 0, launchIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        } else null
        val stopPendingIntent = PendingIntent.getService(
            this, 0,
            Intent(this, KeepAliveService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("🔴 Colab Live — Đang giữ kết nối")
            .setContentText("Nhấn để quay lại trình duyệt")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setUsesChronometer(true)
            .setWhen(startTime)
            .setChronometerCountDown(false)
            .apply { if (contentPendingIntent != null) setContentIntent(contentPendingIntent) }
            .addAction(android.R.drawable.ic_media_pause, "Dừng", stopPendingIntent)
            .build()

        startForeground(NOTIFICATION_ID, notification)

        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        // BUG THẬT (người dùng báo Colab tự ngắt kết nối không rõ lý do khi
        // tắt màn hình): WakeLock trước đây chỉ giữ 10 phút
        // (`10 * 60 * 1000L`) nhưng job làm mới lại (`scheduleKeepAliveJob`)
        // chỉ chạy lại mỗi 15 phút (`setPeriodic(15 * 60 * 1000L)`) — có ít
        // nhất ~5 phút mỗi chu kỳ CPU KHÔNG được giữ thức, thiết bị được
        // phép vào Doze sâu, khiến kết nối mạng nền (kể cả WebSocket của
        // Colab tới backend) bị hệ thống treo/ngắt. Sửa: giữ WakeLock LÂU
        // HƠN chu kỳ job (17 phút > 15 phút), có dư 2 phút để chịu được độ
        // trễ thật tế của JobScheduler (job định kỳ trên Android thường
        // không chạy đúng giờ tuyệt đối, nhất là khi đã ở trong Doze).
        if (wakeLock?.isHeld == true) wakeLock?.release()
        wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "LiveBrowser::KeepAlive").apply {
            setReferenceCounted(false)
            acquire(17 * 60 * 1000L)
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            scheduleKeepAliveJob()
        }

        DebugLog.log("KeepAliveService started")
    }

    private fun scheduleKeepAliveJob() {
        val jobScheduler = getSystemService(Context.JOB_SCHEDULER_SERVICE) as android.app.job.JobScheduler

        // Lá chắn 1 (nguyên nhân gốc của vòng lặp): job này đã được lên lịch
        // (pending) từ trước rồi thì KHÔNG schedule lại. Trước đây gọi
        // schedule() vô điều kiện MỖI LẦN service start — kể cả khi chính
        // service được job khởi động lại → job tự lên lịch lại chính nó →
        // kích hoạt lại gần như ngay lập tức → lặp hàng trăm lần/phút → vượt
        // giới hạn 250 lần/60s của Android → toàn app crash (đã xác nhận
        // đúng bằng log crash thật).
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            if (jobScheduler.getPendingJob(JOB_ID) != null) {
                DebugLog.log("KeepAliveJob đã pending sẵn — bỏ qua, không schedule lại")
                return
            }
        }

        // Lá chắn 2 (phòng thêm — không phụ thuộc hoàn toàn lá chắn 1, vì
        // hành vi getPendingJob có thể khác nhau giữa các OEM/bản Android):
        // không schedule lại nếu vừa schedule cách đây chưa tới 60s.
        val now = System.currentTimeMillis()
        if (now - lastScheduleTime < 60_000L) {
            DebugLog.log("KeepAliveJob vừa schedule <60s trước — bỏ qua để tránh lặp")
            return
        }
        lastScheduleTime = now

        val componentName = android.content.ComponentName(this, KeepAliveJobService::class.java)
        val jobInfo = android.app.job.JobInfo.Builder(JOB_ID, componentName)
            .setRequiredNetworkType(android.app.job.JobInfo.NETWORK_TYPE_ANY)
            .setPeriodic(15 * 60 * 1000L)
            .setPersisted(true)
            .setRequiresCharging(false)
            .setRequiresDeviceIdle(false)
            .build()
        try {
            jobScheduler.schedule(jobInfo)
            DebugLog.log("KeepAliveJob scheduled")
        } catch (e: IllegalStateException) {
            // Lưới an toàn cuối — nếu vì lý do nào khác (thiết bị/OEM cụ thể)
            // 2 lá chắn trên vẫn không đủ chặn, ít nhất KHÔNG để lỗi này kéo
            // sập cả app: bỏ qua lần schedule này, service vẫn chạy bình
            // thường (job định kỳ có thể tạm thời không hoạt động, không
            // nghiêm trọng bằng việc crash toàn app).
            DebugLog.log("KeepAliveJob schedule() bị chặn rate-limit (${e.message}) — bỏ qua, KHÔNG crash app")
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Keep Alive", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Giữ phiên trình duyệt không bị ngắt"
                setShowBadge(false)
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        wakeLock?.let { if (it.isHeld) it.release() }
        DebugLog.log("KeepAliveService stopped")
        super.onDestroy()
    }
}

class KeepAliveJobService : android.app.job.JobService() {
    override fun onStartJob(params: android.app.job.JobParameters?): Boolean {
        DebugLog.log("KeepAliveJob triggered")
        KeepAliveService.start(this)
        return false
    }
    override fun onStopJob(params: android.app.job.JobParameters?): Boolean = false
}
