package com.colablive.keeper

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat

/**
 * Foreground Service thật của Android — đây là thứ mà Firefox addon KHÔNG BAO GIỜ
 * tự tạo ra được (chỉ mượn tạm qua media session). Ở đây app của bạn tự khai báo
 * và Android công nhận priority "foreground" thật sự, khó bị Low Memory Killer giết.
 */
class KeepAliveService : Service() {

    private var wakeLock: PowerManager.WakeLock? = null

    companion object {
        const val CHANNEL_ID = "colab_live_keeper_channel"
        const val NOTIF_ID = 1
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(NOTIF_ID, buildNotification())

        // PARTIAL_WAKE_LOCK: giữ CPU chạy dù màn hình tắt, KHÔNG bật sáng màn hình
        // (khác với FULL_WAKE_LOCK). Đây là cách hợp pháp để JS trong WebView
        // tiếp tục chạy khi bạn tắt màn hình.
        val powerManager = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = powerManager.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "ColabLiveKeeper::KeepAliveWakeLock"
        ).apply {
            setReferenceCounted(false)
            acquire(12 * 60 * 60 * 1000L) // tối đa 12 giờ, khớp hard limit Colab free tier
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // START_STICKY: nếu hệ thống vẫn lỡ kill service, Android sẽ cố khởi động lại
        return START_STICKY
    }

    override fun onDestroy() {
        wakeLock?.let { if (it.isHeld) it.release() }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Colab Live Keeper",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Colab Live Keeper đang chạy")
            .setContentText("Đang giữ notebook Colab hoạt động")
            .setSmallIcon(android.R.drawable.ic_menu_recent_history)
            .setOngoing(true)
            .build()
    }
}
