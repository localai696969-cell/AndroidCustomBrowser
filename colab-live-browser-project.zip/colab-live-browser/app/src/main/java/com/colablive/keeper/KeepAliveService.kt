package com.colablive.keeper

import android.app.*
import android.content.*
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.colablive.keeper.core.DebugLog

/**
 * Foreground Service + WakeLock + JobScheduler backup.
 * Giữ app sống khi chuyển app hoặc tắt màn hình.
 */
class KeepAliveService : Service() {

    companion object {
        const val CHANNEL_ID = "live_browser_keepalive"
        const val NOTIFICATION_ID = 1
        const val JOB_ID = 1001
        const val ACTION_START = "com.colablive.keeper.KEEPALIVE_START"
        const val ACTION_STOP = "com.colablive.keeper.KEEPALIVE_STOP"

        // companion object = sống qua việc Service bị huỷ/tạo lại nhiều lần
        // (khác biến instance thường — mỗi lần service start lại là 1
        // instance MỚI, biến instance sẽ mất giá trị, không chặn được lặp).
        @Volatile private var lastScheduleTime = 0L

        fun start(context: Context) {
            val intent = Intent(context, KeepAliveService::class.java).apply {
                action = ACTION_START
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, KeepAliveService::class.java))
        }
    }

    private var wakeLock: PowerManager.WakeLock? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startKeepAlive()
            ACTION_STOP -> stopSelf()
        }
        return START_STICKY
    }

    private fun startKeepAlive() {
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Live Browser")
            .setContentText("Đang giữ phiên làm việc...")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

        startForeground(NOTIFICATION_ID, notification)

        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "LiveBrowser::KeepAlive").apply {
            setReferenceCounted(false)
            acquire(10 * 60 * 1000L)
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            scheduleKeepAliveJob()
        }

        DebugLog.log("KeepAliveService started")
    }

    private fun scheduleKeepAliveJob() {
        val jobScheduler = getSystemService(Context.JOB_SCHEDULER_SERVICE) as android.app.job.JobScheduler

        // Lá chắn 1 (nguyên nhân gốc của vòng lặp): job này đã được lên lịch
        // (pending) từ trước rồi thì KHÔNG schedule lại. Trước đây gọi
        // schedule() vô điều kiện MỖI LẦN service start — kể cả khi chính
        // service được job khởi động lại → job tự lên lịch lại chính nó →
        // kích hoạt lại gần như ngay lập tức → lặp hàng trăm lần/phút → vượt
        // giới hạn 250 lần/60s của Android → toàn app crash (đã xác nhận
        // đúng bằng log crash thật).
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            if (jobScheduler.getPendingJob(JOB_ID) != null) {
                DebugLog.log("KeepAliveJob đã pending sẵn — bỏ qua, không schedule lại")
                return
            }
        }

        // Lá chắn 2 (phòng thêm — không phụ thuộc hoàn toàn lá chắn 1, vì
        // hành vi getPendingJob có thể khác nhau giữa các OEM/bản Android):
        // không schedule lại nếu vừa schedule cách đây chưa tới 60s.
        val now = System.currentTimeMillis()
        if (now - lastScheduleTime < 60_000L) {
            DebugLog.log("KeepAliveJob vừa schedule <60s trước — bỏ qua để tránh lặp")
            return
        }
        lastScheduleTime = now

        val componentName = android.content.ComponentName(this, KeepAliveJobService::class.java)
        val jobInfo = android.app.job.JobInfo.Builder(JOB_ID, componentName)
            .setRequiredNetworkType(android.app.job.JobInfo.NETWORK_TYPE_ANY)
            .setPeriodic(15 * 60 * 1000L)
            .setPersisted(true)
            .setRequiresCharging(false)
            .setRequiresDeviceIdle(false)
            .build()
        jobScheduler.schedule(jobInfo)
        DebugLog.log("KeepAliveJob scheduled")
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Keep Alive", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Giữ phiên trình duyệt không bị ngắt"
                setShowBadge(false)
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        wakeLock?.let { if (it.isHeld) it.release() }
        DebugLog.log("KeepAliveService stopped")
        super.onDestroy()
    }
}

class KeepAliveJobService : android.app.job.JobService() {
    override fun onStartJob(params: android.app.job.JobParameters?): Boolean {
        DebugLog.log("KeepAliveJob triggered")
        KeepAliveService.start(this)
        return false
    }
    override fun onStopJob(params: android.app.job.JobParameters?): Boolean = false
}
