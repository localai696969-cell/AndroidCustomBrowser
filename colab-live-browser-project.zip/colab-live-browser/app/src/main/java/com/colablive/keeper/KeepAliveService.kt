package com.colablive.keeper

import android.app.*
import android.content.*
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.colablive.keeper.core.DebugLog

/**
 * Foreground Service + WakeLock + JobScheduler backup.
 * Giữ app sống khi chuyển app hoặc tắt màn hình.
 */
class KeepAliveService : Service() {

    companion object {
        const val CHANNEL_ID = "live_browser_keepalive"
        const val NOTIFICATION_ID = 1
        const val ACTION_START = "com.colablive.keeper.KEEPALIVE_START"
        const val ACTION_STOP = "com.colablive.keeper.KEEPALIVE_STOP"

        fun start(context: Context) {
            val intent = Intent(context, KeepAliveService::class.java).apply {
                action = ACTION_START
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, KeepAliveService::class.java))
        }
    }

    private var wakeLock: PowerManager.WakeLock? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startKeepAlive()
            ACTION_STOP -> stopSelf()
        }
        return START_STICKY
    }

    private fun startKeepAlive() {
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Live Browser")
            .setContentText("Đang giữ phiên làm việc...")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

        startForeground(NOTIFICATION_ID, notification)

        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "LiveBrowser::KeepAlive").apply {
            setReferenceCounted(false)
            acquire(10 * 60 * 1000L)
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            scheduleKeepAliveJob()
        }

        DebugLog.log("KeepAliveService started")
    }

    private fun scheduleKeepAliveJob() {
        val jobScheduler = getSystemService(Context.JOB_SCHEDULER_SERVICE) as android.app.job.JobScheduler
        val componentName = android.content.ComponentName(this, KeepAliveJobService::class.java)
        val jobInfo = android.app.job.JobInfo.Builder(1001, componentName)
            .setRequiredNetworkType(android.app.job.JobInfo.NETWORK_TYPE_ANY)
            .setPeriodic(15 * 60 * 1000L)
            .setPersisted(true)
            .setRequiresCharging(false)
            .setRequiresDeviceIdle(false)
            .build()
        jobScheduler.schedule(jobInfo)
        DebugLog.log("KeepAliveJob scheduled")
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Keep Alive", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Giữ phiên trình duyệt không bị ngắt"
                setShowBadge(false)
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        wakeLock?.let { if (it.isHeld) it.release() }
        DebugLog.log("KeepAliveService stopped")
        super.onDestroy()
    }
}

class KeepAliveJobService : android.app.job.JobService() {
    override fun onStartJob(params: android.app.job.JobParameters?): Boolean {
        DebugLog.log("KeepAliveJob triggered")
        KeepAliveService.start(this)
        return false
    }
    override fun onStopJob(params: android.app.job.JobParameters?): Boolean = false
}
