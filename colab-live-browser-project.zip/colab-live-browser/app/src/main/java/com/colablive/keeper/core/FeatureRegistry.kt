package com.colablive.keeper.core

import android.content.Context
import com.colablive.keeper.features.colablive.ColabLiveKeeperFeature
import com.colablive.keeper.features.downloads.DownloadManagerFeature

object FeatureRegistry {
    val features: List<BrowserFeature> = listOf(
        ColabLiveKeeperFeature,
        DownloadManagerFeature
    )

    fun enabledFeatures(context: Context, slotIndex: Int): List<BrowserFeature> =
        features.filter { it.isEnabled(context, slotIndex) }
}
