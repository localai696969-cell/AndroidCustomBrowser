package com.colablive.keeper.core

import android.content.Context
import com.colablive.keeper.features.colablive.ColabLiveKeeperFeature
import com.colablive.keeper.features.downloads.DownloadManagerFeature
import com.colablive.keeper.features.fingerprint.FingerprintSpoofFeature

object FeatureRegistry {
    // Thêm tiện ích mới ở đây khi phát triển thêm — chỉ 1 dòng, không sửa gì khác.
    val features: List<BrowserFeature> = listOf(
        ColabLiveKeeperFeature,
        DownloadManagerFeature,
        FingerprintSpoofFeature
    )

    fun enabledFeatures(context: Context, slotIndex: Int): List<BrowserFeature> =
        features.filter { it.isEnabled(context, slotIndex) }
}
