package com.colablive.keeper.core

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.util.Log
import org.mozilla.geckoview.*
import org.mozilla.geckoview.WebExtension.MessageDelegate
import org.mozilla.geckoview.WebExtension.Port
import org.mozilla.geckoview.WebExtension.PortDelegate
import java.io.File
import java.io.FileOutputStream
import java.util.*
import java.util.concurrent.ConcurrentHashMap
import org.json.JSONObject
import org.json.JSONArray
import com.colablive.keeper.features.fingerprint.DeviceProfiles
import com.colablive.keeper.features.fingerprint.FingerprintSpoofFeature

/**
 * Implementation của BrowserEngine dùng GeckoView.
 * Hỗ trợ multi-tab, drag-drop, proxy per slot, DNS over HTTPS, timezone sync, auto behavior.
 */
class GeckoViewEngine(
    private val context: Context,
    private val geckoView: GeckoView,
    private val slotIndex: Int
) : BrowserEngine {

    private val runtime: GeckoRuntime = GeckoRuntimeProvider.get(context, slotIndex)
    private val tabs = ConcurrentHashMap<String, GeckoSession>()
    private val tabMeta = ConcurrentHashMap<String, BrowserTab>()
    private var activeTabId: String? = null
    private val handler = Handler(Looper.getMainLooper())
    private val random = Random(slotIndex.toLong())

    private var evalCallback: ((String?) -> Unit)? = null
    private val evalPorts = mutableSetOf<Port>()
    private var pendingFilePrompt: GeckoSession.PromptDelegate.FilePrompt? = null
    private var pendingFilePromptResult: GeckoResult<GeckoSession.PromptDelegate.PromptResponse>? = null

    var onPageLoadedListener: ((String) -> Unit)? = null
    var onPageErrorListener: ((String, Int) -> Unit)? = null
    var onTitleChangedListener: ((String) -> Unit)? = null
    var onProgressChangedListener: ((Int) -> Unit)? = null
    var onNewTabRequestedListener: ((String) -> Unit)? = null
    var onDownloadRequestedListener: ((String, String) -> Unit)? = null
    var onFilePromptListener: ((Array<String>?) -> Unit)? = null
    var onTabSwitchedListener: ((BrowserTab) -> Unit)? = null
    var onLongPressLinkListener: ((linkUri: String, linkText: String?) -> Unit)? = null

    /**
     * QUAN TRỌNG: chọn 1 LẦN DUY NHẤT cho cả engine (không phải mỗi tab/mỗi
     * lần connect extension) — dùng CHUNG cho cả:
     *   1) UA header HTTP thật (`GeckoSessionSettings.userAgentOverride`, áp
     *      dụng ở `createSession()`)
     *   2) `navigator.userAgent` phía JS (đẩy qua `buildFingerprintConfigMessage()`)
     * Trước đây 2 chỗ này KHÔNG dùng chung 1 nguồn — hệ quả: header HTTP
     * thật (Firefox/GeckoView) và `navigator.userAgent` JS (chuỗi Chrome giả)
     * KHÔNG KHỚP NHAU, một mismatch cực kỳ dễ bị site/anti-bot phát hiện
     * (nhiều hệ thống so sánh trực tiếp UA header với navigator.userAgent).
     * Cache 1 lần còn tránh việc chế độ "fresh" (random mỗi lần) chọn ra 2
     * profile KHÁC NHAU cho HTTP header và JS trong cùng 1 lần mở khe.
     */
    private var cachedProfile: Pair<DeviceProfiles.HardwareProfile, DeviceProfiles.LocaleProfile>? = null
    private fun resolveProfile(): Pair<DeviceProfiles.HardwareProfile, DeviceProfiles.LocaleProfile> {
        cachedProfile?.let { return it }
        val fresh = AppPrefs.getBoolean(context, slotIndex, "fp_fresh", false)
        val resolved = if (fresh) {
            DeviceProfiles.getRandomProfileFresh()
        } else {
            val profileName = ProfileSlots.getSlotAssignment(context, slotIndex)
            val hwIdx = AppPrefs.getInt(context, slotIndex, "fp_hw_idx", DeviceProfiles.defaultHwIndexForProfile(profileName))
            val localeIdx = AppPrefs.getInt(context, slotIndex, "fp_locale_idx", DeviceProfiles.defaultLocaleIndexForProfile(profileName))
            DeviceProfiles.getProfileByIndex(hwIdx, localeIdx)
        }
        cachedProfile = resolved
        return resolved
    }

    init {
        setupEvalBridge()
        setupFingerprintExtension()
    }

    // ===== BrowserEngine Implementation =====

    override fun currentUrl(): String? {
        return activeTabId?.let { tabMeta[it]?.url }
    }

    override fun evaluateJs(script: String, callback: ((String?) -> Unit)?) {
        evalCallback = callback
        // ĐÃ SỬA (cùng lượt với việc bật all_frames:true cho eval_bridge):
        // trước đây `evalPort` là 1 biến DUY NHẤT, bị GHI ĐÈ mỗi khi có
        // frame mới connect — nghĩa là chỉ script chạy được ở ĐÚNG 1 frame
        // (frame connect SAU CÙNG, không đảm bảo là frame gốc/frame chứa
        // video). Xác nhận qua chính bug đang tìm: `keepPlayingScript`
        // (chống YouTube tự pause khi ẩn trang) chỉ chạm được document GỐC,
        // KHÔNG chạm được vào bên trong iframe (nơi nhiều trình phát video
        // nhúng thật sự chạy) — vì `eval_bridge/manifest.json` thiếu
        // `all_frames: true`. Giờ đã bật `all_frames`, mỗi frame (kể cả
        // iframe) sẽ tự mở 1 port riêng — phải gửi script tới TẤT CẢ port
        // đang có, không chỉ 1, để chạm được đúng frame chứa video.
        val dead = mutableListOf<Port>()
        evalPorts.forEach { port ->
            try {
                port.postMessage(JSONObject().apply {
                    put("action", "eval")
                    put("script", script)
                })
            } catch (e: Exception) {
                dead.add(port) // port đã chết (frame unload) — dọn sau, không sửa trong lúc forEach
            }
        }
        dead.forEach { evalPorts.remove(it) }
    }

    override fun loadUrl(url: String) {
        activeTabId?.let { tabId ->
            tabs[tabId]?.loadUri(url)
            tabMeta[tabId]?.url = url
        }
    }

    override fun reload() {
        activeTabId?.let { tabs[it]?.reload() }
    }

    override fun goBack(): Boolean {
        val tabId = activeTabId ?: return false
        val session = tabs[tabId] ?: return false
        if (tabMeta[tabId]?.canGoBack == true) {
            session.goBack()
            return true
        }
        return false
    }

    override fun goForward(): Boolean {
        val tabId = activeTabId ?: return false
        val session = tabs[tabId] ?: return false
        if (tabMeta[tabId]?.canGoForward == true) {
            session.goForward()
            return true
        }
        return false
    }

    override fun canGoBack(): Boolean {
        return activeTabId?.let { tabMeta[it]?.canGoBack } ?: false
    }

    override fun canGoForward(): Boolean {
        return activeTabId?.let { tabMeta[it]?.canGoForward } ?: false
    }

    // ===== Multi-Tab =====

    /**
     * BUG THẬT đã sửa — trước giờ KHÔNG có gì lưu lại danh sách tab đang mở
     * cả: `tabs`/`tabMeta` chỉ tồn tại TRONG BỘ NHỚ, mất sạch mỗi khi
     * process chết (đóng app, crash, hay Android tự dọn nền) — khác hẳn
     * Chrome/Firefox thật (luôn tự mở lại đúng các tab đang có sau khi
     * khởi động lại). Người dùng hỏi đúng — đây là tính năng thiếu thật, có
     * thể làm được, không phải hạn chế của GeckoView.
     *
     * Cách làm: lưu URL + tiêu đề của từng tab (KHÔNG lưu lịch sử back/
     * forward/scroll/form đầy đủ của từng tab — muốn vậy cần dùng
     * `GeckoSession.saveState()`/`restoreState()`, API bất đồng bộ phức tạp
     * hơn nhiều, để dành làm sau nếu cần) vào 1 file JSON ngay TRONG thư mục
     * hồ sơ Gecko (đi theo hồ sơ luôn — hồ sơ nào có tab nấy, xuất/nhập hồ
     * sơ cũng mang theo danh sách tab). Lưu mỗi khi danh sách tab thay đổi
     * (mở/đóng tab) + mỗi khi khe mất foreground (`onPause`, xem
     * MainActivity) — không lưu SAU KHI crash được (crash thì không kịp
     * chạy code nữa) nhưng lưu ĐỦ THƯỜNG XUYÊN trước đó nên vẫn khôi phục
     * được gần như đầy đủ sau crash.
     */
    private fun tabStateFile(): File {
        val profileNamespace = ProfileSlots.getSlotAssignment(context, slotIndex)
        val dir = File(context.filesDir, "gecko_profile_" + profileNamespace.replace(Regex("[^a-zA-Z0-9_-]"), "_"))
        dir.mkdirs()
        return File(dir, "saved_tabs.json")
    }

    fun saveTabsState() {
        try {
            val arr = JSONArray()
            tabMeta.values.forEach { tab ->
                if (tab.url.isNotBlank()) {
                    arr.put(JSONObject().apply {
                        put("url", tab.url)
                        put("title", tab.title ?: "")
                        put("active", tab.id == activeTabId)
                        // Trạng thái ĐẦY ĐỦ (lịch sử/cuộn/form) nếu có — xem
                        // giải thích lớn ở onSessionStateChange() phía trên.
                        tab.savedState?.let { put("state", it) }
                    })
                }
            }
            if (arr.length() == 0) {
                tabStateFile().delete()
                return
            }
            val tmp = File(tabStateFile().parentFile, "saved_tabs.json.tmp")
            tmp.writeText(arr.toString())
            tmp.renameTo(tabStateFile())
        } catch (e: Exception) {
            DebugLog.log("saveTabsState lỗi: ${e.message}")
        }
    }

    /** Trả về `true` nếu đã khôi phục được ít nhất 1 tab (gọi nơi tạo tab
     * đầu tiên lúc khởi động — nếu trả `true` thì KHÔNG tạo thêm tab trang
     * chủ mặc định nữa, xem `MainActivity.setupUI()`). */
    fun restoreTabsIfAny(): Boolean {
        return try {
            val f = tabStateFile()
            if (!f.exists()) return false
            val arr = JSONArray(f.readText())
            if (arr.length() == 0) return false
            var restoredActiveId: String? = null
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                val url = obj.optString("url", "")
                if (url.isBlank()) continue
                val savedState = if (obj.has("state")) obj.optString("state", null) else null
                val tab = createTabWithState(url, savedState)
                if (obj.optBoolean("active", false)) restoredActiveId = tab.id
            }
            restoredActiveId?.let { switchToTab(it) }
            DebugLog.log("Khe $slotIndex: khôi phục ${arr.length()} tab từ lần trước")
            true
        } catch (e: Exception) {
            DebugLog.log("restoreTabsIfAny lỗi: ${e.message}")
            false
        }
    }

    /**
     * Giống `createTab()` nhưng khôi phục ĐẦY ĐỦ trạng thái (lịch sử back/
     * forward, vị trí cuộn, dữ liệu form) qua `session.restoreState()` nếu
     * có, thay vì chỉ `loadUri()` mở trang trắng mới. KHÔNG gọi `loadUri()`
     * khi có savedState — `restoreState()` đã tự đưa về đúng trang/lịch sử,
     * gọi thêm `loadUri()` sẽ ĐIỀU HƯỚNG ĐI MẤT trạng thái vừa khôi phục.
     */
    private fun createTabWithState(url: String, savedState: String?): BrowserTab {
        val tabId = UUID.randomUUID().toString()
        val session = createSession()
        val tab = BrowserTab(id = tabId, url = url, savedState = savedState)

        tabs[tabId] = session
        tabMeta[tabId] = tab

        if (activeTabId == null) {
            switchToTab(tabId)
        }

        if (savedState != null) {
            try {
                val state = GeckoSession.SessionState.fromString(savedState)
                if (state != null) {
                    session.restoreState(state)
                } else {
                    session.loadUri(url)
                }
            } catch (e: Exception) {
                DebugLog.log("Khe $slotIndex: restoreState lỗi (${e.message}) — tải URL thường thay thế")
                session.loadUri(url)
            }
        } else {
            session.loadUri(url)
        }
        return tab
    }

    /**
     * LỊCH SỬ DUYỆT WEB — logic thật nằm ở `BrowserHistory.kt` (tách riêng
     * để `HistoryActivity` dùng chung được, không cần 1 GeckoViewEngine
     * đang sống). Ở đây chỉ gọi qua, tự bọc luồng nền cho phần ghi (bài học
     * từ bug "chặn UI thread", mục 8t).
     */
    fun recordHistoryVisit(url: String) {
        Thread { BrowserHistory.recordVisit(context, slotIndex, url) }.start()
    }

    fun updateLastHistoryTitle(url: String, title: String) {
        Thread { BrowserHistory.updateTitle(context, slotIndex, url, title) }.start()
    }

    /**
     * "Xem bằng máy tính" (Desktop Site) — API xác nhận từ code mẫu chính
     * thức Mozilla (`GeckoViewActivity.java`): `session.getSettings()` trả
     * về đối tượng cấu hình CÒN SỐNG (đổi lúc đang chạy, không cần tạo lại
     * session) — `setUserAgentMode()` đổi UA gửi lên server,
     * `setViewportMode()` đổi cách trang tự bố cục (đúng cơ chế "Request
     * Desktop Site" thật của trình duyệt mobile, không chỉ đổi 1 chuỗi UA).
     * Gọi `reload()` sau đó để trang tải lại đúng theo chế độ mới.
     */
    /**
     * BUG THẬT đã sửa (người dùng hỏi đúng trọng tâm: "có đồng bộ với
     * fingerprint không, hay đầu voi đuôi chuột"): TRƯỚC ĐÂY hàm này chỉ
     * đổi `userAgentMode`/`viewportMode` — KHÔNG đụng gì tới
     * `userAgentOverride` (chuỗi UA giả CỐ ĐỊNH gán lúc tạo session từ hồ
     * sơ fingerprint, xem `createSessionUnopened()`). Vấn đề:
     * `userAgentOverride` LUÔN ưu tiên hơn `userAgentMode` khi cả 2 cùng
     * tồn tại — bật "Xem bằng máy tính" chỉ đổi LAYOUT trang (viewport)
     * nhưng UA HTTP thật gửi lên server VẪN LÀ chuỗi mobile giả ban đầu.
     * Kết quả: vừa "đầu voi đuôi chuột" (trang tự phát hiện qua UA vẫn
     * phục vụ bản mobile dù layout đã đổi desktop) VỪA làm fingerprint TỆ
     * HƠN cả không bật gì (UA nói "mobile" nhưng hành vi render lại là
     * desktop — bất nhất, chính bất nhất này là 1 tín hiệu fingerprint).
     *
     * Sửa: bật desktop thì XOÁ override (dùng UA desktop mặc định thật của
     * GeckoView — nhất quán với layout desktop); tắt thì khôi phục lại
     * đúng UA giả ban đầu theo hồ sơ fingerprint đang chọn (nếu đang bật
     * fingerprint spoof).
     */
    fun toggleDesktopMode(tabId: String? = null): Boolean {
        val id = tabId ?: activeTabId ?: return false
        val session = tabs[id] ?: return false
        val settings = session.settings
        val turningOn = settings.userAgentMode != GeckoSessionSettings.USER_AGENT_MODE_DESKTOP
        settings.userAgentMode = if (turningOn) GeckoSessionSettings.USER_AGENT_MODE_DESKTOP else GeckoSessionSettings.USER_AGENT_MODE_MOBILE
        settings.viewportMode = if (turningOn) GeckoSessionSettings.VIEWPORT_MODE_DESKTOP else GeckoSessionSettings.VIEWPORT_MODE_MOBILE
        if (turningOn) {
            settings.userAgentOverride = null
        } else if (FingerprintSpoofFeature.isEnabled(context, slotIndex)) {
            val (hw, _) = resolveProfile()
            settings.userAgentOverride = hw.userAgent
        } else {
            settings.userAgentOverride = null
        }
        session.reload()
        DebugLog.log("Khe $slotIndex: toggleDesktopMode -> ${if (turningOn) "BẬT (UA desktop thật, đã xoá UA giả)" else "TẮT (khôi phục UA giả nếu đang bật fingerprint spoof)"}")
        return turningOn
    }

    fun isDesktopMode(tabId: String? = null): Boolean {
        val id = tabId ?: activeTabId ?: return false
        val session = tabs[id] ?: return false
        return session.settings.userAgentMode == GeckoSessionSettings.USER_AGENT_MODE_DESKTOP
    }

    override fun createTab(url: String): BrowserTab {
        val tabId = UUID.randomUUID().toString()
        val session = createSession()
        val tab = BrowserTab(id = tabId, url = url)

        tabs[tabId] = session
        tabMeta[tabId] = tab

        if (activeTabId == null) {
            switchToTab(tabId)
        }

        session.loadUri(url)
        saveTabsState()
        return tab
    }

    override fun closeTab(tabId: String) {
        tabs[tabId]?.close()
        tabs.remove(tabId)
        tabMeta.remove(tabId)

        if (activeTabId == tabId) {
            val remaining = tabs.keys.toList()
            activeTabId = remaining.firstOrNull()
            activeTabId?.let { switchToTab(it) }
        }
        saveTabsState()
    }

    override fun switchToTab(tabId: String) {
        val session = tabs[tabId] ?: return
        activeTabId = tabId
        geckoView.setSession(session)
        tabMeta[tabId]?.let { onTabSwitchedListener?.invoke(it) }
    }

    override fun getTabs(): List<BrowserTab> {
        return tabMeta.values.toList()
    }

    override fun getActiveTab(): BrowserTab? {
        return activeTabId?.let { tabMeta[it] }
    }

    // ===== Drag & Drop =====

    override fun handleDropUri(uri: Uri, mimeType: String?) {
        val actualMime = mimeType ?: context.contentResolver.getType(uri) ?: "*/*"

        try {
            val fileName = getFileNameFromUri(uri) ?: "dropped_file"
            val tempFile = File(context.cacheDir, "drops/$fileName")
            tempFile.parentFile?.mkdirs()

            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(tempFile).use { output ->
                    input.copyTo(output)
                }
            }

            val js = """
                (function() {
                    var inputs = document.querySelectorAll('input[type="file"]');
                    if (inputs.length > 0) {
                        window.dispatchEvent(new CustomEvent('livebrowser:filedrop', {
                            detail: { path: '${tempFile.absolutePath}', mime: '$actualMime' }
                        }));
                        return 'file_drop_triggered';
                    }
                    return 'no_file_input';
                })()
            """.trimIndent()

            evaluateJs(js) { result ->
                DebugLog.log("Drop file: $fileName ($actualMime) → $result")
            }

        } catch (e: Exception) {
            DebugLog.log("Drop file error: ${e.message}")
        }
    }

    // ===== Auto Behavior (Giả lập người dùng) =====

    /**
     * Giả lập hành vi người dùng để tránh bot detection.
     * Chạy ngẫu nhiên: scroll, click, đợi.
     */
    fun startAutoBehavior() {
        if (!AppPrefs.getBoolean(context, slotIndex, "auto_behavior", false)) return

        val behaviorRunnable = object : Runnable {
            override fun run() {
                if (!AppPrefs.getBoolean(context, slotIndex, "auto_behavior", false)) return

                val actions = listOf(
                    "window.scrollBy(0, ${random.nextInt(100, 500)});",
                    "window.scrollBy(0, -${random.nextInt(50, 300)});",
                    "document.querySelector('button, a, input')?.focus();",
                    "document.body.click();",
                    "window.scrollTo(0, document.body.scrollHeight * ${random.nextDouble()});"
                )

                val action = actions[random.nextInt(actions.size)]
                evaluateJs(action) {}

                // Đợi ngẫu nhiên 5-30 giây trước action tiếp
                val delay = 5000 + random.nextInt(25000)
                handler.postDelayed(this, delay.toLong())
            }
        }

        handler.postDelayed(behaviorRunnable, 10000) // Bắt đầu sau 10 giây
        DebugLog.log("Auto behavior started for slot $slotIndex")
    }

    fun stopAutoBehavior() {
        handler.removeCallbacksAndMessages(null)
        DebugLog.log("Auto behavior stopped for slot $slotIndex")
    }

    // ===== Internal =====

    private fun createSessionUnopened(): GeckoSession {
        val builder = GeckoSessionSettings.Builder()
            .usePrivateMode(false)
            .useTrackingProtection(true)
            .suspendMediaWhenInactive(false)
            .contextId("profile_${ProfileSlots.getSlotAssignment(context, slotIndex)}")

        // UA header HTTP THẬT — khớp CHÍNH XÁC với navigator.userAgent phía JS
        // (xem buildFingerprintConfigMessage). Trước đây chỉ có JS override,
        // header HTTP thật vẫn để lộ GeckoView/Firefox thật — mismatch dễ bị
        // phát hiện hơn cả không giả UA gì. LUÔN đi cùng hardware spoof —
        // không có tổ hợp hợp lệ nào khi tách UA ra khỏi platform/GPU giả.
        if (FingerprintSpoofFeature.isEnabled(context, slotIndex)) {
            val (hw, _) = resolveProfile()
            builder.userAgentOverride(hw.userAgent)

            // Hồ sơ desktop: bật CHẾ ĐỘ DESKTOP THẬT của GeckoView — đúng cơ
            // chế "Request Desktop Site" của trình duyệt mobile thật (viewport
            // CSS 980px, KHÔNG theo <meta viewport> của trang). Đây là thay
            // đổi RENDER THẬT (layout, @media query đều đổi theo), không phải
            // chỉ nói dối 1 property JS như screen.width — thu hẹp đáng kể
            // khoảng cách giữa "khai desktop" và "hiển thị thật vẫn mobile"
            // (không xoá được hoàn toàn — 980 CSS px vẫn khác 1920 thật, và
            // pixel vật lý render ra vẫn là màn hình điện thoại).
            if (hw.category == "desktop") {
                builder.viewportMode(GeckoSessionSettings.VIEWPORT_MODE_DESKTOP)
                builder.userAgentMode(GeckoSessionSettings.USER_AGENT_MODE_DESKTOP)
            }
        }

        val settings = builder.build()

        val session = GeckoSession(settings)

        session.progressDelegate = object : GeckoSession.ProgressDelegate {
            override fun onPageStart(session: GeckoSession, url: String) {
                tabIdFor(session)?.let { tabMeta[it]?.isLoading = true }
                if (tabIdFor(session) == activeTabId) onProgressChangedListener?.invoke(0)
            }

            override fun onPageStop(session: GeckoSession, success: Boolean) {
                val tabId = tabIdFor(session)
                tabId?.let { tabMeta[it]?.isLoading = false }
                if (tabId == activeTabId) onProgressChangedListener?.invoke(100)
                if (success && tabId != null) {
                    val url = tabMeta[tabId]?.url ?: return
                    if (tabId == activeTabId) {
                        onPageLoadedListener?.invoke(url)
                        startAutoBehavior()
                    }
                }
            }

            override fun onProgressChange(session: GeckoSession, progress: Int) {
                if (tabIdFor(session) == activeTabId) onProgressChangedListener?.invoke(progress)
            }

            override fun onSecurityChange(session: GeckoSession, securityInfo: GeckoSession.ProgressDelegate.SecurityInformation) {}

            /**
             * KHÔI PHỤC TAB ĐẦY ĐỦ — đã TRA ĐƯỢC API chính xác (trước đây
             * chỉ khôi phục URL/tiêu đề, KHÔNG có lịch sử back/forward/vị
             * trí cuộn/dữ liệu form, vì "chưa có mạng tra API bất đồng bộ
             * phức tạp hơn"). Xác nhận từ tài liệu GeckoView chính thức:
             * `onSessionStateChange()` tự động fire mỗi khi trạng thái
             * phiên đổi (điều hướng, cuộn, nhập form...), cho
             * `GeckoSession.SessionState` — chuỗi hoá qua `.toString()`,
             * khôi phục lại qua `SessionState.fromString()` +
             * `session.restoreState()`. Chỉ cập nhật biến TRONG BỘ NHỚ ở
             * đây (rẻ, fire rất thường xuyên) — việc GHI XUỐNG ĐĨA vẫn theo
             * đúng các mốc cũ (mở/đóng tab, mất foreground) qua
             * `saveTabsState()`, không ghi đĩa mỗi lần hàm này chạy (sẽ quá
             * nhiều I/O).
             */
            override fun onSessionStateChange(session: GeckoSession, sessionState: GeckoSession.SessionState) {
                tabIdFor(session)?.let { tabId -> tabMeta[tabId]?.savedState = sessionState.toString() }
            }
        }

        session.navigationDelegate = object : GeckoSession.NavigationDelegate {
            override fun onLoadRequest(
                session: GeckoSession,
                request: GeckoSession.NavigationDelegate.LoadRequest
            ): GeckoResult<AllowOrDeny> {
                DebugLog.log("onLoadRequest: ${request.uri}")
                return GeckoResult.allow()
            }

            override fun onLoadError(
                session: GeckoSession,
                uri: String?,
                error: WebRequestError
            ): GeckoResult<String>? {
                DebugLog.log("onLoadError: $uri — code=${error.code}")
                onPageErrorListener?.invoke(uri ?: "", error.code)
                return GeckoResult.fromValue(null)
            }

            override fun onLocationChange(
                session: GeckoSession,
                url: String?,
                perms: MutableList<GeckoSession.PermissionDelegate.ContentPermission>,
                hasUserGesture: Boolean
            ) {
                // GeckoSession không có property currentUri đọc đồng bộ — đây là
                // NGUỒN DUY NHẤT để biết URL hiện tại của 1 session, phải tự cache.
                if (url != null) {
                    tabIdFor(session)?.let { tabMeta[it]?.url = url }
                }
            }

            override fun onCanGoBack(session: GeckoSession, canGoBack: Boolean) {
                tabIdFor(session)?.let { tabMeta[it]?.canGoBack = canGoBack }
            }

            override fun onCanGoForward(session: GeckoSession, canGoForward: Boolean) {
                tabIdFor(session)?.let { tabMeta[it]?.canGoForward = canGoForward }
            }

            override fun onNewSession(
                session: GeckoSession,
                uri: String
            ): GeckoResult<GeckoSession> {
                DebugLog.log("onNewSession (popup): $uri")
                /**
                 * BUG THẬT đã sửa — nguyên nhân CHÍNH XÁC của lỗi
                 * "MessageError: Error: credential propagation was
                 * unsuccessful" khi chạy `drive.mount()` trong Colab: hàm
                 * này TRƯỚC ĐÂY trả về `null` — theo đúng tài liệu
                 * GeckoView, `onNewSession` trả `null` nghĩa là TỪ CHỐI
                 * popup hẳn, JS gọi `window.open()` nhận về KHÔNG có cửa sổ
                 * thật nào cả. Popup xác thực Google Colab mở ra để đăng
                 * nhập cần gửi thông tin đăng nhập NGƯỢC LẠI tab chính qua
                 * `window.opener`/`postMessage` — không có cửa sổ thật thì
                 * không có `window.opener`, việc "propagate credential" chắc
                 * chắn thất bại, đúng y hệt lỗi gặp phải.
                 *
                 * Sửa: tạo 1 `GeckoSession` THẬT cho popup, thêm vào danh
                 * sách tab của chính khe này (người dùng thấy/tương tác
                 * được, vd trang đăng nhập Google) — TRẢ VỀ session đó thay
                 * vì `null`, để `window.open()` phía JS nhận cửa sổ thật,
                 * `window.opener` hoạt động đúng — giống hệt cách
                 * Chrome/Firefox xử lý popup.
                 */
                val popupTabId = UUID.randomUUID().toString()
                // BUG THẬT đã sửa (crash log xác nhận): "Must use an
                // unopened GeckoSession instance" — GeckoView tự MỞ session
                // trả về từ onNewSession, không được mở sẵn trước khi trả
                // về (khác hẳn tab thường, nơi TA tự mở). Dùng
                // createSessionUnopened() (không gọi session.open()), KHÔNG
                // dùng createSession() (có gọi open(), gây crash đúng như
                // log).
                val popupSession = createSessionUnopened()
                val popupTab = BrowserTab(id = popupTabId, url = uri)
                tabs[popupTabId] = popupSession
                tabMeta[popupTabId] = popupTab
                handler.post {
                    switchToTab(popupTabId)
                    onNewTabRequestedListener?.invoke(uri)
                }
                return GeckoResult.fromValue(popupSession)
            }
        }

        session.contentDelegate = object : GeckoSession.ContentDelegate {
            override fun onTitleChange(session: GeckoSession, title: String?) {
                title?.let {
                    val tabId = tabIdFor(session)
                    tabId?.let { id -> tabMeta[id]?.title = it }
                    if (tabId == activeTabId) onTitleChangedListener?.invoke(it)
                }
            }

            override fun onContextMenu(
                session: GeckoSession,
                screenX: Int,
                screenY: Int,
                element: GeckoSession.ContentDelegate.ContextElement
            ) {
                val linkUri = element.linkUri
                if (!linkUri.isNullOrBlank()) {
                    handler.post { onLongPressLinkListener?.invoke(linkUri, element.title) }
                }
            }

            // Chữ ký thật: (session, response: WebResponse) — response.uri là
            // property của WebMessage (lớp cha của WebResponse), KHÔNG có class
            // lồng "GeckoSession.WebResponseInfo" (không tồn tại, code cũ đoán sai).
            override fun onExternalResponse(session: GeckoSession, response: WebResponse) {
                val uri = response.uri
                val fileName = uri.substringAfterLast("/").takeIf { it.isNotEmpty() } ?: "download"
                onDownloadRequestedListener?.invoke(uri, fileName)
            }

            override fun onCrash(session: GeckoSession) {
                DebugLog.log("Session crashed!")
            }

            override fun onKill(session: GeckoSession) {
                DebugLog.log("Session killed by system")
            }
        }

        // onFilePrompt KHÔNG thuộc ContentDelegate (code cũ đặt sai chỗ, kèm
        // theo 1 "FileCallback" không tồn tại) — API thật nằm ở PromptDelegate,
        // nhận 1 đối tượng FilePrompt và trả về GeckoResult<PromptResponse>
        // ĐANG CHỜ (chưa hoàn thành ngay, vì việc chọn file thật xảy ra bất
        // đồng bộ qua Activity chọn file của Android) — MainActivity gọi lại
        // `resolveFilePrompt()` khi người dùng đã chọn xong để hoàn thành nó.
        session.promptDelegate = object : GeckoSession.PromptDelegate {
            override fun onFilePrompt(
                session: GeckoSession,
                prompt: GeckoSession.PromptDelegate.FilePrompt
            ): GeckoResult<GeckoSession.PromptDelegate.PromptResponse>? {
                DebugLog.log("onFilePrompt: mimeTypes=${prompt.mimeTypes?.joinToString()}")
                val fixedMimeTypes = prompt.mimeTypes?.map { mime ->
                    if (mime.contains("/")) mime else "*/*"
                }?.toTypedArray()
                pendingFilePrompt = prompt
                val result = GeckoResult<GeckoSession.PromptDelegate.PromptResponse>()
                pendingFilePromptResult = result
                onFilePromptListener?.invoke(fixedMimeTypes)
                return result
            }
        }

        /**
         * NÚT PLAY/PAUSE THẬT TRÊN THÔNG BÁO — đã TRA ĐƯỢC API chính xác từ
         * code mẫu CHÍNH THỨC của Mozilla (GeckoViewActivity.java, ứng dụng
         * mẫu đi kèm GeckoView), không còn đoán. Xác nhận: `GeckoSession` có
         * property `mediaSessionDelegate` nhận 1
         * `MediaSession.Delegate` với `onPlay(session, mediaSession)`/
         * `onPause(...)`/`onStop(...)` — đối tượng `mediaSession` truyền vào
         * có `.play()`/`.pause()`/`.stop()` để ĐIỀU KHIỂN NGƯỢC LẠI (dùng khi
         * người dùng bấm nút trên thông báo).
         *
         * Bọc vào `android.media.session.MediaSession` CHUẨN của Android
         * (API nền tảng có sẵn, không cần thêm thư viện) — để hệ thống
         * (thông báo, màn hình khoá) biết và điều khiển được, giống hệt
         * cách mọi app nhạc/video làm.
         *
         * TÌM RA NGUYÊN NHÂN THẬT SỰ của việc mất nhạc nền (sau rất nhiều lần
         * sửa sai hướng trước đây — xem PROJECT_STATUS.md mục 8zb/8zd/8zh):
         * đọc tài liệu kiến trúc CHÍNH THỨC của Mozilla
         * (firefox-source-docs.mozilla.org/mobile/android/geckoview/
         * contributor/geckoview-architecture.html, mục "Priority Hint") xác
         * nhận: GeckoView TỰ GẮN độ ưu tiên tiến trình của 1 session với
         * việc session đó CÒN SURFACE (còn hiển thị) hay không — khi Activity
         * xuống nền, surface bị Android tự thu hồi, GeckoView tự hạ độ ưu
         * tiên tiến trình của CHÍNH GeckoSession đó (không liên quan gì đến
         * tiến trình chính/`KeepAliveService` — đó là tiến trình con RIÊNG
         * của Gecko, `KeepAliveService` không bảo vệ được nó). Tài liệu ghi
         * rõ đây CHÍNH LÀ tình huống "phát nhạc nền" — và cung cấp sẵn API
         * chính thức để xử lý: `GeckoSession.setPriorityHint(int)` — báo cho
         * GeckoView biết "session này quan trọng, giữ ưu tiên cao dù mất
         * surface". Gọi `PRIORITY_HIGH` khi có media đang phát, trả lại
         * `PRIORITY_DEFAULT` khi dừng hẳn — không giữ `PRIORITY_HIGH` mãi để
         * tránh tốn tài nguyên không cần thiết cho tab không phát gì.
         */
        session.mediaSessionDelegate = object : MediaSession.Delegate {
            override fun onPlay(session: GeckoSession, mediaSession: MediaSession) {
                DebugLog.log("Khe $slotIndex: MediaSession onPlay")
                currentGeckoMediaSession = mediaSession
                session.setPriorityHint(GeckoSession.PRIORITY_HIGH)
                updateNativeMediaSession(true)
            }

            override fun onPause(session: GeckoSession, mediaSession: MediaSession) {
                DebugLog.log("Khe $slotIndex: MediaSession onPause")
                session.setPriorityHint(GeckoSession.PRIORITY_DEFAULT)
                updateNativeMediaSession(false)
            }

            override fun onStop(session: GeckoSession, mediaSession: MediaSession) {
                DebugLog.log("Khe $slotIndex: MediaSession onStop")
                session.setPriorityHint(GeckoSession.PRIORITY_DEFAULT)
                updateNativeMediaSession(false)
            }
        }

        return session
    }

    /** Tạo + cấu hình đầy đủ session (delegates, media session...) NHƯNG
     * KHÔNG mở — dùng cho tab thường (gọi `session.open()` ngay sau) VÀ cho
     * popup trong `onNewSession()` (KHÔNG được mở trước, xem giải thích lớn
     * ở đó — GeckoView tự mở session trả về từ `onNewSession`, mở sẵn sẽ
     * crash "Must use an unopened GeckoSession instance"). */
    private fun createSession(): GeckoSession {
        val session = createSessionUnopened()
        DebugLog.log("GeckoViewEngine slot $slotIndex: bắt đầu session.open(runtime)")
        session.open(runtime)
        DebugLog.log("GeckoViewEngine slot $slotIndex: session.open() XONG (không crash)")
        return session
    }

    // MediaSession GeckoView đang phát GẦN NHẤT — dùng để chuyển tiếp lệnh
    // play()/pause() khi người dùng bấm nút trên thông báo hệ thống ngược
    // lại cho ĐÚNG tab đang phát.
    private var currentGeckoMediaSession: MediaSession? = null
    private var nativeMediaSession: android.media.session.MediaSession? = null

    /** Callback cho MainActivity/feature biết trạng thái play/pause để cập nhật
     * thông báo hiển thị (tên bài/trang, icon...). */
    override var onMediaPlaybackStateListener: ((playing: Boolean) -> Unit)? = null

    private fun ensureNativeMediaSession(): android.media.session.MediaSession {
        nativeMediaSession?.let { return it }
        val ms = android.media.session.MediaSession(context, "LiveBrowserMedia_$slotIndex")
        ms.setCallback(object : android.media.session.MediaSession.Callback() {
            override fun onPlay() {
                DebugLog.log("Khe $slotIndex: hệ thống yêu cầu Play (từ thông báo/màn hình khoá)")
                currentGeckoMediaSession?.play()
            }
            override fun onPause() {
                DebugLog.log("Khe $slotIndex: hệ thống yêu cầu Pause (từ thông báo/màn hình khoá)")
                currentGeckoMediaSession?.pause()
            }
            override fun onStop() {
                currentGeckoMediaSession?.stop()
            }
        })
        nativeMediaSession = ms
        return ms
    }

    override fun getNativeMediaSessionToken(): android.media.session.MediaSession.Token =
        ensureNativeMediaSession().sessionToken

    private fun updateNativeMediaSession(playing: Boolean) {
        val ms = ensureNativeMediaSession()
        val state = android.media.session.PlaybackState.Builder()
            .setActions(
                android.media.session.PlaybackState.ACTION_PLAY or
                android.media.session.PlaybackState.ACTION_PAUSE or
                android.media.session.PlaybackState.ACTION_STOP
            )
            .setState(
                if (playing) android.media.session.PlaybackState.STATE_PLAYING else android.media.session.PlaybackState.STATE_PAUSED,
                android.media.session.PlaybackState.PLAYBACK_POSITION_UNKNOWN,
                1f
            )
            .build()
        ms.setPlaybackState(state)
        /**
         * CẬP NHẬT (đảo ngược 1 phần thay đổi trước — thay đổi đó dựa trên
         * "nghi ngờ" chưa test kiểm chứng, không phải xác nhận thật):
         *
         * Đã tra lại tài liệu chính thức Android — `android.media.session.
         * MediaSession.isActive = true` KHÔNG PHẢI là thứ khiến hệ thống
         * "nhắm vào để tự tắt", mà NGƯỢC LẠI: đây là cách CHÍNH THỨC báo cho
         * Android biết "đây là 1 phiên phát media thật đang diễn ra" — thiếu
         * cờ này, hệ thống coi app như app thường (không có ngoại lệ nào cho
         * phát nhạc nền), dễ bị giới hạn nền (Doze/App Standby) hơn, không
         * phải ít hơn. Comment cũ ở trên chỉ là suy đoán ("nghi ngờ chính
         * xác dòng này") — CHƯA từng được xác nhận bằng test thật trước khi
         * xoá.
         *
         * Khôi phục lại `ms.isActive` (đặt `true` khi đang phát, `false` khi
         * dừng — không giữ `true` mãi kể cả lúc không phát, tránh giữ phiên
         * "sống" không cần thiết) để test lại với dữ liệu thật, thay vì suy
         * đoán tiếp không kiểm chứng.
         */
        ms.isActive = playing

        onMediaPlaybackStateListener?.invoke(playing)
    }

    private fun tabIdFor(session: GeckoSession): String? =
        tabs.entries.firstOrNull { it.value === session }?.key

    private fun setupEvalBridge() {
        runtime.webExtensionController.ensureBuiltIn(
            "resource://android/assets/eval_bridge/",
            "eval-bridge"
        ).accept { ext ->
            ext?.setMessageDelegate(object : MessageDelegate {
                override fun onConnect(port: Port) {
                    evalPorts.add(port)
                    DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN nhạc nền] eval_bridge có frame mới connect — tổng số port hiện tại = ${evalPorts.size}")
                    port.setDelegate(object : PortDelegate {
                        override fun onPortMessage(message: Any, port: Port) {
                            if (message is JSONObject) {
                                val result = message.optString("result", null)
                                evalCallback?.invoke(result)
                            }
                        }

                        override fun onDisconnect(port: Port) {
                            // Frame (kể cả iframe) đã unload/điều hướng đi —
                            // dọn port khỏi tập hợp, tránh giữ tham chiếu
                            // chết + tránh postMessage vào port đã ngắt.
                            evalPorts.remove(port)
                            DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN nhạc nền] eval_bridge có frame ngắt kết nối — còn lại = ${evalPorts.size}")
                        }
                    })
                }
            }, "browser")
        }
    }

    private fun setupFingerprintExtension() {
        runtime.webExtensionController.ensureBuiltIn(
            "resource://android/assets/fingerprint_spoof/",
            "fingerprint-spoof"
        ).accept(
            { ext ->
                if (ext == null) return@accept
                ext.setMessageDelegate(object : MessageDelegate {
                    override fun onConnect(port: Port) {
                        port.postMessage(buildFingerprintConfigMessage())
                    }
                }, "browser")
                DebugLog.log("Fingerprint spoof extension loaded for slot $slotIndex")
            },
            { error -> DebugLog.log("Slot $slotIndex: không đăng ký được fingerprint extension — $error") }
        )
    }

    /**
     * Đọc lựa chọn thật của người dùng (FingerprintSpoofFeature settings) và
     * build message config gửi cho content.js. 1 công tắc chính (fp_enabled)
     * bật/tắt TOÀN BỘ bộ giả lập (hardware+locale+canvas+audio+font+webrtc) —
     * chưa có UI bật/tắt riêng lẻ từng kỹ thuật.
     */
    private fun buildFingerprintConfigMessage(): JSONObject {
        val enabled = FingerprintSpoofFeature.isEnabled(context, slotIndex)
        val config = JSONObject().put("enabled", enabled)
        if (enabled) {
            val (hw, locale) = resolveProfile()
            config.put("hardware", true)
            config.put("spoofLocale", true)
            config.put("canvas", AppPrefs.getBoolean(context, slotIndex, "fp_t_canvas", true))
            config.put("audio", AppPrefs.getBoolean(context, slotIndex, "fp_t_audio", true))
            config.put("font", AppPrefs.getBoolean(context, slotIndex, "fp_t_font", true))
            config.put("webrtc", AppPrefs.getBoolean(context, slotIndex, "fp_t_webrtc", true))
            config.put("uaSync", true)
            config.put("platform", hw.platform)
            config.put("hardwareConcurrency", hw.hardwareConcurrency)
            config.put("deviceMemory", hw.deviceMemory)
            config.put("maxTouchPoints", hw.maxTouchPoints)
            config.put("screenWidth", hw.screenWidth)
            config.put("screenHeight", hw.screenHeight)
            config.put("colorDepth", hw.colorDepth)
            config.put("pixelRatio", hw.pixelRatio)
            config.put("webglVendor", hw.webglVendor)
            config.put("webglRenderer", hw.webglRenderer)
            config.put("userAgent", hw.userAgent)
            config.put("timezone", locale.timezone)
            config.put("language", locale.language)
            config.put("locale", locale.locale)
            config.put("languages", JSONArray(locale.languages))
        }
        return JSONObject().put("config", config)
    }

    private fun getFileNameFromUri(uri: Uri): String? {
        var result: String? = null
        if (uri.scheme == "content") {
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val idx = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0) result = cursor.getString(idx)
                }
            }
        }
        if (result == null) {
            result = uri.path?.let { File(it).name }
        }
        return result
    }

    /**
     * Gọi từ MainActivity sau khi Activity chọn file (ACTION_OPEN_DOCUMENT)
     * trả về kết quả — hoàn thành GeckoResult đang treo từ onFilePrompt() để
     * trang web THẬT SỰ nhận được file qua <input type="file"> (khác hẳn
     * cách cũ dispatch 1 CustomEvent tự chế mà trang bình thường không nghe).
     */
    fun resolveFilePrompt(context: Context, uri: Uri?) {
        val prompt = pendingFilePrompt
        val result = pendingFilePromptResult
        pendingFilePrompt = null
        pendingFilePromptResult = null
        if (prompt == null || result == null) {
            // CHẨN ĐOÁN: nếu dòng này xuất hiện, nghĩa là lúc gọi
            // resolveFilePrompt() thì KHÔNG CÒN prompt nào đang chờ — có
            // thể do: (a) đã resolve rồi (gọi 2 lần), hoặc (b) 1
            // onFilePrompt MỚI đã ghi đè pendingFilePrompt trước khi lượt
            // cũ kịp resolve (2 lần chọn file liên tiếp, lượt đầu chưa xong
            // copy nền thì lượt 2 đã bắt đầu) — nếu đúng vậy thì lượt ĐẦU sẽ
            // luôn "biến mất" không dấu vết, đúng như người dùng mô tả.
            DebugLog.log("resolveFilePrompt: KHÔNG CÒN prompt đang chờ (đã resolve rồi, hoặc bị 1 onFilePrompt mới ghi đè trước khi resolve) — bỏ qua, uri=$uri")
            return
        }
        val response = if (uri != null) prompt.confirm(context, uri) else prompt.dismiss()
        result.complete(response)
        DebugLog.log("resolveFilePrompt: đã ${if (uri != null) "confirm" else "dismiss"} prompt thành công")
    }

    fun release() {
        stopAutoBehavior()
        tabs.values.forEach { it.close() }
        tabs.clear()
        tabMeta.clear()
    }

    /**
     * Cấu hình proxy cho slot này qua eval bridge.
     * Đồng thời setup DNS over HTTPS + timezone.
     */
    /**
     * Proxy riêng theo khe THỰC SỰ được áp dụng — nhưng KHÔNG phải ở đây.
     * Việc đăng ký thật xảy ra tự động trong `GeckoRuntimeProvider.createRuntime()`
     * (đọc proxy_host/proxy_port/... từ AppPrefs, đăng ký WebExtension
     * `proxy_config` dùng browser.proxy.onRequest) ngay khi runtime của khe
     * được tạo lần đầu trong tiến trình.
     *
     * Hàm này chỉ còn tác dụng NHẮC người dùng khởi động lại khe để áp dụng
     * thay đổi vừa lưu — GeckoRuntime của khe đã tồn tại trong tiến trình
     * hiện tại thì không thể đăng ký lại extension với cấu hình mới cho tới
     * khi tiến trình khởi động lại (đóng khe rồi mở lại).
     */
    fun setupProxy(host: String, port: Int, user: String = "", pass: String = "") {
        DebugLog.log(
            "Proxy $host:$port đã lưu cho khe $slotIndex — cần KHỞI ĐỘNG LẠI khe " +
                "(đóng rồi mở lại) để GeckoRuntimeProvider đăng ký WebExtension proxy_config mới."
        )
    }

    fun clearProxy() {
        DebugLog.log("Đã xoá cấu hình proxy cho khe $slotIndex — cần khởi động lại khe để áp dụng.")
    }
}
