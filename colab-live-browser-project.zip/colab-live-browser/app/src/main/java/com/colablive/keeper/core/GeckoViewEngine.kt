package com.colablive.keeper.core

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.util.Log
import org.mozilla.geckoview.*
import org.mozilla.geckoview.WebExtension.MessageDelegate
import org.mozilla.geckoview.WebExtension.Port
import org.mozilla.geckoview.WebExtension.PortDelegate
import java.io.File
import java.io.FileOutputStream
import java.util.*
import java.util.concurrent.ConcurrentHashMap
import org.json.JSONObject
import org.json.JSONArray
import com.colablive.keeper.features.fingerprint.DeviceProfiles
import com.colablive.keeper.features.fingerprint.FingerprintSpoofFeature

/**
 * Implementation của BrowserEngine dùng GeckoView.
 * Hỗ trợ multi-tab, drag-drop, proxy per slot, DNS over HTTPS, timezone sync, auto behavior.
 */
class GeckoViewEngine(
    private val context: Context,
    private val geckoView: GeckoView,
    private val slotIndex: Int
) : BrowserEngine {

    private val runtime: GeckoRuntime = GeckoRuntimeProvider.get(context, slotIndex)
    private val tabs = ConcurrentHashMap<String, GeckoSession>()
    private val tabMeta = ConcurrentHashMap<String, BrowserTab>()
    private var activeTabId: String? = null
    private val handler = Handler(Looper.getMainLooper())
    private val random = Random(slotIndex.toLong())

    private var evalCallback: ((String?) -> Unit)? = null
    private var evalPort: Port? = null
    private var pendingFilePrompt: GeckoSession.PromptDelegate.FilePrompt? = null
    private var pendingFilePromptResult: GeckoResult<GeckoSession.PromptDelegate.PromptResponse>? = null

    var onPageLoadedListener: ((String) -> Unit)? = null
    var onPageErrorListener: ((String, Int) -> Unit)? = null
    var onTitleChangedListener: ((String) -> Unit)? = null
    var onProgressChangedListener: ((Int) -> Unit)? = null
    var onNewTabRequestedListener: ((String) -> Unit)? = null
    var onDownloadRequestedListener: ((String, String) -> Unit)? = null
    var onFilePromptListener: ((Array<String>?) -> Unit)? = null
    var onTabSwitchedListener: ((BrowserTab) -> Unit)? = null

    /**
     * QUAN TRỌNG: chọn 1 LẦN DUY NHẤT cho cả engine (không phải mỗi tab/mỗi
     * lần connect extension) — dùng CHUNG cho cả:
     *   1) UA header HTTP thật (`GeckoSessionSettings.userAgentOverride`, áp
     *      dụng ở `createSession()`)
     *   2) `navigator.userAgent` phía JS (đẩy qua `buildFingerprintConfigMessage()`)
     * Trước đây 2 chỗ này KHÔNG dùng chung 1 nguồn — hệ quả: header HTTP
     * thật (Firefox/GeckoView) và `navigator.userAgent` JS (chuỗi Chrome giả)
     * KHÔNG KHỚP NHAU, một mismatch cực kỳ dễ bị site/anti-bot phát hiện
     * (nhiều hệ thống so sánh trực tiếp UA header với navigator.userAgent).
     * Cache 1 lần còn tránh việc chế độ "fresh" (random mỗi lần) chọn ra 2
     * profile KHÁC NHAU cho HTTP header và JS trong cùng 1 lần mở khe.
     */
    private var cachedProfile: Pair<DeviceProfiles.HardwareProfile, DeviceProfiles.LocaleProfile>? = null
    private fun resolveProfile(): Pair<DeviceProfiles.HardwareProfile, DeviceProfiles.LocaleProfile> {
        cachedProfile?.let { return it }
        val fresh = AppPrefs.getBoolean(context, slotIndex, "fp_fresh", false)
        val resolved = if (fresh) {
            DeviceProfiles.getRandomProfileFresh()
        } else {
            val hwIdx = AppPrefs.getInt(context, slotIndex, "fp_hw_idx", 0)
            val localeIdx = AppPrefs.getInt(context, slotIndex, "fp_locale_idx", 0)
            DeviceProfiles.getProfileByIndex(hwIdx, localeIdx)
        }
        cachedProfile = resolved
        return resolved
    }

    init {
        setupEvalBridge()
        setupFingerprintExtension()
    }

    // ===== BrowserEngine Implementation =====

    override fun currentUrl(): String? {
        return activeTabId?.let { tabMeta[it]?.url }
    }

    override fun evaluateJs(script: String, callback: ((String?) -> Unit)?) {
        evalCallback = callback
        evalPort?.postMessage(JSONObject().apply {
            put("action", "eval")
            put("script", script)
        })
    }

    override fun loadUrl(url: String) {
        activeTabId?.let { tabId ->
            tabs[tabId]?.loadUri(url)
            tabMeta[tabId]?.url = url
        }
    }

    override fun reload() {
        activeTabId?.let { tabs[it]?.reload() }
    }

    override fun goBack(): Boolean {
        val tabId = activeTabId ?: return false
        val session = tabs[tabId] ?: return false
        if (tabMeta[tabId]?.canGoBack == true) {
            session.goBack()
            return true
        }
        return false
    }

    override fun goForward(): Boolean {
        val tabId = activeTabId ?: return false
        val session = tabs[tabId] ?: return false
        if (tabMeta[tabId]?.canGoForward == true) {
            session.goForward()
            return true
        }
        return false
    }

    override fun canGoBack(): Boolean {
        return activeTabId?.let { tabMeta[it]?.canGoBack } ?: false
    }

    override fun canGoForward(): Boolean {
        return activeTabId?.let { tabMeta[it]?.canGoForward } ?: false
    }

    // ===== Multi-Tab =====

    override fun createTab(url: String): BrowserTab {
        val tabId = UUID.randomUUID().toString()
        val session = createSession()
        val tab = BrowserTab(id = tabId, url = url)

        tabs[tabId] = session
        tabMeta[tabId] = tab

        if (activeTabId == null) {
            switchToTab(tabId)
        }

        session.loadUri(url)
        return tab
    }

    override fun closeTab(tabId: String) {
        tabs[tabId]?.close()
        tabs.remove(tabId)
        tabMeta.remove(tabId)

        if (activeTabId == tabId) {
            val remaining = tabs.keys.toList()
            activeTabId = remaining.firstOrNull()
            activeTabId?.let { switchToTab(it) }
        }
    }

    override fun switchToTab(tabId: String) {
        val session = tabs[tabId] ?: return
        activeTabId = tabId
        geckoView.setSession(session)
        tabMeta[tabId]?.let { onTabSwitchedListener?.invoke(it) }
    }

    override fun getTabs(): List<BrowserTab> {
        return tabMeta.values.toList()
    }

    override fun getActiveTab(): BrowserTab? {
        return activeTabId?.let { tabMeta[it] }
    }

    // ===== Drag & Drop =====

    override fun handleDropUri(uri: Uri, mimeType: String?) {
        val actualMime = mimeType ?: context.contentResolver.getType(uri) ?: "*/*"

        try {
            val fileName = getFileNameFromUri(uri) ?: "dropped_file"
            val tempFile = File(context.cacheDir, "drops/$fileName")
            tempFile.parentFile?.mkdirs()

            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(tempFile).use { output ->
                    input.copyTo(output)
                }
            }

            val js = """
                (function() {
                    var inputs = document.querySelectorAll('input[type="file"]');
                    if (inputs.length > 0) {
                        window.dispatchEvent(new CustomEvent('livebrowser:filedrop', {
                            detail: { path: '${tempFile.absolutePath}', mime: '$actualMime' }
                        }));
                        return 'file_drop_triggered';
                    }
                    return 'no_file_input';
                })()
            """.trimIndent()

            evaluateJs(js) { result ->
                DebugLog.log("Drop file: $fileName ($actualMime) → $result")
            }

        } catch (e: Exception) {
            DebugLog.log("Drop file error: ${e.message}")
        }
    }

    // ===== Auto Behavior (Giả lập người dùng) =====

    /**
     * Giả lập hành vi người dùng để tránh bot detection.
     * Chạy ngẫu nhiên: scroll, click, đợi.
     */
    fun startAutoBehavior() {
        if (!AppPrefs.getBoolean(context, slotIndex, "auto_behavior", false)) return

        val behaviorRunnable = object : Runnable {
            override fun run() {
                if (!AppPrefs.getBoolean(context, slotIndex, "auto_behavior", false)) return

                val actions = listOf(
                    "window.scrollBy(0, ${random.nextInt(100, 500)});",
                    "window.scrollBy(0, -${random.nextInt(50, 300)});",
                    "document.querySelector('button, a, input')?.focus();",
                    "document.body.click();",
                    "window.scrollTo(0, document.body.scrollHeight * ${random.nextDouble()});"
                )

                val action = actions[random.nextInt(actions.size)]
                evaluateJs(action) {}

                // Đợi ngẫu nhiên 5-30 giây trước action tiếp
                val delay = 5000 + random.nextInt(25000)
                handler.postDelayed(this, delay.toLong())
            }
        }

        handler.postDelayed(behaviorRunnable, 10000) // Bắt đầu sau 10 giây
        DebugLog.log("Auto behavior started for slot $slotIndex")
    }

    fun stopAutoBehavior() {
        handler.removeCallbacksAndMessages(null)
        DebugLog.log("Auto behavior stopped for slot $slotIndex")
    }

    // ===== Internal =====

    private fun createSession(): GeckoSession {
        val builder = GeckoSessionSettings.Builder()
            .usePrivateMode(false)
            .useTrackingProtection(true)
            .suspendMediaWhenInactive(false)
            .contextId("slot_${slotIndex}")

        // UA header HTTP THẬT — khớp CHÍNH XÁC với navigator.userAgent phía JS
        // (xem buildFingerprintConfigMessage). Trước đây chỉ có JS override,
        // header HTTP thật vẫn để lộ GeckoView/Firefox thật — mismatch dễ bị
        // phát hiện hơn cả không giả UA gì. LUÔN đi cùng hardware spoof —
        // không có tổ hợp hợp lệ nào khi tách UA ra khỏi platform/GPU giả.
        if (FingerprintSpoofFeature.isEnabled(context, slotIndex)) {
            val (hw, _) = resolveProfile()
            builder.userAgentOverride(hw.userAgent)

            // Hồ sơ desktop: bật CHẾ ĐỘ DESKTOP THẬT của GeckoView — đúng cơ
            // chế "Request Desktop Site" của trình duyệt mobile thật (viewport
            // CSS 980px, KHÔNG theo <meta viewport> của trang). Đây là thay
            // đổi RENDER THẬT (layout, @media query đều đổi theo), không phải
            // chỉ nói dối 1 property JS như screen.width — thu hẹp đáng kể
            // khoảng cách giữa "khai desktop" và "hiển thị thật vẫn mobile"
            // (không xoá được hoàn toàn — 980 CSS px vẫn khác 1920 thật, và
            // pixel vật lý render ra vẫn là màn hình điện thoại).
            if (hw.category == "desktop") {
                builder.viewportMode(GeckoSessionSettings.VIEWPORT_MODE_DESKTOP)
                builder.userAgentMode(GeckoSessionSettings.USER_AGENT_MODE_DESKTOP)
            }
        }

        val settings = builder.build()

        val session = GeckoSession(settings)

        session.progressDelegate = object : GeckoSession.ProgressDelegate {
            override fun onPageStart(session: GeckoSession, url: String) {
                tabIdFor(session)?.let { tabMeta[it]?.isLoading = true }
                if (tabIdFor(session) == activeTabId) onProgressChangedListener?.invoke(0)
            }

            override fun onPageStop(session: GeckoSession, success: Boolean) {
                val tabId = tabIdFor(session)
                tabId?.let { tabMeta[it]?.isLoading = false }
                if (tabId == activeTabId) onProgressChangedListener?.invoke(100)
                if (success && tabId != null) {
                    val url = tabMeta[tabId]?.url ?: return
                    if (tabId == activeTabId) {
                        onPageLoadedListener?.invoke(url)
                        startAutoBehavior()
                    }
                }
            }

            override fun onProgressChange(session: GeckoSession, progress: Int) {
                if (tabIdFor(session) == activeTabId) onProgressChangedListener?.invoke(progress)
            }

            override fun onSecurityChange(session: GeckoSession, securityInfo: GeckoSession.ProgressDelegate.SecurityInformation) {}
        }

        session.navigationDelegate = object : GeckoSession.NavigationDelegate {
            override fun onLoadRequest(
                session: GeckoSession,
                request: GeckoSession.NavigationDelegate.LoadRequest
            ): GeckoResult<AllowOrDeny> {
                DebugLog.log("onLoadRequest: ${request.uri}")
                return GeckoResult.allow()
            }

            override fun onLoadError(
                session: GeckoSession,
                uri: String?,
                error: WebRequestError
            ): GeckoResult<String>? {
                DebugLog.log("onLoadError: $uri — code=${error.code}")
                onPageErrorListener?.invoke(uri ?: "", error.code)
                return GeckoResult.fromValue(null)
            }

            override fun onLocationChange(
                session: GeckoSession,
                url: String?,
                perms: MutableList<GeckoSession.PermissionDelegate.ContentPermission>,
                hasUserGesture: Boolean
            ) {
                // GeckoSession không có property currentUri đọc đồng bộ — đây là
                // NGUỒN DUY NHẤT để biết URL hiện tại của 1 session, phải tự cache.
                if (url != null) {
                    tabIdFor(session)?.let { tabMeta[it]?.url = url }
                }
            }

            override fun onCanGoBack(session: GeckoSession, canGoBack: Boolean) {
                tabIdFor(session)?.let { tabMeta[it]?.canGoBack = canGoBack }
            }

            override fun onCanGoForward(session: GeckoSession, canGoForward: Boolean) {
                tabIdFor(session)?.let { tabMeta[it]?.canGoForward = canGoForward }
            }

            override fun onNewSession(
                session: GeckoSession,
                uri: String
            ): GeckoResult<GeckoSession> {
                DebugLog.log("onNewSession (popup): $uri")
                handler.post { onNewTabRequestedListener?.invoke(uri) }
                return GeckoResult.fromValue(null)
            }
        }

        session.contentDelegate = object : GeckoSession.ContentDelegate {
            override fun onTitleChange(session: GeckoSession, title: String?) {
                title?.let {
                    val tabId = tabIdFor(session)
                    tabId?.let { id -> tabMeta[id]?.title = it }
                    if (tabId == activeTabId) onTitleChangedListener?.invoke(it)
                }
            }

            override fun onContextMenu(session: GeckoSession, screenX: Int, screenY: Int, element: GeckoSession.ContentDelegate.ContextElement) {}

            // Chữ ký thật: (session, response: WebResponse) — response.uri là
            // property của WebMessage (lớp cha của WebResponse), KHÔNG có class
            // lồng "GeckoSession.WebResponseInfo" (không tồn tại, code cũ đoán sai).
            override fun onExternalResponse(session: GeckoSession, response: WebResponse) {
                val uri = response.uri
                val fileName = uri.substringAfterLast("/").takeIf { it.isNotEmpty() } ?: "download"
                onDownloadRequestedListener?.invoke(uri, fileName)
            }

            override fun onCrash(session: GeckoSession) {
                DebugLog.log("Session crashed!")
            }

            override fun onKill(session: GeckoSession) {
                DebugLog.log("Session killed by system")
            }
        }

        // onFilePrompt KHÔNG thuộc ContentDelegate (code cũ đặt sai chỗ, kèm
        // theo 1 "FileCallback" không tồn tại) — API thật nằm ở PromptDelegate,
        // nhận 1 đối tượng FilePrompt và trả về GeckoResult<PromptResponse>
        // ĐANG CHỜ (chưa hoàn thành ngay, vì việc chọn file thật xảy ra bất
        // đồng bộ qua Activity chọn file của Android) — MainActivity gọi lại
        // `resolveFilePrompt()` khi người dùng đã chọn xong để hoàn thành nó.
        session.promptDelegate = object : GeckoSession.PromptDelegate {
            override fun onFilePrompt(
                session: GeckoSession,
                prompt: GeckoSession.PromptDelegate.FilePrompt
            ): GeckoResult<GeckoSession.PromptDelegate.PromptResponse>? {
                DebugLog.log("onFilePrompt: mimeTypes=${prompt.mimeTypes?.joinToString()}")
                val fixedMimeTypes = prompt.mimeTypes?.map { mime ->
                    if (mime.contains("/")) mime else "*/*"
                }?.toTypedArray()
                pendingFilePrompt = prompt
                val result = GeckoResult<GeckoSession.PromptDelegate.PromptResponse>()
                pendingFilePromptResult = result
                onFilePromptListener?.invoke(fixedMimeTypes)
                return result
            }
        }

        session.open(runtime)
        return session
    }

    private fun tabIdFor(session: GeckoSession): String? =
        tabs.entries.firstOrNull { it.value === session }?.key

    private fun setupEvalBridge() {
        runtime.webExtensionController.ensureBuiltIn(
            "resource://android/assets/eval_bridge/",
            "eval-bridge"
        ).accept { ext ->
            ext?.setMessageDelegate(object : MessageDelegate {
                override fun onConnect(port: Port) {
                    evalPort = port
                    port.setDelegate(object : PortDelegate {
                        override fun onPortMessage(message: Any, port: Port) {
                            if (message is JSONObject) {
                                val result = message.optString("result", null)
                                evalCallback?.invoke(result)
                            }
                        }
                    })
                }
            }, "browser")
        }
    }

    private fun setupFingerprintExtension() {
        runtime.webExtensionController.ensureBuiltIn(
            "resource://android/assets/fingerprint_spoof/",
            "fingerprint-spoof"
        ).accept(
            { ext ->
                if (ext == null) return@accept
                ext.setMessageDelegate(object : MessageDelegate {
                    override fun onConnect(port: Port) {
                        port.postMessage(buildFingerprintConfigMessage())
                    }
                }, "browser")
                DebugLog.log("Fingerprint spoof extension loaded for slot $slotIndex")
            },
            { error -> DebugLog.log("Slot $slotIndex: không đăng ký được fingerprint extension — $error") }
        )
    }

    /**
     * Đọc lựa chọn thật của người dùng (FingerprintSpoofFeature settings) và
     * build message config gửi cho content.js. 1 công tắc chính (fp_enabled)
     * bật/tắt TOÀN BỘ bộ giả lập (hardware+locale+canvas+audio+font+webrtc) —
     * chưa có UI bật/tắt riêng lẻ từng kỹ thuật.
     */
    private fun buildFingerprintConfigMessage(): JSONObject {
        val enabled = FingerprintSpoofFeature.isEnabled(context, slotIndex)
        val config = JSONObject().put("enabled", enabled)
        if (enabled) {
            val (hw, locale) = resolveProfile()
            config.put("hardware", true)
            config.put("spoofLocale", true)
            config.put("canvas", AppPrefs.getBoolean(context, slotIndex, "fp_t_canvas", true))
            config.put("audio", AppPrefs.getBoolean(context, slotIndex, "fp_t_audio", true))
            config.put("font", AppPrefs.getBoolean(context, slotIndex, "fp_t_font", true))
            config.put("webrtc", AppPrefs.getBoolean(context, slotIndex, "fp_t_webrtc", true))
            config.put("uaSync", true)
            config.put("platform", hw.platform)
            config.put("hardwareConcurrency", hw.hardwareConcurrency)
            config.put("deviceMemory", hw.deviceMemory)
            config.put("maxTouchPoints", hw.maxTouchPoints)
            config.put("screenWidth", hw.screenWidth)
            config.put("screenHeight", hw.screenHeight)
            config.put("colorDepth", hw.colorDepth)
            config.put("pixelRatio", hw.pixelRatio)
            config.put("webglVendor", hw.webglVendor)
            config.put("webglRenderer", hw.webglRenderer)
            config.put("userAgent", hw.userAgent)
            config.put("timezone", locale.timezone)
            config.put("language", locale.language)
            config.put("locale", locale.locale)
            config.put("languages", JSONArray(locale.languages))
        }
        return JSONObject().put("config", config)
    }

    private fun getFileNameFromUri(uri: Uri): String? {
        var result: String? = null
        if (uri.scheme == "content") {
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val idx = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0) result = cursor.getString(idx)
                }
            }
        }
        if (result == null) {
            result = uri.path?.let { File(it).name }
        }
        return result
    }

    /**
     * Gọi từ MainActivity sau khi Activity chọn file (ACTION_OPEN_DOCUMENT)
     * trả về kết quả — hoàn thành GeckoResult đang treo từ onFilePrompt() để
     * trang web THẬT SỰ nhận được file qua <input type="file"> (khác hẳn
     * cách cũ dispatch 1 CustomEvent tự chế mà trang bình thường không nghe).
     */
    fun resolveFilePrompt(context: Context, uri: Uri?) {
        val prompt = pendingFilePrompt
        val result = pendingFilePromptResult
        pendingFilePrompt = null
        pendingFilePromptResult = null
        if (prompt == null || result == null) return
        val response = if (uri != null) prompt.confirm(context, uri) else prompt.dismiss()
        result.complete(response)
    }

    fun release() {
        stopAutoBehavior()
        tabs.values.forEach { it.close() }
        tabs.clear()
        tabMeta.clear()
    }

    /**
     * Cấu hình proxy cho slot này qua eval bridge.
     * Đồng thời setup DNS over HTTPS + timezone.
     */
    /**
     * Proxy riêng theo khe THỰC SỰ được áp dụng — nhưng KHÔNG phải ở đây.
     * Việc đăng ký thật xảy ra tự động trong `GeckoRuntimeProvider.createRuntime()`
     * (đọc proxy_host/proxy_port/... từ AppPrefs, đăng ký WebExtension
     * `proxy_config` dùng browser.proxy.onRequest) ngay khi runtime của khe
     * được tạo lần đầu trong tiến trình.
     *
     * Hàm này chỉ còn tác dụng NHẮC người dùng khởi động lại khe để áp dụng
     * thay đổi vừa lưu — GeckoRuntime của khe đã tồn tại trong tiến trình
     * hiện tại thì không thể đăng ký lại extension với cấu hình mới cho tới
     * khi tiến trình khởi động lại (đóng khe rồi mở lại).
     */
    fun setupProxy(host: String, port: Int, user: String = "", pass: String = "") {
        DebugLog.log(
            "Proxy $host:$port đã lưu cho khe $slotIndex — cần KHỞI ĐỘNG LẠI khe " +
                "(đóng rồi mở lại) để GeckoRuntimeProvider đăng ký WebExtension proxy_config mới."
        )
    }

    fun clearProxy() {
        DebugLog.log("Đã xoá cấu hình proxy cho khe $slotIndex — cần khởi động lại khe để áp dụng.")
    }
}
