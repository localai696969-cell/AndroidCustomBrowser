package com.colablive.keeper.core

import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.GeckoView
import org.mozilla.geckoview.WebExtension

/**
 * Adapter GeckoView cho BrowserEngine.
 *
 * evaluateJs(): hoạt động qua "eval bridge" — content script của WebExtension
 * nội bộ (assets/eval_bridge/) mở 1 Port qua browser.runtime.connectNative(),
 * native side lưu Port qua session.webExtensionController.setMessageDelegate(),
 * evaluateJs() gửi {type:"eval", script} xuống qua port.postMessage(). Cầu
 * nối hiện là 1 CHIỀU (native -> trang) — đủ cho ColabLiveKeeperFeature vì nó
 * không cần giá trị trả về, callback luôn nhận null.
 *
 * onLocationChanged: callback tuỳ chọn để MainActivity biết URL đổi (vì
 * GeckoSession chỉ cho set 1 NavigationDelegate duy nhất — không tự chain
 * nhiều listener được — nên engine giữ delegate, và báo lại qua callback này).
 */
class GeckoViewEngine(
    private val geckoView: GeckoView,
    private val session: GeckoSession,
    private val onLocationChanged: ((String?) -> Unit)? = null
) : BrowserEngine {

    @Volatile private var trackedUrl: String? = null
    @Volatile private var evalPort: WebExtension.Port? = null

    init {
        session.navigationDelegate = object : GeckoSession.NavigationDelegate {
            override fun onLocationChange(
                session: GeckoSession,
                url: String?,
                permissions: MutableList<GeckoSession.PermissionDelegate.ContentPermission>,
                hasUserGesture: Boolean
            ) {
                trackedUrl = url
                onLocationChanged?.invoke(url)
            }
        }

        val extension = GeckoRuntimeProvider.evalBridgeExtension
        if (extension != null) {
            attachPortDelegate(extension)
        } else {
            // Extension cài bất đồng bộ, có thể chưa xong lúc GeckoViewEngine
            // được tạo — thử lại sau 1s thay vì bỏ cuộc luôn.
            Handler(Looper.getMainLooper()).postDelayed({
                GeckoRuntimeProvider.evalBridgeExtension?.let { attachPortDelegate(it) }
            }, 1000L)
        }
    }

    private fun attachPortDelegate(extension: WebExtension) {
        val portDelegate = object : WebExtension.PortDelegate {
            override fun onPortMessage(message: Any, port: WebExtension.Port) {
                // Content script hiện không cần gửi gì lên native cho eval bridge
            }
            override fun onDisconnect(port: WebExtension.Port) {
                if (evalPort == port) evalPort = null
            }
        }
        val messageDelegate = object : WebExtension.MessageDelegate {
            override fun onConnect(port: WebExtension.Port) {
                evalPort = port
                port.setDelegate(portDelegate)
            }
        }
        session.webExtensionController.setMessageDelegate(extension, messageDelegate, GeckoRuntimeProvider.NATIVE_APP_ID)
    }

    override fun currentUrl(): String? = trackedUrl

    override fun loadUrl(url: String) {
        session.load(GeckoSession.Loader().uri(url))
    }

    override fun evaluateJs(script: String, callback: ((String?) -> Unit)?) {
        val port = evalPort
        if (port == null) {
            // Port chưa sẵn sàng (trang vừa mới load, content script chưa kịp
            // connect) — bỏ qua lần này, ColabLiveKeeperFeature sẽ tự thử lại
            // ở chu kỳ tick tiếp theo, không cần retry ở đây.
            callback?.invoke(null)
            return
        }
        port.postMessage(
            JSONObject().apply {
                put("type", "eval")
                put("script", script)
            }
        )
        callback?.invoke(null)
    }
}
