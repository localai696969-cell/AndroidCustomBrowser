package com.colablive.keeper.core

import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import org.mozilla.geckoview.AllowOrDeny
import org.mozilla.geckoview.GeckoResult
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.GeckoView
import org.mozilla.geckoview.WebExtension
import org.mozilla.geckoview.WebRequestError

/**
 * Adapter GeckoView cho BrowserEngine.
 *
 * evaluateJs(): hoạt động qua "eval bridge" (xem assets/eval_bridge/).
 *
 * Thêm mới: goBack()/goForward() + callback onCanGoBackChanged/onCanGoForwardChanged
 * (để MainActivity bật/tắt nút điều hướng đúng trạng thái thật của trang), và
 * onLoadError (để biết trang tải LỖI thay vì tưởng nhầm "bấm không phản ứng"
 * — trước đây load lỗi không có gì báo lại, nhìn như đứng im).
 */
class GeckoViewEngine(
    private val geckoView: GeckoView,
    private val session: GeckoSession,
    private val onLocationChanged: ((String?) -> Unit)? = null,
    private val onCanGoBackChanged: ((Boolean) -> Unit)? = null,
    private val onCanGoForwardChanged: ((Boolean) -> Unit)? = null,
    private val onLoadError: ((String) -> Unit)? = null,
    private val onPopupRequested: ((String) -> Unit)? = null,
    private val onNavigationAttempt: ((String) -> Unit)? = null,
    // Cấu hình fingerprint THẬT (riêng theo khe, tính sẵn bởi
    // FingerprintSpoofFeature.buildConfigJson) — đẩy xuống content script
    // NGAY khi nó connect port, đè lên giá trị mặc định an toàn đã áp dụng
    // sẵn phía JS (xem assets/fingerprint_spoof/content.js).
    private val fingerprintConfig: JSONObject? = null
) : BrowserEngine {

    @Volatile private var trackedUrl: String? = null
    @Volatile private var evalPort: WebExtension.Port? = null

    init {
        session.navigationDelegate = object : GeckoSession.NavigationDelegate {
            override fun onLocationChange(
                session: GeckoSession,
                url: String?,
                permissions: MutableList<GeckoSession.PermissionDelegate.ContentPermission>,
                hasUserGesture: Boolean
            ) {
                trackedUrl = url
                onLocationChanged?.invoke(url)
            }

            override fun onCanGoBack(session: GeckoSession, canGoBack: Boolean) {
                onCanGoBackChanged?.invoke(canGoBack)
            }

            override fun onCanGoForward(session: GeckoSession, canGoForward: Boolean) {
                onCanGoForwardChanged?.invoke(canGoForward)
            }

            override fun onLoadError(
                session: GeckoSession,
                uri: String?,
                error: WebRequestError
            ): GeckoResult<String>? {
                onLoadError?.invoke("Lỗi tải trang: mã ${error.code}, nhóm ${error.category} — URL: $uri")
                return null
            }

            override fun onNewSession(session: GeckoSession, uri: String): GeckoResult<GeckoSession>? {
                // Google Sign-In và nhiều luồng OAuth dùng window.open() để mở
                // popup xác thực. Chưa hỗ trợ popup thật (cần GeckoSession +
                // UI riêng, quy mô lớn hơn) — thay vào đó điều hướng NGAY trên
                // tab hiện tại tới URL đó, đủ dùng cho hầu hết luồng đăng nhập.
                // Trả về null nghĩa là từ chối tạo popup thật (window.open()
                // phía JS sẽ nhận null), nhưng tab hiện tại đã tự chuyển trang.
                onPopupRequested?.invoke(uri)
                return null
            }

            override fun onLoadRequest(
                session: GeckoSession,
                request: GeckoSession.NavigationDelegate.LoadRequest
            ): GeckoResult<AllowOrDeny>? {
                // CHẨN ĐOÁN TẠM THỜI: báo lại MỌI yêu cầu điều hướng — để biết
                // chắc bấm nút đăng nhập có kích hoạt được sự kiện nào không,
                // hay bị chặn từ sớm hơn cả tầng navigation (vd lỗi nhận
                // touch/click trong GeckoView) — không liên quan gì tới code
                // popup/onNewSession đã sửa trước đó nếu event này không fire.
                onNavigationAttempt?.invoke(
                    "onLoadRequest: ${request.uri} (isRedirect=${request.isRedirect}, hasGesture=${request.hasUserGesture})"
                )
                return null
            }
        }

        val extension = GeckoRuntimeProvider.evalBridgeExtension
        if (extension != null) {
            attachPortDelegate(extension)
        } else {
            Handler(Looper.getMainLooper()).postDelayed({
                GeckoRuntimeProvider.evalBridgeExtension?.let { attachPortDelegate(it) }
            }, 1000L)
        }

        val fpExtension = GeckoRuntimeProvider.fingerprintSpoofExtension
        if (fpExtension != null) {
            attachFingerprintPortDelegate(fpExtension)
        } else {
            Handler(Looper.getMainLooper()).postDelayed({
                GeckoRuntimeProvider.fingerprintSpoofExtension?.let { attachFingerprintPortDelegate(it) }
            }, 1000L)
        }
    }

    fun goBack() {
        session.goBack()
    }

    fun goForward() {
        session.goForward()
    }

    private fun attachPortDelegate(extension: WebExtension) {
        val portDelegate = object : WebExtension.PortDelegate {
            override fun onPortMessage(message: Any, port: WebExtension.Port) {}
            override fun onDisconnect(port: WebExtension.Port) {
                if (evalPort == port) evalPort = null
            }
        }
        val messageDelegate = object : WebExtension.MessageDelegate {
            override fun onConnect(port: WebExtension.Port) {
                evalPort = port
                port.setDelegate(portDelegate)
            }
        }
        session.webExtensionController.setMessageDelegate(extension, messageDelegate, GeckoRuntimeProvider.NATIVE_APP_ID)
    }

    private fun attachFingerprintPortDelegate(extension: WebExtension) {
        val portDelegate = object : WebExtension.PortDelegate {
            override fun onPortMessage(message: Any, port: WebExtension.Port) {}
            override fun onDisconnect(port: WebExtension.Port) {}
        }
        val messageDelegate = object : WebExtension.MessageDelegate {
            override fun onConnect(port: WebExtension.Port) {
                port.setDelegate(portDelegate)
                // Đẩy config THẬT xuống NGAY lúc connect — cố gắng thắng
                // trước lúc trang kịp đọc giá trị mặc định đã áp dụng sẵn.
                val cfg = fingerprintConfig ?: return
                port.postMessage(
                    JSONObject().apply {
                        put("type", "fp_config")
                        put("config", cfg)
                    }
                )
            }
        }
        session.webExtensionController.setMessageDelegate(extension, messageDelegate, GeckoRuntimeProvider.NATIVE_APP_ID)
    }

    override fun currentUrl(): String? = trackedUrl

    override fun loadUrl(url: String) {
        session.load(GeckoSession.Loader().uri(url))
    }

    override fun evaluateJs(script: String, callback: ((String?) -> Unit)?) {
        val port = evalPort
        if (port == null) {
            callback?.invoke(null)
            return
        }
        port.postMessage(
            JSONObject().apply {
                put("type", "eval")
                put("script", script)
            }
        )
        callback?.invoke(null)
    }
}
