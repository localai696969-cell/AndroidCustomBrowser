package com.colablive.keeper.core

import android.content.Context
import android.os.Build
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.util.Log
import org.mozilla.geckoview.*
import org.mozilla.geckoview.WebExtension.MessageDelegate
import org.mozilla.geckoview.WebExtension.Port
import org.mozilla.geckoview.WebExtension.PortDelegate
import java.io.File
import java.io.FileOutputStream
import java.util.*
import java.util.concurrent.ConcurrentHashMap
import org.json.JSONObject
import org.json.JSONArray
import com.colablive.keeper.features.fingerprint.DeviceProfiles
import com.colablive.keeper.features.fingerprint.FingerprintSpoofFeature
import com.colablive.keeper.MediaKeepAliveService

/**
 * Implementation của BrowserEngine dùng GeckoView.
 * Hỗ trợ multi-tab, drag-drop, proxy per slot, DNS over HTTPS, timezone sync, auto behavior.
 */
class GeckoViewEngine(
    private val context: Context,
    private var geckoView: GeckoView,
    private val slotIndex: Int
) : BrowserEngine {

    /**
     * Registry nhẹ (slotIndex -> engine đang chạy) — để các màn hình Settings
     * (VD `FingerprintSpoofFeature.buildSettingsView()`) có thể gọi tới
     * engine THẬT đang chạy mà không cần đổi interface `BrowserFeature.
     * buildSettingsView(context, slotIndex)` (chữ ký hiện KHÔNG có tham số
     * `engine` — đổi sẽ động vào 5 file khác, không cần thiết cho việc nhỏ
     * này). Dùng cho: sau khi lưu danh sách ngoại lệ tên miền desktop-player
     * trong Settings, áp dụng lại NGAY cho tab đang mở (không phải đợi điều
     * hướng tiếp theo mới có tác dụng — xem `applyExceptionAndReloadActiveTab()`).
     */
    companion object {
        private val instances = ConcurrentHashMap<Int, GeckoViewEngine>()
        fun forSlot(slotIndex: Int): GeckoViewEngine? = instances[slotIndex]
    }

    private val runtime: GeckoRuntime = GeckoRuntimeProvider.get(context, slotIndex)
    private val tabs = ConcurrentHashMap<String, GeckoSession>()
    private val tabMeta = ConcurrentHashMap<String, BrowserTab>()
    // BUG THẬT tìm ra (người dùng báo tab sắp xếp lộn xộn sau khi khôi
    // phục): `tabMeta`/`tabs` đều là `ConcurrentHashMap` — KHÔNG giữ thứ tự
    // chèn vào, `.values` trả về theo thứ tự bucket hash nội bộ, không phải
    // thứ tự người dùng mở tab. Ảnh hưởng CẢ `getTabs()` (nguồn cho thanh
    // chuyển tab UI — nghĩa là lộn xộn xảy ra ngay cả lúc dùng bình thường,
    // không chỉ lúc khôi phục) LẪN `saveTabsState()`/`restoreTabsIfAny()`.
    // Thêm danh sách thứ tự THẬT, riêng biệt, cập nhật mỗi khi tạo/đóng tab.
    private val tabOrder = java.util.concurrent.CopyOnWriteArrayList<String>()
    // Theo dõi tab đang chờ xác nhận `restoreState()` có THẬT SỰ điều
    // hướng đi đâu không — xem `createTabWithState()`/`onLocationChange`.
    private val pendingRestoreTabIds = java.util.concurrent.CopyOnWriteArraySet<String>()

    /**
     * BUG THẬT (xác nhận lại từ log2.txt — người dùng phải bấm "Xem bằng
     * máy tính" 2 LẦN cách nhau 10s cho cùng 1 trang Colab lúc 22:38:37 và
     * 22:38:47): tập theo dõi tab đang bật desktop THỦ CÔNG qua
     * `toggleDesktopMode()` đã được thiết kế trước đó (xem PROJECT_STATUS.md)
     * nhưng KHÔNG có mặt trong file này — có nghĩa bản vá đó chưa từng được
     * ghi vào code thật, chỉ có trong lời kể. Không có tập này,
     * `applyViewportExceptionForUrl()` (chạy lại ở MỌI `onLoadRequest`, kể
     * cả các bước redirect nội bộ của OAuth/Colab) tiếp tục ghi đè lựa chọn
     * thủ công của người dùng ngay khi trang điều hướng tiếp — y hệt bug cũ.
     * Thêm lại tập này và cho `applyViewportExceptionForUrl` bỏ qua hẳn các
     * tab có trong tập, không đụng gì tới `userAgentMode`/`viewportMode`/
     * `userAgentOverride` của tab đó.
     */
    private val manualDesktopTabIds = java.util.concurrent.CopyOnWriteArraySet<String>()
    private var activeTabId: String? = null
    private val handler = Handler(Looper.getMainLooper())
    private val random = Random(slotIndex.toLong())

    private val evalPorts = mutableSetOf<Port>()
    // FIX HIỆU NĂNG (bug fan-out): trước đây evaluateJs() gửi script tới
    // TẤT CẢ port đang mở — tức MỌI frame của MỌI tab đang mở trong khe
    // này, không chỉ tab đang xem. Mỗi lần chẩn đoán video (6 lần/12s mỗi
    // khi mở YouTube), mỗi lần load trang (zoom), mỗi lần favicon — đều
    // "đánh thức" toàn bộ tab nền, kể cả 7 tab lazy chưa ai xem tới. Chi
    // phí này tăng TUYẾN TÍNH theo số tab đang mở — ngược hướng với việc
    // "mở nhiều tab vẫn mượt". Sửa: lưu port thuộc tab nào (qua
    // `port.sender.session`, xác nhận có thật qua javadoc chính thức
    // Mozilla — `WebExtension.MessageSender.session`: "GeckoSession that
    // sent this message. null if coming from a background script"), để
    // evaluateJs() lọc đúng port của tab cần nhắm tới.
    private val portTabId = java.util.concurrent.ConcurrentHashMap<Port, String>()

    // Xem chú thích "TÍNH NĂNG MỚI" ở content.js — cache tạm cho tên file
    // nguồn (2) (thuộc tính `download` trên thẻ <a>, content script bắt
    // được ngay lúc click/gọi click() bằng JS) để đối chiếu khi
    // onExternalResponse tới. Key = href tuyệt đối content script bắt
    // được, value = (tên file, thời điểm nhận). Dọn theo thời gian
    // (DOWNLOAD_HINT_TTL_MS) — tránh phình bộ nhớ nếu người dùng click
    // nhiều link download nhưng không thực sự tải (huỷ dialog, mất mạng...).
    private val downloadFilenameHints = java.util.concurrent.ConcurrentHashMap<String, Pair<String, Long>>()
    private val DOWNLOAD_HINT_TTL_MS = 30_000L

    private var pendingFilePrompt: GeckoSession.PromptDelegate.FilePrompt? = null
    private var pendingFilePromptResult: GeckoResult<GeckoSession.PromptDelegate.PromptResponse>? = null

    var onPageLoadedListener: ((String) -> Unit)? = null
    /**
     * TÍNH NĂNG THIẾU (người dùng báo: "ko có icon biểu hiện trang load
     * xong hết như các trình duyệt khác"): `BrowserTab.isLoading` đã được
     * cập nhật đúng ở `onPageStart`/`onPageStop` bên dưới TỪ TRƯỚC, nhưng
     * chưa từng có cách nào cho UI (MainActivity) BIẾT NGAY lúc bắt đầu
     * tải để vẽ spinner — chỉ có `onPageLoadedListener` (báo lúc XONG),
     * không có listener tương ứng cho lúc BẮT ĐẦU. Thêm listener này, gọi
     * đúng chỗ `isLoading = true` được set, để `MainActivity` có thể
     * `refreshTabBar()` ngay từ lúc bắt đầu tải — không phải tự tưởng
     * tượng thêm cơ chế mới, chỉ nối dây cho dữ liệu đã có sẵn.
     */
    var onPageStartedListener: ((String) -> Unit)? = null
    var onPageErrorListener: ((String, Int) -> Unit)? = null
    var onTitleChangedListener: ((String) -> Unit)? = null
    var onProgressChangedListener: ((Int) -> Unit)? = null
    var onNewTabRequestedListener: ((String) -> Unit)? = null
    // BUG GỐC THẬT SỰ của "download kẹt ở vài trăm byte" (khớp chính xác
    // ảnh chụp "Downloads (IDM)" — tên nội bộ của DIALOG TẢI FILE CỦA
    // CHÍNH APP NÀY, KHÔNG PHẢI app Internet Download Manager bên thứ 3
    // như từng nhầm tưởng — xem comment ở
    // `DownloadEngine.downloadFileBlocking()`: "không cần hiện lên danh
    // sách IDM" tự xác nhận điều này):
    //
    // TỰ SỬA LẠI PHẠM VI (người dùng chỉ ra đúng — tài liệu dự án ghi rõ
    // TRƯỚC ĐÂY tải video YouTube thành công qua CHÍNH DownloadEngine này,
    // dùng OkHttp KHÔNG hề có cookie — nếu "thiếu cookie luôn làm hỏng mọi
    // download" là đúng thì YouTube đã KHÔNG BAO GIỜ tải được, mâu thuẫn
    // với lịch sử thật). Đính chính: KHÔNG PHẢI "mọi download đều hỏng vì
    // thiếu cookie" — URL video YouTube lấy qua NewPipeExtractor là URL
    // CDN CÔNG KHAI, có token/chữ ký tự xác thực RIÊNG trong chính URL
    // (không cần cookie trình duyệt), nên luôn tải được qua OkHttp bình
    // thường như trước giờ, KHÔNG BỊ ẢNH HƯỞNG bởi thiếu cookie. Phạm vi
    // bug THẬT hẹp hơn: CHỈ ảnh hưởng file cần ĐĂNG NHẬP mới tải được (như
    // export của claude.ai) — loại này MỚI cần cookie phiên trình duyệt để
    // server xác thực, và đây đúng là loại code cũ KHÔNG truyền được (đã
    // grep xác nhận: 0 kết quả "cookie" trong toàn bộ DownloadEngine.kt,
    // mọi lệnh gọi startDownload() đều không truyền headers). Với loại
    // file này, server trả về trang lỗi/redirect NHỎ (khớp đúng "132 B"
    // thấy trong ảnh) thay vì file thật.
    //
    // Đã xác nhận `WebResponse.body` là InputStream công khai, ổn định lâu
    // năm (cross-check gecko-dev GitHub + Fossies + javadoc, đều khớp) —
    // dùng THẲNG bytes GeckoView đã tải sẵn (VỚI cookie phiên trình duyệt
    // thật, vì chính GeckoView làm request đó) cho ĐÚNG những trường hợp
    // cần đăng nhập này, KHÔNG đụng gì tới luồng YouTube/file công khai
    // đang hoạt động tốt (vẫn giữ nguyên `onDownloadRequestedListener` cũ
    // làm fallback cho các trường hợp response.body null hoặc không đi
    // qua onExternalResponse).
    var onDownloadRequestedListener: ((String, String) -> Unit)? = null
    var onDownloadBodyReadyListener: ((String, String, String?) -> Unit)? = null

    // TÍNH NĂNG MỚI (người dùng hỏi: "cài extension từ URL có làm giống
    // Firefox/Chrome — vào trang store rồi tải về dùng được không?").
    // Callback cho MainActivity biết kết quả cài addon bắt được từ luồng
    // duyệt web bình thường (`onExternalResponse` phát hiện `.xpi`) — khác
    // `onDownloadStartedListener` vốn dành cho file tải về lưu đĩa thật,
    // addon thì cài thẳng vào Gecko, không lưu file cho người dùng thấy.
    var onAddonInstallResultListener: ((success: Boolean, name: String?, error: String?) -> Unit)? = null

    /**
     * Phát hiện + cài addon NGAY khi người dùng bấm nút cài trên 1 trang
     * addon THẬT (vd. addons.mozilla.org) — thay vì để rơi vào luồng tải
     * file thông thường. Gọi từ `onExternalResponse` khi phát hiện Content-
     * Type/đuôi file là `.xpi`.
     */
    private fun handleExtensionDownloadResponse(uri: String, body: java.io.InputStream?) {
        Thread {
            var tempFile: java.io.File? = null
            try {
                val tempDir = java.io.File(context.cacheDir, "addon_tmp").apply { mkdirs() }
                tempFile = java.io.File(tempDir, "addon_${System.currentTimeMillis()}.xpi")
                if (body != null) {
                    body.use { input -> tempFile.outputStream().use { output -> input.copyTo(output) } }
                } else {
                    // body null (hiếm — xem chú thích ở onExternalResponse
                    // chỗ khác): tự tải lại qua HttpURLConnection thay vì bó
                    // tay, vẫn đúng cho addon công khai.
                    val conn = java.net.URL(uri).openConnection() as java.net.HttpURLConnection
                    conn.connectTimeout = 15_000
                    conn.readTimeout = 30_000
                    conn.inputStream.use { input -> tempFile.outputStream().use { output -> input.copyTo(output) } }
                }
                val fileUri = "file://${tempFile.absolutePath}"
                runtime.webExtensionController.install(fileUri)
                    .accept(
                        { ext ->
                            val name = ext?.metaData?.name ?: tempFile?.name
                            if (ext != null) {
                                val existing = AppPrefs.getString(context, slotIndex, "installed_addons_csv", "")
                                val updated = if (existing.isBlank()) "${ext.id}::$name" else "$existing|${ext.id}::$name"
                                AppPrefs.setString(context, slotIndex, "installed_addons_csv", updated)
                            }
                            handler.post { onAddonInstallResultListener?.invoke(ext != null, name, null) }
                        },
                        { error ->
                            DebugLog.log("Khe $slotIndex: cài addon từ trang web thất bại: ${error?.message}")
                            handler.post { onAddonInstallResultListener?.invoke(false, null, error?.message) }
                        }
                    )
            } catch (e: Exception) {
                DebugLog.log("Khe $slotIndex: handleExtensionDownloadResponse() lỗi tải/cài: ${e.message}")
                handler.post { onAddonInstallResultListener?.invoke(false, null, e.message) }
            }
        }.start()
    }

    /**
     * BUG THẬT đã tìm ra (người dùng chất vấn đúng: "vậy là không giống
     * Chrome hỏi trước tải sau à?"): thiết kế cũ hỏi `SaveLocationDialog`
     * SAU KHI `onDownloadBodyReadyListener` bắn ra (tức sau khi đã drain
     * XONG HẲN response.body vào file tạm) — với file lớn (VD 692MB thấy
     * trong log thật), người dùng phải CHỜ TOÀN BỘ quá trình tải xong mới
     * được hỏi tên/nơi lưu, khác hẳn Chrome (hỏi/hiện ngay khi bắt đầu).
     *
     * Ràng buộc kỹ thuật THẬT (không đổi được): `response.body` của
     * GeckoView tự hết hạn sau ~30s nếu không đọc — nên KHÔNG THỂ đợi
     * người dùng tương tác dialog xong rồi MỚI bắt đầu đọc stream (dialog
     * modal có thể mở lâu hơn 30s). Nhưng ràng buộc đó chỉ bắt buộc phải
     * BẮT ĐẦU ĐỌC STREAM NGAY — không bắt buộc phải HỎI SAU. Có thể tách
     * 2 việc chạy SONG SONG: bắt đầu drain ngay (như cũ, không đổi) VÀ
     * đồng thời hỏi dialog NGAY (không đợi drain xong) — khi CẢ HAI xong
     * (dialog có kết quả + file đã drain xong), mới thật sự chuyển file
     * vào đúng nơi. Listener này bắn NGAY LẬP TỨC (trước khi Thread drain
     * bắt đầu) để MainActivity hỏi dialog song song — xem
     * `onDownloadBodyReadyListener` (không đổi tín hiệu, vẫn bắn khi drain
     * xong) và cách MainActivity ghép 2 tín hiệu này lại với nhau.
     */
    var onDownloadStartedListener: ((String, String) -> Unit)? = null
    /**
     * BUG THẬT tìm ra (người dùng báo đúng: "khung chat cho phép thêm
     * nhiều file cùng lúc nhưng thực tế chỉ được nhấn vào thêm có một file
     * thôi"): callback này TRƯỚC ĐÂY chỉ báo `mimeTypes`, KHÔNG hề báo cho
     * `MainActivity` biết trang web có yêu cầu CHỌN NHIỀU FILE hay không
     * (`prompt.type == FilePrompt.Type.MULTIPLE`) — nên `showFilePicker()`
     * không có cách nào biết cần thêm `Intent.EXTRA_ALLOW_MULTIPLE`. Thêm
     * tham số `isMultiple` để MainActivity biết chính xác.
     */
    var onFilePromptListener: ((mimeTypes: Array<String>?, isMultiple: Boolean) -> Unit)? = null
    var onTabSwitchedListener: ((BrowserTab) -> Unit)? = null
    var onLongPressLinkListener: ((linkUri: String, linkText: String?) -> Unit)? = null
    // FIX BUG THẬT (xác nhận qua code — ContentDelegate chưa từng override
    // onFullScreen): trang gọi Fullscreen API (nút toàn màn hình trên
    // player) không hề được app biết tới để ẩn thanh URL/tab đi — video chỉ
    // "giả vờ" fullscreen bên trong khung page vẫn bị chèn ép bởi UI trình
    // duyệt + CSS zoom desktop-layout còn active, gây vỡ hình/"vướng url"
    // đúng như người dùng mô tả. Xem MainActivity.setupEngine() để biết
    // UI thật sự làm gì khi listener này bắn ra.
    var onFullScreenListener: ((Boolean) -> Unit)? = null

    /**
     * QUAN TRỌNG: chọn 1 LẦN DUY NHẤT cho cả engine (không phải mỗi tab/mỗi
     * lần connect extension) — dùng CHUNG cho cả:
     *   1) UA header HTTP thật (`GeckoSessionSettings.userAgentOverride`, áp
     *      dụng ở `createSession()`)
     *   2) `navigator.userAgent` phía JS (đẩy qua `buildFingerprintConfigMessage()`)
     * Trước đây 2 chỗ này KHÔNG dùng chung 1 nguồn — hệ quả: header HTTP
     * thật (Firefox/GeckoView) và `navigator.userAgent` JS (chuỗi Chrome giả)
     * KHÔNG KHỚP NHAU, một mismatch cực kỳ dễ bị site/anti-bot phát hiện
     * (nhiều hệ thống so sánh trực tiếp UA header với navigator.userAgent).
     * Cache 1 lần còn tránh việc chế độ "fresh" (random mỗi lần) chọn ra 2
     * profile KHÁC NHAU cho HTTP header và JS trong cùng 1 lần mở khe.
     */
    private var cachedProfile: Pair<DeviceProfiles.HardwareProfile, DeviceProfiles.LocaleProfile>? = null
    private fun resolveProfile(): Pair<DeviceProfiles.HardwareProfile, DeviceProfiles.LocaleProfile> {
        cachedProfile?.let { return it }
        val fresh = AppPrefs.getBoolean(context, slotIndex, "fp_fresh", false)
        val resolved = if (fresh) {
            DeviceProfiles.getRandomProfileFresh()
        } else {
            val profileName = ProfileSlots.getSlotAssignment(context, slotIndex)
            val hwIdx = AppPrefs.getInt(context, slotIndex, "fp_hw_idx", DeviceProfiles.defaultHwIndexForProfile(profileName))
            val localeIdx = AppPrefs.getInt(context, slotIndex, "fp_locale_idx", DeviceProfiles.defaultLocaleIndexForProfile(profileName))
            DeviceProfiles.getProfileByIndex(hwIdx, localeIdx)
        }
        cachedProfile = resolved
        return resolved
    }

    init {
        instances[slotIndex] = this
        setupEvalBridge()
        setupFingerprintExtension()
    }

    // ===== BrowserEngine Implementation =====

    override fun currentUrl(): String? {
        return activeTabId?.let { tabMeta[it]?.url }
    }

    // BUG NGHIÊM TRỌNG đã tìm ra (so sánh trực tiếp code Kotlin ↔ JS, không
    // suy đoán): Kotlin gửi field `"action": "eval"`, JS kiểm tra
    // `msg.type === "eval"` — SAI TÊN FIELD hoàn toàn, điều kiện `if` phía
    // JS KHÔNG BAO GIỜ đúng, script CHƯA TỪNG thực sự được thực thi qua
    // cầu nối này — kể cả `keepPlayingScript` (chống YouTube tự pause) đã
    // tưởng hoạt động trước đây. Sửa: đổi Kotlin sang gửi `"type": "eval"`
    // khớp đúng JS.
    //
    // BUG THỨ 2 (đã nêu ở khai báo `evalCallback` cũ, giờ sửa luôn): 1 biến
    // CALLBACK DUY NHẤT dùng chung cho MỌI lệnh gọi `evaluateJs()` — lệnh
    // gọi SAU (VD `BackgroundMediaFeature.onPageFinished()` gọi không kèm
    // callback) sẽ GHI ĐÈ MẤT callback của lệnh gọi TRƯỚC đang chờ kết quả
    // (VD favicon) trước khi kịp nhận phản hồi bất đồng bộ. Sửa: dùng
    // `requestId` tăng dần + Map để mỗi lệnh gọi có đúng callback riêng,
    // không đá nhau.
    //
    // BUG THẬT tìm thêm được (người dùng chỉ đúng qua ảnh chụp: tab "New
    // chat" của claude.ai hiện icon YouTube — xem chú thích đầy đủ ở
    // content.js): value giờ là Pair<targetTabId, callback> thay vì chỉ
    // callback — để `onPortMessage` (bên dưới) có thể ĐỐI CHIẾU `sourceUrl`
    // (URL THẬT trang đã chạy script, content.js mới thêm) với URL của
    // CHÍNH tab đích, TRƯỚC khi tin kết quả. KHÔNG đổi chữ ký công khai
    // `evaluateJs()`/`evaluateJsForTab()` — mọi nơi gọi hàm này trong toàn
    // bộ codebase (favicon, zoom, video diagnostic, keepPlayingScript...)
    // KHÔNG cần sửa gì, hoàn toàn không ảnh hưởng.
    private val evalCallbacks = java.util.concurrent.ConcurrentHashMap<Int, Pair<String?, (String?) -> Unit>>()
    private val evalRequestIdCounter = java.util.concurrent.atomic.AtomicInteger(0)

    override fun evaluateJs(script: String, callback: ((String?) -> Unit)?) {
        // Mặc định nhắm đúng tab ĐANG XEM — mọi lệnh gọi evaluateJs() thật
        // trong codebase (chẩn đoán video, zoom, favicon, keepPlayingScript
        // chống pause nhạc nền, outerHTML để tải trang) đều chỉ có ý nghĩa
        // với tab người dùng đang thấy, không có nơi nào thật sự cần chạm
        // tới tab nền. Xem `evaluateJsForTab()` nếu sau này cần nhắm tab cụ
        // thể không phải tab active.
        evaluateJsForTab(activeTabId, script, callback)
    }

    /**
     * TÍNH NĂNG MỚI (người dùng yêu cầu) — Tìm trong trang.
     *
     * Dùng `GeckoSession.finder` (kiểu `org.mozilla.geckoview.SessionFinder`)
     * — API TÌM KIẾM NATIVE chính thức của GeckoView, KHÔNG phải tự viết
     * JS quét `document.body.innerText` (cách đó không tô sáng được đúng
     * vị trí thật trên layer render, không xử lý được text trong iframe
     * cross-origin, và không có khái niệm "khớp thứ N/tổng M" sẵn có).
     *
     * `find(searchString, flags)` trả về `GeckoResult<FinderResult>` — mỗi
     * lần gọi lại (kể cả gọi lại với CÙNG searchString để "Tìm tiếp") sẽ tô
     * sáng khớp kế tiếp trên trang thật và trả về đúng chỉ số hiện tại.
     *
     * `flags`: mặc định tìm xuôi (`FINDER_FIND_MATCH_CASE` chỉ set nếu
     * `matchCase=true`), có thể set `FINDER_FIND_BACKWARDS` khi
     * `forward=false` (nút "▲ Tìm lùi").
     */
    override fun findInPage(query: String, forward: Boolean, matchCase: Boolean, callback: ((current: Int, total: Int) -> Unit)?) {
        val tabId = activeTabId
        val session = if (tabId != null) tabs[tabId] else null
        if (session == null) {
            DebugLog.log("findInPage: không có tab active nào — bỏ qua tìm kiếm")
            callback?.invoke(0, 0)
            return
        }
        if (query.isBlank()) {
            // Ô tìm kiếm rỗng — coi như xoá highlight, không tìm gì cả
            // (tránh gọi find("") ra kết quả vô nghĩa trên 1 số bản Gecko).
            session.finder.clear()
            callback?.invoke(0, 0)
            return
        }
        var flags = 0
        // SỬA LỖI BUILD THẬT (build #439 báo "Unresolved reference"):
        // hằng số `FINDER_FIND_BACKWARDS`/`FINDER_FIND_MATCH_CASE` nằm
        // trong class `GeckoSession` (xem javadoc chính thức Mozilla:
        // mozilla.github.io/geckoview/javadoc/.../GeckoSession.html —
        // mục "Finder search flag definitions"), KHÔNG PHẢI trong
        // `SessionFinder` như tôi đoán nhầm ban đầu. `SessionFinder` chỉ
        // chứa `find()`/`clear()`/`getDisplayFlags()`/`setDisplayFlags()`
        // — bản thân các hằng số flag lại định nghĩa ở `GeckoSession`.
        if (!forward) flags = flags or GeckoSession.FINDER_FIND_BACKWARDS
        if (matchCase) flags = flags or GeckoSession.FINDER_FIND_MATCH_CASE
        // BUG THẬT ĐÃ SỬA (người dùng báo: gõ tìm kiếm ra đúng số lượng
        // khớp trong log nhưng KHÔNG THẤY BÔI ĐEN trên trang): theo mã
        // nguồn GeckoView (`SessionFinder` constructor gọi
        // `setDisplayFlags(0)` MẶC ĐỊNH), nếu KHÔNG chủ động gọi
        // `setDisplayFlags()`, GeckoView chỉ "find and SELECT" đúng 1
        // khớp hiện tại (dùng cơ chế text-selection nội bộ, không phải
        // highlight tìm kiếm thật) — các khớp CÒN LẠI trên trang hoàn
        // toàn không được tô màu gì. Phải chủ động bật cờ hiển thị
        // `FINDER_DISPLAY_HIGHLIGHT_ALL` (tô vàng TẤT CẢ khớp cùng lúc,
        // giống Chrome/Firefox desktop) mỗi lần gọi find() — set lại mỗi
        // lần vì initial cờ này reset về 0 khi SessionFinder khởi tạo
        // (theo source `setDisplayFlags(0)` trong constructor).
        try {
            session.finder.setDisplayFlags(GeckoSession.FINDER_DISPLAY_HIGHLIGHT_ALL)
        } catch (e: Exception) {
            DebugLog.log("Khe $slotIndex: [Tìm trong trang] setDisplayFlags() lỗi: ${e.message}")
        }
        try {
            session.finder.find(query, flags).accept({ result ->
                if (result != null) {
                    DebugLog.log("Khe $slotIndex: [Tìm trong trang] query='$query' found=${result.found} current=${result.current} total=${result.total}")
                    handler.post { callback?.invoke(result.current, result.total) }
                } else {
                    handler.post { callback?.invoke(0, 0) }
                }
            }, { error ->
                DebugLog.log("Khe $slotIndex: [Tìm trong trang] find() lỗi: ${error?.message}")
                handler.post { callback?.invoke(0, 0) }
            })
        } catch (e: Exception) {
            DebugLog.log("Khe $slotIndex: [Tìm trong trang] gọi find() ném exception: ${e.message}")
            callback?.invoke(0, 0)
        }
    }

    override fun clearFindInPage() {
        val tabId = activeTabId
        val session = if (tabId != null) tabs[tabId] else null
        try {
            session?.finder?.clear()
        } catch (e: Exception) {
            DebugLog.log("clearFindInPage: lỗi khi clear() — ${e.message}")
        }
    }

    /**
     * FIX HIỆU NĂNG (bug fan-out — xem chú thích ở khai báo `portTabId`):
     * chỉ gửi script tới port thuộc ĐÚNG `targetTabId`, không broadcast
     * toàn bộ `evalPorts` như trước. `targetTabId = null` (VD chưa có tab
     * active nào, hoặc lúc khởi động) vẫn giữ hành vi broadcast CŨ làm lưới
     * an toàn — tốt hơn là im lặng không chạy gì.
     *
     * FALLBACK AN TOÀN: nếu lọc theo tabId ra 0 port (VD content script
     * mới connect nhưng `port.sender.session` vì lý do nào đó chưa map
     * được — CHƯA XÁC NHẬN có xảy ra thật trên máy hay không, chỉ phòng
     * hờ), broadcast toàn bộ như hành vi cũ thay vì lặng thinh không gửi
     * gì — tránh hồi quy tính năng (thà chậm hơn 1 lượt còn hơn favicon/
     * zoom/chẩn đoán video lại im re như trước khi sửa).
     */
    private fun evaluateJsForTab(targetTabId: String?, script: String, callback: ((String?) -> Unit)?) {
        val requestId = evalRequestIdCounter.incrementAndGet()
        if (callback != null) {
            evalCallbacks[requestId] = targetTabId to callback
            // FIX BUG THẬT GÂY CRASH OOM (xác nhận qua log crash thật:
            // OutOfMemoryError ở tầng Java heap sau ~5 tiếng chạy liên tục,
            // KHÔNG phải crash native Gecko — nghĩa là rò rỉ nằm ở phía
            // Kotlin/JVM, không phải native). `evalCallbacks` trước đây CHỈ
            // được dọn ở 1 chỗ DUY NHẤT — khi `onPortMessage` nhận đúng
            // `requestId` khớp. Nếu script gửi đi KHÔNG BAO GIỜ nhận được
            // phản hồi (tab đóng/điều hướng giữa chừng làm port ngắt kết
            // nối trước khi content script kịp trả lời, hoặc fallback
            // broadcast — xem log "[CHẨN ĐOÁN evaluateJs fallback]" xuất
            // hiện CỰC KỲ dày đặc trong log thật — gửi tới port đã chết),
            // closure đó nằm lại trong map VĨNH VIỄN. `pollVideoDiagnostic`
            // tự gọi lại 6 lần/video, `applyZoomCombined`/`fetchFavicon`
            // gọi mỗi lần điều hướng — qua nhiều giờ, số closure tồn đọng
            // đủ lớn để ăn hết heap 256MB (đúng target footprint trong log
            // crash thật) dù mỗi closure riêng lẻ rất nhỏ.
            //
            // Sửa: đặt timeout 15 giây — nếu tới lúc đó vẫn chưa có phản
            // hồi, TỰ DỌN + gọi callback với null (coi như "không có kết
            // quả"), thay vì để treo vô hạn. Giới hạn CỨNG kích thước tối
            // đa của map bất kể nguyên nhân gốc là gì.
            handler.postDelayed({
                evalCallbacks.remove(requestId)?.let { (_, orphaned) ->
                    DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN evalCallbacks timeout] requestId=$requestId không nhận được phản hồi sau 15s — tự dọn để tránh rò rỉ bộ nhớ (xem chú thích ở evaluateJsForTab)")
                    orphaned.invoke(null)
                }
            }, 15_000L)
        }
        val message = JSONObject().apply {
            put("type", "eval")
            put("requestId", requestId)
            put("script", script)
        }
        val dead = mutableListOf<Port>()
        val targetedPorts: Collection<Port> = if (targetTabId != null) {
            evalPorts.filter { portTabId[it] == targetTabId }
        } else {
            evalPorts.toList()
        }
        val portsToSend: Collection<Port> = if (targetTabId != null && targetedPorts.isEmpty()) {
            // Fallback: không có port nào map đúng tab — có thể do
            // port.sender.session chưa kịp gán, hoặc tab vừa tạo session
            // xong content script chưa kịp connect. Broadcast toàn bộ để
            // không mất tính năng, đồng thời log 1 dòng CHẨN ĐOÁN để biết
            // fallback này có thật sự bị hit hay không (chưa test thật).
            DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN evaluateJs fallback] không có port nào khớp tabId=$targetTabId trong ${evalPorts.size} port đang mở — broadcast toàn bộ (cần xác nhận qua log lần tới có bị hit thường xuyên không)")
            evalPorts.toList()
        } else {
            targetedPorts
        }
        portsToSend.forEach { port ->
            try {
                port.postMessage(message)
            } catch (e: Exception) {
                dead.add(port) // port đã chết (frame unload) — dọn sau, không sửa trong lúc forEach
            }
        }
        dead.forEach {
            evalPorts.remove(it)
            portTabId.remove(it)
        }
    }

    override fun loadUrl(url: String) {
        activeTabId?.let { tabId ->
            tabs[tabId]?.loadUri(url)
            tabMeta[tabId]?.url = url
        }
    }

    override fun reload() {
        activeTabId?.let { tabs[it]?.reload() }
    }

    override fun goBack(): Boolean {
        val tabId = activeTabId ?: return false
        val session = tabs[tabId] ?: return false
        if (tabMeta[tabId]?.canGoBack == true) {
            session.goBack()
            return true
        }
        return false
    }

    override fun goForward(): Boolean {
        val tabId = activeTabId ?: return false
        val session = tabs[tabId] ?: return false
        if (tabMeta[tabId]?.canGoForward == true) {
            session.goForward()
            return true
        }
        return false
    }

    override fun canGoBack(): Boolean {
        return activeTabId?.let { tabMeta[it]?.canGoBack } ?: false
    }

    override fun canGoForward(): Boolean {
        return activeTabId?.let { tabMeta[it]?.canGoForward } ?: false
    }

    // ===== Multi-Tab =====

    /**
     * BUG THẬT đã sửa — trước giờ KHÔNG có gì lưu lại danh sách tab đang mở
     * cả: `tabs`/`tabMeta` chỉ tồn tại TRONG BỘ NHỚ, mất sạch mỗi khi
     * process chết (đóng app, crash, hay Android tự dọn nền) — khác hẳn
     * Chrome/Firefox thật (luôn tự mở lại đúng các tab đang có sau khi
     * khởi động lại). Người dùng hỏi đúng — đây là tính năng thiếu thật, có
     * thể làm được, không phải hạn chế của GeckoView.
     *
     * Cách làm: lưu URL + tiêu đề của từng tab (KHÔNG lưu lịch sử back/
     * forward/scroll/form đầy đủ của từng tab — muốn vậy cần dùng
     * `GeckoSession.saveState()`/`restoreState()`, API bất đồng bộ phức tạp
     * hơn nhiều, để dành làm sau nếu cần) vào 1 file JSON ngay TRONG thư mục
     * hồ sơ Gecko (đi theo hồ sơ luôn — hồ sơ nào có tab nấy, xuất/nhập hồ
     * sơ cũng mang theo danh sách tab). Lưu mỗi khi danh sách tab thay đổi
     * (mở/đóng tab) + mỗi khi khe mất foreground (`onPause`, xem
     * MainActivity) — không lưu SAU KHI crash được (crash thì không kịp
     * chạy code nữa) nhưng lưu ĐỦ THƯỜNG XUYÊN trước đó nên vẫn khôi phục
     * được gần như đầy đủ sau crash.
     */
    private fun tabStateFile(): File {
        val profileNamespace = ProfileSlots.getSlotAssignment(context, slotIndex)
        val dir = File(context.filesDir, "gecko_profile_" + profileNamespace.replace(Regex("[^a-zA-Z0-9_-]"), "_"))
        dir.mkdirs()
        return File(dir, "saved_tabs.json")
    }

    fun saveTabsState() {
        try {
            val arr = JSONArray()
            // SỬA BUG (chính là nguồn gây "tab lộn xộn sau khôi phục"):
            // dùng `tabOrder` thay vì `tabMeta.values` — xem giải thích ở
            // khai báo `tabOrder`.
            tabOrder.mapNotNull { tabMeta[it] }.forEach { tab ->
                // Tab ẨN DANH không bao giờ được lưu — đúng hành vi Chrome
                // thật (đóng app là mất hẳn, không khôi phục lại lần sau).
                if (tab.url.isNotBlank() && !tab.isPrivate) {
                    arr.put(JSONObject().apply {
                        put("url", tab.url)
                        put("title", tab.title ?: "")
                        put("active", tab.id == activeTabId)
                        // Trạng thái ĐẦY ĐỦ (lịch sử/cuộn/form) nếu có — xem
                        // giải thích lớn ở onSessionStateChange() phía trên.
                        tab.savedState?.let { put("state", it) }
                        // FIX BUG THẬT (người dùng báo: "vuốt tắt app trong
                        // Recent Apps thì group tab biến mất luôn") — TRƯỚC
                        // ĐÂY dòng này KHÔNG TỒN TẠI, groupId chưa bao giờ
                        // được lưu xuống đĩa dù bản thân tab thì có — xem
                        // giải thích đầy đủ ở `TabGroup` (BrowserEngine.kt).
                        tab.groupId?.let { gid -> put("groupId", gid) }
                    })
                }
            }
            if (arr.length() == 0) {
                tabStateFile().delete()
                return
            }
            // FIX BUG THẬT (cùng vấn đề "group tab biến mất") — TRƯỚC ĐÂY
            // `groups` (tên/màu từng nhóm) hoàn toàn KHÔNG được ghi ra
            // đâu cả, dù đã có `groupId` gắn trên từng tab ở trên — nếu
            // thiếu phần này, khôi phục lại tab CÓ groupId nhưng không có
            // nhóm thật nào tương ứng để tra tên/màu, coi như vẫn mất
            // nhóm. Ghi kèm toàn bộ danh sách nhóm vào CÙNG 1 file, đổi
            // định dạng file từ JSONArray trần sang JSONObject bọc 2
            // mảng — `restoreTabsIfAny()` có fallback đọc được cả định
            // dạng cũ (JSONArray trần) để không mất tab đã lưu từ bản
            // trước bản vá này.
            val groupsArr = JSONArray()
            groups.values.forEach { g ->
                groupsArr.put(JSONObject().apply {
                    put("id", g.id)
                    put("name", g.name)
                    put("colorHex", g.colorHex)
                })
            }
            val root = JSONObject().apply {
                put("tabs", arr)
                put("groups", groupsArr)
            }
            val tmp = File(tabStateFile().parentFile, "saved_tabs.json.tmp")
            tmp.writeText(root.toString())
            tmp.renameTo(tabStateFile())
        } catch (e: Exception) {
            DebugLog.log("saveTabsState lỗi: ${e.message}")
        }
    }

    /** Trả về `true` nếu đã khôi phục được ít nhất 1 tab (gọi nơi tạo tab
     * đầu tiên lúc khởi động — nếu trả `true` thì KHÔNG tạo thêm tab trang
     * chủ mặc định nữa, xem `MainActivity.setupUI()`). */
    fun restoreTabsIfAny(): Boolean {
        return try {
            val f = tabStateFile()
            if (!f.exists()) return false
            val rawText = f.readText()
            // FIX BUG THẬT (group tab biến mất) — TƯƠNG THÍCH NGƯỢC: file
            // TỪ TRƯỚC bản vá này là 1 JSONArray TRẦN (không có "groups").
            // File TỪ bản vá này trở đi là 1 JSONObject bọc {"tabs":[...],
            // "groups":[...]}. Phân biệt bằng ký tự đầu tiên sau khi bỏ
            // khoảng trắng — không đụng gì tới cách đọc tab cũ, chỉ THÊM
            // khả năng đọc groups nếu có.
            val trimmed = rawText.trimStart()
            val (arr, groupsArr) = if (trimmed.startsWith("[")) {
                JSONArray(rawText) to JSONArray()
            } else {
                val root = JSONObject(rawText)
                (root.optJSONArray("tabs") ?: JSONArray()) to (root.optJSONArray("groups") ?: JSONArray())
            }
            if (arr.length() == 0) return false

            // Khôi phục NHÓM TRƯỚC — mỗi tab bên dưới cần tra được tên/màu
            // nhóm thật ngay khi gán lại `groupId`, không phải chờ tạo
            // nhóm "mồ côi" sau đó.
            for (i in 0 until groupsArr.length()) {
                val g = groupsArr.optJSONObject(i) ?: continue
                val gid = g.optString("id", "")
                if (gid.isBlank()) continue
                groups[gid] = TabGroup(
                    id = gid,
                    name = g.optString("name", ""),
                    colorHex = g.optString("colorHex", "#1A73E8")
                )
            }

            var restoredActiveId: String? = null
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                val url = obj.optString("url", "")
                if (url.isBlank()) continue
                val isActive = obj.optBoolean("active", false)
                val savedState = if (obj.has("state")) obj.optString("state", null) else null
                val groupId = if (obj.has("groupId")) obj.optString("groupId", null) else null
                // LAZY RESTORE: chỉ load NGAY tab đang active — các tab khác
                // tạo session/metadata nhưng KHÔNG load gì cả, chỉ đánh dấu
                // `needsLoad=true` (lưu vào savedState hoặc url). Khi người
                // dùng switchToTab mới load thật. Trước đây tất cả tab đều
                // gọi restoreState()/loadUri() ngay lập tức → 7 tab = 7 tải
                // cùng lúc, làm chậm máy và tranh nhau băng thông/CPU Gecko.
                val tab = if (isActive) {
                    createTabWithState(url, savedState)
                } else {
                    createTabLazy(url, savedState)
                }
                // Chỉ gán lại nếu nhóm đó THẬT SỰ tồn tại trong `groups` —
                // phòng file bị chỉnh tay/hỏng, groupId trỏ tới nhóm không
                // còn tồn tại (tab "mồ côi" coi như không thuộc nhóm nào,
                // an toàn hơn là hiện 1 nhóm rỗng không tên/không màu).
                if (groupId != null && groups.containsKey(groupId)) {
                    tabMeta[tab.id]?.groupId = groupId
                }
                if (isActive) restoredActiveId = tab.id
            }
            restoredActiveId?.let { switchToTab(it) }
            DebugLog.log("Khe $slotIndex: khôi phục ${arr.length()} tab (kèm ${groups.size} nhóm) từ lần trước (lazy — chỉ load tab đang active ngay)")
            true
        } catch (e: Exception) {
            DebugLog.log("restoreTabsIfAny lỗi: ${e.message}")
            false
        }
    }

    /**
     * Tạo tab ở trạng thái CHƯA TẢI (lazy) — session được tạo và đăng ký
     * nhưng KHÔNG gọi `restoreState()` hay `loadUri()`. Nội dung chỉ được
     * tải thật khi `switchToTab()` lần đầu đụng vào tab này (lazy load tại
     * thời điểm user thật sự muốn xem). `savedState` được giữ trong
     * `BrowserTab.savedState` để `switchToTab()` dùng sau khi cần.
     *
     * Cơ chế: `isUnloaded = true` trong metadata — `switchToTab()` kiểm tra
     * cờ này, nếu còn thì load thật ngay tại đó, xoá cờ. Session đã open
     * sẵn (cần thiết để GeckoView không bị null session khi vẽ preview tab
     * trong thanh tab) nhưng chưa có nội dung gì.
     */
    private fun createTabLazy(url: String, savedState: String?): BrowserTab {
        val tabId = UUID.randomUUID().toString()
        // THẬT SỰ LAZY (sửa lại lần 2 — lần đầu vẫn gọi createSession() ở
        // đây, tức là vẫn spin lên 1 GeckoSession NATIVE thật cho mỗi tab
        // lazy, dù không load URL gì. Tạo native session vẫn tốn CPU/bộ nhớ/
        // GPU surface đáng kể — 7 session cùng lúc vẫn làm chậm máy y hệt
        // như trước, chỉ là không thấy trong log `onLoadRequest` nên tưởng
        // đã sửa xong). KHÔNG tạo GeckoSession ở đây — không đụng gì tới
        // `tabs` map cả. Chỉ lưu metadata (tabMeta/tabOrder). Session THẬT
        // chỉ được tạo trong `switchToTab()` lần đầu tab này được chọn.
        val tab = BrowserTab(id = tabId, url = url, savedState = savedState).also {
            it.isUnloaded = true
        }
        tabMeta[tabId] = tab
        tabOrder.add(tabId)
        // KHÔNG tạo session, KHÔNG gọi switchToTab, KHÔNG loadUri/restoreState.
        return tab
    }

    /**
     * Giống `createTab()` nhưng khôi phục ĐẦY ĐỦ trạng thái (lịch sử back/
     * forward, vị trí cuộn, dữ liệu form) qua `session.restoreState()` nếu
     * có, thay vì chỉ `loadUri()` mở trang trắng mới. KHÔNG gọi `loadUri()`
     * khi có savedState — `restoreState()` đã tự đưa về đúng trang/lịch sử,
     * gọi thêm `loadUri()` sẽ ĐIỀU HƯỚNG ĐI MẤT trạng thái vừa khôi phục.
     */
    private fun createTabWithState(url: String, savedState: String?): BrowserTab {
        val tabId = UUID.randomUUID().toString()
        val session = createSession()
        val tab = BrowserTab(id = tabId, url = url, savedState = savedState)

        tabs[tabId] = session
        tabMeta[tabId] = tab
        tabOrder.add(tabId)

        if (activeTabId == null) {
            switchToTab(tabId)
        }

        if (savedState != null) {
            try {
                val state = GeckoSession.SessionState.fromString(savedState)
                if (state != null) {
                    pendingRestoreTabIds.add(tabId)
                    session.restoreState(state)
                    // BUG THẬT tìm ra (người dùng báo tab khôi phục ra trang
                    // trắng about:blank): `restoreState()` có thể "thành
                    // công" (không null, không ném lỗi) nhưng dữ liệu khôi
                    // phục THẬT SỰ không đưa tới đâu cả (dữ liệu cũ/hỏng/
                    // không tương thích phiên bản GeckoView) — không có tín
                    // hiệu đồng bộ nào báo "restore thành công hay thất bại
                    // thật". KHÔNG so sánh `tab.url` với "about:blank" (dễ
                    // sai — `tab.url` được khởi tạo bằng URL đã lưu ngay từ
                    // đầu, nếu restore thất bại HOÀN TOÀN không có sự kiện
                    // điều hướng nào cả thì `tab.url` vẫn giữ nguyên giá trị
                    // ban đầu, không bao giờ thành "about:blank" để so khớp
                    // được). Thay vào đó dùng `pendingRestoreTabIds` — cờ chỉ
                    // được xoá khi `onLocationChange` THẬT SỰ bắn ra (bất kỳ
                    // URL nào) — nếu sau 3s cờ vẫn còn, nghĩa là restore
                    // KHÔNG hề gây ra điều hướng nào cả, mới tự tải lại.
                    handler.postDelayed({
                        if (pendingRestoreTabIds.remove(tabId)) {
                            DebugLog.log("Khe $slotIndex: restoreState() không gây ra điều hướng nào sau 3s — tự tải lại URL đã lưu: $url")
                            session.loadUri(url)
                        }
                    }, 3000L)
                } else {
                    session.loadUri(url)
                }
            } catch (e: Exception) {
                DebugLog.log("Khe $slotIndex: restoreState lỗi (${e.message}) — tải URL thường thay thế")
                session.loadUri(url)
            }
        } else {
            session.loadUri(url)
        }
        return tab
    }

    /**
     * LỊCH SỬ DUYỆT WEB — logic thật nằm ở `BrowserHistory.kt` (tách riêng
     * để `HistoryActivity` dùng chung được, không cần 1 GeckoViewEngine
     * đang sống). Ở đây chỉ gọi qua, tự bọc luồng nền cho phần ghi (bài học
     * từ bug "chặn UI thread", mục 8t).
     */
    fun recordHistoryVisit(url: String) {
        Thread { BrowserHistory.recordVisit(context, slotIndex, url) }.start()
    }

    fun updateLastHistoryTitle(url: String, title: String) {
        Thread { BrowserHistory.updateTitle(context, slotIndex, url, title) }.start()
    }

    /**
     * "Xem bằng máy tính" (Desktop Site) — API xác nhận từ code mẫu chính
     * thức Mozilla (`GeckoViewActivity.java`): `session.getSettings()` trả
     * về đối tượng cấu hình CÒN SỐNG (đổi lúc đang chạy, không cần tạo lại
     * session) — `setUserAgentMode()` đổi UA gửi lên server,
     * `setViewportMode()` đổi cách trang tự bố cục (đúng cơ chế "Request
     * Desktop Site" thật của trình duyệt mobile, không chỉ đổi 1 chuỗi UA).
     * Gọi `reload()` sau đó để trang tải lại đúng theo chế độ mới.
     */
    /**
     * BUG THẬT đã sửa (người dùng hỏi đúng trọng tâm: "có đồng bộ với
     * fingerprint không, hay đầu voi đuôi chuột"): TRƯỚC ĐÂY hàm này chỉ
     * đổi `userAgentMode`/`viewportMode` — KHÔNG đụng gì tới
     * `userAgentOverride` (chuỗi UA giả CỐ ĐỊNH gán lúc tạo session từ hồ
     * sơ fingerprint, xem `createSessionUnopened()`). Vấn đề:
     * `userAgentOverride` LUÔN ưu tiên hơn `userAgentMode` khi cả 2 cùng
     * tồn tại — bật "Xem bằng máy tính" chỉ đổi LAYOUT trang (viewport)
     * nhưng UA HTTP thật gửi lên server VẪN LÀ chuỗi mobile giả ban đầu.
     * Kết quả: vừa "đầu voi đuôi chuột" (trang tự phát hiện qua UA vẫn
     * phục vụ bản mobile dù layout đã đổi desktop) VỪA làm fingerprint TỆ
     * HƠN cả không bật gì (UA nói "mobile" nhưng hành vi render lại là
     * desktop — bất nhất, chính bất nhất này là 1 tín hiệu fingerprint).
     *
     * Sửa: bật desktop thì XOÁ override (dùng UA desktop mặc định thật của
     * GeckoView — nhất quán với layout desktop); tắt thì khôi phục lại
     * đúng UA giả ban đầu theo hồ sơ fingerprint đang chọn (nếu đang bật
     * fingerprint spoof).
     */
    fun toggleDesktopMode(tabId: String? = null): Boolean {
        val id = tabId ?: activeTabId ?: return false
        val session = tabs[id] ?: return false
        val settings = session.settings
        val turningOn = settings.userAgentMode != GeckoSessionSettings.USER_AGENT_MODE_DESKTOP
        settings.userAgentMode = if (turningOn) GeckoSessionSettings.USER_AGENT_MODE_DESKTOP else GeckoSessionSettings.USER_AGENT_MODE_MOBILE
        settings.viewportMode = if (turningOn) GeckoSessionSettings.VIEWPORT_MODE_DESKTOP else GeckoSessionSettings.VIEWPORT_MODE_MOBILE
        if (turningOn) {
            settings.userAgentOverride = null
            manualDesktopTabIds.add(id)
        } else if (FingerprintSpoofFeature.isEnabled(context, slotIndex)) {
            val (hw, _) = resolveProfile()
            settings.userAgentOverride = hw.userAgent
            manualDesktopTabIds.remove(id)
        } else {
            settings.userAgentOverride = null
            manualDesktopTabIds.remove(id)
        }
        // FIX BUG THẬT (người dùng hỏi đúng: "trạng thái mở bằng máy tính
        // cho Drive không có backup trong profile, restore lại không thấy
        // bật" — đã xác nhận qua đọc code: `manualDesktopTabIds` TRƯỚC ĐÂY
        // là 1 Set THUẦN TRONG BỘ NHỚ, khoá theo `tabId` (UUID sinh mới mỗi
        // lần mở app/restore) — chưa từng ghi ra đâu cả, nên
        // `ProfileExportImport` (chỉ đọc `AppPrefs.exportNamespace` +
        // thư mục `profile_data/` Gecko) không có cách nào biết để backup.
        // Đây là lỗ hổng cho MỌI domain, không riêng Drive). SỬA: lưu thêm
        // theo DOMAIN (sống sót qua restore, không như tabId) vào AppPrefs
        // — nhờ `exportNamespace`/`importNamespace` đọc TOÀN BỘ key dưới
        // namespace hồ sơ một cách TỔNG QUÁT (xem AppPrefs.kt), chỉ cần ghi
        // vào đây là TỰ ĐỘNG được gồm trong `app_prefs.json` khi backup,
        // không cần sửa gì thêm ở ProfileExportImport.kt. Tự động áp lại
        // khi tab load URL có domain khớp — xem `applyViewportExceptionForUrl()`.
        val host = tabMeta[id]?.url?.let { url ->
            try { android.net.Uri.parse(url).host?.lowercase() } catch (e: Exception) { null }
        }
        if (host != null) {
            val key = "manual_desktop_mode_domains"
            val current = AppPrefs.getString(context, slotIndex, key, "")
                .split(",", "\n").map { it.trim() }.filter { it.isNotEmpty() }
            val updated = if (turningOn) {
                if (current.any { it.equals(host, ignoreCase = true) }) current else current + host
            } else {
                current.filterNot { it.equals(host, ignoreCase = true) }
            }
            AppPrefs.setString(context, slotIndex, key, updated.joinToString(","))
            DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN desktop thủ công] đã ${if (turningOn) "LƯU" else "GỠ"} domain '$host' vào danh sách persist (manual_desktop_mode_domains) — giờ sẽ được gồm trong backup profile và tự áp lại sau restore")
        }
        session.reload()
        pushFingerprintConfig(session)
        DebugLog.log("Khe $slotIndex: toggleDesktopMode -> ${if (turningOn) "BẬT (UA desktop thật, đã xoá UA giả, đã TẮT giả platform/touch/webgl để tránh bất nhất, tab được đánh dấu THỦ CÔNG — applyViewportExceptionForUrl sẽ bỏ qua tab này ở các lần điều hướng tiếp theo)" else "TẮT (khôi phục UA giả + giả platform/touch/webgl nếu đang bật fingerprint spoof, bỏ đánh dấu thủ công)"}")
        return turningOn
    }

    fun isDesktopMode(tabId: String? = null): Boolean {
        val id = tabId ?: activeTabId ?: return false
        val session = tabs[id] ?: return false
        return session.settings.userAgentMode == GeckoSessionSettings.USER_AGENT_MODE_DESKTOP
    }

    override fun createTab(url: String, isPrivate: Boolean): BrowserTab {
        val tabId = UUID.randomUUID().toString()
        val session = createSession(isPrivate)
        val tab = BrowserTab(id = tabId, url = url, isPrivate = isPrivate)

        tabs[tabId] = session
        tabMeta[tabId] = tab
        tabOrder.add(tabId)

        if (activeTabId == null) {
            switchToTab(tabId)
        }

        session.loadUri(url)
        saveTabsState()
        return tab
    }

    // TÍNH NĂNG MỚI (người dùng yêu cầu) — kéo-thả đổi vị trí tab, giống
    // Chrome. `tabOrder` là `MutableList<String>` giữ đúng thứ tự hiển
    // thị thật (xem chú thích ở closeTab() — lý do KHÔNG dùng thứ tự của
    // ConcurrentHashMap `tabs`). Chỉ cần xoá `tabId` khỏi vị trí cũ rồi
    // chèn lại đúng `toIndex` — không đụng gì tới session/dữ liệu tab.
    // TÍNH NĂNG MỚI (người dùng yêu cầu) — nhóm tab giống Chrome. Lưu
    // trong RAM (xem chú thích ở `TabGroup` trong BrowserEngine.kt).
    private val groups = mutableMapOf<String, TabGroup>()

    override fun createGroup(name: String, colorHex: String): TabGroup {
        val group = TabGroup(id = UUID.randomUUID().toString(), name = name, colorHex = colorHex)
        groups[group.id] = group
        return group
    }

    override fun getGroups(): List<TabGroup> = groups.values.toList()

    override fun setTabGroup(tabId: String, groupId: String?) {
        tabMeta[tabId]?.groupId = groupId
        saveTabsState()
    }

    override fun deleteGroup(groupId: String) {
        // Gỡ nhóm khỏi TẤT CẢ tab đang thuộc nhóm này trước khi xoá hẳn
        // nhóm — không để tab nào "mồ côi" trỏ tới groupId không tồn tại.
        tabMeta.values.forEach { if (it.groupId == groupId) it.groupId = null }
        groups.remove(groupId)
        saveTabsState()
    }

    override fun moveTab(tabId: String, toIndex: Int) {
        val fromIndex = tabOrder.indexOf(tabId)
        if (fromIndex == -1) return
        val clampedTo = toIndex.coerceIn(0, tabOrder.size - 1)
        if (fromIndex == clampedTo) return
        tabOrder.removeAt(fromIndex)
        tabOrder.add(clampedTo, tabId)
        saveTabsState()
    }

    /**
     * FIX BUG THẬT (người dùng báo: "group tab trên thanh tab không kéo
     * di chuyển vị trí được như tab thường") — xem giải thích đầy đủ ở
     * khai báo `moveGroup` trong `BrowserEngine.kt`. Lấy TOÀN BỘ tab
     * thuộc `groupId` THEO ĐÚNG thứ tự hiện có trong `tabOrder` (giữ
     * nguyên thứ tự tương đối bên trong nhóm — không xáo lại), xoá cả
     * khối ra khỏi vị trí cũ, rồi chèn nguyên khối vào ngay TRƯỚC
     * `beforeTabId` (hoặc cuối danh sách nếu null).
     */
    override fun moveGroup(groupId: String, beforeTabId: String?) {
        val memberIds = tabOrder.filter { tabMeta[it]?.groupId == groupId }
        if (memberIds.isEmpty()) return
        // Thả ngay lên 1 tab CÙNG nhóm đang kéo — coi như không đổi gì,
        // tránh tự xoá rồi chèn lại đúng chỗ cũ gây rebuild thừa.
        if (beforeTabId != null && beforeTabId in memberIds) return
        tabOrder.removeAll(memberIds)
        val insertAt = if (beforeTabId != null) {
            tabOrder.indexOf(beforeTabId).let { if (it == -1) tabOrder.size else it }
        } else {
            tabOrder.size
        }
        tabOrder.addAll(insertAt, memberIds)
        saveTabsState()
    }

    override fun closeTab(tabId: String) {
        // FIX BUG THẬT (người dùng báo): lưu lại opener TRƯỚC KHI xoá khỏi
        // tabMeta (xoá xong sẽ không đọc được nữa).
        val openerOfClosedTab = tabMeta[tabId]?.openerTabId
        tabs[tabId]?.close()
        tabs.remove(tabId)
        tabMeta.remove(tabId)
        tabOrder.remove(tabId)
        manualDesktopTabIds.remove(tabId)

        if (activeTabId == tabId) {
            // FIX BUG THẬT (người dùng báo): trước đây LUÔN quay về
            // `tabOrder.firstOrNull()` (tab 0) khi đóng tab đang active —
            // kể cả khi đóng 1 tab POPUP (mở ra từ tab khác qua
            // window.open()/target="_blank") — với nhiều tab, rất khó
            // quản lý vì luôn bị "bắn" về tab đầu tiên thay vì quay lại
            // đúng tab vừa mở popup ra. Giờ ưu tiên quay lại ĐÚNG tab gốc
            // (opener) nếu tab đó VẪN CÒN tồn tại (chưa bị đóng) — giống
            // hành vi Chrome/Firefox thật. Chỉ rơi về `tabOrder.firstOrNull()`
            // khi không có opener (tab tự mở, không phải popup) hoặc tab
            // gốc đã bị đóng từ trước.
            activeTabId = if (openerOfClosedTab != null && tabOrder.contains(openerOfClosedTab)) {
                DebugLog.log("closeTab: đóng tab popup, quay lại đúng tab gốc đã mở nó ra (opener=$openerOfClosedTab)")
                openerOfClosedTab
            } else {
                tabOrder.firstOrNull()
            }
            activeTabId?.let { switchToTab(it) }
        }
        saveTabsState()
    }

    override fun switchToTab(tabId: String) {
        val tab = tabMeta[tabId] ?: return

        // TẠO SESSION THẬT tại đây nếu tab này vẫn đang lazy (chưa từng có
        // GeckoSession native nào) — đây là điểm DUY NHẤT native session
        // được tạo cho tab lazy, đảm bảo tại mọi thời điểm chỉ có ĐÚNG số
        // session đang thật sự cần (tab active + các tab đã từng được xem
        // qua), không phải tạo sẵn tất cả lúc khởi động.
        var session = tabs[tabId]
        val isFirstActivation = (session == null && tab.isUnloaded)
        if (session == null) {
            session = createSession(tab.isPrivate)
            tabs[tabId] = session
        }

        // SỬA LẠI cho ĐÚNG sau khi người dùng chỉ ra 2 điểm quan trọng ở
        // mục 41/42:
        // (1) Chrome Android THẬT SỰ đóng băng tab nền rất nhanh (~1 phút,
        //     kể cả KHÔNG rời khỏi app) — nên `setActive(false)` áp dụng
        //     mặc định cho MỌI tab không hiển thị là ĐÚNG hướng, không phải
        //     "quá tay".
        // (2) Nhưng KHÔNG được hard-code riêng "Colab" là ngoại lệ — nếu
        //     vậy các trang khác cũng cần chạy nền thật (vd trang đang phát
        //     nhạc) sẽ bị bỏ rơi. Đúng như người dùng chỉ ra: dùng LẠI cơ
        //     chế "danh sách ngoại lệ theo domain, người dùng tự nhập" ĐÃ
        //     CÓ SẴN trong app (xem `fp_desktop_skip_viewport_domains` +
        //     UI ở FingerprintSpoofFeature) — không phát minh cơ chế mới,
        //     tái dùng đúng pattern đã có. Domain nào người dùng liệt kê
        //     vào `bg_keepalive_domains` thì KHÔNG bị đánh dấu
        //     `setActive(false)` khi rời khỏi (được phép tiếp tục chạy nền
        //     thật, giống hệt cách chỉ có youtube.com/m.youtube.com được
        //     miễn trừ khỏi ngoại lệ desktop mode nếu người dùng liệt kê).
        //     Domain KHÔNG nằm trong danh sách → áp dụng đúng hành vi
        //     Chrome mặc định (bị hạ cấp khi không hiển thị).
        val previousActiveId = activeTabId
        if (previousActiveId != null && previousActiveId != tabId) {
            val previousSession = tabs[previousActiveId]
            val previousUrl = tabMeta[previousActiveId]?.url
            val isExempt = previousUrl != null && isBackgroundKeepAliveExemptUrl(previousUrl)
            if (previousSession != null && !isExempt) {
                previousSession.setActive(false)
            } else if (isExempt) {
                DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN keepalive nền] tab '$previousActiveId' ($previousUrl) nằm trong danh sách ngoại lệ — KHÔNG setActive(false), vẫn cho chạy nền thật")
            }
        }
        session.setActive(true)

        activeTabId = tabId
        geckoView.setSession(session)

        // LAZY LOAD: tab được khôi phục lười (createTabLazy) — lần đầu
        // switchToTab mới thực sự tạo session VÀ tải nội dung, không tải
        // cùng lúc lúc khởi động (tránh 7 session + 7 tải đồng thời làm
        // chậm máy).
        if (isFirstActivation) {
            tab.isUnloaded = false
            val url = tab.url
            val savedState = tab.savedState
            if (savedState != null) {
                try {
                    val state = GeckoSession.SessionState.fromString(savedState)
                    if (state != null) {
                        pendingRestoreTabIds.add(tabId)
                        session.restoreState(state)
                        handler.postDelayed({
                            if (pendingRestoreTabIds.remove(tabId)) {
                                DebugLog.log("Khe $slotIndex: lazy restoreState() không gây điều hướng sau 3s — tải lại URL: $url")
                                session.loadUri(url)
                            }
                        }, 3000L)
                    } else {
                        session.loadUri(url)
                    }
                } catch (e: Exception) {
                    DebugLog.log("Khe $slotIndex: lazy restoreState lỗi (${e.message}) — loadUri thay thế")
                    session.loadUri(url)
                }
            } else if (url.isNotBlank() && url != "about:blank") {
                session.loadUri(url)
            }
            DebugLog.log("Khe $slotIndex: lazy load tab $tabId (tạo session THẬT lần đầu) → $url")
        } else {
            // FIX BUG THẬT (người dùng báo: rời tab YouTube đi rồi quay lại
            // thì layout vỡ thành desktop, dù lúc đầu vẫn đang layout mobile
            // đúng — xác nhận qua code: `applyViewportExceptionForUrl()`
            // trước đây CHỈ được gọi ở `onLoadRequest`/`onLocationChange`
            // (mỗi lần điều hướng trang mới), KHÔNG hề được gọi lại ở
            // `switchToTab()` — nếu `session.settings.viewportMode`/
            // `userAgentMode` của tab đó vì bất kỳ lý do gì (kể cả nội bộ
            // GeckoView khi gắn lại session vào GeckoView qua
            // `geckoView.setSession()`) không còn đúng như lúc set ban đầu,
            // KHÔNG có cơ chế nào tự áp lại — y hệt kiểu bug zoom đã sửa
            // trước đó ở đúng chỗ này (`reapplyManualZoom`). Sửa: gọi lại
            // luôn ở đây, mỗi lần chuyển tab — hàm này đã tự kiểm tra
            // `manualDesktopTabIds` để bỏ qua tab đang ở chế độ desktop
            // THỦ CÔNG (không đụng vào lựa chọn tay của người dùng).
            applyViewportExceptionForUrl(session, tab.url)
            // Áp lại mức zoom đã lưu khi chuyển tab — không chỉ khi trang
            // load xong (onPageStop). Tab vừa tạo session lần đầu sẽ được
            // onPageStop áp sau khi load xong.
            val url = tab.url
            if (url.isNotBlank() && url != "about:blank") {
                reapplyManualZoom(tabId, url)
            }
        }

        onTabSwitchedListener?.invoke(tab)
    }

    /**
     * FIX BUG THẬT (người dùng báo, có tái hiện rõ ràng: "upload Drive
     * bình thường khi màn hình sáng dùng app khác, nhưng tắt màn hình là
     * đi ngủ luôn dù đã ghim chạy nền") — xác nhận qua đọc code, không
     * suy đoán: nhánh "ngoại lệ ghim" ở `switchToTab()` (phía trên) CHỈ
     * né được `setActive(false)` — đó là 1 chuyện, còn việc Gecko TỰ hạ
     * ưu tiên tiến trình con khi MẤT SURFACE (tắt màn hình, hoặc chuyển
     * hẳn sang app khác — 2 trường hợp này Android đều gọi
     * `Activity.onPause()`/`onStop()` giống nhau, không phân biệt được ở
     * tầng Activity) là CƠ CHẾ HOÀN TOÀN KHÁC — bằng chứng nằm ngay trong
     * chính comment cũ ở nút "Colab Live" (MainActivity.kt):
     * `setPriorityHint(PRIORITY_HIGH)` mới là cái THẬT SỰ giữ tiến trình
     * con Gecko không bị hạ ưu tiên khi mất surface — và TRƯỚC ĐÂY,
     * `setPriorityHint(PRIORITY_HIGH)` CHỈ được gọi ở 2 nơi: (1) khi có
     * media đang phát VÀ domain nằm trong danh sách ghim (mục 47), (2)
     * khi "Auto Behavior"/nút Colab Live được bật thủ công. KHÔNG CÓ nơi
     * nào set `PRIORITY_HIGH` chỉ vì 1 tab đang nằm trong danh sách ghim
     * chạy nền THÔNG THƯỜNG (không phát media, không phải Colab) — đúng
     * khớp trường hợp upload Drive của người dùng.
     *
     * Cũng cần xử lý riêng trường hợp KHÔNG chuyển tab trong app (đúng
     * kịch bản người dùng mô tả: vẫn đang ở tab Drive, chỉ tắt màn hình
     * hoặc chuyển hẳn sang app khác) — lúc đó `switchToTab()` KHÔNG hề
     * được gọi (không đổi `activeTabId`), nên nhánh ngoại lệ ở đó cũng
     * không có cơ hội chạy. Đây là lý do cần 1 điểm móc RIÊNG, gọi từ
     * `MainActivity.onPause()` — bao trùm cả 2 kịch bản "tắt màn hình"
     * lẫn "chuyển app khác" vì Android xử lý y hệt nhau ở tầng Activity.
     */
    override fun applyBackgroundPriorityForActiveTabIfExempt() {
        val id = activeTabId ?: return
        val session = tabs[id] ?: return
        val url = tabMeta[id]?.url ?: return
        if (isBackgroundKeepAliveExemptUrl(url)) {
            session.setPriorityHint(GeckoSession.PRIORITY_HIGH)
            DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN keepalive nền] tab đang active '$id' ($url) nằm trong danh sách ghim — setPriorityHint(PRIORITY_HIGH) TRƯỚC KHI mất surface (tắt màn hình/chuyển app khác), tránh bị Gecko tự hạ ưu tiên")
        }
    }

    override fun getTabs(): List<BrowserTab> {
        // SỬA BUG (người dùng báo tab lộn xộn): dùng `tabOrder` (thứ tự
        // chèn thật) thay vì `tabMeta.values` (ConcurrentHashMap — thứ tự
        // theo bucket hash nội bộ, KHÔNG phải thứ tự mở tab).
        return tabOrder.mapNotNull { tabMeta[it] }
    }

    override fun getActiveTab(): BrowserTab? {
        return activeTabId?.let { tabMeta[it] }
    }

    // ===== Drag & Drop =====

    override fun handleDropUri(uri: Uri, mimeType: String?) {
        val actualMime = mimeType ?: context.contentResolver.getType(uri) ?: "*/*"

        try {
            val fileName = getFileNameFromUri(uri) ?: "dropped_file"
            val tempFile = File(context.cacheDir, "drops/$fileName")
            tempFile.parentFile?.mkdirs()

            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(tempFile).use { output ->
                    input.copyTo(output)
                }
            }

            val js = """
                (function() {
                    var inputs = document.querySelectorAll('input[type="file"]');
                    if (inputs.length > 0) {
                        window.dispatchEvent(new CustomEvent('livebrowser:filedrop', {
                            detail: { path: '${tempFile.absolutePath}', mime: '$actualMime' }
                        }));
                        return 'file_drop_triggered';
                    }
                    return 'no_file_input';
                })()
            """.trimIndent()

            evaluateJs(js) { result ->
                DebugLog.log("Drop file: $fileName ($actualMime) → $result")
            }

        } catch (e: Exception) {
            DebugLog.log("Drop file error: ${e.message}")
        }
    }

    // ===== Auto Behavior (Giả lập người dùng) =====

    // Theo dõi tab nào đang được nâng PRIORITY_HIGH vì Auto Behavior — cần
    // lưu lại để hạ đúng tab đó khi dừng (activeTabId có thể đã đổi giữa
    // lúc bắt đầu và lúc dừng, không hạ nhầm tab khác).
    private var autoBehaviorPriorityTabId: String? = null

    /**
     * Giả lập hành vi người dùng để tránh bot detection.
     * Chạy ngẫu nhiên: scroll, click, đợi.
     *
     * FIX BUG THẬT (Colab chết khi tắt màn hình lâu, KHÔNG phát media —
     * xem PROJECT_STATUS.md mục 8zm/8zzu): `setPriorityHint(PRIORITY_HIGH)`
     * trước đây CHỈ áp dụng khi MediaSession phát media thật (đúng khớp
     * bằng chứng A/B người dùng: "phát nhạc + Colab + tắt màn hình = sống,
     * chỉ Colab không phát gì = chết"). Auto Behavior CHÍNH LÀ cơ chế giữ
     * Colab "sống" (giả lập tương tác để tránh bị coi là idle) — tab nó
     * đang chạy cũng cần được nâng ưu tiên y hệt tab phát media, vì đây là
     * CÙNG 1 vấn đề gốc (tiến trình con GeckoSession bị hạ ưu tiên khi mất
     * surface), không phải vấn đề riêng của media.
     */
    fun startAutoBehavior() {
        if (!AppPrefs.getBoolean(context, slotIndex, "auto_behavior", false)) return

        activeTabId?.let { tabId ->
            tabs[tabId]?.setPriorityHint(GeckoSession.PRIORITY_HIGH)
            autoBehaviorPriorityTabId = tabId
            DebugLog.log("Khe $slotIndex: Auto Behavior nâng PRIORITY_HIGH cho tab $tabId")
        }

        val behaviorRunnable = object : Runnable {
            override fun run() {
                if (!AppPrefs.getBoolean(context, slotIndex, "auto_behavior", false)) return

                val actions = listOf(
                    "window.scrollBy(0, ${random.nextInt(100, 500)});",
                    "window.scrollBy(0, -${random.nextInt(50, 300)});",
                    "document.querySelector('button, a, input')?.focus();",
                    "document.body.click();",
                    "window.scrollTo(0, document.body.scrollHeight * ${random.nextDouble()});"
                )

                val action = actions[random.nextInt(actions.size)]
                evaluateJs(action) {}

                // Đợi ngẫu nhiên 5-30 giây trước action tiếp
                val delay = 5000 + random.nextInt(25000)
                handler.postDelayed(this, delay.toLong())
            }
        }

        handler.postDelayed(behaviorRunnable, 10000) // Bắt đầu sau 10 giây
        DebugLog.log("Auto behavior started for slot $slotIndex")
    }

    fun stopAutoBehavior() {
        handler.removeCallbacksAndMessages(null)
        // Hạ lại PRIORITY_DEFAULT đúng tab đã nâng lên lúc bắt đầu — không
        // dùng activeTabId ở đây vì có thể đã đổi tab giữa lúc bắt đầu và
        // lúc dừng, hạ nhầm tab khác đang thật sự cần giữ ưu tiên (VD đang
        // phát media) sẽ vô tình huỷ luôn priority hint của MediaSession.
        autoBehaviorPriorityTabId?.let { tabId ->
            tabs[tabId]?.setPriorityHint(GeckoSession.PRIORITY_DEFAULT)
            DebugLog.log("Khe $slotIndex: Auto Behavior hạ lại PRIORITY_DEFAULT cho tab $tabId")
        }
        autoBehaviorPriorityTabId = null
        DebugLog.log("Auto behavior stopped for slot $slotIndex")
    }

    // ===== Internal =====

    /**
     * Bật/tắt ép viewport-desktop THEO TỪNG LẦN ĐIỀU HƯỚNG, dựa vào danh
     * sách tên miền do người dùng tự nhập (`fp_desktop_skip_viewport_domains`,
     * phân cách bằng dấu phẩy — VD "youtube.com,m.youtube.com"). CHỈ áp
     * dụng ngoại lệ (giữ layout mobile) cho ĐÚNG các tên miền trong danh
     * sách — mọi tên miền KHÁC vẫn ép desktop đầy đủ như mặc định an toàn
     * (đúng yêu cầu người dùng: không ảnh hưởng độ nhất quán fingerprint ở
     * các trang không liên quan).
     *
     * Gọi từ `onLoadRequest` (TRƯỚC khi trang đích thật sự tải) — đổi
     * `session.settings.viewportMode`/`userAgentMode` lúc này có hiệu lực
     * cho chính lần tải đó (khác với lúc tạo session — chỉ áp dụng được 1
     * lần cho cả tab, không theo từng trang).
     */
    /**
     * Gọi từ Settings sau khi lưu danh sách ngoại lệ tên miền — trước đây
     * nút Lưu CHỈ ghi vào `AppPrefs`, KHÔNG áp dụng lại cho tab ĐANG MỞ SẴN
     * (chỉ có tác dụng ở lần điều hướng TIẾP THEO, vì logic nằm trong
     * `onLoadRequest`) — người dùng báo "thêm thủ công mà không có thay đổi
     * gì cả" rất có thể là do đang đứng NGAY TRÊN trang đó lúc lưu, cần tải
     * lại mới thấy hiệu lực.
     */
    fun applyExceptionAndReloadActiveTab() {
        val id = activeTabId ?: return
        val session = tabs[id] ?: return
        val url = tabMeta[id]?.url ?: return
        applyViewportExceptionForUrl(session, url)
        session.reload()
    }

    /**
     * GIẢM NHẸ triệu chứng "layout YouTube lệch/khuất sang trái" (mục
     * 8zzi #6, người dùng xác nhận muốn thử hướng này) — theo đúng cách
     * "Xem bằng máy tính" thật trên Chrome mobile hoạt động: trang desktop
     * vẫn giữ NGUYÊN bố cục thật (không bẻ lại CSS gốc của trang), chỉ THU
     * NHỎ toàn bộ lại cho vừa màn hình hẹp bằng CSS `zoom` — đánh đổi: chữ
     * nhỏ hơn, cần phóng to tay (pinch-zoom) khi muốn đọc, giống hệt trải
     * nghiệm "Request Desktop Site" thật trên điện thoại.
     *
     * XÁC NHẬN TRƯỚC KHI DÙNG (không đoán): `zoom` là thuộc tính CSS vốn
     * CHỈ WebKit/Blink hỗ trợ trong nhiều năm — Firefox/Gecko MỚI thêm hỗ
     * trợ từ bản 126 (2024). Bản GeckoView pin trong `build.gradle` là
     * 145.x — đủ mới, an toàn dùng.
     *
     * `evaluateJs()` phát script tới MỌI frame của MỌI tab đang mở (kiến
     * trúc có sẵn từ trước, xem `attachEvalBridgeToSession` gọi cho từng
     * session) — KHÔNG lọc theo tab nào gọi hàm này. Vì vậy script PHẢI TỰ
     * kiểm tra `location.hostname` của chính nó có khớp danh sách ngoại lệ
     * hay không NGAY TRONG JS, không lọc phía Kotlin trước khi gửi — nếu
     * không sẽ áp nhầm zoom vào tab khác đang mở song song.
     */
    /**
     * BUG THẬT (người dùng báo: chỉnh zoom 90% xong refresh trang thì mất
     * luôn, quay lại 100%): mức zoom set qua `document.documentElement
     * .style.zoom` là INLINE STYLE do JS gán — trang tải lại (refresh)
     * nghĩa là DOM mới hoàn toàn, style cũ mất sạch, không có cơ chế nào
     * tự áp lại nếu không chủ động làm.
     *
     * SỬA LẠI LẦN 2 theo đúng góp ý người dùng: lưu theo TAB (bản đầu)
     * nghĩa là đóng tab là mất, phải chỉnh lại từ đầu mỗi lần mở lại cùng
     * trang — không giống Chrome thật (nhớ zoom theo TỪNG TRANG WEB, còn
     * nguyên dù đóng hết tab/khởi động lại app). Đổi sang đọc từ
     * `ZoomPrefs` (lưu bền theo domain, xuyên suốt tab/phiên) thay vì
     * field tạm trên `BrowserTab`.
     */
    /**
     * FIX RACE CONDITION (PDF chẩn đoán): applyDesktopLayoutZoomIfNeeded và
     * reapplyManualZoom trước đây chạy bất đồng bộ độc lập — cả 2 đều gọi
     * evaluateJs() riêng, thứ tự không đảm bảo, script sau có thể ghi đè
     * zoom của script trước (VD desktop zoom tính 0.38 → áp, xong manual
     * zoom 70% → áp đè lại, hoặc ngược lại tùy timing).
     *
     * FIX ZOOM YOUTUBE HOST (PDF chẩn đoán): ZoomPrefs lưu theo host, nhưng
     * YouTube nhảy m.youtube.com ↔ www.youtube.com liên tục (thấy rõ trong
     * log). Zoom lưu ở m.youtube.com khác key với www.youtube.com → tra ra
     * mặc định 100% dù số dialog hiện đúng (dialog đọc lúc URL cũ, áp lúc
     * URL đã đổi host). Sửa: normalize host YouTube về "youtube.com" trước
     * khi đọc/ghi ZoomPrefs.
     *
     * Giải pháp: gộp cả 2 logic zoom vào 1 hàm duy nhất, gửi 1 script JS
     * duy nhất — trong script đó tính final zoom 1 lần, áp 1 lần.
     */
    private fun reapplyManualZoom(tabId: String, url: String) {
        // Normalize YouTube host để ZoomPrefs luôn dùng 1 key duy nhất
        // bất kể trang đang ở m.youtube.com hay www.youtube.com
        val normalizedUrl = normalizeYouTubeHostForZoom(url)
        val manualPercent = ZoomPrefs.getZoomForUrl(context, slotIndex, normalizedUrl)
        applyZoomCombined(tabId, manualPercent)
    }

    /**
     * Public — gọi lại từ MainActivity khi THOÁT fullscreen (xem
     * `onFullScreen` ở ContentDelegate: lúc VÀO fullscreen zoom bị tắt hẳn
     * về '', nhưng lúc THOÁT ra cần tính lại đúng zoom như trước — dùng lại
     * chính logic reapplyManualZoom() cho tab đang active, không viết lại).
     */
    fun reapplyZoomForActiveTab() {
        val tabId = activeTabId ?: return
        val url = tabMeta[tabId]?.url ?: return
        if (url.isNotBlank() && url != "about:blank") {
            reapplyManualZoom(tabId, url)
        }
    }

    /**
     * Gộp desktop-layout zoom + manual zoom thành 1 script JS duy nhất.
     * Tính final scale trong JS rồi áp 1 lần — không còn 2 async script
     * đè nhau nữa.
     */
    private fun applyZoomCombined(tabId: String, manualPercent: Int) {
        try {
            val domainsRaw = AppPrefs.getString(context, slotIndex, "fp_desktop_skip_viewport_domains", "")
            val exceptionDomains = domainsRaw.split(",", "\n")
                .map { it.trim().lowercase() }.filter { it.isNotEmpty() }
            val domainsJsArray = if (exceptionDomains.isNotEmpty())
                exceptionDomains.joinToString(",") { "\"${it.replace("\"", "")}\"" }
            else "[]"
            val manualScale = manualPercent / 100.0

            // SỬA (mục 59 PROJECT_STATUS.md — "màn hình như bị loạn cảm
            // ứng"): trước đây zoom áp qua CSS `document.documentElement
            // .style.zoom`, một thuộc tính KHÔNG CHUẨN có lịch sử hỗ trợ
            // chưa hoàn thiện trong Gecko (Bugzilla #1254064). Quan trọng
            // hơn: Bugzilla #1257579 xác nhận CHÍNH THỨC có lớp bug
            // sai lệch giữa toạ độ chạm (hit-testing) và mức zoom/resolution
            // khi dùng cơ chế này — khớp đúng triệu chứng "chạm vào 1 chỗ
            // nhưng tác động sai chỗ khác".
            //
            // ĐÃ TRA CỨU LẠI (không đoán): GeckoView KHÔNG có API embedder
            // công khai kiểu "set page zoom" cấp session (PanZoomController
            // chỉ có scrollBy/scrollTo, không có setZoom/zoomToRect —
            // xác nhận qua javadoc GeckoView hiện hành, mục Changelog).
            // Hướng thay thế ĐÚNG cơ chế native của Gecko (không phải
            // CSS, tránh đúng lớp bug hit-testing ở trên): điều khiển
            // zoom qua chính thẻ <meta name="viewport" content=
            // "initial-scale=...">, cơ chế Gecko dùng để tính toán
            // resolution/hit-testing THẬT (không phải ghi đè kích thước
            // hiển thị bằng CSS sau khi layout/hit-test đã tính xong).
            // Xác nhận qua Bugzilla #932690 (thảo luận GeckoView
            // zoom/viewport, cùng thread với bug zoom-property ở trên):
            // trang có đặt initial-scale qua meta viewport thì Gecko áp
            // dụng ở đúng tầng resolution/viewport, không phải tầng CSS
            // layout riêng lẻ như style.zoom.
            //
            // Cách làm: tìm thẻ <meta name="viewport"> có sẵn (nếu có,
            // hầu hết trang responsive đều có) và ghi đè content của nó
            // bằng initial-scale=finalScale, giữ nguyên width=device-width
            // nếu trang đã khai; nếu trang KHÔNG có thẻ này, tạo mới.
            // manual/desktop scale = 1.0 (finalScale=1.0) thì XOÁ HẲN thẻ
            // do app tự thêm, trả trang về viewport gốc của chính nó (nếu
            // trang tự có thẻ viewport riêng, không đụng vào — chỉ đụng
            // thẻ do CHÍNH app này thêm, đánh dấu qua data-attribute).
            //
            // ⚠️ CHƯA build/test trên máy thật — đây là thay đổi kiến trúc
            // (đổi cơ chế zoom), cần xác nhận: (a) zoom vẫn phóng to/thu
            // nhỏ được như trước, (b) hit-testing/chạm giờ đúng vị trí kể
            // cả khi bật "Chế độ máy tính", (c) không phá vỡ trang nào tự
            // quản lý viewport riêng của nó (nghi vấn: trang có sẵn 1 thẻ
            // <meta name="viewport"> KHÁC id/data-attribute app gắn — code
            // dưới đây match theo name="viewport" bất kể ai tạo, ưu tiên
            // đơn giản/nhất quán hơn giữ 2 thẻ viewport song song, vốn
            // không hợp lệ theo spec HTML dù trình duyệt thường chỉ đọc
            // thẻ đầu tiên).
            val script = """
                (function() {
                    var domains = [$domainsJsArray];
                    var host = location.hostname.toLowerCase();
                    var isException = domains.length > 0 && domains.some(function(d) {
                        return host === d || host.slice(-(d.length + 1)) === ('.' + d);
                    });
                    // BUG THẬT đã tìm ra (người dùng báo: đặt "ngoại lệ
                    // desktop" cho YouTube — kỳ vọng PLAYER chất lượng
                    // desktop nhưng LAYOUT trang vẫn gọn kiểu mobile — thực
                    // tế lại ra CẢ LAYOUT lẫn PLAYER đều thành desktop, tức
                    // thiết kế "layout mobile" không hề có tác dụng):
                    // `applyViewportExceptionForUrl()` (hàm khác, phía
                    // Kotlin) đã CỐ Ý đặt `viewportMode = MOBILE` cho đúng
                    // domain trong `isException` này (chỉ đổi User-Agent
                    // giả desktop để site tự chọn stream chất lượng cao,
                    // KHÔNG đổi layout viewport) — nhưng đoạn code NGAY DƯỚI
                    // ĐÂY (đã xoá) lại ĐỘC LẬP tự thu nhỏ
                    // `document.documentElement.style.zoom` xuống còn
                    // ~0.3–0.4 cho ĐÚNG cùng danh sách domain đó. Zoom CSS ở
                    // mức `documentElement` không chỉ là phóng to hình ảnh —
                    // nó làm `window.innerWidth` (viewport LOGIC mà các
                    // media-query/JS của trang dùng để tự quyết định layout
                    // mobile hay desktop) báo về to hơn thật (VD màn 396px
                    // vật lý, zoom=0.396 → innerWidth báo ~1000px) — TỰ KÍCH
                    // HOẠT layout desktop thật của trang, xoá sạch tác dụng
                    // của `viewportMode=MOBILE` đã đặt phía Kotlin. Đoạn
                    // code này vốn được viết cho 1 thiết kế CŨ (giả định
                    // viewportMode ĐANG là DESKTOP, cần zoom nhỏ lại cho vừa
                    // màn hình hẹp) — thiết kế mới ở `applyViewportExceptionForUrl()`
                    // đã đổi hẳn hướng (giữ MOBILE, không cần zoom) nhưng
                    // đoạn zoom cũ này bị BỎ SÓT, không xoá theo, nên 2 cơ
                    // chế đá nhau.
                    // SỬA: domain ngoại lệ KHÔNG còn tự zoom gì nữa — để
                    // nguyên layout mobile thật (đúng ý định gốc), việc giả
                    // desktop chỉ còn nằm ở User-Agent (phía Kotlin). Biến
                    // `isException` GIỮ LẠI chỉ để in log chẩn đoán.
                    var desktopScale = 1.0;
                    // Manual zoom từ ZoomPrefs (người dùng chỉnh thủ công)
                    var manualScale = $manualScale;
                    // Final scale: manual zoom nhân thêm lên desktop scale
                    // Ưu tiên manual zoom nếu người dùng đã đặt (khác 1.0)
                    var finalScale;
                    if (manualScale !== 1.0) {
                        finalScale = manualScale;
                        window.__manualZoomOverride = true;
                    } else {
                        finalScale = desktopScale;
                        window.__manualZoomOverride = false;
                    }
                    // Dọn sạch dấu vết cơ chế CŨ (CSS zoom) nếu còn sót lại
                    // từ 1 lần load trước đó (vd trang không reload, chỉ
                    // đổi setting) — tránh 2 cơ chế zoom cùng áp 1 lúc.
                    if (document.documentElement.style.zoom) {
                        document.documentElement.style.zoom = '';
                    }
                    var meta = document.querySelector('meta[name="viewport"]');
                    if (finalScale !== 1.0) {
                        var content = 'width=device-width, initial-scale=' + finalScale +
                                      ', minimum-scale=' + (finalScale * 0.5) +
                                      ', maximum-scale=' + (finalScale * 3) +
                                      ', user-scalable=yes';
                        if (!meta) {
                            meta = document.createElement('meta');
                            meta.setAttribute('name', 'viewport');
                            meta.setAttribute('data-colablive-zoom', '1');
                            (document.head || document.documentElement).appendChild(meta);
                        }
                        meta.setAttribute('content', content);
                    } else if (meta && meta.getAttribute('data-colablive-zoom') === '1') {
                        // Thẻ này do CHÍNH app tạo lúc trước (đánh dấu qua
                        // data-attribute) và giờ không cần zoom nữa — xoá
                        // hẳn để trang tự quyết viewport của nó (khớp hành
                        // vi "chưa từng bị app đụng vào" khi finalScale=1.0
                        // ngay từ đầu, vì lúc đó if() này không tạo ra meta).
                        meta.parentNode.removeChild(meta);
                    }
                    return 'zoom(meta-viewport)=' + finalScale.toFixed(3) +
                           ' (desktop=' + desktopScale.toFixed(3) +
                           ', manual=' + manualScale.toFixed(3) +
                           ', exception=' + isException + ')';
                })();
            """.trimIndent()
            // FIX HIỆU NĂNG (bug fan-out): gọi evaluateJsForTab(tabId, ...)
            // tường minh thay vì evaluateJs() — chỉ nhắm đúng tab đang zoom,
            // không phát script này tới mọi frame của mọi tab khác đang mở.
            evaluateJsForTab(tabId, script) { result ->
                DebugLog.log("Khe $slotIndex: [zoom gộp] $result")
            }
        } catch (e: Exception) {
            DebugLog.log("applyZoomCombined lỗi: ${e.message}")
        }
    }

    /** Normalize YouTube mobile/desktop host về 1 key chung cho ZoomPrefs */
    private fun normalizeYouTubeHostForZoom(url: String): String {
        return try {
            val uri = android.net.Uri.parse(url)
            val host = uri.host ?: return url
            if (host.endsWith("youtube.com")) {
                // m.youtube.com, www.youtube.com, music.youtube.com, v.v.
                // → dùng "youtube.com" làm key chung để zoom nhất quán
                uri.buildUpon().authority("youtube.com").build().toString()
            } else {
                url
            }
        } catch (e: Exception) { url }
    }

    /**
     * CHẨN ĐOÁN player YouTube spin mãi không phát (xem chú thích ở
     * `onPageStop`) — hỏi thẳng `<video>` element thật đang thấy gì, KHÔNG
     * đoán thêm nữa. `readyState` 0-4 (0=HAVE_NOTHING tới 4=HAVE_ENOUGH_DATA
     * để phát mượt), `networkState` 0-3 (3=NETWORK_NO_SOURCE — trình duyệt
     * không tìm được nguồn phát được, dấu hiệu mạnh nhất của lỗi codec/DRM),
     * `error.code` nếu có (1=ABORTED, 2=NETWORK, 3=DECODE — lỗi giải mã
     * THẬT, rất có thể là nguyên nhân — GeckoView embedded có thể thiếu
     * quyền truy cập MediaCodec phần cứng hoặc bị giới hạn nếu khe khác
     * đang chiếm hết decoder phần cứng cùng lúc).
     *
     * Lặp 6 lần, cách nhau 2s (tổng 12s) — đủ để thấy DIỄN BIẾN thật (spin
     * mãi = readyState đứng yên ở 0-1 suốt 12s; phát được = readyState lên
     * 3-4 trong vài giây đầu).
     */
    private fun pollVideoDiagnostic(tabId: String, url: String, attempt: Int) {
        if (attempt >= 6) return
        if (tabId != activeTabId) return // người dùng đã rời trang, dừng poll cho đỡ tốn
        // BỔ SUNG (mục 62.1 PROJECT_STATUS.md — người dùng hỏi thẳng tại
        // sao chưa fix, không chỉ chẩn đoán mãi). Mục 50.2 đã RÚT LẠI giả
        // thuyết "tranh chấp CPU giữa 2 TIẾN TRÌNH khác nhau" (bằng chứng
        // thời gian không khớp), nhưng CHƯA hề loại giả thuyết KHÁC vẫn
        // còn treo từ mục 49 gốc: tranh chấp DECODER PHẦN CỨNG dùng chung
        // giữa các SESSION GeckoView khác nhau TRONG CÙNG 1 TIẾN TRÌNH
        // (dẫn Bugzilla #1545817 + mozilla/geckoview#203) — đây là tranh
        // chấp Ở TẦNG KHÁC (phần cứng codec dùng chung của thiết bị, không
        // phải CPU giữa 2 tiến trình OS), hoàn toàn có thể vẫn đúng dù giả
        // thuyết đa-tiến-trình đã sai. Trước đây CHƯA từng đo trực tiếp có
        // bao nhiêu session khác (tab khác, CÙNG khe này) đang tồn tại lúc
        // video kẹt — thêm phép đo này NGAY BÂY GIỜ, tự động, không cần
        // người dùng tự dàn dựng kịch bản test thủ công nữa.
        val sessionCountSameSlot = tabMeta.size
        val js = """
            (function() {
                var v = document.querySelector('video');
                if (!v) return 'KHÔNG TÌM THẤY THẺ <video> NÀO TRONG TRANG';
                var err = v.error ? ('code=' + v.error.code + ' message=' + v.error.message) : 'không có';
                var buffered = '';
                try {
                    for (var i = 0; i < v.buffered.length; i++) {
                        buffered += '[' + v.buffered.start(i).toFixed(1) + '-' + v.buffered.end(i).toFixed(1) + ']';
                    }
                } catch (e) { buffered = '(lỗi đọc buffered: ' + e.message + ')'; }
                if (buffered === '') buffered = '(rỗng — chưa buffer được byte nào)';

                // ĐÃ GỠ BỎ việc chủ động gọi v.play() (từng thêm ở lượt
                // trước) — RỦI RO THẬT không phải suy đoán: gọi play() từ
                // BÊN NGOÀI, không thông qua chính cơ chế điều khiển nội bộ
                // của player YouTube, có thể can thiệp vào đúng lúc player
                // đang tự load/play/pause để phục hồi buffer — hoàn toàn có
                // thể CHÍNH LÀ nguyên nhân gây ra (hoặc làm nặng thêm)
                // "AbortError: The fetching process for the media resource
                // was aborted by the user agent at the user's request" đã
                // thấy trong log — công cụ chẩn đoán không nên làm thay đổi
                // trạng thái của chính thứ nó đang đo. Quay lại THUẦN ĐỌC
                // (readyState/networkState/error/buffered) như bản đầu.
                var frameDiag = '(không có getVideoPlaybackQuality)';
                try {
                    if (typeof v.getVideoPlaybackQuality === 'function') {
                        var q = v.getVideoPlaybackQuality();
                        frameDiag = 'totalVideoFrames=' + q.totalVideoFrames + ' droppedVideoFrames=' + q.droppedVideoFrames;
                    }
                } catch (e) { frameDiag = '(lỗi đọc: ' + e.message + ')'; }

                var visDiag = 'visibilityState=' + document.visibilityState + ' hidden=' + document.hidden;

                return 'readyState=' + v.readyState + ' networkState=' + v.networkState +
                       ' paused=' + v.paused + ' currentTime=' + v.currentTime.toFixed(2) +
                       ' duration=' + (isNaN(v.duration) ? 'NaN' : v.duration.toFixed(1)) +
                       ' error=[' + err + '] buffered=' + buffered +
                       ' src=' + (v.currentSrc ? v.currentSrc.substring(0, 60) : '(rỗng)') +
                       ' | ' + frameDiag + ' | ' + visDiag;
            })();
        """.trimIndent()
        // Gọi evaluateJsForTab TƯỜNG MINH với đúng tabId đã biết (không
        // dựa ngầm vào activeTabId của evaluateJs()) — dù đã kiểm tra
        // `tabId == activeTabId` ở trên, dùng tabId tường minh vẫn đúng
        // 100% ngay cả trong khung thời gian hẹp giữa lúc gửi script và
        // lúc nhận callback (nếu người dùng đổi tab active đúng lúc đó).
        evaluateJsForTab(tabId, js) { result ->
            // BỔ SUNG mục 62.1: log kèm SỐ TAB (session) khác đang tồn tại
            // trong CHÍNH khe này tại đúng thời điểm quan sát — bằng chứng
            // còn thiếu để xác nhận/loại trừ giả thuyết tranh chấp decoder
            // phần cứng GIỮA CÁC SESSION cùng tiến trình (khác hẳn giả
            // thuyết đa-tiến-trình đã bị mục 50.2 bác bỏ). Nếu lần tới bug
            // tái hiện mà dòng này cho thấy `tabCount=1` (chỉ đúng 1 tab —
            // tab đang xem video, không tab nào khác) mà VẪN kẹt, giả
            // thuyết tranh chấp decoder (dù cùng hay khác tiến trình) coi
            // như bị loại HẲN, không chỉ riêng nhánh đa-tiến-trình.
            DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN video lần ${attempt + 1}/6, +${attempt * 2}s, tabCountKheThis=$sessionCountSameSlot] $result")
            handler.postDelayed({ pollVideoDiagnostic(tabId, url, attempt + 1) }, 2000L)
        }
    }

    // applyDesktopLayoutZoomIfNeeded() ĐÃ BỊ XÓA — logic gộp vào applyZoomCombined()
    // được gọi qua reapplyManualZoom(). Xem chú thích race condition ở reapplyManualZoom.

    /**
     * TÍNH NĂNG MỚI — dùng LẠI đúng pattern "danh sách ngoại lệ theo domain,
     * người dùng tự nhập" đã có sẵn (xem `applyViewportExceptionForUrl` +
     * pref `fp_desktop_skip_viewport_domains`) cho việc quyết định tab nào
     * được PHÉP tiếp tục chạy nền thật khi không hiển thị (không bị
     * `setActive(false)`) — xem giải thích đầy đủ ở `switchToTab()`. Domain
     * do người dùng tự liệt kê vào `bg_keepalive_domains` (Cài đặt) — KHÔNG
     * hard-code sẵn bất kỳ trang cụ thể nào (Colab, YouTube Music, hay bất
     * cứ gì) — người dùng tự quyết định trang nào cần ngoại lệ.
     */
    private fun isBackgroundKeepAliveExemptUrl(url: String): Boolean {
        // Khoá namespaced theo đúng `BackgroundKeepAliveFeature.id` — file
        // đó (tầng features, phụ thuộc CHIỀU XUỐNG core) và file này (tầng
        // core) không tham chiếu code lẫn nhau, chỉ chia sẻ ĐÚNG 1 khoá
        // AppPrefs làm hợp đồng chung — tránh phụ thuộc vòng core↔features.
        val featureId = "background_keepalive_domains"
        val enabled = AppPrefs.getBoolean(context, slotIndex, featureId, "enabled", true)
        if (!enabled) return false
        val domainsRaw = AppPrefs.getString(context, slotIndex, featureId, "domains", "")
        val exceptionDomains = domainsRaw.split(",", "\n")
            .map { it.trim().lowercase() }
            .filter { it.isNotEmpty() }
        if (exceptionDomains.isEmpty()) return false
        val host = try {
            android.net.Uri.parse(url).host?.lowercase()
        } catch (e: Exception) {
            null
        } ?: return false
        return exceptionDomains.any { d -> host == d || host.endsWith(".$d") }
    }

    private fun applyViewportExceptionForUrl(session: GeckoSession, url: String) {
        val tabId = tabIdFor(session)

        // ĐƠN GIẢN HOÁ (dọn theo hàm dùng chung mới
        // `applyManualDesktopModeIfApplicable()` — xem chú thích đầy đủ ở
        // đó và ở `recoverKilledOrCrashedSession()`, nơi phát hiện ra
        // logic tương tự bị thiếu gây bug thật "tự mất trạng thái
        // desktop"). Logic "áp lại nếu đã đánh dấu thủ công HOẶC domain
        // nằm trong danh sách persist" giờ nằm ở 1 CHỖ DUY NHẤT, tránh 2
        // nơi tự viết lại dễ lệch nhau như đã từng xảy ra.
        if (tabId != null && applyManualDesktopModeIfApplicable(session, tabId, url)) {
            DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN ngoại lệ desktop] bỏ qua phần còn lại — tab $tabId đang ở chế độ desktop THỦ CÔNG")
            return
        }

        val domainsRaw = AppPrefs.getString(context, slotIndex, "fp_desktop_skip_viewport_domains", "")
        val exceptionDomains = domainsRaw.split(",", "\n")
            .map { it.trim().lowercase() }
            .filter { it.isNotEmpty() }
        if (exceptionDomains.isEmpty()) return // chưa cấu hình gì — giữ nguyên hành vi mặc định lúc tạo session

        val host = try {
            android.net.Uri.parse(url).host?.lowercase()
        } catch (e: Exception) {
            null
        } ?: return

        // So khớp domain hoặc subdomain (VD "m.youtube.com" khớp mục
        // "youtube.com") — KHÔNG khớp kiểu "notyoutube.com" chứa chuỗi con.
        val isException = exceptionDomains.any { d -> host == d || host.endsWith(".$d") }

        // LOG CHẨN ĐOÁN — CHỈ 1 DÒNG mỗi lần điều hướng (không spam như các
        // lần trước), để CHẮC CHẮN thấy được domain có khớp không, thay vì
        // đoán qua lại nhiều lượt không có bằng chứng.
        DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN ngoại lệ desktop] host=$host, danh sách=$exceptionDomains, khớp=$isException")

        // BUG THẬT tìm ra (người dùng test đúng, báo lại đúng): dòng
        // `if (!FingerprintSpoofFeature.isEnabled(...)) return` TRƯỚC ĐÂY
        // chặn TOÀN BỘ cơ chế này ngay từ đầu nếu tính năng giả mạo vân tay
        // (công tắc TỔNG, MẶC ĐỊNH TẮT — `AppPrefs...("enabled", false)`)
        // chưa được bật riêng — bất kể danh sách tên miền có gì. Đây là lỗi
        // thiết kế: "ép desktop cho tên miền X" và "giả mạo vân tay" là 2
        // việc KHÁC NHAU, không nên gộp chung 1 công tắc. Đã tách ra: ngoại
        // lệ tên miền giờ hoạt động ĐỘC LẬP, không cần bật fingerprint spoof.
        val fpEnabled = FingerprintSpoofFeature.isEnabled(context, slotIndex)
        val hw = if (fpEnabled) resolveProfile().first else null

        try {
            if (isException) {
                // SỬA LỖI THIẾT KẾ NGHIÊM TRỌNG (người dùng chỉ ra đúng):
                // bản trước ép CẢ `viewportMode = DESKTOP` — y hệt nút "Xem
                // bằng máy tính" — cho ra layout desktop khó dùng, SAI HẲN
                // mục đích ban đầu của tính năng này (mục 8zt: "player
                // desktop + layout MOBILE"). Cơ chế THẬT (đã xác nhận ở mục
                // 8zt): chỉ cần UA/thuộc tính JS (navigator.platform,
                // maxTouchPoints...) trông như desktop để trang (VD YouTube)
                // CHỌN PLAYER desktop — viewport/layout hoàn toàn KHÔNG liên
                // quan tới việc chọn player, chỉ quyết định độ rộng CSS hiển
                // thị. Giữ `viewportMode = MOBILE` (layout dễ dùng), CHỈ đổi
                // `userAgentMode = DESKTOP` (UA THẬT trông như desktop, đủ
                // để qua mặt kiểm tra UA/touch của trang).
                session.settings.userAgentOverride = null
                session.settings.userAgentMode = GeckoSessionSettings.USER_AGENT_MODE_DESKTOP
                session.settings.viewportMode = GeckoSessionSettings.VIEWPORT_MODE_MOBILE
            } else if (fpEnabled && hw != null) {
                // Chỉ khôi phục UA/viewport theo hồ sơ giả nếu fingerprint
                // spoof đang thật sự bật — nếu không, không có gì để khôi
                // phục (giữ nguyên mặc định lúc tạo session).
                session.settings.userAgentOverride = hw.userAgent
                if (hw.category == "desktop") {
                    session.settings.viewportMode = GeckoSessionSettings.VIEWPORT_MODE_DESKTOP
                    session.settings.userAgentMode = GeckoSessionSettings.USER_AGENT_MODE_DESKTOP
                } else {
                    session.settings.viewportMode = GeckoSessionSettings.VIEWPORT_MODE_MOBILE
                    session.settings.userAgentMode = GeckoSessionSettings.USER_AGENT_MODE_MOBILE
                }
            }
            if (fpEnabled) {
                pushFingerprintConfig(session) // đồng bộ lại navigator.platform/maxTouchPoints/WebGL... theo đúng trạng thái vừa đổi
            }
        } catch (e: Exception) {
            DebugLog.log("Khe $slotIndex: applyViewportExceptionForUrl lỗi: ${e.message}")
        }
    }

    private fun createSessionUnopened(isPrivate: Boolean = false): GeckoSession {
        // CHẾ ĐỘ ẨN DANH — tính năng lớn còn thiếu, ghi rõ trong
        // PROJECT_STATUS.md nhiều lượt liền, giờ mới làm: `usePrivateMode(true)`
        // là API THẬT của GeckoView (đúng cơ chế Private Browsing của
        // Firefox — phiên chạy trong bộ nhớ, không ghi cookie/storage/lịch
        // sử xuống đĩa, tự động cô lập khỏi MỌI context thường kể cả khi
        // vẫn set `contextId` như dưới đây — theo đúng thiết kế Gecko,
        // private mode luôn dùng 1 vùng chứa ephemeral RIÊNG, contextId chỉ
        // có ý nghĩa giữa các phiên KHÔNG private với nhau).
        // BUG THẬT ĐÃ SỬA (người dùng báo: đặt tên hồ sơ cho dữ liệu đang
        // có sẵn trong khe làm MẤT ĐĂNG NHẬP GOOGLE). Trước đây dùng thẳng
        // `ProfileSlots.getSlotAssignment(...)` (tên hồ sơ) làm contextId
        // — tên đổi thì contextId đổi thì container storage đổi. Giờ dùng
        // `getStableContextId()` — 1 UUID lưu ngay trong thư mục hồ sơ vật
        // lý, không đổi dù tên hồ sơ có đổi bao nhiêu lần. Xem chú thích
        // đầy đủ ở `ProfileSlots.getStableContextId()`.
        val builder = GeckoSessionSettings.Builder()
            .usePrivateMode(isPrivate)
            .useTrackingProtection(true)
            .suspendMediaWhenInactive(false)
            .contextId("profile_${ProfileSlots.getStableContextId(context, slotIndex)}")

        // UA header HTTP THẬT — khớp CHÍNH XÁC với navigator.userAgent phía JS
        // (xem buildFingerprintConfigMessage). Trước đây chỉ có JS override,
        // header HTTP thật vẫn để lộ GeckoView/Firefox thật — mismatch dễ bị
        // phát hiện hơn cả không giả UA gì. LUÔN đi cùng hardware spoof —
        // không có tổ hợp hợp lệ nào khi tách UA ra khỏi platform/GPU giả.
        if (FingerprintSpoofFeature.isEnabled(context, slotIndex)) {
            val (hw, _) = resolveProfile()
            builder.userAgentOverride(hw.userAgent)

            // Hồ sơ desktop: bật CHẾ ĐỘ DESKTOP THẬT của GeckoView — đúng cơ
            // chế "Request Desktop Site" của trình duyệt mobile thật (viewport
            // CSS 980px, KHÔNG theo <meta viewport> của trang). Đây là thay
            // đổi RENDER THẬT (layout, @media query đều đổi theo), không phải
            // chỉ nói dối 1 property JS như screen.width — thu hẹp đáng kể
            // khoảng cách giữa "khai desktop" và "hiển thị thật vẫn mobile".
            //
            // Giá trị KHỞI TẠO lúc tạo session — mặc định AN TOÀN NHẤT (ép
            // desktop nếu hồ sơ desktop). Việc BỎ ép cho 1 số tên miền cụ
            // thể (VD youtube.com) được xử lý ĐỘNG mỗi lần điều hướng, xem
            // `applyViewportExceptionForUrl()` gọi từ `onLoadRequest` bên
            // dưới — vì `viewportMode`/`userAgentMode` là thuộc tính có thể
            // đổi SAU khi tạo session (bằng chứng: `toggleDesktopMode()` đã
            // làm vậy), không cần cố định 1 lần lúc tạo session cho CẢ tab.
            if (hw.category == "desktop") {
                builder.viewportMode(GeckoSessionSettings.VIEWPORT_MODE_DESKTOP)
                builder.userAgentMode(GeckoSessionSettings.USER_AGENT_MODE_DESKTOP)
            }
        }

        val settings = builder.build()

        val session = GeckoSession(settings)
        attachEvalBridgeToSession(session)
        attachFingerprintExtensionToSession(session)

        session.progressDelegate = object : GeckoSession.ProgressDelegate {
            override fun onPageStart(session: GeckoSession, url: String) {
                tabIdFor(session)?.let { tabMeta[it]?.isLoading = true }
                if (tabIdFor(session) == activeTabId) {
                    onProgressChangedListener?.invoke(0)
                    onPageStartedListener?.invoke(url)
                }
            }

            override fun onPageStop(session: GeckoSession, success: Boolean) {
                val tabId = tabIdFor(session)
                tabId?.let { tabMeta[it]?.isLoading = false }
                if (tabId == activeTabId) onProgressChangedListener?.invoke(100)
                if (success && tabId != null) {
                    val url = tabMeta[tabId]?.url ?: return
                    if (tabId == activeTabId) {
                        onPageLoadedListener?.invoke(url)
                        startAutoBehavior()
                        // FIX race condition: thay vì gọi applyDesktopLayoutZoomIfNeeded()
                        // + reapplyManualZoom() riêng (2 script async có thể đè nhau),
                        // giờ chỉ gọi reapplyManualZoom() — hàm này đã gộp cả 2 logic
                        // vào 1 script JS duy nhất qua applyZoomCombined(). Xem PDF.
                        reapplyManualZoom(tabId, url)
                        // CHẨN ĐOÁN player YouTube quay spin mãi không phát
                        // (người dùng báo Khe 1) — không đoán thêm nữa, hỏi
                        // THẲNG trình duyệt thật đang thấy gì ở thẻ <video>:
                        // readyState (0=chưa có data, 4=đủ data để phát),
                        // networkState, error.code (nếu có — mã lỗi decode/
                        // network THẬT của trình duyệt), paused, buffered.
                        // Chỉ bật khi URL là trang xem video thật (có
                        // "watch" hoặc "/shorts/") để không tốn tài nguyên ở
                        // trang khác. Poll nhiều lần vì lúc onPageStop bắn,
                        // video có thể vẫn đang khởi tạo — cần thấy DIỄN
                        // BIẾN theo thời gian, không chỉ 1 lát cắt.
                        if (url.contains("youtube.com") && (url.contains("watch") || url.contains("/shorts/"))) {
                            pollVideoDiagnostic(tabId, url, attempt = 0)
                        }
                    }
                }
            }

            override fun onProgressChange(session: GeckoSession, progress: Int) {
                if (tabIdFor(session) == activeTabId) onProgressChangedListener?.invoke(progress)
            }

            override fun onSecurityChange(session: GeckoSession, securityInfo: GeckoSession.ProgressDelegate.SecurityInformation) {}

            /**
             * KHÔI PHỤC TAB ĐẦY ĐỦ — đã TRA ĐƯỢC API chính xác (trước đây
             * chỉ khôi phục URL/tiêu đề, KHÔNG có lịch sử back/forward/vị
             * trí cuộn/dữ liệu form, vì "chưa có mạng tra API bất đồng bộ
             * phức tạp hơn"). Xác nhận từ tài liệu GeckoView chính thức:
             * `onSessionStateChange()` tự động fire mỗi khi trạng thái
             * phiên đổi (điều hướng, cuộn, nhập form...), cho
             * `GeckoSession.SessionState` — chuỗi hoá qua `.toString()`,
             * khôi phục lại qua `SessionState.fromString()` +
             * `session.restoreState()`. Chỉ cập nhật biến TRONG BỘ NHỚ ở
             * đây (rẻ, fire rất thường xuyên) — việc GHI XUỐNG ĐĨA vẫn theo
             * đúng các mốc cũ (mở/đóng tab, mất foreground) qua
             * `saveTabsState()`, không ghi đĩa mỗi lần hàm này chạy (sẽ quá
             * nhiều I/O).
             */
            override fun onSessionStateChange(session: GeckoSession, sessionState: GeckoSession.SessionState) {
                tabIdFor(session)?.let { tabId -> tabMeta[tabId]?.savedState = sessionState.toString() }
            }
        }

        session.navigationDelegate = object : GeckoSession.NavigationDelegate {
            override fun onLoadRequest(
                session: GeckoSession,
                request: GeckoSession.NavigationDelegate.LoadRequest
            ): GeckoResult<AllowOrDeny> {
                DebugLog.log("onLoadRequest: ${request.uri}")
                // FIX BUG THẬT (người dùng báo: trang đang tải bị gián đoạn
                // — chuyển app khác/làm việc khác giữa chừng — thì thành
                // about:blank; đã tự tìm ra lỗ hổng cụ thể thay vì chỉ ghi
                // nghi vấn chờ log): TRƯỚC ĐÂY `tab.url` chỉ được cập nhật ở
                // 2 nơi — `loadUrl()` (gõ thanh địa chỉ, cập nhật NGAY) và
                // `onLocationChange` (Gecko tự báo, CÓ ĐỘ TRỄ tới khi Gecko
                // xác nhận điều hướng THẬT SỰ xảy ra). Nếu người dùng bấm 1
                // LIÊN KẾT TRONG TRANG (không qua `loadUrl()` của app) rồi
                // hệ thống kill session GIỮA lúc bấm và lúc `onLocationChange`
                // kịp bắn (cửa sổ hở có thật, không phải suy đoán suông —
                // đúng theo vòng đời GeckoView tài liệu: `onLoadRequest` bắn
                // NGAY khi điều hướng được YÊU CẦU, `onLocationChange` chỉ
                // bắn SAU khi Gecko xác nhận điều hướng đã diễn ra, có độ
                // trễ thật) — `recoverKilledOrCrashedSession()` sẽ phục hồi
                // bằng `tab.url` CŨ (giá trị trước lần điều hướng này), gây
                // đúng cảm giác "trang đang tải mất tích, về trang trống/cũ".
                // SỬA: cập nhật `tab.url` NGAY tại đây — sớm hơn hẳn so với
                // đợi `onLocationChange` — đóng lỗ hổng thời gian đó lại
                // hoàn toàn cho MỌI đường điều hướng (kể cả bấm link trong
                // trang), không chỉ riêng đường gõ thanh địa chỉ.
                tabIdFor(session)?.let { tabMeta[it]?.url = request.uri }
                applyViewportExceptionForUrl(session, request.uri)
                return GeckoResult.allow()
            }

            override fun onLoadError(
                session: GeckoSession,
                uri: String?,
                error: WebRequestError
            ): GeckoResult<String>? {
                DebugLog.log("onLoadError: $uri — code=${error.code}")
                onPageErrorListener?.invoke(uri ?: "", error.code)
                return GeckoResult.fromValue(null)
            }

            override fun onLocationChange(
                session: GeckoSession,
                url: String?,
                perms: MutableList<GeckoSession.PermissionDelegate.ContentPermission>,
                hasUserGesture: Boolean
            ) {
                // GeckoSession không có property currentUri đọc đồng bộ — đây là
                // NGUỒN DUY NHẤT để biết URL hiện tại của 1 session, phải tự cache.
                if (url != null) {
                    tabIdFor(session)?.let { tabId ->
                        val previousUrl = tabMeta[tabId]?.url
                        // BUG THẬT (lịch sử phiên trước KỂ LẠI là đã sửa — "Tìm ra
                        // đúng lý do phải tự bấm nút mới có tác dụng... 7 tab khôi
                        // phục không hề đi qua onLoadRequest" — nhưng việc sửa đó
                        // KHÔNG hề có trong code thật, chỉ có trong lời kể, y hệt
                        // pattern của `manualDesktopTabIds`/`fp_lock` ở trên): tab
                        // khôi phục từ phiên trước (`restoreState()`) bắn
                        // `onLocationChange` chứ KHÔNG bắn `onLoadRequest` —
                        // `applyViewportExceptionForUrl()` trước đây CHỈ được gọi
                        // từ `onLoadRequest`, nên ngoại lệ tên miền (player desktop +
                        // layout mobile) không bao giờ được áp dụng cho 7 tab khôi
                        // phục cho tới khi người dùng tự ép tải lại. Gọi thêm ở đây,
                        // đúng như lời kể mô tả nhưng chưa từng có trong code.
                        val wasPendingRestore = pendingRestoreTabIds.contains(tabId)
                        pendingRestoreTabIds.remove(tabId) // có sự kiện điều hướng thật — restoreState() đã "làm gì đó"
                        tabMeta[tabId]?.url = url
                        if (wasPendingRestore) {
                            applyViewportExceptionForUrl(session, url)
                            session.reload() // áp settings mới có hiệu lực ngay cho trang vừa khôi phục, không cần đợi điều hướng kế tiếp
                        } else if (tabId == activeTabId && url != previousUrl) {
                            // BUG THẬT (người dùng báo: favicon vẫn xanh lè dù đã
                            // reload/mở tab mới; đồng thời chẩn đoán video YouTube
                            // KHÔNG BAO GIỜ chạy dù đã mở video thật — 2 triệu chứng
                            // tưởng KHÁC NHAU nhưng CÙNG 1 GỐC): YouTube là SPA —
                            // chuyển từ trang chủ/tìm kiếm sang 1 video cụ thể, hay
                            // chuyển bài trong playlist, KHÔNG tải trang mới (không
                            // bắn `onLoadRequest`/`onPageStop`) — chỉ đổi URL qua
                            // History API, chỉ bắn ĐÚNG sự kiện này. Trước đây
                            // `onPageLoadedListener` (nơi gọi `fetchFaviconForActiveTab`
                            // + chẩn đoán video ở `onPageStop`) chỉ được gọi từ
                            // `onPageStop` — nghĩa là mọi lần điều hướng KIỂU SPA
                            // (rất phổ biến ở YouTube/Colab/Drive) đều bị bỏ sót
                            // hoàn toàn, không chỉ favicon mà CẢ chẩn đoán video.
                            // Gọi lại đúng listener đó ở đây khi URL tab đang active
                            // thật sự đổi (so sánh với giá trị TRƯỚC đó, không phải
                            // đổi vì thêm tham số vô hại — vẫn chấp nhận gọi hơi dư
                            // còn hơn bỏ sót, vô hại vì các hàm downstream tự chống
                            // trùng lặp/có giới hạn thử lại riêng).
                            onPageLoadedListener?.invoke(url)
                            if (url.contains("youtube.com") && (url.contains("watch") || url.contains("/shorts/"))) {
                                pollVideoDiagnostic(tabId, url, attempt = 0)
                            }
                        }
                    }
                }
            }

            override fun onCanGoBack(session: GeckoSession, canGoBack: Boolean) {
                tabIdFor(session)?.let { tabMeta[it]?.canGoBack = canGoBack }
            }

            override fun onCanGoForward(session: GeckoSession, canGoForward: Boolean) {
                tabIdFor(session)?.let { tabMeta[it]?.canGoForward = canGoForward }
            }

            override fun onNewSession(
                session: GeckoSession,
                uri: String
            ): GeckoResult<GeckoSession> {
                DebugLog.log("onNewSession (popup): $uri")
                /**
                 * BUG THẬT đã sửa — nguyên nhân CHÍNH XÁC của lỗi
                 * "MessageError: Error: credential propagation was
                 * unsuccessful" khi chạy `drive.mount()` trong Colab: hàm
                 * này TRƯỚC ĐÂY trả về `null` — theo đúng tài liệu
                 * GeckoView, `onNewSession` trả `null` nghĩa là TỪ CHỐI
                 * popup hẳn, JS gọi `window.open()` nhận về KHÔNG có cửa sổ
                 * thật nào cả. Popup xác thực Google Colab mở ra để đăng
                 * nhập cần gửi thông tin đăng nhập NGƯỢC LẠI tab chính qua
                 * `window.opener`/`postMessage` — không có cửa sổ thật thì
                 * không có `window.opener`, việc "propagate credential" chắc
                 * chắn thất bại, đúng y hệt lỗi gặp phải.
                 *
                 * Sửa: tạo 1 `GeckoSession` THẬT cho popup, thêm vào danh
                 * sách tab của chính khe này (người dùng thấy/tương tác
                 * được, vd trang đăng nhập Google) — TRẢ VỀ session đó thay
                 * vì `null`, để `window.open()` phía JS nhận cửa sổ thật,
                 * `window.opener` hoạt động đúng — giống hệt cách
                 * Chrome/Firefox xử lý popup.
                 */
                val popupTabId = UUID.randomUUID().toString()
                // FIX BUG THẬT (người dùng báo): ghi lại đúng tab ĐANG MỞ
                // (activeTabId lúc này chính là tab gốc gọi window.open())
                // để dùng khi đóng popup sau này — xem closeTab().
                val openerTabIdSnapshot = activeTabId
                // BUG THẬT đã sửa (crash log xác nhận): "Must use an
                // unopened GeckoSession instance" — GeckoView tự MỞ session
                // trả về từ onNewSession, không được mở sẵn trước khi trả
                // về (khác hẳn tab thường, nơi TA tự mở). Dùng
                // createSessionUnopened() (không gọi session.open()), KHÔNG
                // dùng createSession() (có gọi open(), gây crash đúng như
                // log).
                val popupSession = createSessionUnopened()
                val popupTab = BrowserTab(id = popupTabId, url = uri, openerTabId = openerTabIdSnapshot)
                tabs[popupTabId] = popupSession
                tabMeta[popupTabId] = popupTab
                tabOrder.add(popupTabId)
                handler.post {
                    switchToTab(popupTabId)
                    onNewTabRequestedListener?.invoke(uri)
                }
                return GeckoResult.fromValue(popupSession)
            }
        }

        session.contentDelegate = object : GeckoSession.ContentDelegate {
            override fun onTitleChange(session: GeckoSession, title: String?) {
                title?.let {
                    val tabId = tabIdFor(session)
                    tabId?.let { id -> tabMeta[id]?.title = it }
                    if (tabId == activeTabId) onTitleChangedListener?.invoke(it)
                }
            }

            /**
             * FIX BUG THẬT (xác nhận qua đọc code — hàm này CHƯA TỪNG được
             * override, đối chiếu javadoc chính thức Mozilla:
             * "A page has entered or exited full screen mode. Typically,
             * the implementation would set the Activity containing the
             * GeckoSession to full screen when the page is in full screen
             * mode." — tức đây là nơi BẮT BUỘC phải tự ẩn UI trình duyệt
             * (thanh URL, dải tab), không phải GeckoView tự làm giúp).
             * Người dùng báo: nhấn nút toàn màn hình trên player thì hình
             * bị "vướng url" — đúng như dự đoán, vì trước đây app không hề
             * biết trang đã vào fullscreen để ẩn UI của chính mình đi.
             *
             * Chỉ xử lý cho tab ĐANG ACTIVE — tab nền vào/ra fullscreen (dù
             * hiếm khi xảy ra) không nên ảnh hưởng UI tab đang xem.
             */
            override fun onFullScreen(session: GeckoSession, fullScreen: Boolean) {
                val tabId = tabIdFor(session) ?: return
                if (tabId != activeTabId) return
                // FIX PHỐI HỢP: cơ chế zoom (applyZoomCombined(), giờ dùng
                // meta[name=viewport] — xem mục 59 PROJECT_STATUS.md) KHÔNG
                // được trình duyệt tự động vô hiệu hoá khi 1 phần tử vào
                // Fullscreen API — 2 cơ chế này chạy độc lập, chồng lên
                // nhau. Zoom < 1.0 (thu nhỏ layout desktop) làm player
                // fullscreen bị co lại sai kích thước thay vì phủ kín màn
                // hình thật ("vướng url" người dùng mô tả — thực ra là toàn
                // bộ trang, kể cả URL bar co theo scale cũ, không phải video
                // kẹt ở URL). Sửa: tắt hẳn zoom khi vào fullscreen (xoá thẻ
                // meta viewport do app tạo, giống nhánh finalScale=1.0 của
                // applyZoomCombined), tự tính lại đúng zoom khi thoát (gọi
                // lại applyZoomCombined gián tiếp qua onFullScreenListener
                // bên MainActivity).
                val script = if (fullScreen) {
                    """
                    (function() {
                        var meta = document.querySelector('meta[name="viewport"][data-colablive-zoom="1"]');
                        if (meta) { meta.parentNode.removeChild(meta); }
                    })();
                    """.trimIndent()
                } else {
                    null // khôi phục zoom xử lý ở MainActivity qua onFullScreenListener → reapplyManualZoom lại
                }
                script?.let { evaluateJsForTab(tabId, it, null) }
                onFullScreenListener?.invoke(fullScreen)
            }

            override fun onContextMenu(
                session: GeckoSession,
                screenX: Int,
                screenY: Int,
                element: GeckoSession.ContentDelegate.ContextElement
            ) {
                // BỔ SUNG CHẨN ĐOÁN (mục 66 PROJECT_STATUS.md — long-press
                // vào cell Colab KHÔNG PHẢN ỨNG GÌ trên GeckoView, trong khi
                // Chrome cùng vị trí vẫn hiện được menu). Trước đây hàm này
                // CHỈ log khi có `linkUri` — với text thường trong Colab,
                // `linkUri` luôn null nên KHÔNG CÓ DÒNG LOG NÀO xuất hiện dù
                // `onContextMenu` có được gọi hay không, khiến không thể
                // phân biệt 2 khả năng hoàn toàn khác nhau: (a) long-press
                // không tới được Gecko ở tầng thấp hơn cả `onContextMenu`
                // (touch bị chặn/lệch toạ độ trước khi Gecko kịp xử lý), hay
                // (b) `onContextMenu` CÓ được gọi đúng (long-press tới được
                // Gecko) nhưng `onShowActionRequest`/selection lại không bao
                // giờ theo sau — tức 2 pipeline độc lập, vấn đề nằm ở khâu
                // sau, không phải touch bị chặn từ đầu.
                //
                // Log VÔ ĐIỀU KIỆN (bỏ if linkUri) để lần tới người dùng chỉ
                // cần long-press 1 lần vào đúng cell Colab và gửi log, không
                // cần tự thử tắt/bật desktop mode hay làm gì thêm — đối
                // chiếu trực tiếp dòng log này với có/không có dòng
                // "[CHẨN ĐOÁN selection] onShowActionRequest" theo sau trong
                // vòng ~1 giây sẽ trả lời dứt điểm (a) hay (b) ở trên.
                DebugLog.log(
                    "Khe $slotIndex: [CHẨN ĐOÁN context-menu] onContextMenu " +
                    "screenX=$screenX screenY=$screenY " +
                    "linkUri=${element.linkUri ?: "(không có)"} " +
                    "type=${element.type} " +
                    "srcUri=${element.srcUri ?: "(không có)"} — " +
                    "nếu KHÔNG có dòng '[CHẨN ĐOÁN selection] onShowActionRequest' " +
                    "xuất hiện ngay sau dòng này, xác nhận 2 pipeline tách rời " +
                    "(onContextMenu tới được nhưng selection không theo sau); " +
                    "nếu KHÔNG THẤY dòng NÀY xuất hiện dù đã long-press, xác nhận " +
                    "long-press không tới được Gecko ở tầng thấp hơn (khớp giả " +
                    "thuyết hit-test lệch do zoom/desktop-viewport, mục 66)"
                )
                val linkUri = element.linkUri
                if (!linkUri.isNullOrBlank()) {
                    handler.post { onLongPressLinkListener?.invoke(linkUri, element.title) }
                }
            }

            // Chữ ký thật: (session, response: WebResponse) — response.uri là
            // property của WebMessage (lớp cha của WebResponse), KHÔNG có class
            // lồng "GeckoSession.WebResponseInfo" (không tồn tại, code cũ đoán sai).
            //
            // BUG THẬT (xác nhận qua ảnh chụp màn hình người dùng gửi — dialog
            // "Tải File" cho link Google Drive `.../download?id=...&export=
            // download&...` ra tên file y hệt `download?id=1ZbY4NJ2I-jHri6xr...`):
            // code cũ dùng `uri.substringAfterLast("/")` — KHÔNG cắt bỏ phần
            // `?query` trước khi lấy đoạn cuối URL, nên với URL dạng
            // `.../download?id=...` (không có dấu "/" nào sau "download") thì
            // TOÀN BỘ query string (`download?id=...&export=...&uuid=...`) bị
            // lấy làm tên file. Đồng thời bỏ qua hẳn header `Content-Disposition`
            // mà server tải file (Google Drive, v.v.) chắc chắn có gửi kèm tên
            // file THẬT. Sửa đúng gốc: dùng `URLUtil.guessFileName(uri,
            // contentDisposition, mimeType)` — hàm chuẩn của Android, tự ưu
            // tiên đọc `Content-Disposition` trước, chỉ mới cắt query string
            // khỏi URL khi fallback (không phải bỏ qua như code cũ).
            // TÍNH NĂNG MỚI (người dùng hỏi: "cài extension từ URL có làm
            // giống Firefox/Chrome — vào trang store rồi tải về dùng được
            // không?"). Trước đây chỉ có đường "dán URL .xpi trực tiếp"
            // (`installAddonFromUrl` ở MainActivity) — không bắt được lúc
            // người dùng duyệt bình thường tới addons.mozilla.org rồi bấm
            // "Thêm vào Firefox" (nút đó chỉ là 1 link trỏ thẳng file .xpi,
            // Content-Type "application/x-xpinstall" — Firefox thật chặn
            // NGAY bằng Content-Type/đuôi file tại đây, không tải xuống như
            // file thường). Vì đây LÀ addon từ addons.mozilla.org (đã được
            // Mozilla ký) nên đúng loại DUY NHẤT Gecko Release chấp nhận
            // cài — xem giải thích đầy đủ ở
            // `MainActivity.showAddonManagerDialog()`. Bắt SỚM ở đây, trước
            // khi rơi vào toàn bộ máy tải-file-thông-thường bên dưới.
            override fun onExternalResponse(session: GeckoSession, response: WebResponse) {
                val uri = response.uri
                val headers = response.headers
                val contentType0 = headers?.entries?.firstOrNull {
                    it.key.equals("content-type", ignoreCase = true)
                }?.value
                val isXpi = contentType0?.contains("x-xpinstall", ignoreCase = true) == true ||
                    uri.substringBefore("?").endsWith(".xpi", ignoreCase = true)
                if (isXpi) {
                    handleExtensionDownloadResponse(uri, response.body)
                    return
                }
                val contentDisposition = headers?.entries?.firstOrNull {
                    it.key.equals("content-disposition", ignoreCase = true)
                }?.value
                val contentType = headers?.entries?.firstOrNull {
                    it.key.equals("content-type", ignoreCase = true)
                }?.value
                val fileName = extractFileNameFromResponse(uri, contentDisposition, contentType)

                // Xem chú thích lớn ở khai báo `onDownloadBodyReadyListener`
                // phía trên — nếu response.body có sẵn (thường có, per
                // javadoc "if available"), drain NGAY LẬP TỨC vào file tạm
                // trên nền, KHÔNG chờ người dùng tương tác dialog "ASK" nào
                // (tránh timeout đọc mặc định 30s của chính stream này) —
                // xong thì báo listener kèm đường dẫn file tạm đã có đủ
                // byte thật. Nếu body null (hiếm, hoặc trường hợp không đi
                // qua onExternalResponse), fallback về listener cũ (tải lại
                // qua OkHttp — vẫn đúng cho file CÔNG KHAI như trước giờ).
                val body = response.body
                if (body != null && onDownloadBodyReadyListener != null) {
                    // Bắn NGAY (trước khi Thread drain bắt đầu) — xem chú
                    // thích ở khai báo `onDownloadStartedListener`. Post lên
                    // main thread vì đang chạy trong callback GeckoView.
                    handler.post {
                        onDownloadStartedListener?.invoke(uri, fileName)
                    }
                    Thread {
                        var tempFile: java.io.File? = null
                        // BUG THẬT đã tìm ra (người dùng báo: "cái download
                        // thì là do down ngầm, lúc đó ko hiển thị, tải xong
                        // mới hiển thị... là do tải ngầm lúc đó (cái này là
                        // bug)"): toàn bộ quá trình drain này (bắt buộc phải
                        // làm NGẦM ở đây, vì cần cookie phiên thật mà chỉ
                        // chính GeckoView đang giữ — không thể hỏi người
                        // dùng TRƯỚC khi tải như luồng URL thường, đây là
                        // giới hạn kiến trúc thật, không tránh được) trước
                        // giờ HOÀN TOÀN IM LẶNG — không progress, không
                        // thông báo gì — với file lớn (VD 692MB thấy trong
                        // log thật) có thể mất hàng chục giây tới vài phút
                        // im lặng tuyệt đối, đúng cảm giác "không phản ứng
                        // gì". Không thể tránh việc tải-ngầm-trước (giới hạn
                        // kiến trúc), nhưng CÓ THỂ và NÊN báo tiến độ ngay
                        // trong lúc tải, thay vì im lặng rồi bất ngờ hiện
                        // dialog chọn nơi lưu sau khi đã xong hết.
                        val nm = context.getSystemService(android.app.NotificationManager::class.java)
                        val progressChannelId = "live_browser_dl_progress"
                        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                            nm.createNotificationChannel(
                                android.app.NotificationChannel(
                                    progressChannelId, "Đang tải xuống (nền)",
                                    android.app.NotificationManager.IMPORTANCE_LOW
                                ).apply { setShowBadge(false) }
                            )
                        }
                        val progressNotifId = 4000 + slotIndex
                        val contentLength = headers?.entries?.firstOrNull {
                            it.key.equals("content-length", ignoreCase = true)
                        }?.value?.toLongOrNull() ?: -1L
                        fun postProgress(doneBytes: Long, finished: Boolean) {
                            val builder = android.app.Notification.Builder(context, progressChannelId)
                                .setContentTitle(if (finished) "Đã tải xong (đang chờ chọn nơi lưu)" else "Đang tải xuống: $fileName")
                                .setSmallIcon(android.R.drawable.stat_sys_download)
                                .setOngoing(!finished)
                            if (contentLength > 0) {
                                builder.setProgress(100, ((doneBytes * 100) / contentLength).toInt(), false)
                                builder.setContentText("${doneBytes / 1024 / 1024}MB / ${contentLength / 1024 / 1024}MB")
                            } else {
                                builder.setProgress(0, 0, !finished)
                                builder.setContentText("${doneBytes / 1024 / 1024}MB")
                            }
                            try { nm.notify(progressNotifId, builder.build()) } catch (e: Exception) { /* không nghiêm trọng, bỏ qua */ }
                        }
                        try {
                            val tempDir = java.io.File(context.cacheDir, "download_body_tmp").apply { mkdirs() }
                            tempFile = java.io.File(tempDir, "body_${System.currentTimeMillis()}_$fileName")
                            postProgress(0, false)
                            body.use { input ->
                                tempFile!!.outputStream().use { output ->
                                    val buffer = ByteArray(64 * 1024)
                                    var totalRead = 0L
                                    var lastPosted = 0L
                                    while (true) {
                                        val read = input.read(buffer)
                                        if (read < 0) break
                                        output.write(buffer, 0, read)
                                        totalRead += read
                                        // Chỉ cập nhật notification mỗi ~1MB — cập
                                        // nhật MỖI lần đọc (64KB) sẽ spam
                                        // NotificationManager, có thể bị hệ
                                        // thống rate-limit hoặc tốn pin vô ích.
                                        if (totalRead - lastPosted >= 1_000_000L) {
                                            postProgress(totalRead, false)
                                            lastPosted = totalRead
                                        }
                                    }
                                }
                            }
                            nm.cancel(progressNotifId)
                            DebugLog.log("Khe $slotIndex: đã drain response.body (${tempFile.length()} byte, CÓ cookie phiên thật vì chính GeckoView tải) vào file tạm cho $fileName")
                            val finalTempFile = tempFile
                            // CRASH THẬT tự gây ra, đã xác nhận qua log
                            // ("Can't toast on a thread that has not called
                            // Looper.prepare()" — crash cả app): quên đúng
                            // quy ước ĐÃ CÓ SẴN trong chính dự án này
                            // (`handler.post { ... }` dùng ở onLongPressLink
                            // ngay phía trên, dòng ~1502) — gọi thẳng listener
                            // từ Thread nền, mà listener (qua
                            // startDownloadWithPolicy) có Toast.makeText()
                            // KHÔNG bọc runOnUiThread, luôn giả định chạy main
                            // thread. Sửa: post lên `handler` (main thread)
                            // TRƯỚC khi gọi listener, đúng y hệt pattern có
                            // sẵn — không viết cách mới, dùng lại cách đã có.
                            handler.post {
                                onDownloadBodyReadyListener?.invoke(uri, fileName, finalTempFile?.absolutePath)
                            }
                        } catch (e: Exception) {
                            nm.cancel(progressNotifId)
                            DebugLog.log("Khe $slotIndex: drain response.body lỗi (${e.message}) — fallback về tải lại qua OkHttp (KHÔNG có cookie, chỉ đúng cho file công khai)")
                            tempFile?.delete()
                            handler.post {
                                onDownloadRequestedListener?.invoke(uri, fileName)
                            }
                        }
                    }.start()
                } else {
                    onDownloadRequestedListener?.invoke(uri, fileName)
                }
            }

            override fun onCrash(session: GeckoSession) {
                DebugLog.log("Session crashed!")
                recoverKilledOrCrashedSession(session, wasCrash = true)
            }

            override fun onKill(session: GeckoSession) {
                DebugLog.log("Session killed by system")
                recoverKilledOrCrashedSession(session, wasCrash = false)
            }

            /**
             * CÔNG CỤ CHẨN ĐOÁN MỚI (người dùng báo bug thật: dán 1 lượng
             * text lớn vào cell Colab làm trang đơ hoàn toàn, phải reload
             * mới hết — Chrome cùng thao tác vẫn bình thường). Đã tra cứu
             * mọi hướng có bằng chứng code (hàng đợi `evalCallbacks` đã có
             * timeout 15s tự dọn từ trước — không phải nguyên nhân; không
             * có pref nào ép tắt GPU/layer acceleration ảnh hưởng hiệu năng
             * chung — không tìm thấy). KHÔNG tìm được bằng chứng CODE APP
             * nào gây ra — nghi vấn cao nhất còn lại là JS thread CỦA
             * CHÍNH TRANG (CodeMirror re-tokenize/highlight khối lượng lớn
             * text vừa dán) bị chặn bên trong Gecko, đây là hành vi CỦA
             * ENGINE, không phải app.
             *
             * `onSlowScript()` là delegate CÓ SẴN của GeckoView, TRƯỚC ĐÂY
             * CHƯA từng implement — đây chính là cách CHÍNH THỨC GeckoView
             * dùng để báo "trang có script chạy quá lâu không nhường CPU"
             * (tương đương "trang không phản hồi" của Chrome). Thêm vào
             * đây để lần tới bug này xảy ra, log sẽ cho biết CHẮC CHẮN: có
             * dòng "[CHẨN ĐOÁN slow script]" xuất hiện đúng lúc đơ hay
             * không — CÓ nghĩa là xác nhận 100% đây là giới hạn tầng Gecko
             * (không phải bug code app, không có cách sửa từ phía Kotlin);
             * KHÔNG CÓ nghĩa là loại trừ khả năng đó, cần điều tra hướng
             * khác (IPC/eval_bridge deadlock, hoặc thứ gì đó khác hẳn).
             * Trả về CONTINUE (không tự ý dừng script của người dùng) —
             * chỉ để CHẨN ĐOÁN, chưa vội "sửa" bằng cách ngắt trang khi
             * chưa chắc đó có phải nguyên nhân hay không.
             */
            override fun onSlowScript(
                session: GeckoSession,
                scriptFileName: String
            ): GeckoResult<SlowScriptResponse>? {
                DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN slow script] Gecko báo script CHẠY QUÁ LÂU không nhường CPU — scriptFileName=$scriptFileName (nếu dòng này xuất hiện đúng lúc trang đơ sau khi dán text lớn, XÁC NHẬN chắc chắn đây là giới hạn tầng Gecko/JS engine, không phải bug code app — xem PROJECT_STATUS.md)")
                return GeckoResult.fromValue(SlowScriptResponse.CONTINUE)
            }
        }

        // BUG THẬT (nguyên nhân YT Khe 1 spinner mãi không play): GeckoView
        // KHÔNG tự grant content permission nếu không có `permissionDelegate`
        // — mặc định từ chối HẾT, bao gồm cả AUTOPLAY permission. Khe 1 dùng
        // UA desktop + viewport desktop → YouTube trả trang desktop → player
        // desktop trigger autoplay policy NGHIÊM HƠN của Gecko so với bản
        // mobile (bản mobile có nhiều fallback, bản desktop player đúng nghĩa
        // phụ thuộc autoplay grant). Khe 0 (bản mobile) thoát được vì Gecko
        // có ngoại lệ cho user-initiated navigation với bản mobile YouTube.
        //
        // Sửa: set permissionDelegate tự grant AUTOPLAY và các content
        // permission vô hại khác (geolocation/camera/mic vẫn từ chối — đây
        // là app browser thật, không phải kiosk, không nên auto-grant cảm
        // biến nhạy cảm). API: `onContentPermissionRequest` trả về
        // `GeckoResult.allow()` để grant, `GeckoResult.deny()` để từ chối.
        // CHẨN ĐOÁN (bug "chọn văn bản thường không thấy bôi đen" — mục
        // 23.2/24.1 PROJECT_STATUS.md). Trước đây app KHÔNG có
        // `selectionActionDelegate` — nghĩa là GeckoView tự dùng
        // `BasicSelectionActionDelegate` MẶC ĐỊNH của chính nó (xác nhận
        // qua javadoc chính thức: "This class is used by GeckoView by
        // default if the consumer does not explicitly set a
        // SelectionActionDelegate" — đây CHÍNH LÀ thứ vẽ toolbar "Sao
        // chép/Chọn tất cả/Đọc to" mà người dùng đã thấy trước đây).
        //
        // BUG NGHIÊM TRỌNG TỰ GÂY RA Ở LƯỢT TRƯỚC (đã sửa): lượt trước tôi
        // gán thẳng 1 object tự chế CHỈ LOG, KHÔNG VẼ GÌ, làm
        // `session.selectionActionDelegate` — theo đúng cơ chế Android/
        // GeckoView, làm vậy THAY THẾ HOÀN TOÀN `BasicSelectionActionDelegate`
        // mặc định, không còn ai vẽ toolbar nữa → mất luôn cả Sao chép/Dán/
        // Chọn tất cả (không chỉ mất highlight như bug gốc) — đúng khớp
        // triệu chứng người dùng vừa báo. Đây là lỗi tự gây ra do hiểu sai
        // hành vi delegate, không phải bug có sẵn.
        //
        // SỬA ĐÚNG theo pattern CHÍNH THỨC Mozilla khuyến nghị trong chính
        // javadoc của `BasicSelectionActionDelegate` ("To provide custom
        // actions, extend this class"): KẾ THỪA thay vì THAY THẾ — override
        // 2 hàm chỉ để ghi log chẩn đoán, gọi `super.onShowActionRequest()`/
        // `super.onHideAction()` NGAY SAU ĐÓ để toàn bộ hành vi vẽ toolbar
        // mặc định (bao gồm Sao chép/Dán/Chọn tất cả) hoạt động Y HỆT như
        // lúc chưa có delegate tự chế nào — không "cướp" trách nhiệm hiển
        // thị UI khỏi GeckoView nữa, chỉ "nghe lén" thêm để lấy log.
        // `context` truyền vào `GeckoViewEngine` chính là `MainActivity`
        // (xem `MainActivity`: `GeckoViewEngine(this, geckoView, slotIndex)`)
        // — đủ điều kiện `Activity` mà constructor của
        // `BasicSelectionActionDelegate` yêu cầu.
        //
        // CHƯA build/test — vẫn cần người dùng gửi lại dòng log
        // "[CHẨN ĐOÁN selection]" lần tới để biết `screenRect` có null hay
        // không, xác định bug bôi đen nằm ở tầng model hay tầng vẽ. Đồng
        // thời xác nhận GIÙM: sau bản vá này, Sao chép/Dán/Chọn tất cả đã
        // có lại chưa (phải có — đây là hồi quy chắc chắn phải hết hoàn
        // toàn, không phải giả thuyết).
        session.selectionActionDelegate = object : BasicSelectionActionDelegate(context as android.app.Activity) {
            override fun onShowActionRequest(
                session: GeckoSession,
                selection: GeckoSession.SelectionActionDelegate.Selection
            ) {
                val rect = selection.screenRect
                DebugLog.log(
                    "Khe $slotIndex: [CHẨN ĐOÁN selection] onShowActionRequest — " +
                    "text.length=${selection.text.length}, " +
                    "screenRect=${if (rect == null) "NULL (Gecko không có toạ độ hình học cho selection này)" else "$rect"}, " +
                    "flags=${selection.flags}"
                )
                super.onShowActionRequest(session, selection)
            }

            override fun onHideAction(session: GeckoSession, reason: Int) {
                DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN selection] onHideAction — reason=$reason")
                super.onHideAction(session, reason)
            }

            /**
             * FIX BUG THẬT (người dùng báo: "dán text lớn từ khe nhớ tạm
             * vào cell Colab không phản ứng"). Tra cứu xác nhận qua chính
             * mã nguồn `BasicSelectionActionDelegate` (searchfox.org) +
             * changelog GeckoView (bug 1776829): từ 1 bản GeckoView nhất
             * định, MỌI lần trang gọi `navigator.clipboard.readText()`
             * (cách các trình soạn thảo kiểu CodeMirror — Colab dùng loại
             * này — thường xử lý dán, KHÁC với dán vào 1 ô `<input>` thường
             * qua context menu OS) đều phải xin quyền qua đúng callback
             * này trước. `BasicSelectionActionDelegate` (class app đang kế
             * thừa) mặc định xử lý bằng cách tự vẽ 1 THANH CÔNG CỤ NỔI
             * (`ActionMode` kiểu floating) yêu cầu người dùng CHẠM VÀO để
             * cấp quyền — rất có khả năng thanh này bị layout toàn màn
             * hình/immersive-mode của app (xem log "insets đổi" dày đặc
             * xuyên suốt session) che khuất hoặc định vị sai, khiến người
             * dùng không thấy gì để bấm — "không phản ứng" đúng là cảm
             * giác khi 1 UI cần bấm nhưng không hiển thị được, không phải
             * do bản thân việc dán bị chặn cứng.
             *
             * Sửa: ghi đè trực tiếp, tự động CHO PHÉP luôn — không cần vẽ
             * UI xin phép nào cả. An toàn cho app này (trình duyệt cá nhân
             * 1 người dùng, không phải trình duyệt công cộng nhiều người
             * dùng chung — đây cũng chính là lý do các quyền khác trong
             * app (vd `contentPermission=4/5 → ALLOW` thấy trong log) đã
             * được tự động cấp sẵn theo cùng tinh thần, không riêng gì
             * chỗ này).
             */
            override fun onShowClipboardPermissionRequest(
                session: GeckoSession,
                permission: GeckoSession.SelectionActionDelegate.ClipboardPermission
            ): org.mozilla.geckoview.GeckoResult<org.mozilla.geckoview.AllowOrDeny> {
                DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN clipboard] onShowClipboardPermissionRequest — tự động ALLOW luôn, không vẽ UI xin phép")
                return org.mozilla.geckoview.GeckoResult.fromValue(org.mozilla.geckoview.AllowOrDeny.ALLOW)
            }
        }

        session.permissionDelegate = object : GeckoSession.PermissionDelegate {
            override fun onContentPermissionRequest(
                session: GeckoSession,
                perm: GeckoSession.PermissionDelegate.ContentPermission
            ): GeckoResult<Int> {
                return when (perm.permission) {
                    // AUTOPLAY: grant cả audio lẫn video — đây là nguyên nhân
                    // chính spinner YouTube Khe 1. Không có grant này, Gecko
                    // chặn media element tự play() khi không có user gesture
                    // (đúng spec W3C Autoplay Policy, Gecko tuân thủ nghiêm).
                    GeckoSession.PermissionDelegate.PERMISSION_AUTOPLAY_AUDIBLE,
                    GeckoSession.PermissionDelegate.PERMISSION_AUTOPLAY_INAUDIBLE ->
                        GeckoResult.fromValue(GeckoSession.PermissionDelegate.ContentPermission.VALUE_ALLOW)

                    // DESKTOP NOTIFICATION: grant để không bị hỏi popup xin
                    // phép liên tục (YouTube, Google Meet hay hỏi).
                    GeckoSession.PermissionDelegate.PERMISSION_DESKTOP_NOTIFICATION ->
                        GeckoResult.fromValue(GeckoSession.PermissionDelegate.ContentPermission.VALUE_ALLOW)

                    // GEOLOCATION / CAMERA / MIC: từ chối — app browser thật,
                    // không auto-grant cảm biến nhạy cảm không cần thiết.
                    else ->
                        GeckoResult.fromValue(GeckoSession.PermissionDelegate.ContentPermission.VALUE_DENY)
                }.also {
                    DebugLog.log("Khe $slotIndex: contentPermission=${perm.permission} uri=${perm.uri} → ${
                        when (perm.permission) {
                            GeckoSession.PermissionDelegate.PERMISSION_AUTOPLAY_AUDIBLE,
                            GeckoSession.PermissionDelegate.PERMISSION_AUTOPLAY_INAUDIBLE,
                            GeckoSession.PermissionDelegate.PERMISSION_DESKTOP_NOTIFICATION -> "ALLOW"
                            else -> "DENY"
                        }
                    }")
                }
            }
        }

        // onFilePrompt KHÔNG thuộc ContentDelegate (code cũ đặt sai chỗ, kèm
        // theo 1 "FileCallback" không tồn tại) — API thật nằm ở PromptDelegate,
        // nhận 1 đối tượng FilePrompt và trả về GeckoResult<PromptResponse>
        // ĐANG CHỜ (chưa hoàn thành ngay, vì việc chọn file thật xảy ra bất
        // đồng bộ qua Activity chọn file của Android) — MainActivity gọi lại
        // `resolveFilePrompt()` khi người dùng đã chọn xong để hoàn thành nó.
        session.promptDelegate = object : GeckoSession.PromptDelegate {
            override fun onFilePrompt(
                session: GeckoSession,
                prompt: GeckoSession.PromptDelegate.FilePrompt
            ): GeckoResult<GeckoSession.PromptDelegate.PromptResponse>? {
                DebugLog.log("onFilePrompt: mimeTypes=${prompt.mimeTypes?.joinToString()} type=${prompt.type} (MULTIPLE=${GeckoSession.PromptDelegate.FilePrompt.Type.MULTIPLE})")
                val fixedMimeTypes = prompt.mimeTypes?.map { mime ->
                    if (mime.contains("/")) mime else "*/*"
                }?.toTypedArray()
                pendingFilePrompt = prompt
                val result = GeckoResult<GeckoSession.PromptDelegate.PromptResponse>()
                pendingFilePromptResult = result
                onFilePromptListener?.invoke(fixedMimeTypes, prompt.type == GeckoSession.PromptDelegate.FilePrompt.Type.MULTIPLE)
                return result
            }
        }

        /**
         * NÚT PLAY/PAUSE THẬT TRÊN THÔNG BÁO — đã TRA ĐƯỢC API chính xác từ
         * code mẫu CHÍNH THỨC của Mozilla (GeckoViewActivity.java, ứng dụng
         * mẫu đi kèm GeckoView), không còn đoán. Xác nhận: `GeckoSession` có
         * property `mediaSessionDelegate` nhận 1
         * `MediaSession.Delegate` với `onPlay(session, mediaSession)`/
         * `onPause(...)`/`onStop(...)` — đối tượng `mediaSession` truyền vào
         * có `.play()`/`.pause()`/`.stop()` để ĐIỀU KHIỂN NGƯỢC LẠI (dùng khi
         * người dùng bấm nút trên thông báo).
         *
         * Bọc vào `android.media.session.MediaSession` CHUẨN của Android
         * (API nền tảng có sẵn, không cần thêm thư viện) — để hệ thống
         * (thông báo, màn hình khoá) biết và điều khiển được, giống hệt
         * cách mọi app nhạc/video làm.
         *
         * TÌM RA NGUYÊN NHÂN THẬT SỰ của việc mất nhạc nền (sau rất nhiều lần
         * sửa sai hướng trước đây — xem PROJECT_STATUS.md mục 8zb/8zd/8zh):
         * đọc tài liệu kiến trúc CHÍNH THỨC của Mozilla
         * (firefox-source-docs.mozilla.org/mobile/android/geckoview/
         * contributor/geckoview-architecture.html, mục "Priority Hint") xác
         * nhận: GeckoView TỰ GẮN độ ưu tiên tiến trình của 1 session với
         * việc session đó CÒN SURFACE (còn hiển thị) hay không — khi Activity
         * xuống nền, surface bị Android tự thu hồi, GeckoView tự hạ độ ưu
         * tiên tiến trình của CHÍNH GeckoSession đó (không liên quan gì đến
         * tiến trình chính/`KeepAliveService` — đó là tiến trình con RIÊNG
         * của Gecko, `KeepAliveService` không bảo vệ được nó). Tài liệu ghi
         * rõ đây CHÍNH LÀ tình huống "phát nhạc nền" — và cung cấp sẵn API
         * chính thức để xử lý: `GeckoSession.setPriorityHint(int)` — báo cho
         * GeckoView biết "session này quan trọng, giữ ưu tiên cao dù mất
         * surface". Gọi `PRIORITY_HIGH` khi có media đang phát, trả lại
         * `PRIORITY_DEFAULT` khi dừng hẳn — không giữ `PRIORITY_HIGH` mãi để
         * tránh tốn tài nguyên không cần thiết cho tab không phát gì.
         */
        session.mediaSessionDelegate = object : MediaSession.Delegate {
            override fun onPlay(session: GeckoSession, mediaSession: MediaSession) {
                DebugLog.log("Khe $slotIndex: MediaSession onPlay")
                currentGeckoMediaSession = mediaSession
                currentGeckoMediaSessionTabId = tabIdFor(session)
                // FIX BUG THẬT (người dùng báo đúng: "YouTube không ghim
                // chạy nền mà vẫn chạy nền khi không hiện tab trên màn
                // hình" — đã xác nhận qua đọc lại chính code này, không
                // phải suy đoán): dòng `setPriorityHint(PRIORITY_HIGH)`
                // BẢN CŨ gọi VÔ ĐIỀU KIỆN cho MỌI tab hễ có media bắt đầu
                // phát — hoàn toàn KHÔNG kiểm tra domain đó có nằm trong
                // danh sách ghim (`isBackgroundKeepAliveExemptUrl`,
                // `BackgroundKeepAliveFeature`) hay không. Theo đúng chú
                // thích gốc ngay phía trên (mục "TÌM RA NGUYÊN NHÂN THẬT
                // SỰ của việc mất nhạc nền"), `setPriorityHint(PRIORITY_
                // HIGH)` CHÍNH LÀ cơ chế báo GeckoView "giữ ưu tiên tiến
                // trình cao dù mất surface" — tức là cơ chế THẬT SỰ cho
                // chạy nền. Gọi vô điều kiện = MỌI tab đang phát media đều
                // được chạy nền thật, bất kể có ghim hay không — đúng
                // khớp triệu chứng người dùng báo (YouTube không ghim vẫn
                // chạy nền). SỬA: chỉ boost PRIORITY_HIGH nếu domain của
                // TAB ĐANG PHÁT nằm trong danh sách ghim — dùng lại đúng
                // hàm kiểm tra `isBackgroundKeepAliveExemptUrl()` đã có
                // sẵn (cùng hàm `switchToTab()` dùng), không phát minh cơ
                // chế mới. Tab KHÔNG ghim mà đang là tab ĐANG HIỂN THỊ vẫn
                // không cần boost (đã có ưu tiên tự nhiên vì đang active);
                // khi tab đó bị chuyển đi nền (switchToTab gọi
                // `setActive(false)`), sẽ đúng bị hạ cấp như Chrome thật —
                // không còn "chạy nền lậu" ngoài ý người dùng nữa.
                val tabUrl = tabIdFor(session)?.let { tabMeta[it]?.url }
                val exempt = tabUrl != null && isBackgroundKeepAliveExemptUrl(tabUrl)
                if (exempt) {
                    session.setPriorityHint(GeckoSession.PRIORITY_HIGH)
                } else {
                    DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN keepalive nền] tab đang phát media KHÔNG nằm trong danh sách ghim (url=$tabUrl) — KHÔNG boost PRIORITY_HIGH, để tab bị hạ cấp bình thường khi chuyển đi nền (đúng ý người dùng: không ghim thì không chạy nền)")
                }
                requestNonExclusiveAudioFocus()
                updateNativeMediaSession(true)
            }

            override fun onPause(session: GeckoSession, mediaSession: MediaSession) {
                DebugLog.log("Khe $slotIndex: MediaSession onPause")
                // Không hạ nhầm nếu chính tab này đang được Auto Behavior
                // giữ PRIORITY_HIGH vì lý do khác (xem startAutoBehavior) —
                // 2 cơ chế độc lập cùng có thể muốn giữ ưu tiên cao cho
                // CÙNG 1 tab, chỉ hạ khi KHÔNG còn lý do nào giữ nữa.
                if (tabIdFor(session) != autoBehaviorPriorityTabId) {
                    session.setPriorityHint(GeckoSession.PRIORITY_DEFAULT)
                }
                updateNativeMediaSession(false)
            }

            override fun onStop(session: GeckoSession, mediaSession: MediaSession) {
                DebugLog.log("Khe $slotIndex: MediaSession onStop")
                if (tabIdFor(session) != autoBehaviorPriorityTabId) {
                    session.setPriorityHint(GeckoSession.PRIORITY_DEFAULT)
                }
                updateNativeMediaSession(false)
            }
        }

        return session
    }

    /** Tạo + cấu hình đầy đủ session (delegates, media session...) NHƯNG
     * KHÔNG mở — dùng cho tab thường (gọi `session.open()` ngay sau) VÀ cho
     * popup trong `onNewSession()` (KHÔNG được mở trước, xem giải thích lớn
     * ở đó — GeckoView tự mở session trả về từ `onNewSession`, mở sẵn sẽ
     * crash "Must use an unopened GeckoSession instance"). */
    private fun createSession(isPrivate: Boolean = false): GeckoSession {
        val session = createSessionUnopened(isPrivate)
        DebugLog.log("GeckoViewEngine slot $slotIndex: bắt đầu session.open(runtime)")
        session.open(runtime)
        // Mặc định TẤT CẢ session mới tạo là KHÔNG active — chỉ
        // `switchToTab()` mới có quyền bật `setActive(true)` cho đúng 1
        // session đang thật sự hiển thị tại một thời điểm (xem giải thích
        // đầy đủ ở `switchToTab()`). An toàn kể cả với tab vừa tạo rồi
        // được `switchToTab()` gọi ngay sau (trong `createTab()`) — lúc đó
        // `setActive(true)` sẽ ghi đè lại giá trị `false` này ngay lập tức.
        session.setActive(false)
        DebugLog.log("GeckoViewEngine slot $slotIndex: session.open() XONG (không crash)")
        return session
    }

    /**
     * FIX BUG THẬT (người dùng báo: "để trình duyệt lâu không dùng thì màn
     * hình tối đen như mực, bấm reload không phản hồi — như icon chỉ trưng
     * vậy, phải vuốt xoá app trong Recent Apps mới hết"). Log gửi kèm xác
     * nhận chính xác nguyên nhân: `onKill()`/`onCrash()` CHỈ ghi log, KHÔNG
     * làm gì thêm — trong khi đọc thẳng mã nguồn GeckoSession.java
     * (searchfox.org) xác nhận: trước khi gọi `delegate.onKill()`/`onCrash()`,
     * CHÍNH GeckoSession đã tự gọi `close()` — nghĩa là từ thời điểm đó,
     * session coi như ĐÃ CHẾT HẲN (không load được, không reload được —
     * khớp CHÍNH XÁC "bấm reload không phản hồi": `session.reload()` gọi
     * trên 1 session đã `close()` là no-op im lặng, không lỗi, không tác
     * dụng, đúng cảm giác "icon chỉ trưng vậy"). Javadoc chính thức
     * GeckoView xác nhận thêm: *"The GeckoSession is now closed and
     * unusable. You may call GeckoSession.open(GeckoRuntime) to recover...
     * Most applications will want to call ... GeckoSession.restoreState(
     * SessionState) at this point."*
     *
     * Cách khôi phục dùng ở đây THEO ĐÚNG code THẬT của Mozilla (Firefox
     * for Android, android-components `GeckoEngineSession.onKill/onCrash`,
     * không phải suy đoán): thay vì gọi lại `open()` trên CHÍNH session cũ
     * (đã bị chính họ bỏ, kèm chú thích "đã từng gây lỗi" —
     * mozilla-mobile/android-components#3640), tạo hẳn 1 `GeckoSession`
     * MỚI qua `createSession()` (đã tự gắn đủ mọi delegate — content/
     * navigation/progress/permission/media/selection — không cần gắn lại
     * tay), rồi phục hồi state qua `GeckoSession.SessionState.fromString()`
     * (API ĐÃ DÙNG SẴN ở `switchToTab()` phía trên, không đoán mù) từ
     * `tab.savedState` đã lưu liên tục qua `onSessionStateChange`. QUAN
     * TRỌNG không kém: nếu tab vừa chết chính là tab ĐANG HIỂN THỊ
     * (`activeTabId`), phải tự `geckoView.setSession(newSession)` lại —
     * nếu không, `GeckoView` (widget) vẫn trỏ vào session CŨ đã chết, màn
     * hình tiếp tục đen dù đã có session mới sống trong `tabs` map (đây
     * chính là bước "rebind" mà bản Fenick/Fenix chính thức cũng làm ở
     * tầng View, xem `GeckoEngineView.onProcessKilled { rebind() }`).
     */
    /**
     * BUG THẬT tìm ra khi điều tra báo cáo người dùng ("Drive đang xem
     * bằng máy tính tự nhiên mất trạng thái đó, làm video đang upload bị
     * gãy luôn") — xác nhận qua đọc chính code, không suy đoán:
     * `recoverKilledOrCrashedSession()` (gọi rất thường xuyên trong log
     * thật — hệ thống kill session tab nền là chuyện bình thường trên
     * Android khi thiếu RAM) tạo 1 `GeckoSession` HOÀN TOÀN MỚI, load lại
     * URL, nhưng TRƯỚC ĐÂY không hề gọi lại logic áp desktop mode thủ
     * công. `manualDesktopTabIds` (Set theo tabId) vẫn đúng — không mất —
     * nhưng nó chỉ là 1 CỜ NHỚ, KHÔNG tự áp `userAgentMode`/`viewportMode`
     * lên session MỚI (các thuộc tính đó nằm TRÊN TỪNG OBJECT
     * `GeckoSession`, không tự động theo tabId). Kết quả: UI vẫn tưởng
     * "đang bật" (vì `manualDesktopTabIds` vẫn chứa tabId) nhưng session
     * THẬT đã quay về mobile — đúng khớp "tự nhiên mất trạng thái" mà
     * KHÔNG có dòng log nào báo (im lặng, vì không ai gọi tới nhánh log
     * của toggleDesktopMode/applyViewportExceptionForUrl cả). Việc video
     * đang upload bị gãy cũng khớp — session bị kill+tạo lại nghĩa là
     * TOÀN BỘ trạng thái JS/network in-flight trên trang đó mất sạch,
     * không lạ khi 1 upload đang chạy bị gãy.
     *
     * SỬA: trích logic "áp desktop mode nếu tab nằm trong
     * manualDesktopTabIds HOẶC domain nằm trong danh sách persist" thành
     * 1 hàm dùng chung `applyManualDesktopModeIfApplicable()` — gọi cả ở
     * đây (session mới sau kill/crash) VÀ ở `applyViewportExceptionForUrl()`
     * (đường điều hướng bình thường) để tránh 2 nơi tự viết lại logic
     * riêng dễ lệch nhau như đã xảy ra.
     */
    private fun applyManualDesktopModeIfApplicable(session: GeckoSession, tabId: String, url: String): Boolean {
        val alreadyMarkedManual = manualDesktopTabIds.contains(tabId)
        val host = try { android.net.Uri.parse(url).host?.lowercase() } catch (e: Exception) { null }
        val domainPersisted = host != null && AppPrefs.getString(context, slotIndex, "manual_desktop_mode_domains", "")
            .split(",", "\n").map { it.trim().lowercase() }.filter { it.isNotEmpty() }
            .any { it == host }
        if (!alreadyMarkedManual && !domainPersisted) return false
        session.settings.userAgentOverride = null
        session.settings.userAgentMode = GeckoSessionSettings.USER_AGENT_MODE_DESKTOP
        session.settings.viewportMode = GeckoSessionSettings.VIEWPORT_MODE_DESKTOP
        manualDesktopTabIds.add(tabId)
        pushFingerprintConfig(session)
        DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN desktop thủ công] applyManualDesktopModeIfApplicable() ÁP LẠI desktop mode cho tab $tabId, url=$url (đã đánh dấu thủ công=$alreadyMarkedManual, domain lưu sẵn=$domainPersisted)")
        return true
    }

    private fun recoverKilledOrCrashedSession(deadSession: GeckoSession, wasCrash: Boolean) {
        try {
            val tabId = tabIdFor(deadSession)
            if (tabId == null) {
                DebugLog.log("Khe $slotIndex: recoverKilledOrCrashedSession() không tìm được tabId cho session đã chết — bỏ qua (có thể là session popup chưa gắn tabId)")
                return
            }
            val tab = tabMeta[tabId] ?: return
            val savedStateStr = tab.savedState
            val newSession = createSession(tab.isPrivate)
            tabs[tabId] = newSession
            // FIX BUG THẬT (xem chú thích đầy đủ ở applyManualDesktopModeIfApplicable
            // phía trên): áp lại desktop mode thủ công cho session MỚI này
            // TRƯỚC KHI load/restore — để lần load đầu tiên trên session
            // mới đã đúng UA/viewport ngay từ đầu, không phải load 1 lần
            // sai rồi mới sửa (tránh nháy giao diện mobile→desktop).
            applyManualDesktopModeIfApplicable(newSession, tabId, tab.url)
            when {
                savedStateStr != null -> {
                    try {
                        val state = GeckoSession.SessionState.fromString(savedStateStr)
                        if (state != null) newSession.restoreState(state) else newSession.loadUri(tab.url)
                    } catch (e: Exception) {
                        DebugLog.log("Khe $slotIndex: restoreState sau ${if (wasCrash) "crash" else "kill"} lỗi (${e.message}) — loadUri thay thế")
                        newSession.loadUri(tab.url)
                    }
                }
                tab.url.isNotBlank() && tab.url != "about:blank" -> newSession.loadUri(tab.url)
            }
            if (tabId == activeTabId) {
                newSession.setActive(true)
                geckoView.setSession(newSession)
                DebugLog.log("Khe $slotIndex: đã tạo session MỚI + rebind GeckoView cho tab $tabId (đang hiển thị) sau ${if (wasCrash) "crash" else "bị hệ thống kill"}")
            } else {
                DebugLog.log("Khe $slotIndex: đã tạo session MỚI (nền, chưa cần rebind) cho tab $tabId sau ${if (wasCrash) "crash" else "bị hệ thống kill"}")
            }
        } catch (e: Exception) {
            DebugLog.log("Khe $slotIndex: recoverKilledOrCrashedSession() lỗi: ${e.message}")
        }
    }

    // MediaSession GeckoView đang phát GẦN NHẤT — dùng để chuyển tiếp lệnh
    // play()/pause() khi người dùng bấm nút trên thông báo hệ thống ngược
    // lại cho ĐÚNG tab đang phát.
    private var currentGeckoMediaSession: MediaSession? = null
    /**
     * FIX BUG THẬT trong CHÍNH log tự-chẩn-đoán (`logMediaActionRealEffect()`)
     * — người dùng chỉ đúng: nhiều dòng log "TUA TỚI... KHÔNG CÓ THẺ
     * VIDEO" hoá ra là DO CHÍNH HÀM CHẨN ĐOÁN đọc NHẦM TAB. Hàm đó trước
     * đây dùng `activeTabId` (tab đang HIỂN THỊ/focus trong app) — nhưng
     * media có thể đang phát ở 1 tab NỀN khác (vd đang xem Colab trong khi
     * nhạc/video YouTube ở tab khác vẫn phát) — `currentGeckoMediaSession`
     * hoàn toàn ĐỘC LẬP với tab nào đang hiển thị. Lưu thêm ĐÚNG tabId của
     * tab đang giữ `currentGeckoMediaSession` này (qua `tabIdFor(session)`
     * đã có sẵn) để hàm chẩn đoán đọc đúng tab, không đoán nhầm theo
     * `activeTabId`.
     */
    private var currentGeckoMediaSessionTabId: String? = null
    private var nativeMediaSession: android.media.session.MediaSession? = null

    /** Callback cho MainActivity/feature biết trạng thái play/pause để cập nhật
     * thông báo hiển thị (tên bài/trang, icon...). */
    override var onMediaPlaybackStateListener: ((playing: Boolean) -> Unit)? = null

    /**
     * FIX LOG THẬT (đúng phê bình của người dùng: "nút media như làm
     * cảnh, chả có tác dụng gì" — trước đây log chỉ xác nhận LỆNH ĐÃ TỚI
     * `currentGeckoMediaSession` (`nextTrack()`/`seekForward()`/...), chứ
     * KHÔNG hề xác nhận lệnh đó có THẬT SỰ làm gì trên trang web hay
     * không — đây chính xác là khoảng trống khiến không biết chuyện gì
     * đang xảy ra). Đọc `currentTime`/`src`/`paused` của thẻ `<video>`
     * NGAY TRƯỚC và SAU (2 giây sau) khi gọi 1 hành động MediaSession —
     * nếu `currentTime` hoặc `src` (đổi bài đồng nghĩa đổi src) có thay
     * đổi thật, đó là bằng chứng CHẮC CHẮN lệnh có tác dụng thật trên
     * trang; nếu KHÔNG đổi gì cả, chứng tỏ
     * `currentGeckoMediaSession.nextTrack()/seekForward()/...` tuy được
     * GỌI ĐÚNG (không lỗi) nhưng KHÔNG được trang web (YouTube) thật sự
     * xử lý gì — rất có thể do trang không đăng ký handler tương ứng qua
     * `navigator.mediaSession.setActionHandler(...)`, nằm ngoài tầm sửa
     * của app (GeckoView chỉ CHUYỂN TIẾP lệnh, không tự mô phỏng hành vi
     * nếu trang không có sẵn logic xử lý).
     */
    private fun logMediaActionRealEffect(actionLabel: String) {
        // FIX BUG THẬT: dùng ĐÚNG tab đang giữ currentGeckoMediaSession
        // (`currentGeckoMediaSessionTabId`), KHÔNG dùng `activeTabId` (tab
        // đang hiển thị) — 2 tab này có thể KHÁC NHAU nếu media phát nền ở
        // 1 tab trong khi người dùng đang xem tab khác. Xem chú thích lớn
        // ở khai báo `currentGeckoMediaSessionTabId`.
        val tabId = currentGeckoMediaSessionTabId ?: activeTabId ?: return
        val jsRead = """
            (function() {
                var v = document.querySelector('video');
                if (!v) return 'KHÔNG CÓ THẺ VIDEO';
                return 'currentTime=' + v.currentTime.toFixed(2) + ' paused=' + v.paused + ' src=' + (v.currentSrc ? v.currentSrc.substring(v.currentSrc.length - 40) : '(rỗng)');
            })();
        """.trimIndent()
        evaluateJsForTab(tabId, jsRead) { before ->
            DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN tác dụng thật của '$actionLabel'] TRƯỚC: $before")
            handler.postDelayed({
                evaluateJsForTab(tabId, jsRead) { after ->
                    DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN tác dụng thật của '$actionLabel'] SAU 2s: $after — ${if (before == after) "KHÔNG ĐỔI GÌ CẢ (nghi ngờ trang không xử lý lệnh này thật sự, dù GeckoView nhận lệnh không lỗi)" else "CÓ THAY ĐỔI (lệnh có tác dụng thật trên trang)"}")
                }
            }, 2000L)
        }
    }

    private fun ensureNativeMediaSession(): android.media.session.MediaSession {
        nativeMediaSession?.let { return it }
        val ms = android.media.session.MediaSession(context, "LiveBrowserMedia_$slotIndex")
        ms.setCallback(object : android.media.session.MediaSession.Callback() {
            override fun onPlay() {
                DebugLog.log("Khe $slotIndex: hệ thống yêu cầu Play (từ thông báo/màn hình khoá)")
                currentGeckoMediaSession?.play()
            }
            override fun onPause() {
                DebugLog.log("Khe $slotIndex: hệ thống yêu cầu Pause (từ thông báo/màn hình khoá)")
                currentGeckoMediaSession?.pause()
            }
            override fun onStop() {
                currentGeckoMediaSession?.stop()
            }
            /**
             * FIX TÍNH NĂNG THIẾU (người dùng báo: "thanh media player trên
             * thanh thông báo chỉ có nút play pause, ko có nút tiến tới hay
             * lùi lại"): `PlaybackState` trước đây chỉ khai báo
             * ACTION_PLAY/ACTION_PAUSE/ACTION_STOP — chưa từng có
             * SKIP_TO_NEXT/SKIP_TO_PREVIOUS, nên hệ thống không hiện nút đó
             * (đúng hành vi Android: notification chỉ hiện nút cho action
             * đã khai báo trong PlaybackState).
             *
             * BUG THẬT tiếp theo đã sửa (người dùng báo: "nút tiến lùi media
             * trên thanh thông báo khi nhấn vào vẫn ko thay bài nhạc khác"
             * — xác nhận qua log: bấm nút, log "hệ thống yêu cầu tua
             * tới/lui" xuất hiện đúng, `currentGeckoMediaSession=CÓ`, nghĩa
             * là lệnh CÓ tới nơi, nhưng bài không đổi): lượt sửa TRƯỚC dùng
             * `seekForward()`/`seekBackward()` — tra lại tài liệu Javadoc
             * CHÍNH THỨC của GeckoView (mozilla.github.io/geckoview) xác
             * nhận 2 hàm này CHỈ "Seek forward/backward by a sensible
             * number of seconds" (tua vài giây TRONG CÙNG 1 media element
             * đang phát), khác hẳn `nextTrack()`/`previousTrack()` — đúng
             * mô tả Javadoc: "Select and play the next/previous track. Move
             * playback to the next item in the playlist when supported."
             * Đây chính xác là API tương ứng với action
             * `nexttrack`/`previoustrack` của Web MediaSession API
             * (`navigator.mediaSession.setActionHandler('nexttrack', ...)`)
             * — hàm GeckoView chuyển tiếp đúng xuống handler mà TRANG WEB
             * tự đăng ký (vd YouTube tự set handler này để nhảy sang video
             * kế tiếp trong playlist — đúng ngữ cảnh log cho thấy URL có
             * `list=RDeAc2ZtcE-48` là 1 playlist/radio thật). Lượt sửa
             * TRƯỚC nhận định "hầu hết trang không có khái niệm bài tiếp
             * theo" là suy đoán sai khiến chọn nhầm API — sửa lại dùng đúng
             * `nextTrack()`/`previousTrack()`. Nếu trang KHÔNG tự đăng ký
             * handler `nexttrack`/`previoustrack` (trang phát media đơn
             * giản, không phải playlist), GeckoView/trình duyệt sẽ tự
             * fallback hợp lý (thường là không làm gì hoặc coi như seek) —
             * không tệ hơn hành vi cũ, và ĐÚNG hẳn cho đúng trường hợp
             * playlist mà người dùng đang gặp.
             */
            override fun onSkipToNext() {
                val sess = currentGeckoMediaSession
                DebugLog.log("Khe $slotIndex: hệ thống yêu cầu CHUYỂN BÀI TIẾP THEO (từ thông báo/màn hình khoá) — currentGeckoMediaSession=${if (sess != null) "CÓ (tabId=$currentGeckoMediaSessionTabId)" else "NULL — tab media lazy-load chưa phát lại sau restart; cần vào tab đang phát để kết nối lại session"}")
                if (sess != null) {
                    sess.nextTrack()
                    logMediaActionRealEffect("CHUYỂN BÀI TIẾP THEO")
                }
            }
            override fun onSkipToPrevious() {
                val sess = currentGeckoMediaSession
                DebugLog.log("Khe $slotIndex: hệ thống yêu cầu CHUYỂN BÀI TRƯỚC ĐÓ (từ thông báo/màn hình khoá) — currentGeckoMediaSession=${if (sess != null) "CÓ (tabId=$currentGeckoMediaSessionTabId)" else "NULL — tab media lazy-load chưa phát lại sau restart; cần vào tab đang phát để kết nối lại session"}")
                if (sess != null) {
                    sess.previousTrack()
                    logMediaActionRealEffect("CHUYỂN BÀI TRƯỚC ĐÓ")
                }
            }
            /**
             * THÊM MỚI theo yêu cầu (giữ CẢ 2 loại nút — "chuyển bài"
             * ở trên VÀ "tua giây trong bài" ở đây — thành 4 nút riêng
             * biệt, không phải đổi 2 nút cũ thành nghĩa khác): dùng đúng 2
             * callback THẬT dành riêng cho việc "tua theo giây" của
             * `android.media.session.MediaSession.Callback` —
             * `onFastForward()`/`onRewind()` — khác hẳn
             * `onSkipToNext()`/`onSkipToPrevious()` ở trên (dành cho
             * "chuyển bài"). Gọi đúng `seekForward()`/`seekBackward()` của
             * GeckoView (đã xác nhận qua Javadoc chính thức ở chú thích lớn
             * phía trên: "Seek forward/backward by a sensible number of
             * seconds" — đúng nghĩa tua giây, không phải chuyển bài).
             */
            override fun onFastForward() {
                val sess = currentGeckoMediaSession
                DebugLog.log("Khe $slotIndex: hệ thống yêu cầu TUA TỚI vài giây (từ thông báo/màn hình khoá) — currentGeckoMediaSession=${if (sess != null) "CÓ (tabId=$currentGeckoMediaSessionTabId)" else "NULL — tab media lazy-load chưa phát lại sau restart"}")
                if (sess != null) {
                    sess.seekForward()
                    logMediaActionRealEffect("TUA TỚI (onFastForward)")
                }
            }
            override fun onRewind() {
                val sess = currentGeckoMediaSession
                DebugLog.log("Khe $slotIndex: hệ thống yêu cầu TUA LÙI vài giây (từ thông báo/màn hình khoá) — currentGeckoMediaSession=${if (sess != null) "CÓ (tabId=$currentGeckoMediaSessionTabId)" else "NULL — tab media lazy-load chưa phát lại sau restart"}")
                if (sess != null) {
                    sess.seekBackward()
                    logMediaActionRealEffect("TUA LÙI (onRewind)")
                }
            }
            /**
             * BUG THẬT tìm ra (người dùng báo đúng: widget media control
             * trên thanh thông báo Android 13+ VẪN chỉ hiện 3 nút dù đã
             * khai báo đủ 5 action, xác nhận qua log đúng version mới đang
             * chạy — loại trừ hẳn khả năng "chưa build"). Tra tài liệu
             * CHÍNH THỨC developer.android.com/about/versions/13/behavior-changes-13
             * — mục "Media controls derived from PlaybackState" — có bảng
             * quy định CỨNG: slot 4 và 5 của widget media MỚI (đúng loại
             * card tròn "Điện thoại này" trong ảnh chụp) CHỈ lấy từ
             * `PlaybackState.getCustomActions()` — một danh sách HOÀN TOÀN
             * RIÊNG BIỆT với `.setActions()` (bitmask) đang dùng cho
             * ACTION_FAST_FORWARD/ACTION_REWIND. Bitmask đó KHÔNG BAO GIỜ
             * được widget này dùng để lấp slot 4/5 — đây là lý do THẬT,
             * xác nhận bằng tài liệu, không phải do compact view hay do
             * bản build cũ.
             * Custom Action bấm từ system UI gọi qua
             * `MediaSession.Callback.onCustomAction(action, extras)` —
             * KHÁC hẳn `onFastForward()`/`onRewind()` ở trên (2 hàm đó vẫn
             * giữ lại, dùng cho thông báo mở rộng kiểu cũ/thiết bị dưới
             * Android 13 đọc theo `Notification.Action` thường).
             */
            override fun onCustomAction(action: String, extras: android.os.Bundle?) {
                val sess = currentGeckoMediaSession
                when (action) {
                    CUSTOM_ACTION_REWIND -> {
                        DebugLog.log("Khe $slotIndex: hệ thống yêu cầu TUA LÙI vài giây qua CustomAction (widget media Android 13+) — currentGeckoMediaSession=${if (sess != null) "CÓ (tabId=$currentGeckoMediaSessionTabId)" else "NULL — tab media lazy-load chưa phát lại sau restart; cần vào tab đang phát để kết nối lại session"}")
                        // FIX BUG THẬT: trước đây gọi logMediaActionRealEffect()
                        // VÔ ĐIỀU KIỆN kể cả khi sess=null (currentGeckoMediaSession?.seekBackward()
                        // là no-op im lặng) — hàm đó fallback đọc trạng thái video
                        // của activeTabId (tab ĐANG HIỂN THỊ, có thể KHÁC tab
                        // đang phát nhạc nền), rồi báo "KHÔNG ĐỔI GÌ CẢ" — bị
                        // hiểu nhầm là "trang không xử lý lệnh" trong khi THỰC RA
                        // lệnh chưa từng được gửi đi (session null). Chỉ gọi
                        // logMediaActionRealEffect() khi THẬT SỰ có lệnh gửi.
                        if (sess != null) {
                            sess.seekBackward()
                            logMediaActionRealEffect("TUA LÙI (CustomAction)")
                        }
                    }
                    CUSTOM_ACTION_FAST_FORWARD -> {
                        DebugLog.log("Khe $slotIndex: hệ thống yêu cầu TUA TỚI vài giây qua CustomAction (widget media Android 13+) — currentGeckoMediaSession=${if (sess != null) "CÓ (tabId=$currentGeckoMediaSessionTabId)" else "NULL — tab media lazy-load chưa phát lại sau restart; cần vào tab đang phát để kết nối lại session"}")
                        if (sess != null) {
                            sess.seekForward()
                            logMediaActionRealEffect("TUA TỚI (CustomAction)")
                        }
                    }
                }
            }
        })
        nativeMediaSession = ms
        return ms
    }

    override fun getNativeMediaSessionToken(): android.media.session.MediaSession.Token =
        ensureNativeMediaSession().sessionToken

    /**
     * BUG THẬT đã tìm ra (người dùng báo: "thanh bar phát nhạc không như
     * bar bình thường, nhấn dừng vẫn còn bar, hiện icon tam giác, bấm vào
     * lại phát tiếp"): `nativeMediaSession` (ở trên) có đầy đủ
     * `PlaybackState` đúng (PLAYING/PAUSED) — NHƯNG chưa từng có notification
     * `MediaStyle` THẬT nào được dựng từ nó cả. `onMediaPlaybackStateListener`
     * (khai báo phía trên) CHƯA TỪNG có ai lắng nghe — kiểm tra toàn bộ
     * MainActivity.kt xác nhận không có dòng nào dùng nó. Cái "thanh bar" mà
     * người dùng thấy chỉ là notification TĨNH của `KeepAliveService`
     * (`ic_media_play` — icon tam giác CỨNG, không đổi bao giờ, không có nút
     * bấm thật, không liên quan gì đến nhạc — nó luôn ở đó bất kể có phát
     * nhạc hay không).
     *
     * Sửa: tự dựng notification `MediaStyle` THẬT ở đây, dùng
     * `android.app.Notification.MediaStyle` (lớp NỀN TẢNG, không phải
     * `androidx.media.app.NotificationCompat.MediaStyle` — lớp đó nằm trong
     * dependency `androidx.media:media` CHƯA có trong build.gradle project
     * này, thêm dependency mới sẽ không build-test được ở đây). Lớp nền tảng
     * nhận thẳng `android.media.session.MediaSession.Token` (đúng loại
     * `sessionToken` đã có sẵn), không cần thêm gì.
     *
     * Nút Play/Pause thật: dùng `BroadcastReceiver` tự đăng ký trong chính
     * class này (KHÔNG khai báo trong Manifest, không cần thư viện
     * `androidx.media`/`MediaButtonReceiver`) — khi bấm, gọi thẳng
     * `nativeMediaSession.controller.transportControls.play()/pause()`,
     * chuyển tiếp đúng qua `MediaSession.Callback` đã có ở trên.
     */
    private var mediaActionReceiverRegistered = false
    private val mediaActionReceiver = object : android.content.BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: android.content.Intent) {
            when (intent.action) {
                ACTION_MEDIA_PLAY -> nativeMediaSession?.controller?.transportControls?.play()
                ACTION_MEDIA_PAUSE -> nativeMediaSession?.controller?.transportControls?.pause()
                ACTION_MEDIA_SEEK_FORWARD -> nativeMediaSession?.controller?.transportControls?.skipToNext()
                ACTION_MEDIA_SEEK_BACKWARD -> nativeMediaSession?.controller?.transportControls?.skipToPrevious()
                // THÊM MỚI: 2 action riêng cho "tua giây trong bài" — khác
                // hẳn 2 action ở trên ("chuyển bài", gọi skipToNext/Previous
                // → onSkipToNext/onSkipToPrevious → nextTrack/previousTrack).
                // Ở đây gọi fastForward()/rewind() → đúng
                // onFastForward()/onRewind() → seekForward()/seekBackward().
                ACTION_MEDIA_FAST_FORWARD -> nativeMediaSession?.controller?.transportControls?.fastForward()
                ACTION_MEDIA_REWIND -> nativeMediaSession?.controller?.transportControls?.rewind()
            }
        }
    }
    private val ACTION_MEDIA_PLAY get() = "com.colablive.keeper.MEDIA_PLAY_$slotIndex"
    private val ACTION_MEDIA_PAUSE get() = "com.colablive.keeper.MEDIA_PAUSE_$slotIndex"
    private val ACTION_MEDIA_SEEK_FORWARD get() = "com.colablive.keeper.MEDIA_SEEK_FORWARD_$slotIndex"
    private val ACTION_MEDIA_SEEK_BACKWARD get() = "com.colablive.keeper.MEDIA_SEEK_BACKWARD_$slotIndex"
    private val ACTION_MEDIA_FAST_FORWARD get() = "com.colablive.keeper.MEDIA_FAST_FORWARD_$slotIndex"
    private val ACTION_MEDIA_REWIND get() = "com.colablive.keeper.MEDIA_REWIND_$slotIndex"

    /** Action string cho `PlaybackState.CustomAction` (khác hẳn action
     * string của Intent broadcast ở trên) — xem chú thích lớn ở
     * `onCustomAction()`/`updateNativeMediaSession()`. Không cần gắn
     * $slotIndex vì đây chỉ là định danh NỘI BỘ trong 1 MediaSession
     * (mỗi khe có MediaSession riêng), không phát broadcast toàn hệ thống
     * như 2 hằng số phía trên nên không lo trùng giữa các khe. */
    private val CUSTOM_ACTION_REWIND get() = "com.colablive.keeper.CUSTOM_ACTION_REWIND"
    private val CUSTOM_ACTION_FAST_FORWARD get() = "com.colablive.keeper.CUSTOM_ACTION_FAST_FORWARD"

    private fun ensureMediaActionReceiverRegistered() {
        if (mediaActionReceiverRegistered) return
        val filter = android.content.IntentFilter().apply {
            addAction(ACTION_MEDIA_PLAY)
            addAction(ACTION_MEDIA_PAUSE)
            addAction(ACTION_MEDIA_SEEK_FORWARD)
            addAction(ACTION_MEDIA_SEEK_BACKWARD)
            addAction(ACTION_MEDIA_FAST_FORWARD)
            addAction(ACTION_MEDIA_REWIND)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            context.registerReceiver(mediaActionReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            context.registerReceiver(mediaActionReceiver, filter)
        }
        mediaActionReceiverRegistered = true
    }

    private fun postMediaNotification(playing: Boolean) {
        ensureMediaActionReceiverRegistered()
        val nm = context.getSystemService(android.app.NotificationManager::class.java)
        val channelId = "live_browser_media"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = android.app.NotificationChannel(
                channelId, "Đang phát media", android.app.NotificationManager.IMPORTANCE_LOW
            ).apply { setShowBadge(false) }
            nm.createNotificationChannel(channel)
        }

        val playPauseAction = if (playing) {
            val pi = android.app.PendingIntent.getBroadcast(
                context, slotIndex, android.content.Intent(ACTION_MEDIA_PAUSE),
                android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
            )
            android.app.Notification.Action.Builder(
                android.graphics.drawable.Icon.createWithResource(context, android.R.drawable.ic_media_pause),
                "Tạm dừng", pi
            ).build()
        } else {
            val pi = android.app.PendingIntent.getBroadcast(
                context, slotIndex, android.content.Intent(ACTION_MEDIA_PLAY),
                android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
            )
            android.app.Notification.Action.Builder(
                android.graphics.drawable.Icon.createWithResource(context, android.R.drawable.ic_media_play),
                "Phát", pi
            ).build()
        }

        /**
         * FIX TÍNH NĂNG THIẾU (tiếp tục): 2 nút CHUYỂN BÀI thật, dùng
         * PendingIntent broadcast riêng (giống pattern play/pause đã có
         * sẵn ở trên) — không cần thư viện `androidx.media` mới nào.
         *
         * Nhãn/icon "Bài trước/Bài sau" (ic_media_previous/next) — khớp
         * đúng hành vi THẬT sau khi sửa bug nút không đổi bài (xem chú
         * thích lớn ở `onSkipToNext()`/`onSkipToPrevious()` phía trên): 2
         * nút này gọi `nextTrack()`/`previousTrack()` (chuyển bài trong
         * playlist).
         */
        val previousTrackAction = android.app.Notification.Action.Builder(
            android.graphics.drawable.Icon.createWithResource(context, android.R.drawable.ic_media_previous),
            "Bài trước",
            android.app.PendingIntent.getBroadcast(
                context, slotIndex + 10_000, android.content.Intent(ACTION_MEDIA_SEEK_BACKWARD),
                android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
            )
        ).build()
        val nextTrackAction = android.app.Notification.Action.Builder(
            android.graphics.drawable.Icon.createWithResource(context, android.R.drawable.ic_media_next),
            "Bài sau",
            android.app.PendingIntent.getBroadcast(
                context, slotIndex + 20_000, android.content.Intent(ACTION_MEDIA_SEEK_FORWARD),
                android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
            )
        ).build()

        /**
         * THÊM MỚI theo yêu cầu người dùng ("lỡ có 2 nút kia rồi thì làm
         * thêm 2 nút kia thành 4 nút luôn"): giữ LẠI 2 nút "tua giây trong
         * bài" (ý nghĩa gốc ban đầu, dùng icon tua thật `ic_media_rew`/
         * `ic_media_ff`) — KHÔNG thay thế 2 nút chuyển bài ở trên, mà làm
         * THÊM cho đủ 4 nút điều khiển + 1 nút play/pause = 5 nút tổng.
         * Dùng 2 action string mới (`ACTION_MEDIA_REWIND`/
         * `ACTION_MEDIA_FAST_FORWARD`) + request code riêng (khác hẳn
         * request code của 2 nút chuyển bài ở trên) để 2 cặp PendingIntent
         * không đè lên nhau.
         */
        val rewindAction = android.app.Notification.Action.Builder(
            android.graphics.drawable.Icon.createWithResource(context, android.R.drawable.ic_media_rew),
            "Tua lùi",
            android.app.PendingIntent.getBroadcast(
                context, slotIndex + 30_000, android.content.Intent(ACTION_MEDIA_REWIND),
                android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
            )
        ).build()
        val fastForwardAction = android.app.Notification.Action.Builder(
            android.graphics.drawable.Icon.createWithResource(context, android.R.drawable.ic_media_ff),
            "Tua tới",
            android.app.PendingIntent.getBroadcast(
                context, slotIndex + 40_000, android.content.Intent(ACTION_MEDIA_FAST_FORWARD),
                android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
            )
        ).build()

        val notification = android.app.Notification.Builder(context, channelId)
            .setContentTitle(tabMeta[activeTabId]?.title?.takeIf { it.isNotBlank() } ?: "Live Browser")
            // BUG THẬT đã tìm ra (người dùng báo: "trên thanh thông báo
            // cũng ko biết đang phát nhạc khe nào, profile nào"): trước đây
            // contentText chỉ ghi "Đang phát"/"Đã tạm dừng", không có gì
            // phân biệt khe nào khi chạy nhiều khe song song. Thêm tiền tố
            // "Khe $slotIndex" — đây là thông tin GeckoViewEngine đã có sẵn
            // (không cần tra cứu thêm gì), đủ để phân biệt giữa các khe.
            .setContentText("Khe $slotIndex — ${if (playing) "Đang phát" else "Đã tạm dừng"}")
            .setSmallIcon(if (playing) android.R.drawable.ic_media_play else android.R.drawable.ic_media_pause)
            // Thứ tự 5 nút: lùi bài / tua lùi / play-play / tua tới / bài
            // sau — play/pause nằm CHÍNH GIỮA đúng bố cục media player
            // chuẩn (index 2 trong 5 nút, 0..4).
            .addAction(previousTrackAction)
            .addAction(rewindAction)
            .addAction(playPauseAction)
            .addAction(fastForwardAction)
            .addAction(nextTrackAction)
            .setStyle(
                android.app.Notification.MediaStyle()
                    .setMediaSession(ensureNativeMediaSession().sessionToken)
                    // Compact view (thu gọn trên màn hình khoá/thanh trạng
                    // thái) TỐI ĐA chỉ hiện được 3 nút — ưu tiên "bài
                    // trước/play-pause/bài sau" (index 0,2,4) vì đây là 3
                    // nút hữu ích nhất khi thu gọn; 2 nút tua giây (index
                    // 1,3) chỉ hiện khi mở rộng notification đầy đủ.
                    .setShowActionsInCompactView(0, 2, 4)
            )
            .setOngoing(playing)
            .build()

        /**
         * BUG THẬT đã tìm ra (người dùng báo 2 việc liên quan: nút
         * play/pause trên thông báo không tắt được nhạc; VÀ "trước kia vừa
         * phát nhạc nền vừa chạy Colab, Colab vẫn sống được, giờ dù phát
         * nhạc nền Colab vẫn không sống nổi"): trước lượt gate lại
         * `KeepAliveService` theo đúng cờ `colablive_keepalive_on`, service
         * đó chạy vô điều kiện — VÔ TÌNH bảo vệ luôn CẢ PROCESS (không chỉ
         * riêng Colab) khỏi bị hệ thống đóng băng/giết khi xuống nền, kể cả
         * khi chỉ đang phát nhạc nền không liên quan Colab. Bảo vệ process
         * thì bảo vệ TẤT CẢ mọi thứ chạy trong đó (Colab, MediaSession...).
         * Gate lại đúng cờ (fix hợp lý, không sai) vô tình làm mất luôn tác
         * dụng phụ này.
         * SỬA ĐÚNG GỐC: dùng `MediaKeepAliveService` (đã dựng riêng — xem
         * MediaKeepAliveService.kt) khi ĐANG PHÁT — service này chạy độc
         * lập với `colablive_keepalive_on`, chỉ cần có media đang phát. Vì
         * nó bảo vệ CẢ process, Colab (nếu đang chạy trong cùng khe) được
         * bảo vệ THEO — đúng lại hành vi cũ người dùng đã quen, không phải
         * chủ ý thiết kế mới mà là khôi phục tác dụng phụ có lợi đã mất.
         * Khi TẠM DỪNG, dừng foreground service (không cần bảo vệ liên tục
         * nữa), notification vẫn hiện bình thường qua nm.notify() (không
         * foreground, nhưng vẫn có nút bấm tương tác được ngay lúc process
         * còn sống — đủ dùng cho UI đã tạm dừng, không cần bảo vệ mạnh).
         */
        val serviceClass = MediaKeepAliveService.classForSlot(slotIndex)
        if (playing) {
            MediaKeepAliveService.start(context, serviceClass, 2000 + slotIndex, notification)
        } else {
            MediaKeepAliveService.stop(context, serviceClass)
            nm.notify(2000 + slotIndex, notification)
        }
    }

    private fun updateNativeMediaSession(playing: Boolean) {
        val ms = ensureNativeMediaSession()
        val stateBuilder = android.media.session.PlaybackState.Builder()
            .setActions(
                android.media.session.PlaybackState.ACTION_PLAY or
                android.media.session.PlaybackState.ACTION_PAUSE or
                android.media.session.PlaybackState.ACTION_STOP or
                // FIX TÍNH NĂNG THIẾU: thêm 2 action tua tới/lui — thiếu
                // khai báo ở đây thì dù có addAction() ở notification, hệ
                // thống vẫn có thể ẩn nút (PlaybackState là nguồn sự thật
                // Android dùng để quyết định action nào hợp lệ/hiện được).
                android.media.session.PlaybackState.ACTION_SKIP_TO_NEXT or
                android.media.session.PlaybackState.ACTION_SKIP_TO_PREVIOUS or
                // Giữ lại 2 bitmask action này cho THIẾT BỊ DƯỚI ANDROID 13
                // (hoặc app không target API 33 — theo đúng bảng tài liệu,
                // ở các trường hợp đó hệ thống vẫn đọc theo Notification.Action
                // thường như trước giờ). Ở Android 13+ thì 2 action bitmask
                // này KHÔNG được widget media mới dùng cho slot 4/5 — xem
                // chú thích lớn ở `addCustomAction` ngay dưới đây để biết
                // cách THẬT làm 2 nút tua giây hiện ra trên widget mới.
                android.media.session.PlaybackState.ACTION_FAST_FORWARD or
                android.media.session.PlaybackState.ACTION_REWIND
            )
            .setState(
                if (playing) android.media.session.PlaybackState.STATE_PLAYING else android.media.session.PlaybackState.STATE_PAUSED,
                android.media.session.PlaybackState.PLAYBACK_POSITION_UNKNOWN,
                1f
            )
        /**
         * BUG THẬT đã sửa (xem chú thích đầy đủ, có trích dẫn tài liệu
         * chính thức, ở `onCustomAction()` phía trên): widget media control
         * MỚI của Android 13+ (đúng loại card tròn "Điện thoại này" người
         * dùng chụp) CHỈ lấp slot 4/5 (2 nút thêm ngoài play/pause/prev/
         * next) từ `PlaybackState.getCustomActions()` — một danh sách
         * HOÀN TOÀN RIÊNG, không liên quan gì tới `.setActions()` bitmask
         * ở trên (ACTION_FAST_FORWARD/ACTION_REWIND tuy có khai báo nhưng
         * KHÔNG BAO GIỜ được widget mới dùng để lấp 2 slot đó). Đây là
         * cách THẬT, đúng tài liệu, để 2 nút tua giây hiện ra trên widget
         * mới — dùng đúng `android.R.drawable.ic_media_rew`/`ic_media_ff`
         * làm icon, khớp icon đã dùng ở notification thường.
         */
        stateBuilder.addCustomAction(
            android.media.session.PlaybackState.CustomAction.Builder(
                CUSTOM_ACTION_REWIND, "Tua lùi", android.R.drawable.ic_media_rew
            ).build()
        )
        stateBuilder.addCustomAction(
            android.media.session.PlaybackState.CustomAction.Builder(
                CUSTOM_ACTION_FAST_FORWARD, "Tua tới", android.R.drawable.ic_media_ff
            ).build()
        )
        val state = stateBuilder.build()
        ms.setPlaybackState(state)
        // BUG NGHI NGỜ (người dùng báo: sau khi thêm notification, tính năng
        // phát nhạc nền — vốn đã sửa được — LẠI HỎNG, quay về đúng triệu
        // chứng cũ: tắt ngay khi xuống nền). `postMediaNotification()` chạy
        // ĐỒNG BỘ ngay trong callback THẬT của Gecko
        // (`mediaSessionDelegate.onPlay/onPause`, xem session.mediaSessionDelegate
        // ở trên) — nếu nó ném lỗi mà KHÔNG được bắt, lỗi sẽ dội ngược lên
        // callback native của Gecko đang chạy, có thể làm rối/ngắt luôn xử lý
        // phía Gecko cho session đó. Trước đây (chưa có `postMediaNotification`)
        // callback này chỉ làm 2 việc đơn giản, không có gì để ném lỗi. Giờ bọc
        // `try/catch` để LOẠI TRỪ HẲN khả năng này — dù đúng hay không, đây là
        // rủi ro thật cần chặn trước, không phải suy đoán suông.
        try {
            handler.post {
                try {
                    postMediaNotification(playing)
                } catch (e: Exception) {
                    DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN nhạc nền] postMediaNotification NÉM LỖI: ${e.javaClass.simpleName}: ${e.message}")
                }
            }
        } catch (e: Exception) {
            DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN nhạc nền] handler.post lỗi: ${e.message}")
        }
        /**
         * CẬP NHẬT (đảo ngược 1 phần thay đổi trước — thay đổi đó dựa trên

         * "nghi ngờ" chưa test kiểm chứng, không phải xác nhận thật):
         *
         * Đã tra lại tài liệu chính thức Android — `android.media.session.
         * MediaSession.isActive = true` KHÔNG PHẢI là thứ khiến hệ thống
         * "nhắm vào để tự tắt", mà NGƯỢC LẠI: đây là cách CHÍNH THỨC báo cho
         * Android biết "đây là 1 phiên phát media thật đang diễn ra" — thiếu
         * cờ này, hệ thống coi app như app thường (không có ngoại lệ nào cho
         * phát nhạc nền), dễ bị giới hạn nền (Doze/App Standby) hơn, không
         * phải ít hơn. Comment cũ ở trên chỉ là suy đoán ("nghi ngờ chính
         * xác dòng này") — CHƯA từng được xác nhận bằng test thật trước khi
         * xoá.
         *
         * Khôi phục lại `ms.isActive` (đặt `true` khi đang phát, `false` khi
         * dừng — không giữ `true` mãi kể cả lúc không phát, tránh giữ phiên
         * "sống" không cần thiết) để test lại với dữ liệu thật, thay vì suy
         * đoán tiếp không kiểm chứng.
         */
        ms.isActive = playing

        onMediaPlaybackStateListener?.invoke(playing)
    }

    // Helper cho tên file download sai (xem comment ở onExternalResponse).
    //
    // TỰ PHÊ BÌNH LẠI (người dùng chỉ ra đúng — bản trước đọc query param
    // "path=" của URL để đoán tên file là HARDCODE, không phải fix tổng
    // quát): bản đó chỉ hoạt động với URL có ĐÚNG hình dạng
    // `...?path=/mnt/.../TenFile.zip` — tức chỉ khớp riêng endpoint
    // `/wiggle/download-file` của claude.ai, đoán từ 1 tấm ảnh chụp màn
    // hình, KHÔNG PHẢI xác nhận qua log thật rằng Content-Disposition có bị
    // thiếu/sai hay không. Đây là vá theo hình dạng URL cụ thể, không phải
    // sửa đúng nguyên nhân gốc — nếu server khác trả tên file sai theo 1
    // hình dạng URL khác, patch này không giúp được gì.
    //
    // Sửa lại đúng hướng: CƠ CHẾ CHUẨN HTTP duy nhất đáng tin cậy cho MỌI
    // server là `Content-Disposition` — củng cố việc đọc header này cho
    // đúng chuẩn (RFC 6266/5987: hỗ trợ cả `filename=` lẫn `filename*=`,
    // ưu tiên `filename*=` vì có encoding đầy đủ hơn, giải mã URL-encode
    // đúng chuẩn thay vì giữ nguyên chuỗi thô). Bỏ hẳn heuristic "path="
    // dựa vào hình dạng URL — thay bằng LOG rõ ràng khi rơi vào fallback
    // URLUtil, để lần sau có bug tương tự sẽ có LOG THẬT (giá trị
    // Content-Disposition thô nhận được, nếu có) thay vì phải đoán mù qua
    // ảnh chụp màn hình.
    private fun extractFileNameFromResponse(uri: String, contentDisposition: String?, contentType: String?): String {
        if (!contentDisposition.isNullOrBlank()) {
            // Ưu tiên filename*= (RFC 5987, có thể có charset + URL-encode,
            // vd: filename*=UTF-8''B%C3%A1o%20c%C3%A1o.pdf) trước
            // filename= (ASCII fallback đơn giản) — theo đúng thứ tự ưu
            // tiên RFC 6266 khuyến nghị khi cả 2 cùng xuất hiện.
            val extendedMatch = Regex("""filename\*\s*=\s*([^;\r\n]+)""", RegexOption.IGNORE_CASE)
                .find(contentDisposition)
            if (extendedMatch != null) {
                val raw = extendedMatch.groupValues[1].trim().trim('"')
                // Dạng chuẩn: charset''percent-encoded-name, vd "UTF-8''a%20b.zip"
                val afterCharset = raw.substringAfter("''", raw)
                val decoded = try {
                    java.net.URLDecoder.decode(afterCharset, "UTF-8")
                } catch (e: Exception) {
                    afterCharset
                }
                if (decoded.isNotBlank()) return decoded
            }

            val simpleMatch = Regex("""filename\s*=\s*"?([^";\r\n]+)"?""", RegexOption.IGNORE_CASE)
                .find(contentDisposition)
            val simpleName = simpleMatch?.groupValues?.get(1)?.trim()?.trim('"')
            if (!simpleName.isNullOrBlank()) return simpleName
        }

        // Không đọc được tên file thật từ Content-Disposition — thử nguồn
        // (2): thuộc tính `download` mà content script bắt được ngay lúc
        // click (xem chú thích "TÍNH NĂNG MỚI" ở content.js — đây là NGUỒN
        // THỨ 2 mà trình duyệt thật Chrome/Firefox dùng, đã tra cứu xác
        // nhận qua nhiều nguồn, KHÔNG phải đoán theo hình dạng URL như bản
        // vá cũ đã bị chỉ ra là hardcode). Dọn hint hết hạn (TTL) trước khi
        // tra, tránh dùng nhầm hint cũ của 1 lượt click khác.
        val nowMs = System.currentTimeMillis()
        downloadFilenameHints.entries.removeIf { nowMs - it.value.second > DOWNLOAD_HINT_TTL_MS }
        val hint = downloadFilenameHints.remove(uri)
        if (hint != null) {
            DebugLog.log("extractFileNameFromResponse: dùng download_hint từ content script cho uri=$uri -> filename=${hint.first}")
            return hint.first
        }

        // Không đọc được tên file thật từ Content-Disposition, cũng không
        // có download_hint khớp URL — log NGUYÊN VĂN header (nếu có) để
        // lần sau xảy ra bug tương tự có dữ liệu thật để chẩn đoán, thay vì
        // phải đoán qua ảnh chụp màn hình như lần trước.
        DebugLog.log(
            "extractFileNameFromResponse: không tách được filename từ Content-Disposition " +
                "(giá trị thô nhận được = ${contentDisposition ?: "null/không có header"}), " +
                "fallback về URLUtil.guessFileName() cho uri=$uri"
        )
        return android.webkit.URLUtil.guessFileName(uri, contentDisposition, contentType)
    }

    // BUG THẬT liên quan (người dùng báo: Khe 0 đang phát nhạc, Khe 1 bắt
    // đầu phát tiếp thì bị "player spinner" treo mãi — ĐÃ KIỂM TRA: KHÔNG
    // PHẢI rò rỉ dữ liệu giữa 2 tiến trình, mỗi khe chạy GeckoRuntime +
    // profile hoàn toàn riêng, đã có CookieLeakDetector.kt xác nhận cách ly
    // đúng bằng test thật).
    //
    // TỰ SỬA LẠI (người dùng chất vấn đúng — bản trước viết "Gecko-native
    // tự ý xin AUDIOFOCUS_GAIN, ngoài tầm kiểm soát Kotlin" mà CHƯA hề tra
    // cứu xác nhận, chỉ là suy đoán): đã web_search và đọc trực tiếp
    // Bugzilla Mozilla #1545817 ("GeckoView never requests audio focus, so
    // YouTube plays over other audio apps") — bug này đã ĐÓNG WONTFIX với
    // kết luận rõ ràng từ chính GV team: "WONTFIX because the GV team says
    // this is an app bug" — tức là GeckoView KHÔNG HỀ tự request Audio
    // Focus, đây là trách nhiệm CỦA APP NHÚNG (đúng là code Kotlin này),
    // không phải nằm ở tầng native ngoài tầm với như đã viết sai trước đó.
    //
    // Điều này cũng làm SUY YẾU giả thuyết gốc: nếu GeckoView không tự xin
    // Audio Focus, thì hệ thống Android sẽ KHÔNG tự gửi LOSS/LOSS_TRANSIENT
    // cho Khe 0 khi Khe 1 phát — vì trước patch này, KHÔNG ai xin Focus cả,
    // nghĩa là tranh chấp Audio Focus có thể KHÔNG PHẢI nguyên nhân gốc
    // thật của "player spinner". Đã tìm thêm 1 báo cáo cùng triệu chứng ở
    // chính GitHub issue mozilla/geckoview#203 ("Play multiple videos... 
    // when a video starts playing the other is interrupted") — xảy ra
    // NGAY CẢ trong 1 tiến trình (2 GeckoView cùng activity), càng cho
    // thấy nguyên nhân nhiều khả năng nằm ở tranh chấp TÀI NGUYÊN PHẦN
    // CỨNG (audio HAL/AudioTrack, số phiên decoder đồng thời tối đa của
    // thiết bị) chứ không phải riêng Audio Focus ở tầng hệ điều hành.
    //
    // Patch dưới đây (tự request AudioFocusRequest ở tầng Kotlin) vẫn ĐÚNG
    // HƯỚNG theo đúng khuyến nghị chính thức của Mozilla (app phải tự làm
    // việc này, không phải Gecko) — nhưng KHÔNG CÒN CHẮC nó giải quyết
    // được triệu chứng spinner cụ thể đã gặp, vì nguyên nhân thật có thể
    // nằm ở tầng phần cứng/driver, ngoài tầm với của AudioManager Java API.
    // CẦN log "AudioFocus đổi" thật khi tái hiện lỗi để biết chắc — nếu
    // log không thấy LOSS/LOSS_TRANSIENT nào xảy ra đúng lúc Khe 1 phát,
    // xác nhận đúng giả thuyết mới (tranh chấp phần cứng, không phải Audio
    // Focus) và patch này sẽ KHÔNG giúp được gì, cần hướng khác hoàn toàn.
    private var audioFocusRequest: android.media.AudioFocusRequest? = null

    private fun requestNonExclusiveAudioFocus() {
        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.O) return
        try {
            val am = context.getSystemService(Context.AUDIO_SERVICE) as? android.media.AudioManager ?: return
            val attrs = android.media.AudioAttributes.Builder()
                .setUsage(android.media.AudioAttributes.USAGE_MEDIA)
                .setContentType(android.media.AudioAttributes.CONTENT_TYPE_MUSIC)
                .build()
            val request = android.media.AudioFocusRequest.Builder(android.media.AudioManager.AUDIOFOCUS_GAIN)
                .setAudioAttributes(attrs)
                .setAcceptsDelayedFocusGain(false)
                .setWillPauseWhenDucked(false)
                .setOnAudioFocusChangeListener { focusChange ->
                    // CHỦ Ý bỏ qua LOSS/LOSS_TRANSIENT — chỉ log để chẩn
                    // đoán, không tự pause/dừng gì ở tầng Kotlin.
                    DebugLog.log("Khe $slotIndex: AudioFocus đổi = $focusChange (bỏ qua, không tự pause)")
                }
                .build()
            audioFocusRequest = request
            val result = am.requestAudioFocus(request)
            DebugLog.log(
                "Khe $slotIndex: requestAudioFocus() kết quả = $result " +
                    "(${if (result == android.media.AudioManager.AUDIOFOCUS_REQUEST_GRANTED) "GRANTED" else "FAILED/DELAYED"})"
            )
        } catch (e: Exception) {
            DebugLog.log("Khe $slotIndex: requestNonExclusiveAudioFocus() lỗi: ${e.message}")
        }
    }

    private fun tabIdFor(session: GeckoSession): String? =
        tabs.entries.firstOrNull { it.value === session }?.key

    // Extension eval_bridge đã đăng ký — lưu lại để gắn message delegate
    // CHO TỪNG SESSION khi tạo (xem attachEvalBridgeToSession bên dưới).
    private var evalBridgeExtension: WebExtension? = null

    private val evalBridgeContentDelegate = object : MessageDelegate {
        override fun onConnect(port: Port) {
            evalPorts.add(port)
            /**
             * BUG THẬT (tìm qua tự đối chiếu code với chính comment của nó):
             * comment ở `attachEvalBridgeToSession` phía trên tự nói "chỉ tin
             * khi build lại, log THẬT SỰ có dòng xác nhận connect" — nhưng
             * dòng log đó CHƯA TỪNG được viết ra ở đây. Hệ quả: log của
             * người dùng liên tục ghi "0 port đang mở" ở MỌI request, nhưng
             * không có cách nào phân biệt được 2 khả năng: (a) fix session-
             * delegate (dòng 2362) chưa từng chạy tới (APK cũ) hay (b) fix
             * ĐÃ chạy nhưng `onConnect` vẫn không được Gecko gọi vì lý do
             * khác. Thêm log để lần build tới trả lời dứt điểm câu hỏi này.
             */
            DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN eval_bridge] port CONNECT được (tabId=${port.sender?.session?.let { tabIdFor(it) } ?: "không xác định session"}, tổng số port đang mở=${evalPorts.size})")
            // FIX HIỆU NĂNG: map port này thuộc tab nào ngay lúc connect —
            // dùng port.sender.session (API xác nhận thật qua javadoc chính
            // thức Mozilla, xem chú thích ở khai báo `portTabId`). Nếu
            // session null (lý thuyết là background script — không nên xảy
            // ra ở đây vì eval_bridge chỉ đăng ký content_scripts, không có
            // background script, nhưng vẫn phòng hờ) thì không map được,
            // evaluateJsForTab() sẽ tự fallback broadcast cho port này.
            val session = port.sender?.session
            if (session != null) {
                tabIdFor(session)?.let { tabId -> portTabId[port] = tabId }
            }
            port.setDelegate(object : PortDelegate {
                override fun onPortMessage(message: Any, port: Port) {
                    if (message is JSONObject) {
                        // Xem chú thích "TÍNH NĂNG MỚI" ở content.js — nhánh
                        // này xử lý message TỰ NGUYỆN báo tên file từ thuộc
                        // tính `download` trên <a>, KHÔNG phải trả lời cho
                        // lệnh eval nào (không có requestId để khớp).
                        if (message.optString("type", "") == "download_hint") {
                            val href = message.optString("href", "")
                            val filename = message.optString("filename", "")
                            if (href.isNotBlank() && filename.isNotBlank()) {
                                downloadFilenameHints[href] = filename to System.currentTimeMillis()
                                DebugLog.log("Khe $slotIndex: nhận download_hint từ content script — href=$href, filename=$filename")
                            }
                            return
                        }
                        val result = message.optString("result", null)
                        val requestId = message.optInt("requestId", -1)
                        val sourceUrl = message.optString("sourceUrl", "")
                        if (requestId >= 0) {
                            // .remove() thay vì chỉ đọc — đảm bảo callback CHỈ
                            // chạy 1 LẦN dù `all_frames:true` có thể khiến
                            // nhiều frame cùng phản hồi cho cùng 1 requestId
                            // (mỗi frame tự có port riêng, script chạy ở mọi
                            // frame nên có thể có nhiều phản hồi cho 1 yêu cầu).
                            val entry = evalCallbacks.remove(requestId)
                            if (entry != null) {
                                val (expectedTabId, cb) = entry
                                // BUG THẬT (xem chú thích đầy đủ ở content.js
                                // và khai báo evalCallbacks phía trên): khi
                                // fallback broadcast gửi lệnh tới MỌI tab,
                                // tab SAI có thể trả lời trước tab đích —
                                // đối chiếu sourceUrl (URL THẬT nơi script
                                // vừa chạy) với URL hiện tại của tab đích
                                // TRƯỚC khi tin kết quả. Chỉ so sánh host
                                // (không so cả URL đầy đủ) — đủ để phát hiện
                                // "trả lời từ tab hoàn toàn khác trang", vẫn
                                // chấp nhận nếu chỉ khác query/path do cùng
                                // trang đổi nhẹ giữa lúc gửi và lúc nhận.
                                val expectedHost = expectedTabId?.let { tabMeta[it]?.url }
                                    ?.let { try { java.net.URI(it).host } catch (e: Exception) { null } }
                                val actualHost = sourceUrl.takeIf { it.isNotBlank() }
                                    ?.let { try { java.net.URI(it).host } catch (e: Exception) { null } }
                                /**
                                 * BUG THẬT tìm thêm được (người dùng chụp ảnh
                                 * xác nhận: tab claude.ai hiện favicon Google
                                 * "G" dù cơ chế đối chiếu `sourceUrl` này đã
                                 * có sẵn): điều kiện gốc chỉ TỪ CHỐI khi CẢ
                                 * `expectedHost` LẪN `actualHost` đều xác định
                                 * được VÀ khác nhau — nghĩa là nếu `actualHost`
                                 * là `null` (content script ở tab kia không
                                 * gửi được `sourceUrl` hợp lệ — dễ xảy ra ở
                                 * trang có iframe/sandbox như luồng đăng nhập
                                 * Google, `location.href` có thể ném exception
                                 * hoặc rỗng trong ngữ cảnh đó), code CŨ rơi
                                 * thẳng vào nhánh `else` — TỰ ĐỘNG CHẤP NHẬN
                                 * kết quả, dù hoàn toàn không xác minh được nó
                                 * đến từ đúng tab hay không. Đây là thiết kế
                                 * "fail-open" (mặc định tin tưởng khi không
                                 * chắc) — SAI hướng cho 1 cơ chế an toàn.
                                 * Sửa thành "fail-closed": nếu ta CÓ
                                 * `expectedHost` (biết rõ tab đích là trang
                                 * nào) nhưng KHÔNG xác minh được `actualHost`
                                 * (không rõ phản hồi đến từ đâu), từ chối
                                 * luôn — thà bỏ lỡ 1 lượt favicon (sẽ tự thử
                                 * lại, xem `attempt < 3` ở MainActivity) còn
                                 * hơn gán nhầm favicon từ tab khác.
                                 */
                                val suspicious = expectedHost != null && (actualHost == null || expectedHost != actualHost)
                                if (suspicious) {
                                    DebugLog.log(
                                        "Khe $slotIndex: [CHẨN ĐOÁN cross-tab] BỎ kết quả eval vì sourceUrl khác tab đích hoặc không xác minh được " +
                                            "(mong đợi host=$expectedHost, thực nhận host=$actualHost, requestId=$requestId) " +
                                            "— khả năng broadcast fallback trả lời từ tab khác, không dùng kết quả sai này"
                                    )
                                    cb.invoke(null)
                                } else {
                                    cb.invoke(result)
                                }
                            }
                        }
                    }
                }

                override fun onDisconnect(port: Port) {
                    evalPorts.remove(port)
                    portTabId.remove(port)
                }
            })
        }
    }

    /**
     * BUG THẬT tìm ra (sau khi bị người dùng chất vấn đúng — trước đó lỡ ghi
     * "đã xác nhận" khi thật ra chưa từng thấy log "frame mới connect" nào cả):
     * đối chiếu với ví dụ CHÍNH THỨC của Mozilla (firefox-source-docs.mozilla.
     * org/mobile/android/geckoview/consumer/web-extensions.html) — để nhận
     * message từ CONTENT SCRIPT (không phải background script — `eval_bridge`
     * không hề có background script), phải gọi:
     *   `session.webExtensionController.setMessageDelegate(extension, delegate, "browser")`
     * — tức là gắn theo TỪNG SESSION (`GeckoSession.WebExtensionController`,
     * xác nhận có thật qua `WebExtension.SessionController.setMessageDelegate`
     * trong javadoc chính thức) — KHÔNG PHẢI `extension.setMessageDelegate(...)`
     * (gắn theo EXTENSION, chỉ dành cho message từ BACKGROUND SCRIPT).
     *
     * Code cũ dùng nhầm `ext.setMessageDelegate(...)` — đây CHÍNH XÁC là lý do
     * `ensureBuiltIn THÀNH CÔNG` nhưng KHÔNG BAO GIỜ thấy "frame mới connect":
     * content script gọi `connectNative()` gửi đi đúng, nhưng Kotlin lắng nghe
     * SAI kênh (kênh background-script, không ai gửi gì vào đó cả).
     */
    private fun attachEvalBridgeToSession(session: GeckoSession) {
        val ext = evalBridgeExtension ?: return
        try {
            session.webExtensionController.setMessageDelegate(ext, evalBridgeContentDelegate, "browser")
        } catch (e: Exception) {
            DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN nhạc nền] attachEvalBridgeToSession lỗi: ${e.message}")
        }
    }

    private fun setupEvalBridge() {
        DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN nhạc nền] setupEvalBridge() bắt đầu — gọi ensureBuiltIn cho eval_bridge")
        runtime.webExtensionController.ensureBuiltIn(
            "resource://android/assets/eval_bridge/",
            "eval-bridge"
        ).accept({ ext ->
            if (ext == null) {
                DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN nhạc nền] ensureBuiltIn TRẢ VỀ NULL — eval_bridge KHÔNG được đăng ký")
                return@accept
            }
            DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN nhạc nền] ensureBuiltIn THÀNH CÔNG — eval_bridge đã đăng ký")
            evalBridgeExtension = ext
            // Gắn cho MỌI session đã tồn tại từ trước (vì ensureBuiltIn chạy
            // bất đồng bộ — có thể các tab/session đã được tạo xong TRƯỚC
            // khi extension đăng ký xong).
            tabs.values.forEach { attachEvalBridgeToSession(it) }
        }, { throwable ->
            DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN nhạc nền] ensureBuiltIn LỖI: ${throwable?.message}")
        })
    }

    // Extension fingerprint-spoof đã đăng ký — lưu lại để gắn delegate CHO
    // TỪNG SESSION (giống hệt eval_bridge, xem attachEvalBridgeToSession).
    private var fingerprintExtension: WebExtension? = null
    // Port đang mở của TỪNG session — cần để có thể ĐẨY config MỚI theo
    // yêu cầu (VD khi bật/tắt "Xem bằng máy tính" — xem toggleDesktopMode())
    // mà không phải đợi trang tự reload rồi content script tự hỏi lại.
    private val fingerprintPortsBySession = ConcurrentHashMap<GeckoSession, Port>()

    private fun attachFingerprintExtensionToSession(session: GeckoSession) {
        val ext = fingerprintExtension ?: return
        try {
            session.webExtensionController.setMessageDelegate(ext, object : MessageDelegate {
                override fun onConnect(port: Port) {
                    fingerprintPortsBySession[session] = port
                    // Log ĐÚNG như comment ở trên đã tự đề ra làm tiêu chuẩn
                    // xác nhận ("chỉ tin khi... log THẬT SỰ có dòng...") —
                    // trước đây thiếu dòng này nên không ai biết fix
                    // session-delegate có thật sự làm port connect được hay
                    // không, dù comment đã viết sẵn kỳ vọng.
                    DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN fingerprint] fingerprint-spoof content script CONNECT được")
                    port.postMessage(buildFingerprintConfigMessage(session))
                }
            }, "browser")
        } catch (e: Exception) {
            DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN fingerprint] attachFingerprintExtensionToSession lỗi: ${e.message}")
        }
    }

    /**
     * BUG THẬT (cùng loại đã tìm ra và sửa cho eval_bridge, mục 8zq
     * PROJECT_STATUS.md — người dùng hỏi 1 câu về toggleDesktopMode mà lộ
     * ra bug NGHIÊM TRỌNG HƠN cả câu hỏi gốc): `fingerprint-spoof` không có
     * background script, nhưng code CŨ dùng `ext.setMessageDelegate(...)` —
     * kênh CHỈ dành cho background script. Content script gọi
     * `connectNative()` gửi đúng, nhưng Kotlin lắng nghe SAI kênh — rất có
     * khả năng TOÀN BỘ tính năng giả mạo vân tay (`navigator.platform`,
     * `maxTouchPoints`, WebGL, canvas, audio, font, timezone...) CHƯA TỪNG
     * hoạt động thật từ đầu, vì `config.enabled` mặc định `false` trong
     * content.js, chỉ được bật khi nhận được message từ Kotlin — mà message
     * đó chưa bao giờ tới nơi.
     *
     * Cũng bổ sung permission `nativeMessaging`/`nativeMessagingFromContent`/
     * `geckoViewAddons` còn thiếu trong manifest.json (so với `eval_bridge`
     * đã xác nhận hoạt động, có đủ 3 quyền này).
     *
     * CHƯA đánh dấu "đã xác nhận" — theo đúng kỷ luật đã rút ra (mục 8zp):
     * chỉ tin khi build lại, log THẬT SỰ có dòng
     * "[CHẨN ĐOÁN fingerprint] fingerprint-spoof content script CONNECT được".
     */
    private fun setupFingerprintExtension() {
        runtime.webExtensionController.ensureBuiltIn(
            "resource://android/assets/fingerprint_spoof/",
            "fingerprint-spoof"
        ).accept(
            { ext ->
                if (ext == null) {
                    DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN fingerprint] ensureBuiltIn TRẢ VỀ NULL")
                    return@accept
                }
                fingerprintExtension = ext
                tabs.values.forEach { attachFingerprintExtensionToSession(it) }
                DebugLog.log("Fingerprint spoof extension loaded for slot $slotIndex")
            },
            { error -> DebugLog.log("Slot $slotIndex: không đăng ký được fingerprint extension — $error") }
        )
    }

    /**
     * Đẩy lại config MỚI cho content script đang kết nối (nếu có) — dùng khi
     * cần đồng bộ ngay lập tức, không đợi trang tự reload (VD từ
     * `toggleDesktopMode()` — xem sửa đổi ở đó: khi bật desktop mode, TẮT
     * hẳn phần giả platform/touch/webgl thay vì để lộ tổ hợp UA-thật +
     * platform-giả-mobile bất nhất).
     */
    private fun pushFingerprintConfig(session: GeckoSession) {
        val port = fingerprintPortsBySession[session] ?: return
        try {
            port.postMessage(buildFingerprintConfigMessage(session))
        } catch (e: Exception) {
            DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN fingerprint] pushFingerprintConfig lỗi: ${e.message}")
        }
    }

    /**
     * Đọc lựa chọn thật của người dùng (FingerprintSpoofFeature settings) và
     * build message config gửi cho content.js. 1 công tắc chính (fp_enabled)
     * bật/tắt TOÀN BỘ bộ giả lập (hardware+locale+canvas+audio+font+webrtc) —
     * chưa có UI bật/tắt riêng lẻ từng kỹ thuật.
     *
     * CẬP NHẬT (trả lời câu hỏi người dùng về `toggleDesktopMode()` +
     * fingerprint): khi session đang bật "Xem bằng máy tính"
     * (`userAgentMode == USER_AGENT_MODE_DESKTOP`, và tên miền KHÔNG nằm
     * trong danh sách ngoại lệ mobile-layout — xem `applyViewportExceptionForUrl`),
     * `userAgentOverride` đã bị xoá (dùng UA desktop THẬT của GeckoView,
     * xem `toggleDesktopMode()`). Nếu vẫn gửi `platform`/`maxTouchPoints`/
     * WebGL... theo hồ sơ CŨ (có thể là mobile) → tạo ra tổ hợp UA-thật-
     * desktop + platform-giả-mobile — BẤT NHẤT NẶNG, dễ bị soi hơn hẳn so
     * với không giả gì cả. Sửa: khi phát hiện đang ở chế độ desktop-mode-
     * toggle, TẮT hẳn phần `hardware` (để trình duyệt trả về giá trị THẬT
     * của chính điện thoại) — thà lộ đúng 1 thiết bị thật còn hơn lộ 1 tổ
     * hợp giả-thật lẫn lộn không tồn tại trên đời thực.
     */
    private fun buildFingerprintConfigMessage(session: GeckoSession? = null): JSONObject {
        val enabled = FingerprintSpoofFeature.isEnabled(context, slotIndex)
        val desktopModeToggledOn = session?.settings?.userAgentMode == GeckoSessionSettings.USER_AGENT_MODE_DESKTOP &&
            session?.settings?.userAgentOverride == null
        val config = JSONObject().put("enabled", enabled)
        if (enabled) {
            val (hw, locale) = resolveProfile()
            config.put("hardware", !desktopModeToggledOn)
            config.put("spoofLocale", true)
            config.put("canvas", AppPrefs.getBoolean(context, slotIndex, "fp_t_canvas", true))
            config.put("audio", AppPrefs.getBoolean(context, slotIndex, "fp_t_audio", true))
            config.put("font", AppPrefs.getBoolean(context, slotIndex, "fp_t_font", true))
            config.put("webrtc", AppPrefs.getBoolean(context, slotIndex, "fp_t_webrtc", true))
            config.put("uaSync", !desktopModeToggledOn)
            config.put("platform", hw.platform)
            config.put("hardwareConcurrency", hw.hardwareConcurrency)
            config.put("deviceMemory", hw.deviceMemory)
            config.put("maxTouchPoints", hw.maxTouchPoints)
            config.put("screenWidth", hw.screenWidth)
            config.put("screenHeight", hw.screenHeight)
            config.put("colorDepth", hw.colorDepth)
            config.put("pixelRatio", hw.pixelRatio)
            config.put("webglVendor", hw.webglVendor)
            config.put("webglRenderer", hw.webglRenderer)
            config.put("userAgent", hw.userAgent)
            config.put("timezone", locale.timezone)
            config.put("language", locale.language)
            config.put("locale", locale.locale)
            config.put("languages", JSONArray(locale.languages))
            // BUG THẬT người dùng chỉ ra ĐÚNG (bản vá trước của tôi CHƯA
            // hoàn chỉnh — chỉ seed ổn định TRONG 1 lần tải trang, KHÔNG
            // cố định theo hồ sơ như mọi giá trị hardware/locale khác ở
            // trên đã làm đúng từ trước): mỗi lần tải trang MỚI (kể cả
            // cùng 1 hồ sơ, chỉ cách nhau vài giây), seed random cũ tự sinh
            // lại từ `Date.now()` — khác hoàn toàn lần trước, nghĩa là
            // NHIỄU CANVAS/AUDIO/WEBGL ĐỔI KHÁC NHAU MỖI LẦN ĐĂNG NHẬP, dù
            // hardware/locale/UA vẫn giữ nguyên. Đây CHÍNH XÁC là điều
            // người dùng phản ánh và đúng là tôi làm nửa vời — hệ thống
            // chống gian lận chỉ cần thấy TOÀN BỘ fingerprint (bao gồm
            // canvas/audio) ổn định qua nhiều lần ghé thăm mới coi là 1
            // thiết bị thật, không chỉ ổn định trong 1 trang.
            //
            // Sửa ĐÚNG: seed nhiễu giờ lấy từ `getOrCreateNoiseSeedForSlot()`
            // — sinh 1 LẦN DUY NHẤT cho hồ sơ này, LƯU LẠI qua AppPrefs
            // (đúng namespace theo slot, sống sót qua app restart/nhiều
            // ngày, y hệt cách `resolveProfile()` đã làm cho hardware/
            // locale) — không tự sinh lại theo `Date.now()` mỗi lần tải
            // trang nữa.
            config.put("noiseSeed", getOrCreateNoiseSeedForSlot())
        }
        return JSONObject().put("config", config)
    }

    /**
     * Seed nhiễu fingerprint (canvas/audio/WebGL/timing) — sinh 1 lần duy
     * nhất cho MỖI HỒ SƠ (namespace theo slot, qua AppPrefs — cùng cơ chế
     * độ bền dữ liệu mà `resolveProfile()` đã dùng cho hardware profile),
     * KHÔNG sinh lại mỗi lần tải trang. Xem chú thích ở
     * `buildFingerprintConfigMessage()`.
     */
    private fun getOrCreateNoiseSeedForSlot(): Long {
        // Nhất quán với công tắc "Đổi mới mỗi lần mở" (fp_fresh, xem
        // FingerprintSpoofFeature.kt) — nếu người dùng CHỦ Ý bật fresh mode
        // (muốn TOÀN BỘ danh tính, kể cả hardware/locale, đổi mới mỗi lần
        // mở app), seed nhiễu canvas/audio/WebGL cũng PHẢI đổi theo, không
        // được giữ cố định — nếu không sẽ mâu thuẫn nửa vời: hardware đổi
        // mới nhưng nhiễu vẫn y hệt lần trước, tự nó cũng là 1 tín hiệu bất
        // nhất đáng ngờ không kém. Khi fresh=false (mặc định), hành vi giữ
        // nguyên như đã sửa — seed cố định bền theo hồ sơ.
        val fresh = AppPrefs.getBoolean(context, slotIndex, "fp_fresh", false)
        if (!fresh) {
            val existing = AppPrefs.getString(context, slotIndex, "fp_noise_seed", "")
            existing.toLongOrNull()?.let { return it }
        }
        val newSeed = (System.currentTimeMillis() xor (Math.random() * Long.MAX_VALUE).toLong())
        if (!fresh) {
            AppPrefs.setString(context, slotIndex, "fp_noise_seed", newSeed.toString())
        }
        return newSeed
    }

    private fun getFileNameFromUri(uri: Uri): String? {
        var result: String? = null
        if (uri.scheme == "content") {
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val idx = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0) result = cursor.getString(idx)
                }
            }
        }
        if (result == null) {
            result = uri.path?.let { File(it).name }
        }
        return result
    }

    /**
     * Gọi từ MainActivity sau khi Activity chọn file (ACTION_OPEN_DOCUMENT)
     * trả về kết quả — hoàn thành GeckoResult đang treo từ onFilePrompt() để
     * trang web THẬT SỰ nhận được file qua <input type="file"> (khác hẳn
     * cách cũ dispatch 1 CustomEvent tự chế mà trang bình thường không nghe).
     */
    fun resolveFilePrompt(context: Context, uri: Uri?) {
        val prompt = pendingFilePrompt
        val result = pendingFilePromptResult
        pendingFilePrompt = null
        pendingFilePromptResult = null
        if (prompt == null || result == null) {
            // CHẨN ĐOÁN: nếu dòng này xuất hiện, nghĩa là lúc gọi
            // resolveFilePrompt() thì KHÔNG CÒN prompt nào đang chờ — có
            // thể do: (a) đã resolve rồi (gọi 2 lần), hoặc (b) 1
            // onFilePrompt MỚI đã ghi đè pendingFilePrompt trước khi lượt
            // cũ kịp resolve (2 lần chọn file liên tiếp, lượt đầu chưa xong
            // copy nền thì lượt 2 đã bắt đầu) — nếu đúng vậy thì lượt ĐẦU sẽ
            // luôn "biến mất" không dấu vết, đúng như người dùng mô tả.
            DebugLog.log("resolveFilePrompt: KHÔNG CÒN prompt đang chờ (đã resolve rồi, hoặc bị 1 onFilePrompt mới ghi đè trước khi resolve) — bỏ qua, uri=$uri")
            return
        }
        val response = if (uri != null) prompt.confirm(context, uri) else prompt.dismiss()
        result.complete(response)
        DebugLog.log("resolveFilePrompt: đã ${if (uri != null) "confirm" else "dismiss"} prompt thành công")
    }

    /**
     * FIX BUG THẬT (đúng người dùng báo — xem chú thích lớn ở
     * `onFilePromptListener`): dùng đúng overload `FilePrompt.confirm(Context,
     * Uri[])` — XÁC NHẬN CÓ THẬT qua tài liệu chính thức GeckoView Javadoc
     * ("Confirms the prompt and passes the file URIs back to content") —
     * để trả về NHIỀU file cùng lúc cho trang web, thay vì luôn chỉ gọi
     * overload 1-Uri (`confirm(Context, Uri)`) khiến trang chỉ NHẬN ĐƯỢC
     * ĐÚNG 1 FILE dù người dùng đã chọn/kéo-thả nhiều file.
     */
    fun resolveFilePromptMultiple(context: Context, uris: Array<Uri>?) {
        val prompt = pendingFilePrompt
        val result = pendingFilePromptResult
        pendingFilePrompt = null
        pendingFilePromptResult = null
        if (prompt == null || result == null) {
            DebugLog.log("resolveFilePromptMultiple: KHÔNG CÒN prompt đang chờ — bỏ qua, uris=${uris?.size}")
            return
        }
        val response = if (uris != null && uris.isNotEmpty()) prompt.confirm(context, uris) else prompt.dismiss()
        result.complete(response)
        DebugLog.log("resolveFilePromptMultiple: đã ${if (uris != null && uris.isNotEmpty()) "confirm (${uris.size} file)" else "dismiss"} prompt thành công")
    }

    fun release() {
        stopAutoBehavior()
        tabs.values.forEach { it.close() }
        tabs.clear()
        tabMeta.clear()
        // Dọn dẹp nativeMediaSession và mediaActionReceiver khi khe đóng.
        // Quan trọng: nếu không release, nativeMediaSession vẫn "sống" trong
        // hệ thống MediaSession của Android, nhưng nativeMediaSession.controller
        // trỏ về object đã bị GC — bấm nút từ widget màn hình khoá sau khi
        // app restart sẽ gọi callback vào nativeMediaSession cũ (null hoặc
        // instance cũ trong process mới), không có tác dụng. Release đúng lúc
        // shutdown đảm bảo lần khởi động tiếp theo, ensureNativeMediaSession()
        // tạo instance mới sạch và isActive được set đúng khi có media event.
        try {
            nativeMediaSession?.isActive = false
            nativeMediaSession?.release()
        } catch (e: Exception) {
            DebugLog.log("Khe $slotIndex: release() — nativeMediaSession.release() lỗi: ${e.message}")
        }
        nativeMediaSession = null
        currentGeckoMediaSession = null
        currentGeckoMediaSessionTabId = null
        if (mediaActionReceiverRegistered) {
            try { context.unregisterReceiver(mediaActionReceiver) } catch (_: Exception) {}
            mediaActionReceiverRegistered = false
        }
        // Xoá notification media còn sót (nếu khe bị đóng khi đang tạm dừng —
        // lúc đó MediaKeepAliveService không chạy nhưng notification vẫn còn qua nm.notify).
        try {
            val nm = context.getSystemService(android.app.NotificationManager::class.java)
            nm.cancel(2000 + slotIndex)
        } catch (_: Exception) {}
        // FIX BUG THẬT (xem giải thích đầy đủ ở `rebindView()`/`hasLiveTabs()`
        // phía dưới) — release() nghĩa là khe ĐÓNG HẲN THẬT SỰ (người dùng
        // chủ động đóng, hoặc gán lại profile), nên PHẢI gỡ khỏi registry
        // `instances`. Thiếu dòng này, lần mở khe MỚI (thật sự mới, không
        // phải Activity bị Android tự huỷ+tạo lại) sẽ tìm thấy 1 entry CŨ đã
        // `release()` (tabs/sessions đã đóng hết) trong `forSlot()`, tưởng
        // nhầm là "engine đang sống" rồi cố gắn vào — hỏng hoàn toàn.
        instances.remove(slotIndex)
    }

    /**
     * FIX BUG THẬT NGHIÊM TRỌNG (người dùng báo: chuyển sang app khác/vào
     * Cài đặt lấy log, quay lại thì TOÀN BỘ tab bị tải lại từ đầu — kể cả
     * tab vừa bật chế độ máy tính cũng mất luôn trạng thái đó). Nguyên nhân
     * THẬT (đọc code xác nhận, không đoán): `MainActivity.setupEngine()`
     * trước đây LUÔN gọi `GeckoViewEngine(this, geckoView, slotIndex)` —
     * tạo hẳn 1 instance MỚI, map `tabs`/`tabMeta` RỖNG — mỗi khi
     * `onCreate()` chạy lại. Trong khi đó `GeckoRuntimeProvider` (runtime
     * Gecko thật) CÓ cache theo tiến trình (`runtimes` map), sống sót qua
     * việc Activity bị Android tự thu hồi rồi tạo lại (rất hay gặp — xem
     * `onDestroy()` log "isFinishing=false (Android tự thu hồi Activity
     * nền)") — CHỈ RIÊNG lớp `GeckoViewEngine` (nơi giữ danh sách tab/
     * session THẬT đang chạy) là KHÔNG được tái sử dụng, bị bỏ rơi (leak)
     * rồi Activity mới lại tự đi phục hồi tab từ file JSON đã lưu — y hệt
     * như vừa khởi động lại thật, mất mọi trạng thái CHỈ SỐNG TRONG RAM (vd
     * cờ "chế độ máy tính THỦ CÔNG" của 1 tab, `manualDesktopTabIds`).
     *
     * Sửa: `rebindView()` được gọi từ `MainActivity.setupEngine()` khi tìm
     * thấy 1 instance CÒN SỐNG qua `forSlot()` (registry vốn đã có sẵn từ
     * trước, dùng cho `FingerprintSpoofFeature` — chỉ là chưa ai tận dụng
     * nó để TÁI SỬ DỤNG thay vì tạo mới) — trỏ lại field `geckoView` sang
     * `GeckoView` widget MỚI (widget cũ đã chết cùng Activity cũ), rồi gắn
     * lại đúng session đang active vào widget mới này
     * (`newView.setSession(...)`) — y hệt bước "rebind" đã dùng ở
     * `recoverKilledOrCrashedSession()` cho trường hợp onKill/onCrash, cùng
     * 1 bản chất vấn đề (View mới, Session cũ vẫn sống, cần nối lại).
     */
    fun rebindView(newView: GeckoView) {
        geckoView = newView
        val activeSession = activeTabId?.let { tabs[it] }
        if (activeSession != null) {
            activeSession.setActive(true)
            geckoView.setSession(activeSession)
            DebugLog.log("Khe $slotIndex: rebindView() — đã gắn lại session của tab đang active vào GeckoView mới, KHÔNG tải lại gì cả")
        } else {
            DebugLog.log("Khe $slotIndex: rebindView() — không có activeTabId/session nào để gắn (bất thường, kiểm tra thêm nếu thấy màn hình trắng)")
        }
    }

    /** Có tab nào đang sống trong RAM hay không — dùng ở `MainActivity.
     * onCreate()` để quyết định có cần restoreTabsIfAny()/tạo tab trang chủ
     * hay không khi vừa rebind vào 1 engine cũ (đã có sẵn tab, không cần
     * làm gì thêm). */
    fun hasLiveTabs(): Boolean = tabs.isNotEmpty()

    /**
     * Cấu hình proxy cho slot này qua eval bridge.
     * Đồng thời setup DNS over HTTPS + timezone.
     */
    /**
     * Proxy riêng theo khe THỰC SỰ được áp dụng — nhưng KHÔNG phải ở đây.
     * Việc đăng ký thật xảy ra tự động trong `GeckoRuntimeProvider.createRuntime()`
     * (đọc proxy_host/proxy_port/... từ AppPrefs, đăng ký WebExtension
     * `proxy_config` dùng browser.proxy.onRequest) ngay khi runtime của khe
     * được tạo lần đầu trong tiến trình.
     *
     * Hàm này chỉ còn tác dụng NHẮC người dùng khởi động lại khe để áp dụng
     * thay đổi vừa lưu — GeckoRuntime của khe đã tồn tại trong tiến trình
     * hiện tại thì không thể đăng ký lại extension với cấu hình mới cho tới
     * khi tiến trình khởi động lại (đóng khe rồi mở lại).
     */
    fun setupProxy(host: String, port: Int, user: String = "", pass: String = "") {
        DebugLog.log(
            "Proxy $host:$port đã lưu cho khe $slotIndex — cần KHỞI ĐỘNG LẠI khe " +
                "(đóng rồi mở lại) để GeckoRuntimeProvider đăng ký WebExtension proxy_config mới."
        )
    }

    fun clearProxy() {
        DebugLog.log("Đã xoá cấu hình proxy cho khe $slotIndex — cần khởi động lại khe để áp dụng.")
    }
}
