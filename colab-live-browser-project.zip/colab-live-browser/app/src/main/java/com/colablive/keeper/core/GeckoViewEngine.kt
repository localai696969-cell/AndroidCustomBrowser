package com.colablive.keeper.core

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.util.Log
import org.json.JSONObject
import org.mozilla.geckoview.*
import org.mozilla.geckoview.WebResponse
import org.mozilla.geckoview.WebExtension.MessageDelegate
import org.mozilla.geckoview.WebExtension.Port
import org.mozilla.geckoview.WebExtension.PortDelegate
import java.io.File
import java.io.FileOutputStream
import java.util.*
import java.util.concurrent.ConcurrentHashMap

class GeckoViewEngine(
    private val context: Context,
    private val geckoView: GeckoView,
    private val slotIndex: Int
) : BrowserEngine {

    private val runtime: GeckoRuntime = GeckoRuntimeProvider.get(context, slotIndex)
    private val tabs = ConcurrentHashMap<String, GeckoSession>()
    private val tabMeta = ConcurrentHashMap<String, BrowserTab>()
    private var activeTabId: String? = null
    private val handler = Handler(Looper.getMainLooper())
    private val random = Random(slotIndex.toLong())

    private var evalCallback: ((String?) -> Unit)? = null
    private var evalPort: Port? = null

    var onPageLoadedListener: ((String) -> Unit)? = null
    var onPageErrorListener: ((String, Int) -> Unit)? = null
    var onTitleChangedListener: ((String) -> Unit)? = null
    var onProgressChangedListener: ((Int) -> Unit)? = null
    var onNewTabRequestedListener: ((String) -> Unit)? = null
    var onDownloadRequestedListener: ((String, String) -> Unit)? = null
    var onFilePromptListener: ((Array<String>?) -> Unit)? = null

    private var _canGoBack = false
    private var _canGoForward = false
    private var _currentUrl: String? = null

    init {
        setupEvalBridge()
        setupFingerprintExtension()
    }

    override fun currentUrl(): String? = _currentUrl

    override fun evaluateJs(script: String, callback: ((String?) -> Unit)?) {
        evalCallback = callback
        evalPort?.postMessage(JSONObject().apply {
            put("action", "eval")
            put("script", script)
        })
    }

    override fun loadUrl(url: String) {
        activeTabId?.let { tabId ->
            tabs[tabId]?.loadUri(url)
            tabMeta[tabId]?.url = url
        }
    }

    override fun reload() { activeTabId?.let { tabs[it]?.reload() } }

    override fun goBack(): Boolean {
        val session = activeTabId?.let { tabs[it] } ?: return false
        if (_canGoBack) { session.goBack(); return true }
        return false
    }

    override fun goForward(): Boolean {
        val session = activeTabId?.let { tabs[it] } ?: return false
        if (_canGoForward) { session.goForward(); return true }
        return false
    }

    override fun canGoBack(): Boolean = _canGoBack
    override fun canGoForward(): Boolean = _canGoForward

    override fun createTab(url: String): BrowserTab {
        val tabId = UUID.randomUUID().toString()
        val session = createSession()
        val tab = BrowserTab(id = tabId, url = url)
        tabs[tabId] = session
        tabMeta[tabId] = tab
        if (activeTabId == null) switchToTab(tabId)
        session.loadUri(url)
        return tab
    }

    override fun closeTab(tabId: String) {
        tabs[tabId]?.let { session ->
            session.close()
        }
        tabs.remove(tabId)
        tabMeta.remove(tabId)
        if (activeTabId == tabId) {
            activeTabId = tabs.keys.firstOrNull()
            activeTabId?.let { switchToTab(it) }
        }
    }

    override fun switchToTab(tabId: String) {
        val session = tabs[tabId] ?: return
        activeTabId = tabId
        geckoView.setSession(session)
    }

    override fun getTabs(): List<BrowserTab> = tabMeta.values.toList()
    override fun getActiveTab(): BrowserTab? = activeTabId?.let { tabMeta[it] }

    override fun handleDropUri(uri: Uri, mimeType: String?) {
        val actualMime = mimeType ?: context.contentResolver.getType(uri) ?: "*/*"
        try {
            val fileName = getFileNameFromUri(uri) ?: "dropped_file"
            val tempFile = File(context.cacheDir, "drops/$fileName")
            tempFile.parentFile?.mkdirs()
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(tempFile).use { output -> input.copyTo(output) }
            }
            val js = "(function() { var inputs = document.querySelectorAll('input[type=\"file\"]'); if (inputs.length > 0) { window.dispatchEvent(new CustomEvent('livebrowser:filedrop', { detail: { path: '" + tempFile.absolutePath + "', mime: '" + actualMime + "' } })); return 'file_drop_triggered'; } return 'no_file_input'; })()"
            evaluateJs(js) { result -> DebugLog.log("Drop file: $fileName -> $result") }
        } catch (e: Exception) { DebugLog.log("Drop file error: ${e.message}") }
    }

    fun this@GeckoViewEngine.startAutoBehavior() {
        if (!AppPrefs.getBoolean(context, slotIndex, "auto_behavior", false)) return
        val behaviorRunnable = object : Runnable {
            override fun run() {
                if (!AppPrefs.getBoolean(context, slotIndex, "auto_behavior", false)) return
                val actions = listOf(
                    "window.scrollBy(0, " + random.nextInt(100, 500) + ");",
                    "window.scrollBy(0, -" + random.nextInt(50, 300) + ");",
                    "document.querySelector('button, a, input')?.focus();",
                    "document.body.click();",
                    "window.scrollTo(0, document.body.scrollHeight * " + random.nextDouble() + ");"
                )
                evaluateJs(actions[random.nextInt(actions.size)]) {}
                handler.postDelayed(this, (5000 + random.nextInt(25000)).toLong())
            }
        }
        handler.postDelayed(behaviorRunnable, 10000)
        DebugLog.log("Auto behavior started for slot $slotIndex")
    }

    fun stopAutoBehavior() { handler.removeCallbacksAndMessages(null) }

    private fun createSession(): GeckoSession {
        val settings = GeckoSessionSettings.Builder()
            .usePrivateMode(false)
            .useTrackingProtection(true)
            .suspendMediaWhenInactive(false)
            .contextId("slot_${slotIndex}")
            .build()
        val session = GeckoSession(settings)

        session.progressDelegate = object : GeckoSession.ProgressDelegate {
            override fun onPageStart(session: GeckoSession, url: String) {
                activeTabId?.let { tabMeta[it]?.isLoading = true }
                onProgressChangedListener?.invoke(0)
            }
            override fun onPageStop(session: GeckoSession, success: Boolean) {
                activeTabId?.let { tabMeta[it]?.isLoading = false }
                onProgressChangedListener?.invoke(100)
                if (success) {
                    val url = _currentUrl ?: ""
                    activeTabId?.let { id -> tabMeta[id]?.url = url }
                    onPageLoadedListener?.invoke(url)
                    this@GeckoViewEngine.startAutoBehavior()
                }
            }
            override fun onProgressChange(session: GeckoSession, progress: Int) {
                onProgressChangedListener?.invoke(progress)
            }
            override fun onSecurityChange(session: GeckoSession, securityInfo: GeckoSession.ProgressDelegate.SecurityInformation) {}
        }

        session.navigationDelegate = object : GeckoSession.NavigationDelegate {
            override fun onLoadRequest(session: GeckoSession, request: GeckoSession.NavigationDelegate.LoadRequest): GeckoResult<AllowOrDeny> {
                DebugLog.log("onLoadRequest: ${request.uri}")
                return GeckoResult.allow()
            }
            override fun onLoadError(session: GeckoSession, uri: String?, error: WebRequestError): GeckoResult<String> {
                DebugLog.log("onLoadError: $uri - code=${error.code}")
                onPageErrorListener?.invoke(uri ?: "", error.code)
                return GeckoResult.fromValue(null)
            }
            override fun onNewSession(session: GeckoSession, uri: String): GeckoResult<GeckoSession> {
                DebugLog.log("onNewSession (popup): $uri")
                handler.post { onNewTabRequestedListener?.invoke(uri) }
                return GeckoResult.fromValue(null)
            }
            override fun onLocationChange(session: GeckoSession, url: String?, perms: List<GeckoSession.PermissionDelegate.ContentPermission>, hasUserGesture: Boolean) {
                _currentUrl = url
            }
            override fun onCanGoBack(session: GeckoSession, canGoBack: Boolean) {
                _canGoBack = canGoBack
            }
            override fun onCanGoForward(session: GeckoSession, canGoForward: Boolean) {
                _canGoForward = canGoForward
            }
        }

        session.contentDelegate = object : GeckoSession.ContentDelegate {
            override fun onTitleChange(session: GeckoSession, title: String?) {
                title?.let {
                    activeTabId?.let { id -> tabMeta[id]?.title = it }
                    onTitleChangedListener?.invoke(it)
                }
            }
            override fun onContextMenu(session: GeckoSession, screenX: Int, screenY: Int, element: GeckoSession.ContentDelegate.ContextElement) {}
            override fun onExternalResponse(session: GeckoSession, response: WebResponse) {
                response.uri?.let { uri ->
                    val fileName = uri.substringAfterLast("/").takeIf { it.isNotEmpty() } ?: "download"
                    onDownloadRequestedListener?.invoke(uri, fileName)
                }
            }
            override fun onFilePrompt(session: GeckoSession, title: String?, type: Int, mimeTypes: Array<String>?, capture: Int, callback: GeckoSession.PromptDelegate.FileCallback) {
                val fixedMimeTypes = mimeTypes?.map { if (it.contains("/")) it else "*/*" }?.toTypedArray()
                onFilePromptListener?.invoke(fixedMimeTypes)
            }
            override fun onCrash(session: GeckoSession) { DebugLog.log("Session crashed!") }
            override fun onKill(session: GeckoSession) { DebugLog.log("Session killed by system") }
        }

        session.open(runtime)
        return session
    }

    private fun setupEvalBridge() {
        runtime.webExtensionController.ensureBuiltIn(
            Uri.parse("resource://android/assets/eval_bridge/"), "eval-bridge"
        ).accept { ext ->
            ext?.setMessageDelegate(object : MessageDelegate {
                override fun onConnect(port: Port) {
                    evalPort = port
                    port.setDelegate(object : PortDelegate {
                        override fun onPortMessage(message: Any, port: Port) {
                            if (message is JSONObject) {
                                evalCallback?.invoke(message.optString("result", null))
                            }
                        }
                    })
                }
            }, "browser")
        }
    }

    private fun setupFingerprintExtension() {
        runtime.webExtensionController.ensureBuiltIn(
            Uri.parse("resource://android/assets/fingerprint_spoof/"), "fingerprint-spoof"
        ).accept { ext -> DebugLog.log("Fingerprint spoof extension loaded for slot $slotIndex") }
    }

    private fun getFileNameFromUri(uri: Uri): String? {
        var result: String? = null
        if (uri.scheme == "content") {
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val idx = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0) result = cursor.getString(idx)
                }
            }
        }
        if (result == null) result = uri.path?.let { File(it).name }
        return result
    }

    fun release() {
        stopAutoBehavior()
        tabs.values.forEach { it.close() }
        tabs.clear(); tabMeta.clear()
    }

    fun setupProxy(host: String, port: Int, user: String = "", pass: String = "") {
        val js = buildString {
            append("Services.prefs.setIntPref(\"network.proxy.type\", 1);")
            append("Services.prefs.setCharPref(\"network.proxy.http\", \"$host\");")
            append("Services.prefs.setIntPref(\"network.proxy.http_port\", $port);")
            append("Services.prefs.setCharPref(\"network.proxy.ssl\", \"$host\");")
            append("Services.prefs.setIntPref(\"network.proxy.ssl_port\", $port);")
            append("Services.prefs.setCharPref(\"network.proxy.socks\", \"$host\");")
            append("Services.prefs.setIntPref(\"network.proxy.socks_port\", $port);")
            if (user.isNotEmpty()) {
                append("Services.prefs.setCharPref(\"network.proxy.http_username\", \"$user\");")
                append("Services.prefs.setCharPref(\"network.proxy.http_password\", \"$pass\");")
            }
            append("Services.prefs.setBoolPref(\"network.proxy.socks_remote_dns\", true);")
            append("Services.prefs.setIntPref(\"network.trr.mode\", 2);")
            append("Services.prefs.setCharPref(\"network.trr.uri\", \"https://mozilla.cloudflare-dns.com/dns-query\");")
            append("Services.prefs.setBoolPref(\"network.trr.wait-for-portal\", false);")
            val tz = AppPrefs.getString(context, slotIndex, "fp_timezone", "")
            if (tz.isNotEmpty()) append("Services.prefs.setCharPref(\"intl.timezone.default\", \"$tz\");")
        }
        evaluateJs(js) { DebugLog.log("Network setup for slot $slotIndex: proxy=$host:$port") }
    }

    fun clearProxy() {
        evaluateJs("Services.prefs.setIntPref(\"network.proxy.type\", 0);") {
            DebugLog.log("Proxy cleared for slot $slotIndex")
        }
    }
}
