package com.colablive.keeper.features.colablive

import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.widget.*
import com.colablive.keeper.core.AppPrefs
import com.colablive.keeper.core.BrowserFeature
import com.colablive.keeper.core.DebugLog

class ColabLiveKeeperFeature : BrowserFeature {

    override val id = "colab_live_keeper"
    override val displayName = "Colab Live Keeper"
    override val description = "Giu phien Colab song khi chuyen app/tat man hinh"

    companion object {
        const val MODE_DOM = "dom"
        const val MODE_ACCESSIBILITY = "accessibility"
        private const val KEY_MODE = "mode"
        private const val KEY_INTERVAL = "interval_minutes"
        private const val KEY_ENABLED = "enabled"
        private const val DEFAULT_INTERVAL = 20
    }

    private val targetTexts = listOf("Connect", "Ket noi", "Reconnect", "Ket noi lai")

    private val keepAliveScript = "(function() { var btn = document.querySelector('colab-connect-button, #connect, [class*=\"connect\"]'); if (btn) { btn.click(); } document.dispatchEvent(new MouseEvent('mousemove', {bubbles:true})); window.dispatchEvent(new Event('scroll')); })();"

    private val overrideVisibilityScript = "(function() { Object.defineProperty(document, 'hidden', { get: function() { return false; } }); Object.defineProperty(document, 'visibilityState', { get: function() { return 'visible'; } }); document.dispatchEvent(new Event('visibilitychange')); })();"

    override fun isEnabled(context: Context, slotIndex: Int) =
        AppPrefs.getBoolean(context, slotIndex, id, KEY_ENABLED, false)

    override fun setEnabled(context: Context, slotIndex: Int, enabled: Boolean) =
        AppPrefs.setBoolean(context, slotIndex, id, KEY_ENABLED, enabled)

    fun getMode(context: Context, slotIndex: Int) =
        AppPrefs.getString(context, slotIndex, id, KEY_MODE, MODE_DOM)

    fun setMode(context: Context, slotIndex: Int, mode: String) =
        AppPrefs.setString(context, slotIndex, id, KEY_MODE, mode)

    override fun intervalMinutes(context: Context, slotIndex: Int) =
        AppPrefs.getInt(context, slotIndex, id, KEY_INTERVAL, DEFAULT_INTERVAL)

    fun setIntervalMinutes(context: Context, slotIndex: Int, minutes: Int) =
        AppPrefs.setInt(context, slotIndex, id, KEY_INTERVAL, minutes)

    override fun accessibilityTargetTexts(context: Context, slotIndex: Int): List<String> = targetTexts

    override fun matchesUrl(url: String): Boolean {
        return url.contains("colab.research.google.com") ||
            url.contains("github.dev") ||
            url.contains("vscode.dev")
    }

    override fun onPageLoaded(context: Context, slotIndex: Int, url: String) {
        if (!isEnabled(context, slotIndex) || !matchesUrl(url)) return
        DebugLog.log("ColabLiveKeeper: Page loaded $url")

        val engine = getEngineForSlot(context, slotIndex)
        engine?.evaluateJs(overrideVisibilityScript) {}

        if (getMode(context, slotIndex) == MODE_DOM) {
            startDomPolling(context, slotIndex, engine)
        }
    }

    override fun onPageLoadError(context: Context, slotIndex: Int, url: String, errorCode: Int) {}
    override fun onDropFile(context: Context, slotIndex: Int, uri: android.net.Uri, mimeType: String?) {}

    private fun startDomPolling(context: Context, slotIndex: Int, engine: GeckoViewEngine?) {
        val interval = intervalMinutes(context, slotIndex) * 60 * 1000L
        val handler = android.os.Handler(android.os.Looper.getMainLooper())
        val runnable = object : Runnable {
            override fun run() {
                if (!isEnabled(context, slotIndex)) return
                engine?.evaluateJs(keepAliveScript) {}
                handler.postDelayed(this, interval)
            }
        }
        handler.postDelayed(runnable, interval)
        DebugLog.log("ColabLiveKeeper: DOM polling started for slot $slotIndex")
    }

    private fun getEngineForSlot(context: Context, slotIndex: Int): GeckoViewEngine? {
        return null // Will be injected by MainActivity
    }

    override fun buildSettingsView(context: Context, slotIndex: Int): View {
        val container = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 16, 16, 16)
        }

        val switch = Switch(context)
        switch.text = displayName
        switch.isChecked = isEnabled(context, slotIndex)
        switch.setOnCheckedChangeListener { _, checked -> setEnabled(context, slotIndex, checked) }
        container.addView(switch)

        val modeLabel = TextView(context)
        modeLabel.text = "Mode:"
        container.addView(modeLabel)

        val modeSpinner = Spinner(context)
        val modes = listOf(MODE_DOM, MODE_ACCESSIBILITY)
        val adapter = ArrayAdapter(context, android.R.layout.simple_spinner_item, modes)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        modeSpinner.adapter = adapter
        modeSpinner.setSelection(modes.indexOf(getMode(context, slotIndex)))
        modeSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                setMode(context, slotIndex, modes[position])
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        container.addView(modeSpinner)

        val intervalLabel = TextView(context)
        intervalLabel.text = "Interval (minutes):"
        container.addView(intervalLabel)

        val intervalInput = EditText(context).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(intervalMinutes(context, slotIndex).toString())
        }
        container.addView(intervalInput)

        val saveBtn = Button(context)
        saveBtn.text = "Luu"
        saveBtn.setOnClickListener {
            val minutes = intervalInput.text.toString().toIntOrNull() ?: DEFAULT_INTERVAL
            setIntervalMinutes(context, slotIndex, minutes)
        }
        container.addView(saveBtn)

        val accessibilityBtn = Button(context)
        accessibilityBtn.text = "Mo Accessibility Settings"
        accessibilityBtn.setOnClickListener {
            context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        container.addView(accessibilityBtn)

        return container
    }
}
