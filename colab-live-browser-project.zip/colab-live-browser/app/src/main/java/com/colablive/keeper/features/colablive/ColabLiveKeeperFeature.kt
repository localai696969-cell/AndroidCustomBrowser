package com.colablive.keeper.features.colablive

import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.widget.*
import com.colablive.keeper.core.AppPrefs
import com.colablive.keeper.core.BrowserFeature
import com.colablive.keeper.core.DebugLog

class ColabLiveKeeperFeature : BrowserFeature {

    override val id = "colab_live_keeper"
    override val displayName = "Colab Live Keeper"
    override val description = "Giữ phiên Colab sống khi chuyển app/tắt màn hình"

    companion object {
        const val MODE_DOM = "dom"
        const val MODE_ACCESSIBILITY = "accessibility"
    }

    private const val KEY_MODE = "mode"
    private const val KEY_INTERVAL = "interval_minutes"
    private const val KEY_ENABLED = "enabled"
    private const val DEFAULT_INTERVAL = 20

    private val targetTexts = listOf("Connect", "Kết nối", "Reconnect", "Kết nối lại")

    private val keepAliveScript = """
        (function() {
            var btn = document.querySelector('colab-connect-button, #connect, [class*="connect"]');
            if (btn) { btn.click(); }
            document.dispatchEvent(new MouseEvent('mousemove', {bubbles:true}));
            window.dispatchEvent(new Event('scroll'));
        })();
    """.trimIndent()

    private val overrideVisibilityScript = """
        (function() {
            Object.defineProperty(document, 'hidden', { get: function() { return false; } });
            Object.defineProperty(document, 'visibilityState', { get: function() { return 'visible'; } });
            document.dispatchEvent(new Event('visibilitychange'));
        })();
    """.trimIndent()

    override fun isEnabled(context: Context, slotIndex: Int) = 
        AppPrefs.getBoolean(context, slotIndex, id, KEY_ENABLED, false)

    override fun setEnabled(context: Context, slotIndex: Int, enabled: Boolean) =
        AppPrefs.setBoolean(context, slotIndex, id, KEY_ENABLED, enabled)

    fun getMode(context: Context, slotIndex: Int) = 
        AppPrefs.getString(context, slotIndex, id, KEY_MODE, MODE_DOM)

    fun setMode(context: Context, slotIndex: Int, mode: String) = 
        AppPrefs.setString(context, slotIndex, id, KEY_MODE, mode)

    override fun intervalMinutes(context: Context, slotIndex: Int) = 
        AppPrefs.getInt(context, slotIndex, id, KEY_INTERVAL, DEFAULT_INTERVAL)

    fun setIntervalMinutes(context: Context, slotIndex: Int, minutes: Int) = 
        AppPrefs.setInt(context, slotIndex, id, KEY_INTERVAL, minutes)

    override fun accessibilityTargetTexts(context: Context, slotIndex: Int): List<String> = targetTexts

    override fun matchesUrl(url: String): Boolean {
        return url.contains("colab.research.google.com") || 
               url.contains("github.dev") ||
               url.contains("vscode.dev")
    }

    override fun onPageLoaded(context: Context, slotIndex: Int, url: String) {
        if (!isEnabled(context, slotIndex) || !matchesUrl(url)) return
        DebugLog.log("ColabLiveKeeper: Page loaded $url")
    }

    override fun onPageLoadError(context: Context, slotIndex: Int, url: String, errorCode: Int) {}
    override fun onDropFile(context: Context, slotIndex: Int, uri: android.net.Uri, mimeType: String?) {}

    override fun onTick(context: Context, slotIndex: Int) {
        if (!isEnabled(context, slotIndex)) return
        DebugLog.log("ColabLiveKeeper: Tick for slot $slotIndex")
    }

    override fun buildSettingsView(context: Context, slotIndex: Int): View {
        val container = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 16, 16, 16)
        }

        container.addView(Switch(context).apply {
            text = "Bật Colab Live Keeper"
            isChecked = isEnabled(context, slotIndex)
            setOnCheckedChangeListener { _, checked -> setEnabled(context, slotIndex, checked) }
        })

        container.addView(TextView(context).apply {
            text = "Chế độ:"
            textSize = 16f
        })

        val modeGroup = RadioGroup(context).apply {
            orientation = LinearLayout.VERTICAL
            addView(RadioButton(context).apply {
                text = "DOM Polling (tự động click nút Connect)"
                id = android.R.id.button1
                tag = MODE_DOM
            })
            addView(RadioButton(context).apply {
                text = "Accessibility Service (nếu DOM thất bại)"
                id = android.R.id.button2
                tag = MODE_ACCESSIBILITY
            })
        }
        val currentMode = getMode(context, slotIndex)
        for (i in 0 until modeGroup.childCount) {
            val btn = modeGroup.getChildAt(i) as RadioButton
            if (btn.tag == currentMode) btn.isChecked = true
        }
        modeGroup.setOnCheckedChangeListener { _, checkedId ->
            val selected = modeGroup.findViewById<RadioButton>(checkedId)
            setMode(context, slotIndex, selected.tag as String)
        }
        container.addView(modeGroup)

        container.addView(TextView(context).apply {
            text = "Khoảng cách (phút):"
            textSize = 16f
        })

        container.addView(EditText(context).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(intervalMinutes(context, slotIndex).toString())
            addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                override fun afterTextChanged(s: android.text.Editable?) {
                    s?.toString()?.toIntOrNull()?.let { setIntervalMinutes(context, slotIndex, it) }
                }
            })
        })

        container.addView(Button(context).apply {
            text = "Mở cài đặt Accessibility"
            setOnClickListener {
                context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        })

        return container
    }
}
