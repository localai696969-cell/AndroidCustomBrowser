package com.colablive.keeper.features.colablive

import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.text.InputType
import android.view.View
import com.colablive.keeper.core.BrowserEngine
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import com.colablive.keeper.core.AppPrefs
import com.colablive.keeper.core.BrowserFeature

object ColabLiveKeeperFeature : BrowserFeature {

    override val id = "colab_live_keeper"
    override val displayName = "Colab Live Keeper"
    override val description =
        "Giữ notebook Google Colab không bị ngắt do idle-timeout khi chuyển app khác hoặc tắt màn hình."

    const val MODE_DOM = "dom"
    const val MODE_ACCESSIBILITY = "accessibility"
    private const val KEY_MODE = "mode"
    private const val KEY_INTERVAL = "interval_minutes"
    private const val KEY_ENABLED = "enabled"
    private const val DEFAULT_INTERVAL = 20

    private val targetTexts = listOf("Connect", "Kết nối", "Reconnect", "Kết nối lại")
    private var lastRunAtMs = 0L

    private val keepAliveScript = """
        (function() {
            var btn = document.querySelector('colab-connect-button, #connect, [class*="connect"]');
            if (btn) { btn.click(); }
            document.dispatchEvent(new MouseEvent('mousemove', {bubbles:true}));
            window.dispatchEvent(new Event('scroll'));
        })();
    """.trimIndent()

    private val overrideVisibilityScript = """
        (function() {
            Object.defineProperty(document, 'hidden', { get: function() { return false; } });
            Object.defineProperty(document, 'visibilityState', { get: function() { return 'visible'; } });
            document.dispatchEvent(new Event('visibilitychange'));
        })();
    """.trimIndent()

    override fun isEnabled(context: Context, slotIndex: Int) = AppPrefs.getBoolean(context, slotIndex, id, KEY_ENABLED, false)
    override fun setEnabled(context: Context, slotIndex: Int, enabled: Boolean) =
        AppPrefs.setBoolean(context, slotIndex, id, KEY_ENABLED, enabled)

    fun getMode(context: Context, slotIndex: Int) = AppPrefs.getString(context, slotIndex, id, KEY_MODE, MODE_DOM)
    fun setMode(context: Context, slotIndex: Int, mode: String) = AppPrefs.setString(context, slotIndex, id, KEY_MODE, mode)

    override fun intervalMinutes(context: Context, slotIndex: Int) =
        AppPrefs.getInt(context, slotIndex, id, KEY_INTERVAL, DEFAULT_INTERVAL)

    fun setIntervalMinutes(context: Context, slotIndex: Int, minutes: Int) =
        AppPrefs.setInt(context, slotIndex, id, KEY_INTERVAL, minutes.coerceIn(1, 90))

    override fun matchesUrl(url: String?): Boolean =
        url?.contains("colab.research.google.com") == true

    override fun onPageFinished(context: Context, slotIndex: Int, engine: BrowserEngine, url: String?) {
        if (!isEnabled(context, slotIndex) || !matchesUrl(url)) return
        engine.evaluateJs(overrideVisibilityScript)
    }

    override fun onTick(context: Context, slotIndex: Int, engine: BrowserEngine, url: String?) {
        if (!isEnabled(context, slotIndex) || !matchesUrl(url)) return
        val now = System.currentTimeMillis()
        val intervalMs = intervalMinutes(context, slotIndex) * 60_000L
        if (now - lastRunAtMs < intervalMs) return
        lastRunAtMs = now
        if (getMode(context, slotIndex) == MODE_DOM) {
            engine.evaluateJs(keepAliveScript)
        }
        // Nếu mode == ACCESSIBILITY, việc tap thật do AutoClickAccessibilityService
        // đảm nhiệm (đọc accessibilityTargetTexts() bên dưới), không xử lý ở đây.
    }

    override fun accessibilityTargetTexts(context: Context, slotIndex: Int): List<String> =
        if (isEnabled(context, slotIndex) && getMode(context, slotIndex) == MODE_ACCESSIBILITY) targetTexts else emptyList()

    override fun buildSettingsView(context: Context, slotIndex: Int): View {
        val padding = (16 * context.resources.displayMetrics.density).toInt()

        val enableSwitch = Switch(context).apply {
            text = "Bật $displayName"
            isChecked = isEnabled(context, slotIndex)
            setOnCheckedChangeListener { _, checked -> setEnabled(context, slotIndex, checked) }
        }

        val radioGroup = RadioGroup(context).apply { orientation = RadioGroup.VERTICAL }
        val domRadio = RadioButton(context).apply {
            id = 2001
            text = "DOM (JS giả lập) — không cần bật màn hình, isTrusted không chắc chắn"
        }
        val accessibilityRadio = RadioButton(context).apply {
            id = 2002
            text = "Accessibility (chạm thật) — cần bật màn hình mỗi chu kỳ, isTrusted đáng tin hơn"
        }
        radioGroup.addView(domRadio)
        radioGroup.addView(accessibilityRadio)
        radioGroup.check(if (getMode(context, slotIndex) == MODE_ACCESSIBILITY) 2002 else 2001)

        val intervalLabel = TextView(context).apply {
            text = "Chu kỳ (phút, 1-90, khuyến nghị ~20):"
        }
        val intervalInput = EditText(context).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(intervalMinutes(context, slotIndex).toString())
        }

        val saveButton = Button(context).apply {
            text = "Lưu"
            setOnClickListener {
                setMode(context, slotIndex, if (radioGroup.checkedRadioButtonId == 2002) MODE_ACCESSIBILITY else MODE_DOM)
                setIntervalMinutes(context, intervalInput.text.toString().toIntOrNull() ?: DEFAULT_INTERVAL)
                Toast.makeText(context, "$displayName: đã lưu cài đặt", Toast.LENGTH_SHORT).show()
            }
        }

        val accessibilityButton = Button(context).apply {
            text = "Mở Accessibility Settings (cần cho chế độ Accessibility)"
            setOnClickListener {
                context.startActivity(
                    Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }
        }

        return LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(padding, padding, padding, padding)
            addView(TextView(context).apply { text = description })
            addView(enableSwitch)
            addView(radioGroup)
            addView(intervalLabel)
            addView(intervalInput)
            addView(saveButton)
            addView(accessibilityButton)
        }
    }
}
