package com.colablive.keeper

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

/**
 * Màn hình hiển thị crash gần nhất — cố tình viết TỐI GIẢN, không đụng tới
 * GeckoView/Feature nào, để chính màn hình này không trở thành nạn nhân của
 * đúng loại lỗi nó đang cố hiển thị. Mở tự động ngay khi có crash chưa xử lý
 * (xem LiveBrowserApp.installCrashHandler), hoặc mở lại được từ menu chính
 * ("Xem crash gần nhất") nếu người dùng bỏ lỡ màn hình tự động lúc đó.
 */
class CrashReportActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val padding = (16 * resources.displayMetrics.density).toInt()

        // BUG THẬT đã sửa (cùng loại với DebugLogActivity — xem chú thích
        // đầy đủ ở DebugLog.kt): Activity này không khai báo
        // `android:process`, không đảm bảo chạy đúng tiến trình khe nào —
        // nhận tường minh `slot_index` từ Intent, không đoán qua tiến trình.
        val slotIndex = intent.getIntExtra("slot_index", 0)
        val crashText = intent.getStringExtra("crash_text")
        val fileLogTail = runCatching {
            com.colablive.keeper.core.DebugLog.readFullFile(this, slotIndex).lines().takeLast(80).joinToString("\n")
        }.getOrDefault("(không đọc được file log)")

        val displayText = buildString {
            if (crashText != null) {
                append(crashText)
            } else {
                append(
                    "(Không có crash Kotlin/Java nào được bắt lần gần nhất — nếu app vừa " +
                        "crash mà bạn đang xem màn hình này qua menu 'Xem crash gần nhất', " +
                        "rất có thể đó là CRASH NATIVE (vd chính engine Gecko), loại handler " +
                        "Kotlin không bắt được. Log file dưới đây vẫn cho biết app dừng lại " +
                        "ở bước nào trước khi crash — dòng CUỐI CÙNG là manh mối quan trọng nhất.)"
                )
            }
            append("\n\n=== Đuôi file log (80 dòng gần nhất, ghi liên tục kể cả khi không crash) ===\n")
            append(fileLogTail)
        }

        val textView = TextView(this).apply {
            text = displayText
            setPadding(padding, padding, padding, padding)
            textSize = 12f
            setTextIsSelectable(true)
        }

        val copyButton = Button(this).apply {
            text = "Sao chép toàn bộ"
            setOnClickListener {
                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("crash_log", displayText))
                Toast.makeText(this@CrashReportActivity, "Đã sao chép — dán gửi lại để được hỗ trợ", Toast.LENGTH_LONG).show()
            }
        }

        val closeButton = Button(this).apply {
            text = "Đóng"
            setOnClickListener { finish() }
        }

        val buttonRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(copyButton)
            addView(closeButton)
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(buttonRow)
            addView(
                ScrollView(this@CrashReportActivity).apply { addView(textView) },
                LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
            )
        }
        setContentView(root)
    }
}
