package com.colablive.keeper.core

import android.content.Context
import java.util.*

/**
 * Phát hiện cookie leak giữa các slot.
 * Mỗi slot tạo 1 marker cookie unique.
 * Kiểm tra xem slot này có thấy marker của slot khác không.
 */
class CookieLeakDetector(private val context: Context) {

    private val markers = mutableMapOf<Int, String>()
    private val testUrl = "https://example.com"

    /**
     * Tạo marker cookie cho slot.
     * Gọi sau khi slot mở và load trang.
     */
    fun setMarker(slotIndex: Int, engine: GeckoViewEngine) {
        val marker = "slot_${slotIndex}_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        markers[slotIndex] = marker

        // Inject marker cookie vào trang test
        engine.evaluateJs("""
            (function() {
                try {
                    document.cookie = "leak_test_marker=$marker; path=/; SameSite=Lax";
                    return "marker_set:$marker";
                } catch(e) {
                    return "error:" + e.message;
                }
            })()
        """) { result ->
            DebugLog.log("Leak marker set for slot $slotIndex: $marker")
        }
    }

    /**
     * Kiểm tra slot này có thấy marker của slot khác không.
     * Gọi sau khi setMarker và đợi 2-3 giây.
     */
    fun checkLeak(slotIndex: Int, engine: GeckoViewEngine, callback: (Boolean, String) -> Unit) {
        val otherMarkers = markers.filter { it.key != slotIndex }.values.toList()

        if (otherMarkers.isEmpty()) {
            callback(false, "Chưa có slot khác để so sánh")
            return
        }

        // Build JS để kiểm tra tất cả marker khác
        val checkJs = buildString {
            append("(function() {")
            append("var cookies = document.cookie;")
            append("var leaks = [];")
            otherMarkers.forEach { marker ->
                append("if (cookies.includes('$marker')) leaks.push('$marker');")
            }
            append("return leaks.length > 0 ? 'LEAK:' + leaks.join(',') : 'CLEAN';")
            append("})()")
        }

        engine.evaluateJs(checkJs) { result ->
            val isLeak = result?.startsWith("LEAK:") == true
            val detail = if (isLeak) {
                "Phát hiện cookie của slot khác: ${result?.removePrefix("LEAK:")}"
            } else {
                "Không phát hiện leak"
            }
            callback(isLeak, detail)
        }
    }

    /**
     * Test đầy đủ: Load trang test → Set marker → Đợi → Check leak.
     */
    fun runFullTest(slotIndex: Int, engine: GeckoViewEngine, callback: (Boolean, String) -> Unit) {
        // Load trang test trước
        engine.loadUrl(testUrl)

        // Đợi trang load xong rồi set marker
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
            setMarker(slotIndex, engine)

            // Đợi 3 giây rồi check
            android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                checkLeak(slotIndex, engine, callback)
            }, 3000)
        }, 2000)
    }

    /**
     * Xóa tất cả markers.
     */
    fun clearMarkers() {
        markers.clear()
    }
}
