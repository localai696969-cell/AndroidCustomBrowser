package com.colablive.keeper.core

import android.content.Context
import org.mozilla.geckoview.GeckoSession
import java.util.*

class CookieLeakDetector(private val context: Context) {

    private val markers = mutableMapOf<Int, String>()

    fun setMarker(slotIndex: Int, engine: GeckoViewEngine) {
        val marker = "slot_${slotIndex}_${UUID.randomUUID()}"
        markers[slotIndex] = marker

        engine.evaluateJs("""
            document.cookie = "leak_test_marker=$marker; path=/; domain=.example.com";
            "marker_set"
        """) {}
    }

    fun checkLeak(slotIndex: Int, engine: GeckoViewEngine, callback: (Boolean) -> Unit) {
        val otherMarkers = markers.filter { it.key != slotIndex }.values

        if (otherMarkers.isEmpty()) {
            callback(false)
            return
        }

        engine.evaluateJs("""
            (function() {
                var cookies = document.cookie;
                var leak = false;
                ${otherMarkers.joinToString("") { marker ->
                    "if (cookies.includes('$marker')) leak = true;"
                }}
                return leak ? "LEAK_DETECTED" : "CLEAN";
            })()
        """) { result ->
            callback(result == "LEAK_DETECTED")
        }
    }

    fun runFullTest(slotIndex: Int, engine: GeckoViewEngine, callback: (Boolean) -> Unit) {
        // Load test page
        engine.loadUrl("https://example.com")

        // Đợi 2 giây rồi set marker
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
            setMarker(slotIndex, engine)

            // Đợi 1 giây rồi check
            android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                checkLeak(slotIndex, engine) { isLeak ->
                    callback(isLeak)
                }
            }, 1000)
        }, 2000)
    }

    fun clearMarkers() {
        markers.clear()
    }
}
