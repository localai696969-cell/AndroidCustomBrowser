package com.colablive.keeper.core

import android.content.Context
import java.io.File
import java.io.FileWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Log trong bộ nhớ (xem nhanh qua DebugLogActivity) VÀ GHI RA FILE NGAY LẬP
 * TỨC, flush đồng bộ mỗi dòng — không dùng buffer/ghi trễ.
 *
 * Lý do ghi đồng bộ dù chậm hơn: mục đích chính là sống sót qua CRASH NATIVE
 * (vd chính thư viện Gecko libxul.so crash ở tầng C++) — loại crash này giết
 * tiến trình NGAY LẬP TỨC, không hề chạy qua
 * `Thread.setDefaultUncaughtExceptionHandler` của Kotlin/Java (xem
 * LiveBrowserApp) — nên KHÔNG có cơ hội "ghi nốt trước khi thoát" giống như
 * crash Kotlin thường. Muốn có manh mối cho loại crash này, dữ liệu PHẢI đã
 * nằm trên đĩa TỪ TRƯỚC lúc crash xảy ra, không phải ghi tại thời điểm crash.
 */
object DebugLog {
    private const val MAX_ENTRIES = 300
    // Giới hạn file — KeepAliveService có thể chạy hàng giờ/ngày liên tục,
    // không giới hạn thì file phình vô hạn.
    private const val MAX_FILE_BYTES = 2 * 1024 * 1024
    private const val FILE_NAME = "debug_log.txt"

    private val entries = ArrayDeque<String>()
    private val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
    private var logFile: File? = null

    /** Gọi 1 LẦN DUY NHẤT từ LiveBrowserApp.onCreate(), TRƯỚC mọi log() khác. */
    @Synchronized
    fun init(context: Context) {
        if (logFile != null) return
        logFile = File(context.filesDir, FILE_NAME)
        log("========== App process start ==========")
    }

    @Synchronized
    fun log(message: String) {
        val line = "[${timeFormat.format(Date())}] $message"
        entries.addLast(line)
        while (entries.size > MAX_ENTRIES) entries.removeFirst()

        val f = logFile ?: return
        try {
            if (f.exists() && f.length() > MAX_FILE_BYTES) trimFile(f)
            // FileWriter(append=true) mở/ghi/đóng mỗi lần — chậm hơn giữ
            // stream mở sẵn, nhưng ĐÓNG = flush thật xuống đĩa ngay, không
            // treo trong buffer OS/JVM chờ crash rồi mất.
            FileWriter(f, true).use { it.appendLine(line) }
        } catch (e: Exception) {
            // Không để lỗi ghi log làm hỏng luồng chính của app.
        }
    }

    private fun trimFile(f: File) {
        try {
            val lines = f.readLines()
            val keep = lines.takeLast(MAX_ENTRIES * 2)
            f.writeText(keep.joinToString("\n") + "\n")
        } catch (e: Exception) {
            // bỏ qua — thà giữ file cũ còn hơn crash khi đang cố dọn log
        }
    }

    @Synchronized
    fun getAll(): List<String> = entries.toList()

    /**
     * Đọc TOÀN BỘ nội dung file trên đĩa (nhiều hơn 300 dòng giữ trong bộ
     * nhớ) — dùng khi cần soát kỹ log của LẦN CHẠY TRƯỚC, sau khi app vừa
     * crash và mở lại (bộ nhớ `entries` đã mất, file thì còn).
     */
    fun readFullFile(context: Context): String {
        val f = logFile ?: File(context.filesDir, FILE_NAME)
        return runCatching { f.readText() }.getOrDefault("(chưa có file log)")
    }

    @Synchronized
    fun clear() {
        entries.clear()
        try {
            logFile?.writeText("")
        } catch (e: Exception) {
        }
    }
}
