package com.colablive.keeper.core

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Log trong bộ nhớ (không ghi file) — thay cho Toast thoáng qua khó chụp lại.
 * Xem qua DebugLogActivity, có thể cuộn lại xem log cũ, không tự mất.
 */
object DebugLog {
    private const val MAX_ENTRIES = 300
    private val entries = ArrayDeque<String>()
    private val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    @Synchronized
    fun log(message: String) {
        entries.addLast("[${timeFormat.format(Date())}] $message")
        while (entries.size > MAX_ENTRIES) entries.removeFirst()
    }

    @Synchronized
    fun getAll(): List<String> = entries.toList()

    @Synchronized
    fun clear() = entries.clear()
}
