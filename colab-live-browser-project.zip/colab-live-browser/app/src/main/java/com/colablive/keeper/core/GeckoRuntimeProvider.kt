package com.colablive.keeper.core

import android.content.Context
import org.json.JSONObject
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.GeckoRuntimeSettings
import org.mozilla.geckoview.WebExtension
import java.io.File

/**
 * Mỗi khe (process riêng) tự tạo 1 GeckoRuntime — đúng theo tài liệu chính
 * thức Mozilla: "GeckoRuntime can only be initialized once per process".
 *
 * Cô lập cookie/storage — 2 LỚP:
 *   1) `arguments(["-profile", <thư mục riêng của khe>, "-no-remote"])` —
 *      cờ dòng lệnh CHUẨN của Gecko/Firefox (xem tài liệu automation chính
 *      thức của GeckoView: args: [-profile, "/path"]), cho mỗi khe 1 thư
 *      mục hồ sơ Gecko RIÊNG BIỆT trên đĩa (cookies.sqlite, storage,
 *      permissions, cache... tách hẳn, không chỉ tách trong 1 hồ sơ dùng
 *      chung). "-no-remote" ngăn Gecko cố gắng dùng lại 1 instance khác
 *      đang chạy (quan trọng vì có NHIỀU tiến trình :slotN của CÙNG 1 app).
 *      ⚠️ CHƯA XÁC NHẬN TRÊN THIẾT BỊ THẬT — `-profile` là cờ chuẩn của
 *      Gecko nhưng KHÔNG có API public riêng (`GeckoRuntimeSettings` không
 *      có hàm `.profileDir()`) cho việc này trong ngữ cảnh nhúng Android
 *      (tài liệu chính thức mới thấy dùng trong automation/geckodriver) —
 *      cần build thật + kiểm tra log/file để xác nhận Gecko có thực sự ghi
 *      vào đúng thư mục này không, hay vẫn rơi về hồ sơ mặc định dùng
 *      chung. NẾU KHÔNG ăn, lớp 2 (contextId) vẫn còn tác dụng.
 *   2) `GeckoSessionSettings.Builder().contextId()` (xem GeckoViewEngine.kt)
 *      — cô lập cookie/storage theo "container" NGAY CẢ KHI dùng chung 1
 *      hồ sơ vật lý — đây là cơ chế CHẮC CHẮN có tác dụng (API công khai,
 *      không cần xác nhận thêm), nhưng chỉ cô lập storage theo-origin, KHÔNG
 *      cô lập permission/cache/profile-level prefs như lớp 1 nếu lớp 1 ăn.
 *
 * Proxy riêng theo khe: đăng ký WebExtension `proxy_config`
 * (assets/proxy_config/) dùng browser.proxy.onRequest — API CHUẨN của
 * WebExtension, xác nhận đúng hướng qua Mozilla bug 1525486 (đội Secure
 * Proxy: "có thể làm được bằng chính Proxy API sẵn có trong WebExtension").
 * KHÁC với việc DÙNG `arguments()` ĐỂ SET PROXY (đã xác nhận không hoạt
 * động qua báo lỗi công khai — không nhầm với việc dùng arguments() để set
 * `-profile` ở trên, đó là 2 việc khác nhau, `-profile` không liên quan gì
 * tới proxy).
 *
 * Background script (không phải content script) nên đăng ký message
 * delegate ở CẤP EXTENSION (`extension.setMessageDelegate`), không phải cấp
 * session như eval_bridge/fingerprint_spoof.
 */
object GeckoRuntimeProvider {
    private const val PROXY_CONFIG_LOCATION = "resource://android/assets/proxy_config/"
    private const val PROXY_CONFIG_ID = "proxy-config@colablive.internal"

    private val runtimes = mutableMapOf<Int, GeckoRuntime>()
    private val dataDirs = mutableMapOf<Int, File>()

    @Synchronized
    fun get(context: Context, slotIndex: Int): GeckoRuntime {
        return runtimes.getOrPut(slotIndex) {
            createRuntime(context, slotIndex)
        }
    }

    private fun createRuntime(context: Context, slotIndex: Int): GeckoRuntime {
        // Thư mục hồ sơ RIÊNG cho HỒ SƠ đang gán vào khe này (không phải cho
        // bản thân số khe — xem AppPrefs.kt giải thích đầy đủ lý do) —
        // truyền vào Gecko qua cờ dòng lệnh "-profile" (xem giải thích ở
        // comment lớp 1 phía trên class).
        val profileNamespace = ProfileSlots.getSlotAssignment(context, slotIndex)
        val safeDirName = "gecko_profile_" + profileNamespace.replace(Regex("[^a-zA-Z0-9_-]"), "_")
        val slotDataDir = File(context.filesDir, safeDirName)
        slotDataDir.mkdirs()
        dataDirs[slotIndex] = slotDataDir

        val settings = GeckoRuntimeSettings.Builder()
            .consoleOutput(false)
            .aboutConfigEnabled(true)
            .arguments(arrayOf("-profile", slotDataDir.absolutePath, "-no-remote"))
            .build()

        DebugLog.log("GeckoRuntimeProvider slot $slotIndex (hồ sơ '$profileNamespace'): bắt đầu GeckoRuntime.create() với -profile=${slotDataDir.absolutePath}")
        val runtime = try {
            GeckoRuntime.create(context, settings)
        } catch (e: Throwable) {
            // Không phải mọi lỗi native đều crash cứng process — 1 số lỗi
            // validate tham số vẫn ném exception JVM bắt được. Nếu vậy, thử
            // lại KHÔNG dùng cờ "-profile" (chưa xác nhận chắc chắn hoạt
            // động — xem PROJECT_STATUS.md mục "Lượt 3") thay vì để cả app
            // crash hẳn — cô lập vẫn còn contextId (lớp 2, chắc chắn hoạt
            // động) dù không có cô lập hồ sơ vật lý riêng (lớp 1).
            DebugLog.log("GeckoRuntimeProvider slot $slotIndex: GeckoRuntime.create() với -profile LỖI (${e.javaClass.simpleName}: ${e.message}) — thử lại KHÔNG có -profile")
            val fallbackSettings = GeckoRuntimeSettings.Builder()
                .consoleOutput(false)
                .aboutConfigEnabled(true)
                .build()
            GeckoRuntime.create(context, fallbackSettings)
        }
        DebugLog.log("GeckoRuntimeProvider slot $slotIndex: GeckoRuntime.create() XONG (không crash)")

        registerProxyExtensionIfConfigured(context, runtime, slotIndex)

        DebugLog.log(
            "GeckoRuntime slot $slotIndex: -profile=${slotDataDir.absolutePath} " +
                "(CHƯA XÁC NHẬN có ăn thật không — xem log Gecko/kiểm tra file trong " +
                "thư mục này sau khi duyệt web) + contextId isolation (GeckoViewEngine)"
        )
        return runtime
    }

    private fun registerProxyExtensionIfConfigured(context: Context, runtime: GeckoRuntime, slotIndex: Int) {
        val proxyType = AppPrefs.getInt(context, slotIndex, "proxy_type", 0)
        if (proxyType == 0) return // "Direct" — không cần đăng ký extension proxy

        val host = AppPrefs.getString(context, slotIndex, "proxy_host", "")
        val proxyPort = AppPrefs.getString(context, slotIndex, "proxy_port", "0").toIntOrNull() ?: 0
        if (host.isEmpty() || proxyPort == 0) {
            DebugLog.log("Slot $slotIndex: proxy_type != Direct nhưng thiếu host/port, bỏ qua đăng ký proxy extension")
            return
        }
        val user = AppPrefs.getString(context, slotIndex, "proxy_user", "")
        val pass = AppPrefs.getString(context, slotIndex, "proxy_pass", "")

        runtime.webExtensionController
            .ensureBuiltIn(PROXY_CONFIG_LOCATION, PROXY_CONFIG_ID)
            .accept(
                { extension ->
                    if (extension == null) return@accept
                    val messageDelegate = object : WebExtension.MessageDelegate {
                        override fun onConnect(port: WebExtension.Port) {
                            val cfg = JSONObject().apply {
                                put("enabled", true)
                                put("type", if (proxyType == 2) "socks" else "http")
                                put("host", host)
                                put("port", proxyPort)
                                put("username", user)
                                put("password", pass)
                            }
                            port.postMessage(
                                JSONObject().apply {
                                    put("type", "proxy_config")
                                    put("config", cfg)
                                }
                            )
                            DebugLog.log("Slot $slotIndex: đã đẩy cấu hình proxy xuống ($host:$proxyPort)")
                        }
                    }
                    extension.setMessageDelegate(messageDelegate, "browser")
                },
                { error -> DebugLog.log("Slot $slotIndex: không đăng ký được proxy extension — $error") }
            )
    }

    fun getDataDir(slotIndex: Int): File? = dataDirs[slotIndex]

    fun release(slotIndex: Int) {
        runtimes.remove(slotIndex)
    }

    fun releaseAll() {
        runtimes.clear()
        dataDirs.clear()
    }

    fun clearSlotData(context: Context, slotIndex: Int) {
        val profileNamespace = ProfileSlots.getSlotAssignment(context, slotIndex)
        val safeDirName = "gecko_profile_" + profileNamespace.replace(Regex("[^a-zA-Z0-9_-]"), "_")
        val dir = File(context.filesDir, safeDirName)
        if (dir.exists()) {
            dir.deleteRecursively()
            DebugLog.log("Cleared Gecko profile data for '$profileNamespace' (slot $slotIndex)")
        }
    }
}
