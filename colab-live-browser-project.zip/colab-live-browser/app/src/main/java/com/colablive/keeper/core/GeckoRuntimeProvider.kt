package com.colablive.keeper.core

import android.content.Context
import android.util.Log
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.WebExtension

/**
 * GeckoRuntime chỉ nên tạo 1 lần cho mỗi process — mỗi khe (profile slot) là
 * 1 process riêng (xem ProfileSlots) nên mỗi process tự có GeckoRuntime
 * riêng, đúng ý cô lập.
 *
 * LƯU Ý (đã nói rõ với người dùng, không giấu): CHƯA xử lý cô lập thư mục dữ
 * liệu GeckoRuntime riêng theo khe — tạm thời dùng cấu hình mặc định để ưu
 * tiên hoàn thành tính năng Colab chạy được trước. Việc cô lập triệt để theo
 * khe (giống WebView.setDataDirectorySuffix trước đây) cần làm ở bước sau.
 *
 * Đăng ký kèm "eval bridge" — WebExtension nội bộ để BrowserEngine.evaluateJs()
 * hoạt động, KHÔNG phải addon thật cho người dùng cài.
 * Nguồn API: https://firefox-source-docs.mozilla.org/mobile/android/geckoview/consumer/web-extensions.html
 */
object GeckoRuntimeProvider {
    private const val TAG = "GeckoRuntimeProvider"
    private const val EVAL_BRIDGE_LOCATION = "resource://android/assets/eval_bridge/"
    private const val EVAL_BRIDGE_ID = "eval-bridge@colablive.internal"
    const val NATIVE_APP_ID = "browser"

    @Volatile private var runtime: GeckoRuntime? = null

    @Volatile var evalBridgeExtension: WebExtension? = null
        private set

    fun get(context: Context): GeckoRuntime {
        runtime?.let { return it }
        synchronized(this) {
            runtime?.let { return it }
            val rt = GeckoRuntime.create(context.applicationContext)
            rt.webExtensionController
                .ensureBuiltIn(EVAL_BRIDGE_LOCATION, EVAL_BRIDGE_ID)
                .accept(
                    { extension -> evalBridgeExtension = extension },
                    { error -> Log.e(TAG, "Không cài được eval bridge extension", error) }
                )
            runtime = rt
            return rt
        }
    }
}
