package com.colablive.keeper.core

import android.content.Context
import org.json.JSONObject
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.GeckoRuntimeSettings
import org.mozilla.geckoview.WebExtension
import java.io.File

/**
 * Mỗi khe (process riêng) tự tạo 1 GeckoRuntime — đúng theo tài liệu chính
 * thức Mozilla: "GeckoRuntime can only be initialized once per process".
 *
 * Cô lập cookie/storage — 2 LỚP:
 *   1) `arguments(["-profile", <thư mục riêng của khe>, "-no-remote"])` —
 *      cờ dòng lệnh CHUẨN của Gecko/Firefox (xem tài liệu automation chính
 *      thức của GeckoView: args: [-profile, "/path"]), cho mỗi khe 1 thư
 *      mục hồ sơ Gecko RIÊNG BIỆT trên đĩa (cookies.sqlite, storage,
 *      permissions, cache... tách hẳn, không chỉ tách trong 1 hồ sơ dùng
 *      chung). "-no-remote" ngăn Gecko cố gắng dùng lại 1 instance khác
 *      đang chạy (quan trọng vì có NHIỀU tiến trình :slotN của CÙNG 1 app).
 *      ⚠️ CHƯA XÁC NHẬN TRÊN THIẾT BỊ THẬT — `-profile` là cờ chuẩn của
 *      Gecko nhưng KHÔNG có API public riêng (`GeckoRuntimeSettings` không
 *      có hàm `.profileDir()`) cho việc này trong ngữ cảnh nhúng Android
 *      (tài liệu chính thức mới thấy dùng trong automation/geckodriver) —
 *      cần build thật + kiểm tra log/file để xác nhận Gecko có thực sự ghi
 *      vào đúng thư mục này không, hay vẫn rơi về hồ sơ mặc định dùng
 *      chung. NẾU KHÔNG ăn, lớp 2 (contextId) vẫn còn tác dụng.
 *   2) `GeckoSessionSettings.Builder().contextId()` (xem GeckoViewEngine.kt)
 *      — cô lập cookie/storage theo "container" NGAY CẢ KHI dùng chung 1
 *      hồ sơ vật lý — đây là cơ chế CHẮC CHẮN có tác dụng (API công khai,
 *      không cần xác nhận thêm), nhưng chỉ cô lập storage theo-origin, KHÔNG
 *      cô lập permission/cache/profile-level prefs như lớp 1 nếu lớp 1 ăn.
 *
 * Proxy riêng theo khe: đăng ký WebExtension `proxy_config`
 * (assets/proxy_config/) dùng browser.proxy.onRequest — API CHUẨN của
 * WebExtension, xác nhận đúng hướng qua Mozilla bug 1525486 (đội Secure
 * Proxy: "có thể làm được bằng chính Proxy API sẵn có trong WebExtension").
 * KHÁC với việc DÙNG `arguments()` ĐỂ SET PROXY (đã xác nhận không hoạt
 * động qua báo lỗi công khai — không nhầm với việc dùng arguments() để set
 * `-profile` ở trên, đó là 2 việc khác nhau, `-profile` không liên quan gì
 * tới proxy).
 *
 * Background script (không phải content script) nên đăng ký message
 * delegate ở CẤP EXTENSION (`extension.setMessageDelegate`), không phải cấp
 * session như eval_bridge/fingerprint_spoof.
 */
object GeckoRuntimeProvider {
    private const val PROXY_CONFIG_LOCATION = "resource://android/assets/proxy_config/"
    private const val PROXY_CONFIG_ID = "proxy-config@colablive.internal"

    private val runtimes = mutableMapOf<Int, GeckoRuntime>()

    // Cho phép MainActivity truy cập runtime hiện có của 1 khe để gọi
    // `webExtensionController.install()` (tính năng cài addon từ file/URL
    // ngoài — xem `showAddonManagerDialog()` ở MainActivity.kt). Chỉ đọc,
    // không cho phép sửa map từ ngoài.
    fun getRuntime(slotIndex: Int): GeckoRuntime? = runtimes[slotIndex]
    private val dataDirs = mutableMapOf<Int, File>()

    /** Tên thư mục AN TOÀN trên đĩa ứng với 1 namespace hồ sơ — dùng chung ở
     * `createRuntime`, `clearSlotData`, `renameProfileDir` để 3 chỗ này
     * LUÔN tính ra đúng cùng 1 đường dẫn cho cùng 1 namespace (trước đây
     * mỗi hàm tự viết lại y hệt logic này riêng — dễ lệch nếu sửa 1 chỗ mà
     * quên chỗ khác). */
    private fun safeDirNameFor(namespace: String) =
        "gecko_profile_" + namespace.replace(Regex("[^a-zA-Z0-9_-]"), "_")

    @Synchronized
    fun get(context: Context, slotIndex: Int): GeckoRuntime {
        return runtimes.getOrPut(slotIndex) {
            createRuntime(context, slotIndex)
        }
    }

    private fun createRuntime(context: Context, slotIndex: Int): GeckoRuntime {
        // Thư mục hồ sơ RIÊNG cho HỒ SƠ đang gán vào khe này (không phải cho
        // bản thân số khe — xem AppPrefs.kt giải thích đầy đủ lý do) —
        // truyền vào Gecko qua cờ dòng lệnh "-profile" (xem giải thích ở
        // comment lớp 1 phía trên class).
        val profileNamespace = ProfileSlots.getSlotAssignment(context, slotIndex)
        val slotDataDir = File(context.filesDir, safeDirNameFor(profileNamespace))
        slotDataDir.mkdirs()
        dataDirs[slotIndex] = slotDataDir

        /**
         * BUG DO TÔI GÂY RA — ĐÃ THỬ 2 LẦN ĐỀU SAI, DỪNG LẠI Ở ĐÂY, KHÔNG
         * ĐOÁN LẦN 3 (người dùng chỉ đúng: đây là kiểu vá mù, dù có tra
         * cứu, vì tra SAI PHIÊN BẢN):
         *
         * Lần 1: đoán tên method `androidZygotePreloadEnabled` — sai, đã tự
         * phát hiện và gỡ trước khi build.
         * Lần 2: fetch thẳng trang javadoc gốc
         * mozilla.github.io/geckoview/javadoc/mozilla-central/... — tưởng
         * đã chắc chắn 100% vì đọc được chữ ký thật `appZygoteProcessEnabled`
         * — NHƯNG trang đó là bản "geckoview 156.0.20260823..." (mozilla-
         * central = bản NIGHTLY MỚI NHẤT), trong khi `app/build.gradle`
         * của CHÍNH dự án này pin CỨNG version 145.0.20251124145406 — lệch
         * 11 phiên bản. Method này khả năng cao được thêm SAU version 145,
         * không tồn tại trong bản project thực sự build — gây lỗi
         * "Unresolved reference 'appZygoteProcessEnabled'" thật trên CI.
         *
         * BÀI HỌC: mozilla-central javadoc LUÔN là bản mới nhất/nightly,
         * KHÔNG PHẢI tài liệu khớp với version PIN CỨNG trong build.gradle
         * — tra cứu "đúng trang chính thức" vẫn có thể sai nếu không khớp
         * đúng version đang dùng. Mozilla KHÔNG public sẵn javadoc tách
         * riêng theo từng version cũ tại 1 URL tĩnh dễ truy cập — không có
         * cách xác nhận chắc chắn 100% qua web mà không có chính file .aar
         * của geckoview:145.0.20251124145406 để giải nén/đọc trực tiếp
         * (cần Android Studio mở dependency đó, hoặc giải nén .aar thật).
         *
         * QUYẾT ĐỊNH: KHÔNG thêm `appZygoteProcessEnabled` (hay bất kỳ
         * tối ưu chưa xác nhận được đúng version nào khác) vào code nữa.
         * Nếu người dùng muốn bật tối ưu này, cách DUY NHẤT đáng tin: mở
         * project trong Android Studio, gõ `GeckoRuntimeSettings.Builder()`
         * rồi gõ `.`, để autocomplete hiện đúng danh sách method THẬT của
         * đúng bản .aar 145.0.20251124145406 đang nằm trong classpath — đó
         * là nguồn duy nhất khớp 100% với bản build thật, không phải web.
         */
        val settings = GeckoRuntimeSettings.Builder()
            .consoleOutput(false)
            .aboutConfigEnabled(true)
            .arguments(arrayOf("-profile", slotDataDir.absolutePath, "-no-remote"))
            .build()

        DebugLog.log("GeckoRuntimeProvider slot $slotIndex (hồ sơ '$profileNamespace'): bắt đầu GeckoRuntime.create() với -profile=${slotDataDir.absolutePath}")
        val runtime = try {
            GeckoRuntime.create(context, settings)
        } catch (e: Throwable) {
            // Không phải mọi lỗi native đều crash cứng process — 1 số lỗi
            // validate tham số vẫn ném exception JVM bắt được. Nếu vậy, thử
            // lại KHÔNG dùng cờ "-profile" (chưa xác nhận chắc chắn hoạt
            // động — xem PROJECT_STATUS.md mục "Lượt 3") thay vì để cả app
            // crash hẳn — cô lập vẫn còn contextId (lớp 2, chắc chắn hoạt
            // động) dù không có cô lập hồ sơ vật lý riêng (lớp 1).
            DebugLog.log("GeckoRuntimeProvider slot $slotIndex: GeckoRuntime.create() với -profile LỖI (${e.javaClass.simpleName}: ${e.message}) — thử lại KHÔNG có -profile")
            val fallbackSettings = GeckoRuntimeSettings.Builder()
                .consoleOutput(false)
                .aboutConfigEnabled(true)
                .build()
            try {
                GeckoRuntime.create(context, fallbackSettings)
            } catch (e2: Throwable) {
                // Lượt thử lại (không -profile) CŨNG lỗi — thường là vì lỗi
                // gốc không liên quan gì tới "-profile" (ví dụ đúng là đã có
                // 1 GeckoRuntime khác trong process này, xem PROJECT_STATUS.md
                // mục "Only one GeckoRuntime instance"). Trước đây để lỗi này
                // BAY THẲNG lên ActivityThread → crash cứng cả app. Giờ log
                // rõ + ném lại 1 exception có thông điệp dễ hiểu hơn thay vì
                // im lặng nuốt lỗi (nuốt lỗi ở đây nguy hiểm hơn — app sẽ
                // chạy tiếp với engine null/half-broken).
                DebugLog.log("GeckoRuntimeProvider slot $slotIndex: fallback KHÔNG -profile CŨNG lỗi (${e2.javaClass.simpleName}: ${e2.message}) — không tạo được GeckoRuntime")
                throw IllegalStateException(
                    "Không tạo được trình duyệt cho Khe $slotIndex (có thể do process cũ chưa kịp đóng hẳn — thử đóng hẳn app rồi mở lại). Lỗi gốc: ${e2.message}",
                    e2
                )
            }
        }
        DebugLog.log("GeckoRuntimeProvider slot $slotIndex: GeckoRuntime.create() XONG (không crash)")

        registerProxyExtensionIfConfigured(context, runtime, slotIndex)

        DebugLog.log(
            "GeckoRuntime slot $slotIndex: -profile=${slotDataDir.absolutePath} " +
                "(CHƯA XÁC NHẬN có ăn thật không — xem log Gecko/kiểm tra file trong " +
                "thư mục này sau khi duyệt web) + contextId isolation (GeckoViewEngine)"
        )
        return runtime
    }

    private fun registerProxyExtensionIfConfigured(context: Context, runtime: GeckoRuntime, slotIndex: Int) {
        val proxyType = AppPrefs.getInt(context, slotIndex, "proxy_type", 0)
        if (proxyType == 0) return // "Direct" — không cần đăng ký extension proxy

        val host = AppPrefs.getString(context, slotIndex, "proxy_host", "")
        val proxyPort = AppPrefs.getString(context, slotIndex, "proxy_port", "0").toIntOrNull() ?: 0
        if (host.isEmpty() || proxyPort == 0) {
            DebugLog.log("Slot $slotIndex: proxy_type != Direct nhưng thiếu host/port, bỏ qua đăng ký proxy extension")
            return
        }
        val user = AppPrefs.getString(context, slotIndex, "proxy_user", "")
        val pass = AppPrefs.getString(context, slotIndex, "proxy_pass", "")

        runtime.webExtensionController
            .ensureBuiltIn(PROXY_CONFIG_LOCATION, PROXY_CONFIG_ID)
            .accept(
                { extension ->
                    if (extension == null) return@accept
                    val messageDelegate = object : WebExtension.MessageDelegate {
                        override fun onConnect(port: WebExtension.Port) {
                            val cfg = JSONObject().apply {
                                put("enabled", true)
                                put("type", if (proxyType == 2) "socks" else "http")
                                put("host", host)
                                put("port", proxyPort)
                                put("username", user)
                                put("password", pass)
                            }
                            port.postMessage(
                                JSONObject().apply {
                                    put("type", "proxy_config")
                                    put("config", cfg)
                                }
                            )
                            DebugLog.log("Slot $slotIndex: đã đẩy cấu hình proxy xuống ($host:$proxyPort)")
                        }
                    }
                    extension.setMessageDelegate(messageDelegate, "browser")
                },
                { error -> DebugLog.log("Slot $slotIndex: không đăng ký được proxy extension — $error") }
            )
    }

    fun getDataDir(slotIndex: Int): File? = dataDirs[slotIndex]

    /** Chỉ quên khỏi map — KHÔNG tắt native runtime (xem bug 8g: dùng hàm
     * này mà process không chết theo ngay sau đó sẽ gây crash "Only one
     * GeckoRuntime instance"). Giữ lại cho `releaseAll()`. Muốn đóng THẬT
     * (đảm bảo Gecko flush dữ liệu) và CHẮC CHẮN process sẽ chết ngay sau,
     * dùng `shutdown()` bên dưới thay vì hàm này. */
    fun release(slotIndex: Int) {
        runtimes.remove(slotIndex)
    }

    /**
     * Tắt hẳn GeckoRuntime — gọi `runtime.shutdown()` thật (API chuẩn của
     * GeckoView, dùng để đảm bảo mọi dữ liệu persistent — cookie, session
     * store — được flush xuống đĩa trước khi tiến trình chết), rồi mới quên
     * khỏi map. CHỈ được gọi khi CHẮC CHẮN tiến trình này sẽ bị kill/exit
     * ngay sau đó (hiện chỉ gọi từ `MainActivity`'s gracefulCloseReceiver,
     * bản thân broadcast đó chỉ được gửi từ
     * `ProfilePickerActivity.restartSlot()` — luôn kill/exit process ngay
     * sau khi nhận ACK) — nếu process còn sống tiếp mà gọi hàm này thì lần
     * tạo GeckoRuntime kế tiếp trong CHÍNH process đó sẽ bị Gecko từ chối
     * (đúng bug đã sửa ở mục 8g, chỉ là giờ đổi từ "quên mà không tắt"
     * thành "tắt nhưng process không chết" — TRIỆU CHỨNG GIỐNG NHAU).
     */
    fun shutdown(slotIndex: Int) {
        runtimes.remove(slotIndex)?.let { runtime ->
            try {
                runtime.shutdown()
                DebugLog.log("GeckoRuntimeProvider slot $slotIndex: runtime.shutdown() xong")
            } catch (e: Exception) {
                DebugLog.log("GeckoRuntimeProvider slot $slotIndex: lỗi khi shutdown runtime: ${e.javaClass.simpleName}: ${e.message}")
            }
        }
    }

    fun releaseAll() {
        runtimes.clear()
        dataDirs.clear()
    }

    fun clearSlotData(context: Context, slotIndex: Int) {
        val profileNamespace = ProfileSlots.getSlotAssignment(context, slotIndex)
        val dir = File(context.filesDir, safeDirNameFor(profileNamespace))
        if (dir.exists()) {
            dir.deleteRecursively()
            DebugLog.log("Cleared Gecko profile data for '$profileNamespace' (slot $slotIndex)")
        }
    }

    /**
     * Đổi tên thư mục hồ sơ Gecko trên đĩa từ `oldNamespace` sang
     * `newNamespace` — dùng khi "đặt tên" dữ liệu đang có sẵn trong 1 khe
     * thành hồ sơ có tên (xem `ProfileSlots.schedulePromoteSlotData`).
     *
     * CHỈ được gọi từ `LiveBrowserApp.onCreate()` — TRƯỚC khi `get()`/
     * `createRuntime()` của khe đó từng chạy trong tiến trình này (tiến
     * trình vừa khởi động sạch), để chắc chắn không có GeckoRuntime nào
     * đang mở file trong thư mục bị đổi tên.
     */
    fun renameProfileDir(context: Context, oldNamespace: String, newNamespace: String) {
        if (oldNamespace == newNamespace) return
        val oldDir = File(context.filesDir, safeDirNameFor(oldNamespace))
        val newDir = File(context.filesDir, safeDirNameFor(newNamespace))
        if (oldDir.exists() && !newDir.exists()) {
            val ok = oldDir.renameTo(newDir)
            DebugLog.log("renameProfileDir: '$oldNamespace' -> '$newNamespace' ${if (ok) "OK" else "THẤT BẠI"}")
        } else {
            DebugLog.log("renameProfileDir: bỏ qua (oldDir tồn tại=${oldDir.exists()}, newDir đã tồn tại=${newDir.exists()})")
        }
    }
}
