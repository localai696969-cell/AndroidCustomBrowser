package com.colablive.keeper.core

import android.content.Context
import android.util.Log
import com.colablive.keeper.features.fingerprint.FingerprintSpoofFeature
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.WebExtension

/**
 * GeckoRuntime chỉ nên tạo 1 lần cho mỗi process — mỗi khe (profile slot) là
 * 1 process riêng (xem ProfileSlots) nên mỗi process tự có GeckoRuntime
 * riêng, đúng ý cô lập.
 *
 * LƯU Ý: CHƯA xử lý cô lập thư mục dữ liệu GeckoRuntime riêng theo khe (xem
 * TODO trong LiveBrowserApp.kt) — mọi khe hiện dùng chung 1 GeckoRuntime data.
 *
 * Đăng ký 2 WebExtension nội bộ (KHÔNG PHẢI addon thật cho người dùng cài):
 * 1. "eval bridge" — LUÔN đăng ký, cần thiết cho BrowserEngine.evaluateJs()
 *    hoạt động (ColabLiveKeeperFeature chế độ DOM phụ thuộc vào cái này).
 * 2. "fingerprint spoof" — CHỈ đăng ký nếu FingerprintSpoofFeature đang bật
 *    cho đúng khe này lúc khởi động. Đây là lý do bật/tắt fingerprint spoof
 *    cần khởi động lại app — quyết định "có đăng ký hay không" chỉ xảy ra 1
 *    lần ở đây, lúc GeckoRuntime được tạo.
 */
object GeckoRuntimeProvider {
    private const val TAG = "GeckoRuntimeProvider"

    private const val EVAL_BRIDGE_LOCATION = "resource://android/assets/eval_bridge/"
    private const val EVAL_BRIDGE_ID = "eval-bridge@colablive.internal"

    private const val FINGERPRINT_SPOOF_LOCATION = "resource://android/assets/fingerprint_spoof/"
    private const val FINGERPRINT_SPOOF_ID = "fingerprint-spoof@colablive.internal"

    const val NATIVE_APP_ID = "browser"

    @Volatile private var runtime: GeckoRuntime? = null

    @Volatile var evalBridgeExtension: WebExtension? = null
        private set

    @Volatile var fingerprintSpoofExtension: WebExtension? = null
        private set

    fun get(context: Context, slotIndex: Int): GeckoRuntime {
        runtime?.let { return it }
        synchronized(this) {
            runtime?.let { return it }
            val rt = GeckoRuntime.create(context.applicationContext)

            rt.webExtensionController
                .ensureBuiltIn(EVAL_BRIDGE_LOCATION, EVAL_BRIDGE_ID)
                .accept(
                    { extension -> evalBridgeExtension = extension },
                    { error -> Log.e(TAG, "Không cài được eval bridge extension", error) }
                )

            if (FingerprintSpoofFeature.isEnabled(context, slotIndex)) {
                rt.webExtensionController
                    .ensureBuiltIn(FINGERPRINT_SPOOF_LOCATION, FINGERPRINT_SPOOF_ID)
                    .accept(
                        { extension -> fingerprintSpoofExtension = extension },
                        { error -> Log.e(TAG, "Không cài được fingerprint spoof extension", error) }
                    )
            }

            runtime = rt
            return rt
        }
    }
}
