package com.colablive.keeper.core

import android.content.Context
import org.json.JSONObject
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.GeckoRuntimeSettings
import org.mozilla.geckoview.WebExtension
import java.io.File

/**
 * Mỗi khe (process riêng) tự tạo 1 GeckoRuntime — đúng theo tài liệu chính
 * thức Mozilla: "GeckoRuntime can only be initialized once per process".
 *
 * Cô lập cookie/storage — 2 LỚP:
 *   1) `arguments(["-profile", <thư mục riêng của khe>, "-no-remote"])` —
 *      cờ dòng lệnh CHUẨN của Gecko/Firefox (xem tài liệu automation chính
 *      thức của GeckoView: args: [-profile, "/path"]), cho mỗi khe 1 thư
 *      mục hồ sơ Gecko RIÊNG BIỆT trên đĩa (cookies.sqlite, storage,
 *      permissions, cache... tách hẳn, không chỉ tách trong 1 hồ sơ dùng
 *      chung). "-no-remote" ngăn Gecko cố gắng dùng lại 1 instance khác
 *      đang chạy (quan trọng vì có NHIỀU tiến trình :slotN của CÙNG 1 app).
 *      ⚠️ CHƯA XÁC NHẬN TRÊN THIẾT BỊ THẬT — `-profile` là cờ chuẩn của
 *      Gecko nhưng KHÔNG có API public riêng (`GeckoRuntimeSettings` không
 *      có hàm `.profileDir()`) cho việc này trong ngữ cảnh nhúng Android
 *      (tài liệu chính thức mới thấy dùng trong automation/geckodriver) —
 *      cần build thật + kiểm tra log/file để xác nhận Gecko có thực sự ghi
 *      vào đúng thư mục này không, hay vẫn rơi về hồ sơ mặc định dùng
 *      chung. NẾU KHÔNG ăn, lớp 2 (contextId) vẫn còn tác dụng.
 *   2) `GeckoSessionSettings.Builder().contextId()` (xem GeckoViewEngine.kt)
 *      — cô lập cookie/storage theo "container" NGAY CẢ KHI dùng chung 1
 *      hồ sơ vật lý — đây là cơ chế CHẮC CHẮN có tác dụng (API công khai,
 *      không cần xác nhận thêm), nhưng chỉ cô lập storage theo-origin, KHÔNG
 *      cô lập permission/cache/profile-level prefs như lớp 1 nếu lớp 1 ăn.
 *
 * Proxy riêng theo khe: đăng ký WebExtension `proxy_config`
 * (assets/proxy_config/) dùng browser.proxy.onRequest — API CHUẨN của
 * WebExtension, xác nhận đúng hướng qua Mozilla bug 1525486 (đội Secure
 * Proxy: "có thể làm được bằng chính Proxy API sẵn có trong WebExtension").
 * KHÁC với việc DÙNG `arguments()` ĐỂ SET PROXY (đã xác nhận không hoạt
 * động qua báo lỗi công khai — không nhầm với việc dùng arguments() để set
 * `-profile` ở trên, đó là 2 việc khác nhau, `-profile` không liên quan gì
 * tới proxy).
 *
 * Background script (không phải content script) nên đăng ký message
 * delegate ở CẤP EXTENSION (`extension.setMessageDelegate`), không phải cấp
 * session như eval_bridge/fingerprint_spoof.
 */
object GeckoRuntimeProvider {
    private const val PROXY_CONFIG_LOCATION = "resource://android/assets/proxy_config/"
    private const val PROXY_CONFIG_ID = "proxy-config@colablive.internal"

    private val runtimes = mutableMapOf<Int, GeckoRuntime>()

    // Cho phép MainActivity truy cập runtime hiện có của 1 khe để gọi
    // `webExtensionController.install()` (tính năng cài addon từ file/URL
    // ngoài — xem `showAddonManagerDialog()` ở MainActivity.kt). Chỉ đọc,
    // không cho phép sửa map từ ngoài.
    fun getRuntime(slotIndex: Int): GeckoRuntime? = runtimes[slotIndex]
    private val dataDirs = mutableMapOf<Int, File>()

    /** Tên thư mục AN TOÀN trên đĩa ứng với 1 namespace hồ sơ — dùng chung ở
     * `createRuntime`, `clearSlotData`, `renameProfileDir` để 3 chỗ này
     * LUÔN tính ra đúng cùng 1 đường dẫn cho cùng 1 namespace (trước đây
     * mỗi hàm tự viết lại y hệt logic này riêng — dễ lệch nếu sửa 1 chỗ mà
     * quên chỗ khác). */
    private fun safeDirNameFor(namespace: String) =
        "gecko_profile_" + namespace.replace(Regex("[^a-zA-Z0-9_-]"), "_")

    @Synchronized
    fun get(context: Context, slotIndex: Int): GeckoRuntime {
        return runtimes.getOrPut(slotIndex) {
            createRuntime(context, slotIndex)
        }
    }

    /**
     * FIX BUG THẬT (người dùng xác nhận qua thử nghiệm: CHỈ 2 khe cùng mở
     * video YouTube là ĐÃ lỗi — không cần tới 4 khe) — xem chẩn đoán đầy đủ
     * ở `GeckoViewEngine.pollVideoDiagnostic()`: `readyState` kẹt ở 1,
     * `totalVideoFrames=0` mãi mãi dù `buffered` vẫn tăng đều (mạng tải
     * bình thường) — không hề có `error` nào.
     *
     * SỬA LẠI CHẨN ĐOÁN (người dùng chỉ đúng, lượt trước diễn giải quá tay):
     * đây KHÔNG phải phát hiện mới — `PROJECT_STATUS.md` đã tự đặt ra CHÍNH
     * giả thuyết "tranh chấp phần cứng giải mã" này từ trước (mục "8zzs") và
     * ĐÃ tự nghi ngờ lại chính nó sau khi tra thêm Bugzilla #1545817 + GitHub
     * mozilla/geckoview#203 ("phát nhiều video, video này bị gián đoạn khi
     * video kia phát" — xảy ra NGAY TRONG 1 TIẾN TRÌNH, 2 GeckoView cùng 1
     * activity). Lượt trước bỏ sót điểm quan trọng: nếu đây thật sự là giới
     * hạn "chip chỉ có N decoder phần cứng dùng chung cho MỌI app" thì 2 ỨNG
     * DỤNG KHÁC NHAU (trình duyệt + app phát nhạc/video khác) cũng phải
     * tranh nhau y hệt — nhưng thực tế (người dùng xác nhận) 2 app khác
     * nhau vẫn chồng chéo phát được bình thường. Việc chính GitHub issue
     * #203 ghi nhận lỗi này xảy ra NGAY TRONG GeckoView (kể cả cùng 1 tiến
     * trình) cho thấy nhiều khả năng đây là vấn đề nằm ở cách CHÍNH GeckoView
     * quản lý/tuần tự hoá tài nguyên giải mã cho MỖI SESSION nó tạo ra —
     * không phải một giới hạn phần cứng chia đều cho MỌI app trên máy như đã
     * viết quá tay trước đó.
     *
     * Vì vậy: đổi giải mã sang PHẦN MỀM (`media.hardware-video-decoding.
     * enabled=false`, xác nhận là pref THẬT qua chính test suite nội bộ
     * Mozilla trên searchfox.org, không suy đoán) vẫn là hướng giảm nhẹ HỢP
     * LÝ — né hẳn tài nguyên giải mã phần cứng mà GeckoView đang tranh chấp
     * với CHÍNH NÓ giữa các session/tiến trình của CÙNG app này, bất kể cơ
     * chế THẬT SỰ gây tranh chấp là gì (giới hạn phần cứng máy, hay hạn chế/
     * bug nội bộ GeckoView) — nhưng KHÔNG khẳng định đây là "giới hạn ROM/
     * chip dùng chung mọi app" như trước, vì bằng chứng thực tế không khớp
     * cách diễn giải đó. Đổi lại: TỐN CPU/PIN hơn hẳn so với phần cứng.
     *
     * Cách áp dụng AN TOÀN nhất (không đoán tên method Java theo đúng bài
     * học ở `createRuntime()` phía dưới — `GeckoRuntimeSettings` không có
     * hàm `setPreference(name, value)` chung, và API mới hơn như
     * `GeckoPreferenceController.setBoolPref` có thể chưa tồn tại ở bản pin
     * cứng 145.0.20251124145406, CHƯA XÁC NHẬN): dùng cơ chế
     * `GeckoRuntimeSettings.Builder.configFilePath()` — TỒN TẠI ổn định
     * xuyên suốt GeckoView từ rất lâu (Mozilla bug 1533385, năm 2019 — gần
     * như chắc chắn có mặt ở bản 145 pin cứng, khác hẳn rủi ro "javadoc
     * mozilla-central mới nhất" đã vấp phải trước đây), đọc 1 file YAML với
     * mục `prefs:` để set pref TRƯỚC khi Gecko khởi động.
     *
     * ⚠️ CHƯA XÁC NHẬN TRÊN THIẾT BỊ THẬT — cần build + test lại đúng kịch
     * bản "2 khe cùng phát" để biết chắc có hết bug không, và xem log
     * "GeckoRuntime I Adding debug configuration from: ..." trong logcat để
     * xác nhận Gecko THẬT SỰ đọc file này — KHÔNG suy luận thêm nếu chưa có
     * log/kết quả thật, y hệt tinh thần "chưa xác nhận" đã áp dụng cho cờ
     * `-profile` ở dưới.
     */
    private fun writeSoftwareDecodeConfigFile(context: Context): File {
        val f = File(context.filesDir, "gv-config.yaml")
        f.writeText(
            "prefs:\n" +
                "  media.hardware-video-decoding.enabled: false\n"
        )
        return f
    }

    private fun createRuntime(context: Context, slotIndex: Int): GeckoRuntime {
        // Thư mục hồ sơ RIÊNG cho HỒ SƠ đang gán vào khe này (không phải cho
        // bản thân số khe — xem AppPrefs.kt giải thích đầy đủ lý do) —
        // truyền vào Gecko qua cờ dòng lệnh "-profile" (xem giải thích ở
        // comment lớp 1 phía trên class).
        val profileNamespace = ProfileSlots.getSlotAssignment(context, slotIndex)
        val slotDataDir = File(context.filesDir, safeDirNameFor(profileNamespace))
        slotDataDir.mkdirs()
        dataDirs[slotIndex] = slotDataDir

        /**
         * BUG DO TÔI GÂY RA — ĐÃ THỬ 2 LẦN ĐỀU SAI, DỪNG LẠI Ở ĐÂY, KHÔNG
         * ĐOÁN LẦN 3 (người dùng chỉ đúng: đây là kiểu vá mù, dù có tra
         * cứu, vì tra SAI PHIÊN BẢN):
         *
         * Lần 1: đoán tên method `androidZygotePreloadEnabled` — sai, đã tự
         * phát hiện và gỡ trước khi build.
         * Lần 2: fetch thẳng trang javadoc gốc
         * mozilla.github.io/geckoview/javadoc/mozilla-central/... — tưởng
         * đã chắc chắn 100% vì đọc được chữ ký thật `appZygoteProcessEnabled`
         * — NHƯNG trang đó là bản "geckoview 156.0.20260823..." (mozilla-
         * central = bản NIGHTLY MỚI NHẤT), trong khi `app/build.gradle`
         * của CHÍNH dự án này pin CỨNG version 145.0.20251124145406 — lệch
         * 11 phiên bản. Method này khả năng cao được thêm SAU version 145,
         * không tồn tại trong bản project thực sự build — gây lỗi
         * "Unresolved reference 'appZygoteProcessEnabled'" thật trên CI.
         *
         * BÀI HỌC: mozilla-central javadoc LUÔN là bản mới nhất/nightly,
         * KHÔNG PHẢI tài liệu khớp với version PIN CỨNG trong build.gradle
         * — tra cứu "đúng trang chính thức" vẫn có thể sai nếu không khớp
         * đúng version đang dùng. Mozilla KHÔNG public sẵn javadoc tách
         * riêng theo từng version cũ tại 1 URL tĩnh dễ truy cập — không có
         * cách xác nhận chắc chắn 100% qua web mà không có chính file .aar
         * của geckoview:145.0.20251124145406 để giải nén/đọc trực tiếp
         * (cần Android Studio mở dependency đó, hoặc giải nén .aar thật).
         *
         * QUYẾT ĐỊNH: KHÔNG thêm `appZygoteProcessEnabled` (hay bất kỳ
         * tối ưu chưa xác nhận được đúng version nào khác) vào code nữa.
         * Nếu người dùng muốn bật tối ưu này, cách DUY NHẤT đáng tin: mở
         * project trong Android Studio, gõ `GeckoRuntimeSettings.Builder()`
         * rồi gõ `.`, để autocomplete hiện đúng danh sách method THẬT của
         * đúng bản .aar 145.0.20251124145406 đang nằm trong classpath — đó
         * là nguồn duy nhất khớp 100% với bản build thật, không phải web.
         */
        val configFile = writeSoftwareDecodeConfigFile(context)
        // FIX BUG THẬT (người dùng chỉ ra bằng chứng: log "TỰ KIỂM
        // configFilePath" báo KHÔNG thấy pref trong prefs.js ở CẢ 2 khe,
        // nhiều lần liên tiếp — không phải do chưa flush kịp, mà nhiều khả
        // năng `configFilePath()` THẬT SỰ không có tác dụng ở bản Gecko
        // 145 pin cứng này). Thêm 1 CƠ CHẾ THỨ HAI, cổ điển hơn và độc lập
        // hoàn toàn với `configFilePath()`: ghi thẳng file `user.js` vào
        // ĐÚNG thư mục hồ sơ (`slotDataDir`) — đây là cơ chế gốc của
        // Gecko/Firefox (không phải riêng GeckoView, dùng được từ rất lâu
        // đời, xuyên suốt mọi bản), TỰ ĐỘNG được đọc bởi bất kỳ tiến trình
        // Gecko nào khởi động với đúng thư mục hồ sơ đó — miễn `-profile`
        // (đã dùng ở dòng dưới) thật sự có tác dụng (mà log xác nhận CÓ —
        // dữ liệu mỗi khe tách biệt đúng theo tên hồ sơ). Ghi CẢ 2 cách
        // (configFilePath + user.js) — nếu 1 trong 2 có tác dụng là đạt
        // mục đích, không cần biết chính xác cách nào ăn.
        try {
            val userJs = File(slotDataDir, "user.js")
            userJs.writeText("user_pref(\"media.hardware-video-decoding.enabled\", false);\n")
            // FIX LỖ HỔNG LOGIC THẬT (đào sâu theo yêu cầu người dùng —
            // trước đây chỉ suy đoán "có thể tranh chấp tài nguyên", CHƯA
            // thực sự tra cứu tới cùng): tự-kiểm-tra cũ (dưới, khối
            // `Thread { ... prefs.js ... }`) đọc SAI FILE để xác nhận —
            // `prefs.js` là file GECKO TỰ GHI RA lúc ĐÓNG SẠCH (hoặc theo
            // 1 số mốc định kỳ khác), KHÔNG PHẢI lúc đang chạy; còn
            // `user.js` (file NÀY, cơ chế cổ điển Firefox/Gecko rất ổn
            // định, dùng xuyên suốt hàng chục năm) mới là file Gecko ĐỌC
            // LÚC KHỞI ĐỘNG để áp pref. Kiểm tra `prefs.js` trong lúc
            // runtime vẫn đang chạy sống gần như CHẮC CHẮN sẽ "không
            // thấy" bất kể `user.js` có ăn hay không — tự-kiểm-tra cũ dễ
            // gây hiểu lầm "pref có thể chưa ăn" trong khi thực ra chỉ là
            // đang hỏi nhầm file. SỬA: đọc lại NGAY chính `user.js` vừa
            // ghi (đồng bộ, không cần chờ Gecko làm gì cả — đây chỉ là
            // xác nhận BƯỚC GHI FILE của app tự nó có thành công hay
            // không, một nửa câu chuyện nhưng xác nhận được NGAY LẬP TỨC,
            // không cần đoán).
            val readback = userJs.readText()
            val writeOk = readback.contains("media.hardware-video-decoding.enabled")
            DebugLog.log(
                "GeckoRuntimeProvider slot $slotIndex: [TỰ KIỂM user.js] đọc lại NGAY sau khi ghi — " +
                    (if (writeOk) "ĐÚNG, có dòng pref trong file (bước GHI của app thành công — " +
                        "phần còn lại là Gecko có ĐỌC file này lúc khởi động hay không, cơ chế " +
                        "user.js là cơ chế gốc rất ổn định của Gecko nên khả năng cao có ăn, nhưng " +
                        "KHÔNG có cách xác nhận 100% từ phía app mà không có quyền truy cập " +
                        "about:config runtime — xem PROJECT_STATUS.md mục 49)"
                    else "SAI, KHÔNG thấy dòng pref sau khi đọc lại — bước GHI của app THẤT BẠI THẬT " +
                        "SỰ, cần điều tra tiếp (quyền ghi thư mục, disk đầy...)")
            )
            DebugLog.log("GeckoRuntimeProvider slot $slotIndex: đã ghi user.js ép giải mã phần mềm (cơ chế thứ 2, độc lập với configFilePath) tại ${userJs.absolutePath}")
        } catch (e: Exception) {
            DebugLog.log("GeckoRuntimeProvider slot $slotIndex: ghi user.js lỗi: ${e.message}")
        }
        val settings = GeckoRuntimeSettings.Builder()
            .consoleOutput(false)
            .aboutConfigEnabled(true)
            .arguments(arrayOf("-profile", slotDataDir.absolutePath, "-no-remote"))
            .configFilePath(configFile.absolutePath)
            .build()

        DebugLog.log("GeckoRuntimeProvider slot $slotIndex (hồ sơ '$profileNamespace'): bắt đầu GeckoRuntime.create() với -profile=${slotDataDir.absolutePath}")
        val runtime = try {
            GeckoRuntime.create(context, settings)
        } catch (e: Throwable) {
            // Không phải mọi lỗi native đều crash cứng process — 1 số lỗi
            // validate tham số vẫn ném exception JVM bắt được. Nếu vậy, thử
            // lại KHÔNG dùng cờ "-profile" (chưa xác nhận chắc chắn hoạt
            // động — xem PROJECT_STATUS.md mục "Lượt 3") thay vì để cả app
            // crash hẳn — cô lập vẫn còn contextId (lớp 2, chắc chắn hoạt
            // động) dù không có cô lập hồ sơ vật lý riêng (lớp 1).
            DebugLog.log("GeckoRuntimeProvider slot $slotIndex: GeckoRuntime.create() với -profile LỖI (${e.javaClass.simpleName}: ${e.message}) — thử lại KHÔNG có -profile")
            val fallbackSettings = GeckoRuntimeSettings.Builder()
                .consoleOutput(false)
                .aboutConfigEnabled(true)
                .configFilePath(configFile.absolutePath)
                .build()
            try {
                GeckoRuntime.create(context, fallbackSettings)
            } catch (e2: Throwable) {
                // Lượt thử lại (không -profile) CŨNG lỗi — thường là vì lỗi
                // gốc không liên quan gì tới "-profile" (ví dụ đúng là đã có
                // 1 GeckoRuntime khác trong process này, xem PROJECT_STATUS.md
                // mục "Only one GeckoRuntime instance"). Trước đây để lỗi này
                // BAY THẲNG lên ActivityThread → crash cứng cả app. Giờ log
                // rõ + ném lại 1 exception có thông điệp dễ hiểu hơn thay vì
                // im lặng nuốt lỗi (nuốt lỗi ở đây nguy hiểm hơn — app sẽ
                // chạy tiếp với engine null/half-broken).
                DebugLog.log("GeckoRuntimeProvider slot $slotIndex: fallback KHÔNG -profile CŨNG lỗi (${e2.javaClass.simpleName}: ${e2.message}) — không tạo được GeckoRuntime")
                throw IllegalStateException(
                    "Không tạo được trình duyệt cho Khe $slotIndex (có thể do process cũ chưa kịp đóng hẳn — thử đóng hẳn app rồi mở lại). Lỗi gốc: ${e2.message}",
                    e2
                )
            }
        }
        DebugLog.log("GeckoRuntimeProvider slot $slotIndex: GeckoRuntime.create() XONG (không crash)")

        registerProxyExtensionIfConfigured(context, runtime, slotIndex)

        DebugLog.log(
            "GeckoRuntime slot $slotIndex: -profile=${slotDataDir.absolutePath} " +
                "(CHƯA XÁC NHẬN có ăn thật không — xem log Gecko/kiểm tra file trong " +
                "thư mục này sau khi duyệt web) + contextId isolation (GeckoViewEngine)"
        )

        // FIX BUG THẬT (người dùng chỉ đúng: "tại sao không tự log mà bắt
        // người dùng tự vào about:config kiểm tra") — TỰ đọc thẳng file
        // `prefs.js` trong đúng thư mục profile vừa dùng, tìm dòng pref
        // `media.hardware-video-decoding.enabled` (bản vá mục 34.4/36 ghi
        // qua `configFilePath()`), log lại kết quả THẬT — không cần người
        // dùng tự làm gì cả nữa. LƯU Ý ĐỘ TIN CẬY (nói rõ, không giấu):
        // Gecko không ghi `prefs.js` ngay lập tức lúc khởi động — chỉ ghi
        // khi có 1 số mốc nhất định (đóng runtime sạch, sau 1 khoảng thời
        // gian...) nên poll thử trong tối đa ~20s thay vì đọc 1 lần rồi kết
        // luận vội "không có" — vẫn có thể ra "chưa thấy" nếu Gecko thật sự
        // chưa flush kịp, không phải nghĩa là pref chưa ăn.
        Thread {
            val prefFile = File(slotDataDir, "prefs.js")
            var found = false
            repeat(10) { attempt ->
                Thread.sleep(2000)
                if (prefFile.exists()) {
                    try {
                        val line = prefFile.readLines()
                            .firstOrNull { it.contains("media.hardware-video-decoding.enabled") }
                        if (line != null) {
                            DebugLog.log("Slot $slotIndex: [TỰ KIỂM configFilePath] TÌM THẤY trong prefs.js (lần thử ${attempt + 1}/10): $line")
                            found = true
                            return@Thread
                        }
                    } catch (e: Exception) {
                        DebugLog.log("Slot $slotIndex: [TỰ KIỂM configFilePath] lỗi đọc prefs.js: ${e.message}")
                    }
                }
            }
            if (!found) {
                DebugLog.log("Slot $slotIndex: [TỰ KIỂM configFilePath qua prefs.js] KHÔNG thấy dòng 'media.hardware-video-decoding.enabled' sau 20s — ĐÂY LÀ KẾT QUẢ GẦN NHƯ CHẮC CHẮN SẼ XẢY RA (không phải dấu hiệu pref chưa ăn): prefs.js là file Gecko TỰ GHI RA lúc ĐÓNG SẠCH runtime (hoặc 1 số mốc định kỳ khác), KHÔNG PHẢI lúc runtime đang chạy sống — kiểm tra file này trong lúc app vẫn mở gần như luôn ra 'không thấy' bất kể pref có ăn hay không. Xem tự-kiểm-tra ĐÁNG TIN CẬY hơn ngay ở chỗ ghi user.js phía trên (đọc lại NGAY sau khi ghi, đồng bộ, không phụ thuộc Gecko flush gì cả) — đó mới là bằng chứng thật cho bước GHI. Muốn xác nhận 100% Gecko có THẬT SỰ đọc/áp dụng pref này lúc khởi động hay không thì vẫn cần vào about:config thủ công (xem PROJECT_STATUS.md mục 49).")
            }
        }.start()

        return runtime
    }

    private fun registerProxyExtensionIfConfigured(context: Context, runtime: GeckoRuntime, slotIndex: Int) {
        val proxyType = AppPrefs.getInt(context, slotIndex, "proxy_type", 0)
        if (proxyType == 0) return // "Direct" — không cần đăng ký extension proxy

        val host = AppPrefs.getString(context, slotIndex, "proxy_host", "")
        val proxyPort = AppPrefs.getString(context, slotIndex, "proxy_port", "0").toIntOrNull() ?: 0
        if (host.isEmpty() || proxyPort == 0) {
            DebugLog.log("Slot $slotIndex: proxy_type != Direct nhưng thiếu host/port, bỏ qua đăng ký proxy extension")
            return
        }
        val user = AppPrefs.getString(context, slotIndex, "proxy_user", "")
        val pass = AppPrefs.getString(context, slotIndex, "proxy_pass", "")

        runtime.webExtensionController
            .ensureBuiltIn(PROXY_CONFIG_LOCATION, PROXY_CONFIG_ID)
            .accept(
                { extension ->
                    if (extension == null) return@accept
                    val messageDelegate = object : WebExtension.MessageDelegate {
                        override fun onConnect(port: WebExtension.Port) {
                            val cfg = JSONObject().apply {
                                put("enabled", true)
                                put("type", if (proxyType == 2) "socks" else "http")
                                put("host", host)
                                put("port", proxyPort)
                                put("username", user)
                                put("password", pass)
                            }
                            port.postMessage(
                                JSONObject().apply {
                                    put("type", "proxy_config")
                                    put("config", cfg)
                                }
                            )
                            DebugLog.log("Slot $slotIndex: đã đẩy cấu hình proxy xuống ($host:$proxyPort)")
                        }
                    }
                    extension.setMessageDelegate(messageDelegate, "browser")
                },
                { error -> DebugLog.log("Slot $slotIndex: không đăng ký được proxy extension — $error") }
            )
    }

    fun getDataDir(slotIndex: Int): File? = dataDirs[slotIndex]

    /** Chỉ quên khỏi map — KHÔNG tắt native runtime (xem bug 8g: dùng hàm
     * này mà process không chết theo ngay sau đó sẽ gây crash "Only one
     * GeckoRuntime instance"). Giữ lại cho `releaseAll()`. Muốn đóng THẬT
     * (đảm bảo Gecko flush dữ liệu) và CHẮC CHẮN process sẽ chết ngay sau,
     * dùng `shutdown()` bên dưới thay vì hàm này. */
    fun release(slotIndex: Int) {
        runtimes.remove(slotIndex)
    }

    /**
     * Tắt hẳn GeckoRuntime — gọi `runtime.shutdown()` thật (API chuẩn của
     * GeckoView, dùng để đảm bảo mọi dữ liệu persistent — cookie, session
     * store — được flush xuống đĩa trước khi tiến trình chết), rồi mới quên
     * khỏi map. CHỈ được gọi khi CHẮC CHẮN tiến trình này sẽ bị kill/exit
     * ngay sau đó (hiện chỉ gọi từ `MainActivity`'s gracefulCloseReceiver,
     * bản thân broadcast đó chỉ được gửi từ
     * `ProfilePickerActivity.restartSlot()` — luôn kill/exit process ngay
     * sau khi nhận ACK) — nếu process còn sống tiếp mà gọi hàm này thì lần
     * tạo GeckoRuntime kế tiếp trong CHÍNH process đó sẽ bị Gecko từ chối
     * (đúng bug đã sửa ở mục 8g, chỉ là giờ đổi từ "quên mà không tắt"
     * thành "tắt nhưng process không chết" — TRIỆU CHỨNG GIỐNG NHAU).
     */
    fun shutdown(slotIndex: Int) {
        runtimes.remove(slotIndex)?.let { runtime ->
            try {
                runtime.shutdown()
                DebugLog.log("GeckoRuntimeProvider slot $slotIndex: runtime.shutdown() xong")
            } catch (e: Exception) {
                DebugLog.log("GeckoRuntimeProvider slot $slotIndex: lỗi khi shutdown runtime: ${e.javaClass.simpleName}: ${e.message}")
            }
        }
    }

    fun releaseAll() {
        runtimes.clear()
        dataDirs.clear()
    }

    fun clearSlotData(context: Context, slotIndex: Int) {
        val profileNamespace = ProfileSlots.getSlotAssignment(context, slotIndex)
        val dir = File(context.filesDir, safeDirNameFor(profileNamespace))
        if (dir.exists()) {
            dir.deleteRecursively()
            DebugLog.log("Cleared Gecko profile data for '$profileNamespace' (slot $slotIndex)")
        }
    }

    /**
     * Đổi tên thư mục hồ sơ Gecko trên đĩa từ `oldNamespace` sang
     * `newNamespace` — dùng khi "đặt tên" dữ liệu đang có sẵn trong 1 khe
     * thành hồ sơ có tên (xem `ProfileSlots.schedulePromoteSlotData`).
     *
     * CHỈ được gọi từ `LiveBrowserApp.onCreate()` — TRƯỚC khi `get()`/
     * `createRuntime()` của khe đó từng chạy trong tiến trình này (tiến
     * trình vừa khởi động sạch), để chắc chắn không có GeckoRuntime nào
     * đang mở file trong thư mục bị đổi tên.
     */
    fun renameProfileDir(context: Context, oldNamespace: String, newNamespace: String) {
        if (oldNamespace == newNamespace) return
        val oldDir = File(context.filesDir, safeDirNameFor(oldNamespace))
        val newDir = File(context.filesDir, safeDirNameFor(newNamespace))
        if (oldDir.exists() && !newDir.exists()) {
            val ok = oldDir.renameTo(newDir)
            DebugLog.log("renameProfileDir: '$oldNamespace' -> '$newNamespace' ${if (ok) "OK" else "THẤT BẠI"}")
        } else {
            DebugLog.log("renameProfileDir: bỏ qua (oldDir tồn tại=${oldDir.exists()}, newDir đã tồn tại=${newDir.exists()})")
        }
    }
}
