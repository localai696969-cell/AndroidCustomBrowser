package com.colablive.keeper.core

import android.content.Context
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.GeckoRuntimeSettings
import java.io.File

/**
 * Mỗi slot có GeckoRuntime RIÊNG với:
 * - Data directory riêng (cô lập cookie/storage)
 * - Proxy riêng (đổi IP per profile)
 * - DNS over HTTPS (che DNS leak)
 * - Timezone đồng bộ proxy
 * - Fingerprint riêng
 */
object GeckoRuntimeProvider {
    private val runtimes = mutableMapOf<Int, GeckoRuntime>()
    private val dataDirs = mutableMapOf<Int, File>()

    @Synchronized
    fun get(context: Context, slotIndex: Int): GeckoRuntime {
        return runtimes.getOrPut(slotIndex) {
            createRuntime(context, slotIndex)
        }
    }

    private fun createRuntime(context: Context, slotIndex: Int): GeckoRuntime {
        val slotDataDir = File(context.filesDir, "gecko_profile_slot_$slotIndex")
        slotDataDir.mkdirs()
        dataDirs[slotIndex] = slotDataDir

        val settings = GeckoRuntimeSettings.Builder()
            .consoleOutputEnabled(false)
            .aboutConfigEnabled(true)
            .build()

        val runtime = GeckoRuntime.create(context, settings)

        // Cấu hình proxy + DNS + timezone cho slot này
        setupNetworkForSlot(runtime, slotIndex)

        DebugLog.log("GeckoRuntime created for slot $slotIndex, dataDir=${slotDataDir.absolutePath}")
        return runtime
    }

    /**
     * Cấu hình proxy + DNS + timezone per slot.
     */
    private fun setupNetworkForSlot(runtime: GeckoRuntime, slotIndex: Int) {
        val proxyType = AppPrefs.getString(null, slotIndex, "proxy_type", "0")
        val proxyHost = AppPrefs.getString(null, slotIndex, "proxy_host", "")
        val proxyPort = AppPrefs.getInt(null, slotIndex, "proxy_port", 0)
        val proxyUser = AppPrefs.getString(null, slotIndex, "proxy_user", "")
        val proxyPass = AppPrefs.getString(null, slotIndex, "proxy_pass", "")
        val timezone = AppPrefs.getString(null, slotIndex, "fp_timezone", "")

        // Proxy setup
        if (proxyType == "1" && proxyHost.isNotEmpty() && proxyPort > 0) {
            // Sẽ setup qua eval bridge khi session mở
            DebugLog.log("Slot $slotIndex proxy: $proxyHost:$proxyPort")
        }

        // DNS over HTTPS — che DNS leak
        val dnsJs = buildString {
            append("Services.prefs.setIntPref(\"network.trr.mode\", 2);") // Mode 2 = TRR first
            append("Services.prefs.setCharPref(\"network.trr.uri\", \"https://mozilla.cloudflare-dns.com/dns-query\");")
            append("Services.prefs.setBoolPref(\"network.trr.wait-for-portal\", false);")
            append("Services.prefs.setIntPref(\"network.trr.request-timeout\", 3000);")
        }
        // Lưu để eval sau
        AppPrefs.setString(null, slotIndex, "_dns_js", dnsJs)

        // Timezone đồng bộ
        if (timezone.isNotEmpty()) {
            val tzJs = "Services.prefs.setCharPref(\"intl.timezone.default\", \"$timezone\");"
            AppPrefs.setString(null, slotIndex, "_tz_js", tzJs)
        }
    }

    fun getDataDir(slotIndex: Int): File? = dataDirs[slotIndex]

    fun release(slotIndex: Int) {
        runtimes.remove(slotIndex)
    }

    fun releaseAll() {
        runtimes.clear()
        dataDirs.clear()
    }

    fun clearSlotData(context: Context, slotIndex: Int) {
        val dir = File(context.filesDir, "gecko_profile_slot_$slotIndex")
        if (dir.exists()) {
            dir.deleteRecursively()
            DebugLog.log("Cleared data for slot $slotIndex")
        }
    }
}
