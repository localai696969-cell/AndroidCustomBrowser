package com.colablive.keeper.core

import android.content.Context
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.GeckoRuntimeSettings
import java.io.File

object GeckoRuntimeProvider {
    private val runtimes = mutableMapOf<Int, GeckoRuntime>()
    private val dataDirs = mutableMapOf<Int, File>()

    @Synchronized
    fun get(context: Context, slotIndex: Int): GeckoRuntime {
        return runtimes.getOrPut(slotIndex) {
            createRuntime(context, slotIndex)
        }
    }

    private fun createRuntime(context: Context, slotIndex: Int): GeckoRuntime {
        val slotDataDir = File(context.filesDir, "gecko_profile_slot_$slotIndex")
        slotDataDir.mkdirs()
        dataDirs[slotIndex] = slotDataDir

        val settings = GeckoRuntimeSettings.Builder()
            .consoleOutput(false)
            .aboutConfigEnabled(true)
            .build()

        val runtime = GeckoRuntime.create(context, settings)
        setupNetworkForSlot(context, slotIndex)
        DebugLog.log("GeckoRuntime created for slot $slotIndex")
        return runtime
    }

    private fun setupNetworkForSlot(context: Context, slotIndex: Int) {
        val dnsJs = buildString {
            append("Services.prefs.setIntPref(\"network.trr.mode\", 2);")
            append("Services.prefs.setCharPref(\"network.trr.uri\", \"https://mozilla.cloudflare-dns.com/dns-query\");")
            append("Services.prefs.setBoolPref(\"network.trr.wait-for-portal\", false);")
            append("Services.prefs.setIntPref(\"network.trr.request-timeout\", 3000);")
        }
        AppPrefs.setString(context, slotIndex, "_dns_js", dnsJs)

        val timezone = AppPrefs.getString(context, slotIndex, "fp_timezone", "")
        if (timezone.isNotEmpty()) {
            val tzJs = "Services.prefs.setCharPref(\"intl.timezone.default\", \"$timezone\");"
            AppPrefs.setString(context, slotIndex, "_tz_js", tzJs)
        }
    }

    fun getDataDir(slotIndex: Int): File? = dataDirs[slotIndex]
    fun release(slotIndex: Int) { runtimes.remove(slotIndex) }
    fun releaseAll() { runtimes.clear(); dataDirs.clear() }

    fun clearSlotData(context: Context, slotIndex: Int) {
        val dir = File(context.filesDir, "gecko_profile_slot_$slotIndex")
        if (dir.exists()) {
            dir.deleteRecursively()
            DebugLog.log("Cleared data for slot $slotIndex")
        }
    }
}
