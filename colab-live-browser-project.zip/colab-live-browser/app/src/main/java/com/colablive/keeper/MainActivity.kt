package com.colablive.keeper

import android.app.Dialog

import android.Manifest
import android.content.ClipData
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.DragEvent
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.colablive.keeper.core.*
import com.colablive.keeper.features.colablive.ColabLiveKeeperFeature
import com.colablive.keeper.features.downloads.DownloadManagerFeature
import com.colablive.keeper.features.fingerprint.FingerprintSpoofFeature
import org.mozilla.geckoview.GeckoView
import java.net.URLEncoder

open class MainActivity : AppCompatActivity() {

    private lateinit var geckoView: GeckoView
    private lateinit var engine: GeckoViewEngine
    private lateinit var urlBar: EditText
    private lateinit var tabBar: HorizontalScrollView
    private lateinit var tabContainer: LinearLayout
    private lateinit var progressBar: ProgressBar
    private lateinit var backButton: ImageButton
    private lateinit var forwardButton: ImageButton
    private lateinit var refreshButton: ImageButton
    private lateinit var menuButton: ImageButton
    private lateinit var newTabButton: ImageButton
    private lateinit var tabSwitcherButton: TextView
    private lateinit var toolbarContainer: LinearLayout

    private val handler = Handler(Looper.getMainLooper())
    private var slotIndex = 0
    private val tabViews = mutableMapOf<String, View>()

    companion object {
        private const val RC_FILE_PICKER = 1001
        private const val RC_NOTIFICATIONS = 1002
        private const val PERMISSION_NOTIFICATIONS = Manifest.permission.POST_NOTIFICATIONS
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // QUAN TRỌNG: launcher (bấm icon màn hình chính) KHÔNG gửi kèm extra
        // tuỳ ý — "slot_index" chỉ có khi CHÍNH APP tự mở 1 khe khác. Bấm
        // thẳng icon "Khe 1/2/3" (activity-alias, chạy process ":slot1/2/3"
        // riêng) sẽ không có extra này — nếu chỉ dựa extra, mọi khe sẽ luôn
        // nghĩ mình là khe 0, khiến 2 tiến trình khác nhau cùng cố mở CHUNG 1
        // thư mục hồ sơ Gecko (`gecko_profile_slot_0`) cùng lúc — Gecko có
        // khoá hồ sơ, việc này có thể khiến GeckoRuntime khởi tạo lỗi/crash ở
        // tiến trình mở sau. Nguồn đáng tin cậy thật là TÊN TIẾN TRÌNH đang chạy.
        slotIndex = if (intent.hasExtra("slot_index")) {
            intent.getIntExtra("slot_index", 0)
        } else {
            ProfileSlots.getCurrentSlotIndex(this)
        }
        ForegroundState.broadcastActiveSlot(this, slotIndex)

        DebugLog.log("MainActivity.onCreate: slot=$slotIndex, bắt đầu setupUI()")
        setupUI()
        DebugLog.log("MainActivity.onCreate: setupUI xong, bắt đầu setupEngine() (tạo GeckoRuntime — điểm nghi ngờ crash native cao nhất)")
        setupEngine()
        DebugLog.log("MainActivity.onCreate: setupEngine xong, bắt đầu setupDragDrop()")
        setupDragDrop()
        DebugLog.log("MainActivity.onCreate: setupDragDrop xong, bắt đầu initServices()")
        initServices()
        DebugLog.log("MainActivity.onCreate: initServices xong, bắt đầu requestPermissions()")
        requestPermissions()
        DebugLog.log("MainActivity.onCreate: HOÀN TẤT")
    }

    private fun initServices() {
        KeepAliveService.start(this)
        val downloadFeature = FeatureRegistry.all().filterIsInstance<DownloadManagerFeature>().firstOrNull()
        downloadFeature?.initEngine(this)

        // Setup proxy cho slot này
        setupProxyForSlot()

        // Load trang mặc định — hoặc URL được truyền vào từ "Mở ở khe khác"
        // (nhấn giữ link ở khe khác, chọn mở link này ở khe này)
        val openUrl = intent.getStringExtra("open_url")
        val homeUrl = openUrl ?: AppPrefs.getString(this, slotIndex, "home_url", "https://www.google.com")
        engine.createTab(homeUrl)
        refreshTabBar()
    }

    private fun setupProxyForSlot() {
        val proxyType = AppPrefs.getInt(this, slotIndex, "proxy_type", 0)
        if (proxyType > 0) {
            val host = AppPrefs.getString(this, slotIndex, "proxy_host", "")
            val port = AppPrefs.getString(this, slotIndex, "proxy_port", "").toIntOrNull() ?: 0
            val user = AppPrefs.getString(this, slotIndex, "proxy_user", "")
            val pass = AppPrefs.getString(this, slotIndex, "proxy_pass", "")

            if (host.isNotEmpty() && port > 0) {
                engine.setupProxy(host, port, user, pass)
                DebugLog.log("Slot $slotIndex proxy: $host:$port")
            }
        }
    }

    // ===== UI Setup =====

    private fun setupUI() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
        }

        // Toolbar container
        toolbarContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#F8F9FA"))
        }

        // Tab bar
        tabBar = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            val tabLayout = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(8, 8, 8, 8)
            }
            tabContainer = tabLayout
            addView(tabLayout, ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        toolbarContainer.addView(tabBar, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // URL + Navigation bar
        val navBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(16, 8, 16, 8)
            gravity = Gravity.CENTER_VERTICAL
        }

        backButton = ImageButton(this).apply {
            setImageResource(android.R.drawable.ic_media_previous)
            setBackgroundColor(Color.TRANSPARENT)
            setOnClickListener { engine.goBack() }
        }
        navBar.addView(backButton, ViewGroup.LayoutParams(48, 48))

        forwardButton = ImageButton(this).apply {
            setImageResource(android.R.drawable.ic_media_next)
            setBackgroundColor(Color.TRANSPARENT)
            setOnClickListener { engine.goForward() }
        }
        navBar.addView(forwardButton, ViewGroup.LayoutParams(48, 48))

        refreshButton = ImageButton(this).apply {
            setImageResource(android.R.drawable.ic_menu_rotate)
            setBackgroundColor(Color.TRANSPARENT)
            setOnClickListener { engine.reload() }
        }
        navBar.addView(refreshButton, ViewGroup.LayoutParams(48, 48))

        urlBar = EditText(this).apply {
            hint = "Nhập URL hoặc tìm kiếm..."
            setBackgroundResource(android.R.drawable.edit_text)
            setPadding(16, 12, 16, 12)
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            imeOptions = EditorInfo.IME_ACTION_GO
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_GO) {
                    navigateToUrl(text.toString())
                    true
                } else false
            }
        }
        navBar.addView(urlBar, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        newTabButton = ImageButton(this).apply {
            setImageResource(android.R.drawable.ic_input_add)
            setBackgroundColor(Color.TRANSPARENT)
            setOnClickListener {
                engine.createTab("https://www.google.com")
                refreshTabBar()
            }
        }
        navBar.addView(newTabButton, ViewGroup.LayoutParams(48, 48))

        // Nút "N tab" kiểu Chrome — bấm mở lưới xem/chuyển/đóng tab, thay
        // vì phải cuộn dải chip ngang khi có nhiều tab.
        tabSwitcherButton = TextView(this).apply {
            text = "1"
            textSize = 13f
            gravity = Gravity.CENTER
            setTextColor(Color.DKGRAY)
            setBackgroundResource(android.R.drawable.btn_default_small)
            setOnClickListener { showTabSwitcher() }
        }
        navBar.addView(tabSwitcherButton, ViewGroup.LayoutParams(48, 48))

        menuButton = ImageButton(this).apply {
            setImageResource(android.R.drawable.ic_menu_more)
            setBackgroundColor(Color.TRANSPARENT)
            setOnClickListener { showMenu() }
        }
        navBar.addView(menuButton, ViewGroup.LayoutParams(48, 48))

        toolbarContainer.addView(navBar, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // Progress bar
        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            visibility = View.GONE
        }
        toolbarContainer.addView(progressBar, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 4))

        root.addView(toolbarContainer, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // GeckoView
        geckoView = GeckoView(this)
        root.addView(geckoView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        setContentView(root)
    }

    private fun setupEngine() {
        engine = GeckoViewEngine(this, geckoView, slotIndex)

        engine.onPageLoadedListener = { url ->
            urlBar.setText(url)
            updateNavButtons()
            ForegroundState.broadcastActiveSlot(this, slotIndex, url)
            FeatureRegistry.enabledFeatures(this, slotIndex).forEach {
                it.onPageFinished(this, slotIndex, engine, url)
            }
        }

        engine.onPageErrorListener = { url, code ->
            DebugLog.log("Page error: $url code=$code")
        }

        engine.onTitleChangedListener = { title ->
            updateTabTitle(title)
        }

        engine.onProgressChangedListener = { progress ->
            progressBar.progress = progress
            progressBar.visibility = if (progress in 1..99) View.VISIBLE else View.GONE
        }

        engine.onNewTabRequestedListener = { url ->
            engine.createTab(url)
            refreshTabBar()
        }

        engine.onTabSwitchedListener = {
            urlBar.setText(engine.currentUrl() ?: "")
            updateNavButtons()
            refreshTabBar()
        }

        engine.onLongPressLinkListener = { uri, text ->
            runOnUiThread { showLinkContextMenu(uri, text) }
        }

        engine.onDownloadRequestedListener = { url, fileName ->
            val downloadFeature = FeatureRegistry.all().filterIsInstance<com.colablive.keeper.features.downloads.DownloadManagerFeature>().firstOrNull()
            downloadFeature?.startDownloadWithPolicy(this, url, fileName)
        }

        engine.onFilePromptListener = { mimeTypes ->
            showFilePicker(mimeTypes)
        }

        startFeatureTickLoop()
    }

    /**
     * Vòng lặp tick 60s/lần cho các feature cần hành vi định kỳ (vd Colab Live
     * Keeper chế độ DOM — bấm nút Connect lại). Trước đây `onTick` được viết
     * đầy đủ trong ColabLiveKeeperFeature nhưng KHÔNG CÓ GÌ GỌI TỚI NÓ, nên
     * chế độ DOM (mặc định) không có tác dụng gì dù đã bật switch trong Settings.
     */
    private val featureTickRunnable = object : Runnable {
        override fun run() {
            FeatureRegistry.enabledFeatures(this@MainActivity, slotIndex).forEach {
                it.onTick(this@MainActivity, slotIndex, engine, engine.currentUrl())
            }
            handler.postDelayed(this, 60_000L)
        }
    }

    private fun startFeatureTickLoop() {
        handler.removeCallbacks(featureTickRunnable)
        handler.postDelayed(featureTickRunnable, 60_000L)
    }

    private fun navigateToUrl(input: String) {
        val url = when {
            input.startsWith("http://") || input.startsWith("https://") -> input
            input.contains(".") && !input.contains(" ") -> "https://$input"
            else -> "https://www.google.com/search?q=${URLEncoder.encode(input, "UTF-8")}"
        }
        engine.loadUrl(url)
    }

    private fun updateNavButtons() {
        backButton.isEnabled = engine.canGoBack()
        backButton.alpha = if (engine.canGoBack()) 1f else 0.3f
        forwardButton.isEnabled = engine.canGoForward()
        forwardButton.alpha = if (engine.canGoForward()) 1f else 0.3f
    }

    private fun updateTabTitle(title: String) {
        // Tiêu đề chỉ đổi cho tab đang active — vẽ lại cả thanh tab cho đơn giản
        // và luôn nhất quán (số lượng tab thường nhỏ, chi phí không đáng kể).
        refreshTabBar()
    }

    /**
     * Vẽ lại toàn bộ thanh tab từ danh sách tab thật của engine.
     * Trước đây thanh tab được khai báo nhưng KHÔNG BAO GIỜ có view nào được
     * thêm vào `tabContainer` — tạo tab mới không hiện gì, không bấm chuyển
     * được. Đây là hàm khắc phục, gọi lại mỗi khi danh sách/tab active/tiêu
     * đề thay đổi.
     */
    private fun refreshTabBar() {
        tabContainer.removeAllViews()
        tabViews.clear()
        val activeId = engine.getActiveTab()?.id
        val tabs = engine.getTabs()
        tabs.forEach { tab ->
            val chip = createTabChip(tab, tab.id == activeId)
            tabViews[tab.id] = chip
            tabContainer.addView(chip)
        }
        if (::tabSwitcherButton.isInitialized) {
            tabSwitcherButton.text = tabs.size.toString()
        }
    }

    private fun createTabChip(tab: com.colablive.keeper.core.BrowserTab, isActive: Boolean): View {
        val chip = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(20, 10, 8, 10)
            setBackgroundColor(if (isActive) Color.WHITE else Color.parseColor("#E0E0E0"))
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                setMargins(4, 4, 4, 4)
            }
            isClickable = true
            setOnClickListener {
                if (tab.id != engine.getActiveTab()?.id) {
                    engine.switchToTab(tab.id)
                }
            }
        }

        chip.addView(TextView(this).apply {
            text = (tab.title.takeIf { it.isNotEmpty() } ?: tab.url).take(16)
            textSize = 13f
            setTextColor(Color.DKGRAY)
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(160, ViewGroup.LayoutParams.WRAP_CONTENT)
        })

        chip.addView(ImageButton(this).apply {
            setImageResource(android.R.drawable.ic_menu_close_clear_cancel)
            setBackgroundColor(Color.TRANSPARENT)
            layoutParams = LinearLayout.LayoutParams(40, 40)
            setOnClickListener {
                if (engine.getTabs().size <= 1) {
                    Toast.makeText(this@MainActivity, "Không thể đóng tab cuối cùng", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                engine.closeTab(tab.id)
                refreshTabBar()
            }
        })

        return chip
    }

    /**
     * Lưới xem/chuyển/đóng tab kiểu Chrome (bấm nút "N" cạnh nút + trên
     * thanh công cụ) — thay vì phải dò dải chip ngang khi có nhiều tab.
     */
    private fun showTabSwitcher() {
        val dialog = Dialog(this, android.R.style.Theme_Black_NoTitleBar)
        val activeId = engine.getActiveTab()?.id
        val tabs = engine.getTabs()

        val grid = GridLayout(this).apply {
            columnCount = 2
            setPadding(24, 24, 24, 24)
        }
        tabs.forEach { tab ->
            grid.addView(createTabCard(tab, tab.id == activeId, dialog))
        }
        grid.addView(createNewTabCard(dialog))

        val scroll = ScrollView(this).apply { addView(grid) }

        val titleBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(24, 16, 24, 16)
            addView(TextView(this@MainActivity).apply {
                text = "${tabs.size} tab đang mở"
                textSize = 16f
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            })
            addView(Button(this@MainActivity).apply {
                text = "Đóng"
                setOnClickListener { dialog.dismiss() }
            })
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
            addView(titleBar)
            addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        }
        dialog.setContentView(root)
        dialog.show()
    }

    private fun createTabCard(tab: com.colablive.keeper.core.BrowserTab, isActive: Boolean, dialog: Dialog): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 16, 20, 16)
            setBackgroundColor(if (isActive) Color.parseColor("#D2E3FC") else Color.parseColor("#F1F3F4"))
            layoutParams = GridLayout.LayoutParams().apply {
                width = 0
                height = ViewGroup.LayoutParams.WRAP_CONTENT
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(8, 8, 8, 8)
            }
            isClickable = true
            setOnClickListener {
                engine.switchToTab(tab.id)
                dialog.dismiss()
            }
        }

        val titleRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        titleRow.addView(TextView(this).apply {
            text = tab.title.takeIf { it.isNotEmpty() } ?: tab.url
            textSize = 14f
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        })
        titleRow.addView(ImageButton(this).apply {
            setImageResource(android.R.drawable.ic_menu_close_clear_cancel)
            setBackgroundColor(Color.TRANSPARENT)
            layoutParams = LinearLayout.LayoutParams(36, 36)
            setOnClickListener {
                if (engine.getTabs().size <= 1) {
                    Toast.makeText(this@MainActivity, "Không thể đóng tab cuối cùng", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                engine.closeTab(tab.id)
                refreshTabBar()
                dialog.dismiss()
                showTabSwitcher() // vẽ lại lưới cho khớp danh sách mới
            }
        })
        card.addView(titleRow)

        card.addView(TextView(this).apply {
            text = tab.url
            textSize = 11f
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            setTextColor(Color.GRAY)
        })
        return card
    }

    private fun createNewTabCard(dialog: Dialog): View {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(20, 24, 20, 24)
            setBackgroundColor(Color.parseColor("#F1F3F4"))
            layoutParams = GridLayout.LayoutParams().apply {
                width = 0
                height = ViewGroup.LayoutParams.WRAP_CONTENT
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(8, 8, 8, 8)
            }
            isClickable = true
            addView(TextView(this@MainActivity).apply {
                text = "+  Tab mới"
                textSize = 14f
                gravity = Gravity.CENTER
            })
            setOnClickListener {
                engine.createTab("https://www.google.com")
                refreshTabBar()
                dialog.dismiss()
            }
        }
    }

    private fun showMenu() {
        val items = arrayOf("Settings", "Features", "Debug Log", "Chuyển Khe", "Proxy Config", "Test Cookie Leak", "IDM Downloads", "Sniff Media", "💾 Lưu Trang Web", "⚙️ Cài đặt Download", "🩹 Xem crash gần nhất", "📋 Sao chép URL hiện tại")
        AlertDialog.Builder(this)
            .setTitle("Menu (Slot $slotIndex)")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> startActivity(Intent(this, SettingsActivity::class.java).putExtra("slot_index", slotIndex))
                    1 -> startActivity(Intent(this, FeatureSettingsActivity::class.java).putExtra("slot_index", slotIndex))
                    2 -> startActivity(Intent(this, DebugLogActivity::class.java))
                    3 -> startActivity(Intent(this, ProfilePickerActivity::class.java))
                    4 -> showProxyDialog()
                    5 -> showLeakTestDialog()
                    6 -> showIDMDialog()
                    7 -> showSniffDialog()
                    8 -> showWebArchiveDialog()
                    9 -> showDownloadPolicySettings()
                    10 -> startActivity(Intent(this, CrashReportActivity::class.java))
                    11 -> copyToClipboard("URL", engine.currentUrl() ?: "")
                }
            }
            .show()
    }

    private fun copyToClipboard(label: String, text: String) {
        val clipboard = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
        clipboard.setPrimaryClip(android.content.ClipData.newPlainText(label, text))
        Toast.makeText(this, "Đã sao chép: $text", Toast.LENGTH_SHORT).show()
    }

    /** Menu hiện ra khi nhấn giữ 1 liên kết trên trang (trước đây không làm gì cả). */
    private fun showLinkContextMenu(uri: String, linkText: String?) {
        val items = arrayOf("Mở trong tab mới", "Mở ở khe khác…", "Sao chép liên kết", "Chia sẻ liên kết")
        AlertDialog.Builder(this)
            .setTitle(linkText?.takeIf { it.isNotBlank() } ?: uri)
            .setItems(items) { _, which ->
                when (which) {
                    0 -> {
                        engine.createTab(uri)
                        refreshTabBar()
                    }
                    1 -> showOpenInSlotDialog(uri)
                    2 -> copyToClipboard("link", uri)
                    3 -> {
                        val shareIntent = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, uri)
                        }
                        startActivity(Intent.createChooser(shareIntent, "Chia sẻ liên kết"))
                    }
                }
            }
            .show()
    }

    /** Mở 1 URL cụ thể ở 1 khe KHÁC (không phải khe đang đứng) — mở tiến trình khe đó kèm URL qua extra "open_url". */
    private fun showOpenInSlotDialog(uri: String) {
        val slotOptions = (0..ProfileSlots.SLOT_COUNT).filter { it != slotIndex }
        val labels = slotOptions.map { ProfileSlots.getSlotName(it) }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Mở liên kết ở khe nào?")
            .setItems(labels) { _, which ->
                val targetSlot = slotOptions[which]
                val className = ProfileSlots.componentClassNameForSlot(targetSlot)
                val intent = Intent().apply {
                    component = ComponentName(packageName, className)
                    putExtra("open_url", uri)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                startActivity(intent)
            }
            .show()
    }

    private fun showProxyDialog() {
        val proxyType = AppPrefs.getInt(this, slotIndex, "proxy_type", 0)
        val host = AppPrefs.getString(this, slotIndex, "proxy_host", "")
        val port = AppPrefs.getString(this, slotIndex, "proxy_port", "")
        val user = AppPrefs.getString(this, slotIndex, "proxy_user", "")

        val msg = """
            ✅ Áp dụng qua WebExtension Proxy API (browser.proxy.onRequest) —
            đăng ký khi khe khởi động (GeckoRuntimeProvider). Đổi cấu hình bên
            dưới cần ĐÓNG VÀ MỞ LẠI khe này để có tác dụng.

            Proxy Type: ${if (proxyType == 0) "Direct" else if (proxyType == 1) "HTTP" else "SOCKS5"}
            Host: $host
            Port: $port
            User: $user

            ⚠️ Với proxy miễn phí (nút "Tự động tìm proxy"): rủi ro thật là bị
            log traffic hoặc honeypot — không dùng để đăng nhập tài khoản quan
            trọng.

            Vào Settings > Fingerprint Spoof để thay đổi.
        """.trimIndent()

        AlertDialog.Builder(this)
            .setTitle("Proxy Config (Slot $slotIndex)")
            .setMessage(msg)
            .setPositiveButton("OK", null)
            .show()
    }

    private fun showLeakTestDialog() {
        val downloadFeature = FeatureRegistry.all().filterIsInstance<com.colablive.keeper.features.downloads.DownloadManagerFeature>().firstOrNull()
        downloadFeature?.showLeakTestDialog(this, slotIndex, engine)
    }

    private fun showIDMDialog() {
        val downloadFeature = FeatureRegistry.all().filterIsInstance<com.colablive.keeper.features.downloads.DownloadManagerFeature>().firstOrNull()
        downloadFeature?.showIDMDialog(this)
    }

    private fun showSniffDialog() {
        val downloadFeature = FeatureRegistry.all().filterIsInstance<com.colablive.keeper.features.downloads.DownloadManagerFeature>().firstOrNull()
        // Lấy HTML từ trang hiện tại
        engine.evaluateJs("document.documentElement.outerHTML") { html ->
            html?.let {
                val links = downloadFeature?.sniffPage(this, it, engine.currentUrl() ?: "")
                links?.let { list ->
                    runOnUiThread {
                        downloadFeature?.showSniffedLinksDialog(this, list)
                    }
                }
            }
        }
    }

    private fun showWebArchiveDialog() {
        val currentUrl = engine.currentUrl() ?: return
        val currentTitle = engine.getActiveTab()?.title ?: "page"
        val downloadFeature = FeatureRegistry.all().filterIsInstance<com.colablive.keeper.features.downloads.DownloadManagerFeature>().firstOrNull()
        downloadFeature?.showWebArchiveDialog(this, currentUrl, currentTitle, geckoView)
    }

    private fun showDownloadPolicySettings() {
        val downloadFeature = FeatureRegistry.all().filterIsInstance<com.colablive.keeper.features.downloads.DownloadManagerFeature>().firstOrNull()
        downloadFeature?.showPolicySettings(this)
    }



    private fun showDownloadDialog(url: String, fileName: String) {
        AlertDialog.Builder(this)
            .setTitle("Tải xuống")
            .setMessage("$fileName\n$url")
            .setPositiveButton("Tải") { _, _ ->
                val downloadFeature = FeatureRegistry.all().filterIsInstance<DownloadManagerFeature>().firstOrNull()
                downloadFeature?.startDownload(this, url, fileName)
            }
            .setNegativeButton("Hủy", null)
            .show()
    }

    private fun showFilePicker(mimeTypes: Array<String>?) {
        val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
            type = mimeTypes?.firstOrNull() ?: "*/*"
            addCategory(Intent.CATEGORY_OPENABLE)
        }
        startActivityForResult(Intent.createChooser(intent, "Chọn file"), RC_FILE_PICKER)
    }

    private fun setupDragDrop() {
        geckoView.setOnDragListener { _, event ->
            when (event.action) {
                DragEvent.ACTION_DROP -> {
                    val clipData: ClipData? = event.clipData
                    if (clipData != null) {
                        for (i in 0 until clipData.itemCount) {
                            val item = clipData.getItemAt(i)
                            item.uri?.let { uri ->
                                engine.handleDropUri(uri, null)
                            }
                        }
                    }
                    true
                }
                else -> true
            }
        }
    }

    private fun requestPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, PERMISSION_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, arrayOf(PERMISSION_NOTIFICATIONS), RC_NOTIFICATIONS)
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == RC_FILE_PICKER) {
            val uri = if (resultCode == RESULT_OK) data?.data else null
            engine.resolveFilePrompt(this, uri)
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        // Khe này (singleTask) ĐÃ ĐANG CHẠY SẴN — Android gọi đây thay vì
        // onCreate() lại. Trước đây không xử lý gì cả, nên "Mở ở khe khác"
        // im lặng KHÔNG mở link nếu khe đích đã mở sẵn từ trước (chỉ đưa
        // khe đó lên foreground, giữ nguyên trang đang xem).
        val openUrl = intent.getStringExtra("open_url")
        if (openUrl != null) {
            engine.createTab(openUrl)
            refreshTabBar()
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(featureTickRunnable)
        engine.release()
        GeckoRuntimeProvider.release(slotIndex)
        super.onDestroy()
    }

    override fun onBackPressed() {
        if (engine.canGoBack()) {
            engine.goBack()
        } else {
            super.onBackPressed()
        }
    }
}
