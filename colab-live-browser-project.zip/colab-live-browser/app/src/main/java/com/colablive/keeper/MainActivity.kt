package com.colablive.keeper

import android.app.Dialog

import android.Manifest
import android.content.ClipData
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.DragEvent
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.colablive.keeper.core.*
import com.colablive.keeper.features.colablive.ColabLiveKeeperFeature
import java.io.File
import com.colablive.keeper.features.downloads.DownloadManagerFeature
import com.colablive.keeper.features.fingerprint.FingerprintSpoofFeature
import org.mozilla.geckoview.GeckoView
import java.net.URLEncoder

open class MainActivity : AppCompatActivity() {

    private lateinit var geckoView: GeckoView
    private lateinit var engine: GeckoViewEngine
    private lateinit var urlBar: EditText
    private lateinit var tabBar: HorizontalScrollView
    private lateinit var tabBarCollapseButton: ImageButton
    private var tabBarExpanded = true
    private lateinit var tabContainer: LinearLayout
    private lateinit var progressBar: ProgressBar
    private lateinit var backButton: ImageButton
    private lateinit var forwardButton: ImageButton
    private lateinit var refreshButton: ImageButton
    private lateinit var bookmarkButton: ImageButton
    private lateinit var menuButton: ImageButton
    private lateinit var newTabButton: ImageButton
    private lateinit var tabSwitcherButton: TextView
    private lateinit var toolbarContainer: LinearLayout

    private val handler = Handler(Looper.getMainLooper())
    private var slotIndex = 0
    private val tabViews = mutableMapOf<String, View>()
    private var gracefulCloseReceiver: android.content.BroadcastReceiver? = null

    companion object {
        private const val RC_FILE_PICKER = 1001
        private const val RC_NOTIFICATIONS = 1002
        private const val RC_HISTORY = 1003
        private const val RC_BOOKMARKS = 1004
        private const val PERMISSION_NOTIFICATIONS = Manifest.permission.POST_NOTIFICATIONS
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // QUAN TRỌNG: launcher (bấm icon màn hình chính) KHÔNG gửi kèm extra
        // tuỳ ý — "slot_index" chỉ có khi CHÍNH APP tự mở 1 khe khác. Bấm
        // thẳng icon "Khe 1/2/3" (activity-alias, chạy process ":slot1/2/3"
        // riêng) sẽ không có extra này — nếu chỉ dựa extra, mọi khe sẽ luôn
        // nghĩ mình là khe 0, khiến 2 tiến trình khác nhau cùng cố mở CHUNG 1
        // thư mục hồ sơ Gecko (`gecko_profile_slot_0`) cùng lúc — Gecko có
        // khoá hồ sơ, việc này có thể khiến GeckoRuntime khởi tạo lỗi/crash ở
        // tiến trình mở sau. Nguồn đáng tin cậy thật là TÊN TIẾN TRÌNH đang chạy.
        slotIndex = if (intent.hasExtra("slot_index")) {
            intent.getIntExtra("slot_index", 0)
        } else {
            ProfileSlots.getCurrentSlotIndex(this)
        }
        // CHẨN ĐOÁN TRỰC TIẾP — dòng này lộ ra ĐÚNG nguồn nào quyết định
        // slotIndex của Activity đang chạy: nếu intent CÓ "slot_index" thì
        // dùng giá trị đó (bỏ qua tên tiến trình hoàn toàn) — nếu nơi gọi
        // startActivity truyền sai giá trị này, MainActivity sẽ nhận sai
        // mà không hề đụng tới getCurrentSlotIndex() chút nào. Log rõ CẢ 2
        // để so sánh trực tiếp, không đoán.
        val rawProcessNameCheck = if (android.os.Build.VERSION.SDK_INT >= 28) android.app.Application.getProcessName() else "(SDK<28)"
        DebugLog.log("CHẨN ĐOÁN MainActivity.onCreate: intent.hasExtra(slot_index)=${intent.hasExtra("slot_index")}, intent.slot_index=${intent.getIntExtra("slot_index", -999)}, processName_THẬT='$rawProcessNameCheck', slotIndex_CUỐI_CÙNG=$slotIndex")
        ForegroundState.broadcastActiveSlot(this, slotIndex)
        updateTaskDescription() // nhãn thẻ trong Recent Apps — xem hàm bên dưới

        /**
         * BUG CỰC KỲ NGHIÊM TRỌNG — lần sửa TRƯỚC (chỉ `engine.release()` +
         * đợi ack) người dùng test lại VẪN mất dữ liệu. Nghĩ lại kỹ hơn:
         * `engine.release()` chỉ đóng CÁC TAB (`GeckoSession.close()`) — đây
         * KHÔNG đồng nghĩa với việc Gecko đã ghi xong cookie/phiên đăng nhập
         * xuống đĩa! Kho lưu cookie trong Gecko chạy như 1 dịch vụ RIÊNG,
         * độc lập với việc đóng tab — đóng tab không tự động ép dịch vụ đó
         * flush ngay. Cách THẬT SỰ đảm bảo Gecko ghi hết dữ liệu là tắt hẳn
         * `GeckoRuntime` (`runtime.shutdown()`) — đây mới đúng là điểm Gecko
         * dọn dẹp/flush toàn bộ trước khi thoát.
         *
         * Trước đây KHÔNG dám gọi `shutdown()` vì sợ lặp lại đúng bug đã sửa
         * ở mục 8g (gọi `release()`/quên khỏi map mà KHÔNG shutdown khiến
         * tạo runtime lần 2 trong process còn sống bị Gecko từ chối). Nhưng
         * ở ĐÂY khác: broadcast này CHỈ được gửi từ đúng 1 chỗ duy nhất —
         * `ProfilePickerActivity.restartSlot()` — và ngay sau khi nhận được,
         * process này CHẮC CHẮN bị kill/exit ngay sau đó (xem
         * `doRestartSlot()`), không bao giờ còn cơ hội tạo GeckoRuntime nào
         * khác trong CHÍNH process này nữa — nên `shutdown()` ở đây an toàn,
         * không tái diễn bug 8g.
         */
        gracefulCloseReceiver = object : android.content.BroadcastReceiver() {
            override fun onReceive(context: android.content.Context?, intent: Intent?) {
                DebugLog.log("Khe $slotIndex: nhận broadcast đóng đàng hoàng — đóng tab + TẮT HẲN GeckoRuntime (đảm bảo flush thật) trước khi finish()")
                engine.release()
                GeckoRuntimeProvider.shutdown(slotIndex)
                DebugLog.log("Khe $slotIndex: đã shutdown xong — gửi ACK")
                sendBroadcast(Intent(ProfileSlots.gracefulCloseAckAction(slotIndex)).apply { setPackage(packageName) })
                finish()
            }
        }
        // ContextCompat.registerReceiver (không phải registerReceiver() thẳng)
        // vì cờ RECEIVER_NOT_EXPORTED + overload 3 tham số chỉ có từ API 33 —
        // app này minSdk 26, gọi thẳng sẽ crash NoSuchMethodError trên máy cũ.
        ContextCompat.registerReceiver(
            this,
            gracefulCloseReceiver,
            android.content.IntentFilter(ProfileSlots.gracefulCloseAction(slotIndex)),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )

        DebugLog.log("MainActivity.onCreate: slot=$slotIndex, bắt đầu setupUI()")
        setupUI()
        DebugLog.log("MainActivity.onCreate: setupUI xong, bắt đầu setupEngine() (tạo GeckoRuntime — điểm nghi ngờ crash native cao nhất)")
        setupEngine()
        DebugLog.log("MainActivity.onCreate: setupEngine xong, bắt đầu setupDragDrop()")
        setupDragDrop()
        DebugLog.log("MainActivity.onCreate: setupDragDrop xong, bắt đầu initServices()")
        initServices()
        DebugLog.log("MainActivity.onCreate: initServices xong, bắt đầu requestPermissions()")
        requestPermissions()
        DebugLog.log("MainActivity.onCreate: HOÀN TẤT")
    }

    private fun initServices() {
        KeepAliveService.start(this)
        requestIgnoreBatteryOptimizations()
        com.colablive.keeper.features.downloads.AudioExtractor.cleanupOrphanedTempFiles(this) // dọn rác file tạm mồ côi từ lần chạy trước (app bị kill giữa chừng khi đang tách audio)
        val downloadFeature = FeatureRegistry.all().filterIsInstance<DownloadManagerFeature>().firstOrNull()
        downloadFeature?.initEngine(this)

        // Setup proxy cho slot này
        setupProxyForSlot()

        // Load trang mặc định — hoặc URL được truyền vào từ "Mở ở khe khác"
        // (nhấn giữ link ở khe khác, chọn mở link này ở khe này)
        //
        // THEO YÊU CẦU: khôi phục lại các tab đang mở từ lần trước (giống
        // Chrome/Firefox thật) thay vì luôn mở trang chủ trắng — xem
        // `GeckoViewEngine.restoreTabsIfAny()`. Nếu người dùng đang cố mở 1
        // URL cụ thể (`openUrl` != null, từ "Mở ở khe khác") thì ưu tiên mở
        // đúng URL đó trước, không khôi phục (tránh gây nhầm lẫn "tôi bấm mở
        // link này mà sao lại ra tab cũ").
        val openUrl = intent.getStringExtra("open_url")
        if (openUrl != null) {
            engine.createTab(openUrl)
        } else if (!engine.restoreTabsIfAny()) {
            val homeUrl = AppPrefs.getString(this, slotIndex, "home_url", "https://www.google.com")
            engine.createTab(homeUrl)
        }
        refreshTabBar()
    }

    /**
     * BUG THẬT (người dùng báo Colab tự ngắt kết nối khi tắt màn hình): app
     * chưa từng xin miễn trừ "Tối ưu hoá pin" (Battery Optimization) —
     * KHÔNG có dòng gọi `ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS` nào
     * trong toàn bộ code trước đây. Dù có Foreground Service + WakeLock,
     * Android vẫn có thể áp Doze/App Standby lên app nếu app không nằm
     * trong danh sách miễn trừ pin — khiến kết nối mạng nền (WebSocket của
     * Colab) bị treo. Xin quyền này CÙNG với việc sửa khoảng hở WakeLock
     * (xem `KeepAliveService.kt`) — cả 2 đều cần thiết, sửa 1 mình không đủ.
     *
     * LƯU Ý: trên các máy OEM tự chỉnh sửa Android mạnh (Xiaomi/MIUI,
     * Huawei, Oppo, Vivo...) — đúng loại máy trong Hardware Profile giả lập
     * của app này — riêng quyền hệ thống Android CHUẨN này KHÔNG đủ, hãng
     * còn có cơ chế diệt app nền RIÊNG (VD MIUI "Tự khởi động"/"Khoá app
     * trong Recent"). Việc đó nằm ngoài phạm vi code sửa được, người dùng
     * cần tự vào Cài đặt hãng để thêm.
     */
    private fun requestIgnoreBatteryOptimizations() {
        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        if (!powerManager.isIgnoringBatteryOptimizations(packageName)) {
            try {
                val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                    data = Uri.parse("package:$packageName")
                }
                startActivity(intent)
            } catch (e: Exception) {
                DebugLog.log("requestIgnoreBatteryOptimizations lỗi (${e.message}) — 1 số ROM chặn intent này, không crash app")
            }
        }
    }

    private fun setupProxyForSlot() {
        val proxyType = AppPrefs.getInt(this, slotIndex, "proxy_type", 0)
        if (proxyType > 0) {
            val host = AppPrefs.getString(this, slotIndex, "proxy_host", "")
            val port = AppPrefs.getString(this, slotIndex, "proxy_port", "").toIntOrNull() ?: 0
            val user = AppPrefs.getString(this, slotIndex, "proxy_user", "")
            val pass = AppPrefs.getString(this, slotIndex, "proxy_pass", "")

            if (host.isNotEmpty() && port > 0) {
                engine.setupProxy(host, port, user, pass)
                DebugLog.log("Slot $slotIndex proxy: $host:$port")
            }
        }
    }

    // ===== UI Setup =====

    /** Quy đổi dp -> pixel thật theo mật độ màn hình — dùng để tránh lặp lại
     * bug "48 PIXEL THÔ tưởng là 48dp" (xem giải thích lớn ở `setupUI()`). */
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    // Lưu URL THẬT ĐẦY ĐỦ riêng — omnibox chỉ HIỂN THỊ rút gọn (tên miền)
    // khi không focus, cần giữ giá trị gốc để hiện lại đầy đủ lúc bấm vào.
    private var lastLoadedUrl: String = ""

    /**
     * Rút gọn URL về "tên miền" để hiện trong omnibox khi KHÔNG focus,
     * đúng hành vi Chrome thật (VD "https://m.youtube.com/watch?v=xyz..."
     * → "m.youtube.com"). Trả về nguyên URL nếu không parse được domain
     * (VD "about:blank", url rỗng) thay vì làm rỗng ô địa chỉ.
     */
    private fun displayHostOnly(url: String): String {
        if (url.isBlank()) return ""
        return try {
            val uri = Uri.parse(url)
            uri.host ?: url
        } catch (e: Exception) {
            url
        }
    }

    /** Gọi mỗi khi URL thật sự đổi (trang mới load xong / chuyển tab) —
     * cập nhật cả giá trị gốc lẫn hiển thị rút gọn đúng, tôn trọng việc ô
     * đang được focus hay không (không cướp focus/chèn chữ khi người dùng
     * đang gõ dở). */
    /**
     * BUG GỐC đã tìm ra (ảnh chụp: mọi tab đều hiện chấm tròn xanh lè
     * giống hệt nhau, không phân biệt được trang nào với trang nào):
     * `BrowserTab.favicon` có sẵn field từ trước nhưng CHƯA TỪNG được gán
     * ở bất kỳ đâu trong toàn bộ code — luôn `null`, `createTabChip()` tự
     * rơi vào nhánh dự phòng (`presence_online`, chấm tròn xanh) cho MỌI
     * tab. GeckoView KHÔNG có callback "nhận được favicon" sẵn như WebView
     * cũ (`onReceivedIcon`) — phải tự đọc thẻ `<link rel="icon">` qua JS
     * rồi tự tải ảnh bằng HTTP thường.
     */
    /**
     * BUG THẬT đã tìm ra (người dùng báo icon tab vẫn xanh lè dù đã sửa
     * field name ở eval_bridge): `content_scripts` của eval_bridge chạy ở
     * `document_idle` — đây là tín hiệu ĐỘC LẬP với lúc GeckoView tự báo
     * "trang tải xong" (kích hoạt `onPageLoadedListener`, nơi gọi hàm
     * này) — KHÔNG đảm bảo thứ tự trước/sau nhau. Nếu gọi `evaluateJs()`
     * NGAY khi trang vừa báo tải xong mà content script CHƯA KỊP connect
     * port, script bị phát ra 0 port (không lỗi, không log gì — chỉ âm
     * thầm không ai nhận), callback không bao giờ được gọi. Thêm cơ chế
     * TỰ THỬ LẠI (tối đa 3 lần, giãn cách tăng dần) nếu chưa có phản hồi.
     */
    private fun fetchFaviconForActiveTab(pageUrl: String, attempt: Int = 1) {
        val tabId = engine.getActiveTab()?.id ?: return
        var handled = false
        engine.evaluateJs(
            """
            (function() {
                var link = document.querySelector('link[rel~="icon"]');
                if (link && link.href) return link.href;
                return location.origin + '/favicon.ico';
            })();
            """.trimIndent()
        ) { result ->
            handled = true
            // Định dạng thật trả về từ eval_bridge: "OK: <giá trị>" (thành
            // công) hoặc "LOI: <thông báo lỗi>" (thất bại) — KHÔNG phải
            // chuỗi JSON thô như code lúc đầu lỡ giả định sai.
            if (result == null || !result.startsWith("OK")) return@evaluateJs
            val faviconUrl = result.removePrefix("OK: ").removePrefix("OK").trim()
                .takeIf { it.isNotBlank() && it != "null" && it != "undefined" } ?: return@evaluateJs
            Thread {
                try {
                    val conn = java.net.URL(faviconUrl).openConnection() as java.net.HttpURLConnection
                    conn.connectTimeout = 5000
                    conn.readTimeout = 5000
                    conn.instanceFollowRedirects = true
                    val bitmap = conn.inputStream.use { android.graphics.BitmapFactory.decodeStream(it) }
                    conn.disconnect()
                    if (bitmap != null) {
                        runOnUiThread {
                            // Chỉ gán nếu tab vẫn còn tồn tại VÀ vẫn đang ở
                            // đúng trang lúc bắt đầu tải icon (không gán nhầm
                            // icon cũ vào tab đã điều hướng sang trang khác
                            // trong lúc chờ tải favicon).
                            val tab = engine.getTabs().find { it.id == tabId }
                            if (tab != null && tab.url == pageUrl) {
                                tab.favicon = bitmap
                                refreshTabBar()
                            }
                        }
                    }
                } catch (e: Exception) {
                    DebugLog.log("fetchFavicon lỗi ($faviconUrl): ${e.message}")
                }
            }.start()
        }
        if (attempt < 3) {
            Handler(Looper.getMainLooper()).postDelayed({
                // Chỉ thử lại nếu tab vẫn còn tồn tại, vẫn đúng trang, VÀ
                // vẫn chưa có favicon (tránh thử lại vô nghĩa nếu lần trước
                // đã thành công hoặc người dùng đã điều hướng sang trang khác).
                val tab = engine.getTabs().find { it.id == tabId }
                if (!handled && tab != null && tab.url == pageUrl && tab.favicon == null) {
                    fetchFaviconForActiveTab(pageUrl, attempt + 1)
                }
            }, 1500L * attempt)
        }
    }

    private fun updateOmnibox(url: String) {
        lastLoadedUrl = url
        if (!urlBar.hasFocus()) {
            urlBar.setText(displayHostOnly(url))
        }
        updateBookmarkButton(url)
    }

    private fun updateBookmarkButton(url: String) {
        if (!::bookmarkButton.isInitialized) return
        val isBookmarked = com.colablive.keeper.core.BrowserBookmarks.isBookmarked(this, slotIndex, url)
        bookmarkButton.setImageResource(if (isBookmarked) android.R.drawable.btn_star_big_on else android.R.drawable.btn_star_big_off)
    }

    /**
     * Chỉ báo trực quan tab ẩn danh — đúng theo Chrome thật (toolbar/status
     * bar chuyển màu tối #202124 khi đang ở tab ẩn danh, dễ phân biệt ngay
     * không cần đọc URL). Gọi mỗi khi chuyển tab / tạo tab mới.
     */
    private fun updatePrivateModeUI() {
        val isPrivate = engine.getActiveTab()?.isPrivate == true
        if (isPrivate) {
            toolbarContainer.setBackgroundColor(Color.parseColor("#202124"))
            urlBar.background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.parseColor("#3C4043"))
                cornerRadius = dp(24).toFloat()
            }
            urlBar.setTextColor(Color.WHITE)
            urlBar.setHintTextColor(Color.LTGRAY)
            window.statusBarColor = Color.parseColor("#202124")
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                window.decorView.systemUiVisibility = window.decorView.systemUiVisibility and View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv()
            }
        } else {
            toolbarContainer.setBackgroundColor(Color.parseColor("#F8F9FA"))
            urlBar.background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.parseColor("#F1F3F4"))
                cornerRadius = dp(24).toFloat()
            }
            urlBar.setTextColor(Color.BLACK)
            urlBar.setHintTextColor(Color.GRAY)
            window.statusBarColor = Color.parseColor("#F8F9FA")
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                window.decorView.systemUiVisibility = window.decorView.systemUiVisibility or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
            }
        }
    }

    private fun setupUI() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
        }

        // Toolbar container
        toolbarContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#F8F9FA"))
        }

        // Tab bar — dạng VÒNG TRÒN cuộn ngang (theo yêu cầu người dùng,
        // kèm ảnh tham khảo + bản GeckoView cũ của chính project này) —
        // ĐẢO NGƯỢC lại quyết định trước đó (mục 8zz8, khi đó bỏ hẳn dải
        // tab vì nghĩ Chrome không có) sau khi người dùng làm rõ đây là
        // kiểu giao diện họ THỰC SỰ muốn, không phải lỗi hiểu Chrome.
        // Thêm nút mũi tên (^) thu gọn/mở lại — không có trong ảnh gốc
        // nhưng hợp lý để không chiếm chỗ màn hình khi không cần, người
        // dùng tự bật lại khi muốn.
        tabBarCollapseButton = ImageButton(this).apply {
            setImageResource(android.R.drawable.arrow_up_float)
            setBackgroundColor(Color.TRANSPARENT)
            setOnClickListener {
                tabBarExpanded = !tabBarExpanded
                tabBar.visibility = if (tabBarExpanded) View.VISIBLE else View.GONE
                setImageResource(if (tabBarExpanded) android.R.drawable.arrow_up_float else android.R.drawable.arrow_down_float)
            }
        }
        toolbarContainer.addView(tabBarCollapseButton, ViewGroup.LayoutParams(dp(32), dp(32)))

        tabBar = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            val tabLayout = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(12, 8, 12, 8)
            }
            tabContainer = tabLayout
            addView(tabLayout, ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        toolbarContainer.addView(tabBar, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // Nhãn LUÔN HIỂN THỊ "đang ở Khe nào / hồ sơ nào" — trước đây thông
        // tin này chỉ hiện trong tiêu đề 1 vài dialog (vd "Menu (Slot 1)"),
        // không có gì hiển thị thường trực trong lúc duyệt web, dễ nhầm
        // đang ở khe nào khi mở nhiều khe cùng lúc. Chỉ cần đọc 1 lần lúc
        // tạo UI vì việc đổi gán hồ sơ luôn khởi động lại khe (xem
        // `ProfilePickerActivity.restartSlot`), nên giá trị không đổi trong
        // suốt vòng đời Activity này.
        val slotLabel = TextView(this).apply {
            text = "Khe $slotIndex — ${ProfileSlots.getSlotAssignmentDisplay(this@MainActivity, slotIndex)}"
            textSize = 11f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#616161"))
            setPadding(16, 4, 16, 4)
        }
        toolbarContainer.addView(slotLabel, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // URL + Navigation bar
        //
        // BUG THẬT đã sửa (người dùng phản ánh "icon nhí nhí khó nhấn"): các
        // nút back/forward/refresh/tab/menu trước đây có kích thước
        // `ViewGroup.LayoutParams(48, 48)` — đây là 48 PIXEL THÔ, không phải
        // 48dp! Trên màn hình mật độ điểm ảnh cao (3x, rất phổ biến) thì 48px
        // chỉ tương đương ~16dp thật — thấp hơn NHIỀU so với khuyến nghị tối
        // thiểu 48dp của Material Design cho vùng chạm ngón tay, nên khó
        // bấm trúng là đúng, không phải cảm giác. Sửa: đổi hết sang `dp(48)`
        // (hàm quy đổi theo mật độ màn hình thật), thêm đệm bên trong icon +
        // hiệu ứng gợn sóng khi chạm (giống Material/Chrome) cho dễ bấm và
        // có phản hồi rõ ràng khi chạm trúng.
        //
        // THEO YÊU CẦU: gom back/forward/refresh vào menu 3 chấm thay vì để
        // cố định trên thanh công cụ — đúng như Chrome thật làm (Chrome
        // KHÔNG có nút Back riêng trên thanh công cụ, dùng nút/vuốt Back của
        // hệ thống — app này đã tự làm đúng việc đó từ trước, xem
        // `onBackPressed()` phía dưới gọi `engine.goBack()`). Forward/Reload
        // chuyển vào `showMenu()`. Vẫn giữ nguyên các biến `backButton`/
        // `forwardButton`/`refreshButton` (không xoá) vì vài chỗ khác trong
        // file còn cập nhật trạng thái enable/alpha của chúng — chỉ không
        // gắn vào `navBar` để không chiếm chỗ trên màn hình nữa.
        val navBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(4), dp(6), dp(4), dp(6))
            gravity = Gravity.CENTER_VERTICAL
        }

        val rippleBg = android.util.TypedValue().also {
            theme.resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, it, true)
        }.resourceId

        backButton = ImageButton(this).apply {
            setImageResource(android.R.drawable.ic_media_previous)
            setBackgroundResource(rippleBg)
            setPadding(dp(10), dp(10), dp(10), dp(10))
            setOnClickListener { engine.goBack() }
        }
        forwardButton = ImageButton(this).apply {
            setImageResource(android.R.drawable.ic_media_next)
            setBackgroundResource(rippleBg)
            setPadding(dp(10), dp(10), dp(10), dp(10))
            setOnClickListener { engine.goForward() }
        }
        refreshButton = ImageButton(this).apply {
            setImageResource(android.R.drawable.ic_menu_rotate)
            setBackgroundResource(rippleBg)
            setPadding(dp(10), dp(10), dp(10), dp(10))
            setOnClickListener { engine.reload() }
        }

        // Omnibox kiểu Chrome: bo tròn viên thuốc, nền xám nhạt, không viền —
        // thay vì ô nhập viền vuông mặc định trước đây. Giờ rộng hơn nhiều
        // vì không còn phải chia chỗ với 3 nút back/forward/refresh nữa.
        //
        // THEO YÊU CẦU "giống Chrome": Chrome CHỈ hiện TÊN MIỀN khi ô địa
        // chỉ KHÔNG được focus (VD "youtube.com" thay vì cả URL dài đầy
        // tham số) — bấm vào mới hiện URL ĐẦY ĐỦ để sửa, kèm chọn hết chữ
        // sẵn để gõ đè nhanh. Trước đây ô này luôn hiện URL đầy đủ, kể cả
        // lúc không bấm vào — không giống Chrome, dài dòng khó đọc.
        urlBar = EditText(this).apply {
            hint = "Tìm kiếm hoặc nhập URL"
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.parseColor("#F1F3F4"))
                cornerRadius = dp(24).toFloat()
            }
            setPadding(dp(16), dp(10), dp(16), dp(10))
            setSingleLine(true)
            textSize = 15f
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            imeOptions = EditorInfo.IME_ACTION_GO
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_GO) {
                    navigateToUrl(text.toString())
                    clearFocus()
                    true
                } else false
            }
            setOnFocusChangeListener { _, hasFocus ->
                if (hasFocus) {
                    setText(lastLoadedUrl)
                    selectAll()
                } else {
                    setText(displayHostOnly(lastLoadedUrl))
                }
            }
        }
        navBar.addView(urlBar, LinearLayout.LayoutParams(0, dp(44), 1f).apply {
            marginStart = dp(4); marginEnd = dp(4)
        })

        // BUG THẬT đã sửa (người dùng chỉ ra): "Tiến tới"/"Tải lại trang"
        // trên Chrome THẬT là ICON ngay trên thanh công cụ, KHÔNG phải dòng
        // CHỮ trong menu 3 chấm — phiên trước hiểu sai, nhét cả 2 vào
        // showMenu() dạng text. `forwardButton`/`refreshButton` (bên trên)
        // đã được TẠO SẴN đầy đủ icon từ trước nhưng chưa từng gắn vào
        // `navBar` — chỉ cần thêm vào đây, bỏ 2 dòng chữ tương ứng khỏi
        // showMenu(). Không thêm `backButton` ở đây (giữ nguyên quyết định
        // cũ) vì nút/vuốt Back hệ thống đã tự làm đúng việc đó.
        navBar.addView(forwardButton, ViewGroup.LayoutParams(dp(40), dp(40)))
        navBar.addView(refreshButton, ViewGroup.LayoutParams(dp(40), dp(40)))

        // Nút SAO bookmark nhanh 1 chạm — đã hứa "để dành lượt sau", giờ
        // làm luôn theo yêu cầu. Đổi hình đầy/rỗng theo đúng trạng thái
        // bookmark của trang ĐANG XEM, cập nhật ở `updateBookmarkButton()`
        // (gọi từ `updateOmnibox()` — cùng chỗ mọi lần URL đổi).
        bookmarkButton = ImageButton(this).apply {
            setImageResource(android.R.drawable.btn_star_big_off)
            setBackgroundColor(Color.TRANSPARENT)
            setOnClickListener {
                val url = engine.currentUrl() ?: return@setOnClickListener
                if (engine.getActiveTab()?.isPrivate == true) {
                    Toast.makeText(this@MainActivity, "Tab ẩn danh không lưu bookmark", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                val title = engine.getActiveTab()?.title ?: url
                val nowBookmarked = com.colablive.keeper.core.BrowserBookmarks.toggle(this@MainActivity, slotIndex, url, title)
                updateBookmarkButton(url)
                Toast.makeText(this@MainActivity, if (nowBookmarked) "Đã thêm bookmark" else "Đã bỏ bookmark", Toast.LENGTH_SHORT).show()
            }
        }
        navBar.addView(bookmarkButton, ViewGroup.LayoutParams(dp(40), dp(40)))

        newTabButton = ImageButton(this).apply {
            setImageResource(android.R.drawable.ic_input_add)
            setBackgroundResource(rippleBg)
            setPadding(dp(10), dp(10), dp(10), dp(10))
            setOnClickListener {
                engine.createTab("https://www.google.com")
                refreshTabBar()
            }
        }
        navBar.addView(newTabButton, ViewGroup.LayoutParams(dp(48), dp(48)))

        // Nút "N tab" kiểu Chrome — bấm mở lưới xem/chuyển/đóng tab, thay
        // vì phải cuộn dải chip ngang khi có nhiều tab.
        tabSwitcherButton = TextView(this).apply {
            text = "1"
            textSize = 13f
            gravity = Gravity.CENTER
            setTextColor(Color.DKGRAY)
            background = android.graphics.drawable.GradientDrawable().apply {
                setStroke(dp(2), Color.DKGRAY)
                cornerRadius = dp(6).toFloat()
            }
            foreground = androidx.core.content.ContextCompat.getDrawable(this@MainActivity, rippleBg)
            setOnClickListener { showTabSwitcher() }
        }
        // BUG BUILD đã sửa: `ViewGroup.LayoutParams` (lớp cha) KHÔNG có
        // marginStart/marginEnd — chỉ `ViewGroup.MarginLayoutParams` (và các
        // lớp con như `LinearLayout.LayoutParams`) mới có. Trước đây viết
        // nhầm `ViewGroup.LayoutParams` ở đây → "Unresolved reference" lúc
        // build. navBar là LinearLayout nên đổi đúng sang `LinearLayout.LayoutParams`.
        navBar.addView(tabSwitcherButton, LinearLayout.LayoutParams(dp(40), dp(40)).apply {
            marginStart = dp(4); marginEnd = dp(4)
        })

        menuButton = ImageButton(this).apply {
            setImageResource(android.R.drawable.ic_menu_more)
            setBackgroundResource(rippleBg)
            setPadding(dp(10), dp(10), dp(10), dp(10))
            setOnClickListener { showMenu() }
        }
        navBar.addView(menuButton, ViewGroup.LayoutParams(dp(48), dp(48)))

        toolbarContainer.addView(navBar, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // Progress bar
        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            visibility = View.GONE
        }
        toolbarContainer.addView(progressBar, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 4))

        root.addView(toolbarContainer, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // Bóng đổ mỏng dưới toolbar — Chrome dùng elevation thật (Material)
        // để tạo cảm giác toolbar "nổi" trên nội dung trang, không phải chỉ
        // đường viền phẳng. Không set màu status bar tối ở đây vì theme mặc
        // định của Activity đã đủ dùng, tránh đụng vào theme toàn app.
        toolbarContainer.elevation = dp(4).toFloat()
        window.statusBarColor = Color.parseColor("#F8F9FA")
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            window.decorView.systemUiVisibility = window.decorView.systemUiVisibility or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        }

        // GeckoView
        geckoView = GeckoView(this)
        root.addView(geckoView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        setContentView(root)
    }

    private fun setupEngine() {
        engine = GeckoViewEngine(this, geckoView, slotIndex)
        updateNavButtons() // trạng thái mờ/đậm đúng ngay từ đầu, trước khi có sự kiện điều hướng đầu tiên (tab mới thường canGoBack/Forward đều false)
        updatePrivateModeUI() // màu toolbar mặc định đúng ngay từ đầu (chưa có tab nào thì coi như không ẩn danh)

        engine.onPageLoadedListener = { url ->
            updateOmnibox(url)
            updateNavButtons()
            ForegroundState.broadcastActiveSlot(this, slotIndex, url)
            // Tab ẨN DANH không ghi lịch sử — đúng hành vi Chrome thật.
            if (engine.getActiveTab()?.isPrivate != true) {
                engine.recordHistoryVisit(url)
            }
            fetchFaviconForActiveTab(url) // xem chú thích ở hàm — BUG GỐC khiến mọi tab hiện icon chấm xanh giống hệt nhau
            FeatureRegistry.enabledFeatures(this, slotIndex).forEach {
                it.onPageFinished(this, slotIndex, engine, url)
            }
        }

        engine.onPageErrorListener = { url, code ->
            DebugLog.log("Page error: $url code=$code")
        }

        engine.onTitleChangedListener = { title ->
            updateTabTitle(title)
            if (engine.getActiveTab()?.isPrivate != true) {
                engine.currentUrl()?.let { engine.updateLastHistoryTitle(it, title) }
            }
        }

        engine.onProgressChangedListener = { progress ->
            progressBar.progress = progress
            progressBar.visibility = if (progress in 1..99) View.VISIBLE else View.GONE
        }

        engine.onNewTabRequestedListener = { url ->
            // Không tự tạo tab nữa — GeckoViewEngine.onNewSession() giờ đã
            // tự tạo VÀ đăng ký đúng tab cho popup (kèm session THẬT, có
            // window.opener hoạt động — xem giải thích lớn ở đó, sửa lỗi
            // "credential propagation unsuccessful" của Colab). Gọi
            // `createTab()` thêm ở đây sẽ tạo ra 1 tab THỨ HAI trùng lặp,
            // không có window.opener, cùng URL — chỉ cần vẽ lại thanh tab.
            refreshTabBar()
        }

        engine.onTabSwitchedListener = {
            updateOmnibox(engine.currentUrl() ?: "")
            updateNavButtons()
            refreshTabBar()
            updatePrivateModeUI()
        }

        engine.onLongPressLinkListener = { uri, text ->
            runOnUiThread { showLinkContextMenu(uri, text) }
        }

        engine.onDownloadRequestedListener = { url, fileName ->
            val downloadFeature = FeatureRegistry.all().filterIsInstance<com.colablive.keeper.features.downloads.DownloadManagerFeature>().firstOrNull()
            downloadFeature?.startDownloadWithPolicy(this, url, fileName)
        }

        engine.onFilePromptListener = { mimeTypes ->
            showFilePicker(mimeTypes)
        }

        startFeatureTickLoop()
    }

    /**
     * Vòng lặp tick 60s/lần cho các feature cần hành vi định kỳ (vd Colab Live
     * Keeper chế độ DOM — bấm nút Connect lại). Trước đây `onTick` được viết
     * đầy đủ trong ColabLiveKeeperFeature nhưng KHÔNG CÓ GÌ GỌI TỚI NÓ, nên
     * chế độ DOM (mặc định) không có tác dụng gì dù đã bật switch trong Settings.
     */
    private val featureTickRunnable = object : Runnable {
        override fun run() {
            FeatureRegistry.enabledFeatures(this@MainActivity, slotIndex).forEach {
                it.onTick(this@MainActivity, slotIndex, engine, engine.currentUrl())
            }
            handler.postDelayed(this, 60_000L)
        }
    }

    private fun startFeatureTickLoop() {
        handler.removeCallbacks(featureTickRunnable)
        handler.postDelayed(featureTickRunnable, 60_000L)
    }

    private fun navigateToUrl(input: String) {
        val url = when {
            input.startsWith("http://") || input.startsWith("https://") -> input
            input.contains(".") && !input.contains(" ") -> "https://$input"
            else -> "https://www.google.com/search?q=${URLEncoder.encode(input, "UTF-8")}"
        }
        lastLoadedUrl = url // cập nhật lạc quan — tránh omnibox nháy về domain CŨ 1 nhịp khi mất focus trước lúc trang mới load xong
        engine.loadUrl(url)
    }

    private fun updateNavButtons() {
        backButton.isEnabled = engine.canGoBack()
        backButton.alpha = if (engine.canGoBack()) 1f else 0.3f
        forwardButton.isEnabled = engine.canGoForward()
        forwardButton.alpha = if (engine.canGoForward()) 1f else 0.3f
    }

    private fun updateTabTitle(title: String) {
        // Tiêu đề chỉ đổi cho tab đang active — vẽ lại cả thanh tab cho đơn giản
        // và luôn nhất quán (số lượng tab thường nhỏ, chi phí không đáng kể).
        refreshTabBar()
    }

    /**
     * Vẽ lại toàn bộ thanh tab từ danh sách tab thật của engine.
     * Trước đây thanh tab được khai báo nhưng KHÔNG BAO GIỜ có view nào được
     * thêm vào `tabContainer` — tạo tab mới không hiện gì, không bấm chuyển
     * được. Đây là hàm khắc phục, gọi lại mỗi khi danh sách/tab active/tiêu
     * đề thay đổi.
     */
    private fun refreshTabBar() {
        tabContainer.removeAllViews()
        tabViews.clear()
        val activeId = engine.getActiveTab()?.id
        val tabs = engine.getTabs()
        tabs.forEach { tab ->
            val chip = createTabChip(tab, tab.id == activeId)
            tabViews[tab.id] = chip
            tabContainer.addView(chip)
        }
        // "+" ở cuối dải vòng tròn — đúng theo ảnh tham khảo. Nút riêng
        // trên toolbar (`newTabButton`) vẫn giữ nguyên, không xoá — vẫn
        // cần dùng được khi dải này đang thu gọn. Bọc trong LinearLayout
        // dọc giống hệt `createTabChip` (thêm dòng trống bên dưới cho
        // thẳng hàng, vì tab chip giờ cao hơn do có thêm tên tab).
        tabContainer.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(dp(60), ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(4, 4, 4, 4) }
            addView(FrameLayout(this@MainActivity).apply {
                layoutParams = LinearLayout.LayoutParams(dp(52), dp(52))
                addView(ImageButton(this@MainActivity).apply {
                    setImageResource(android.R.drawable.ic_input_add)
                    background = android.graphics.drawable.GradientDrawable().apply {
                        shape = android.graphics.drawable.GradientDrawable.OVAL
                        setColor(Color.parseColor("#F1F3F4"))
                    }
                    layoutParams = FrameLayout.LayoutParams(dp(44), dp(44)).apply { gravity = Gravity.CENTER }
                    setOnClickListener {
                        val tab = engine.createTab("https://www.google.com")
                        engine.switchToTab(tab.id)
                        refreshTabBar()
                    }
                })
            })
            addView(TextView(this@MainActivity).apply {
                text = " "
                textSize = 9f
                layoutParams = LinearLayout.LayoutParams(dp(58), ViewGroup.LayoutParams.WRAP_CONTENT)
            })
        })
        if (::tabSwitcherButton.isInitialized) {
            tabSwitcherButton.text = tabs.size.toString()
        }
    }

    /**
     * Vòng tròn cho 1 tab — theo đúng ảnh tham khảo người dùng gửi: hình
     * tròn (favicon nếu có, icon mặc định nếu chưa tải xong), tab ĐANG
     * ACTIVE có viền xanh bao quanh + nút X đè góc trên-phải để đóng
     * nhanh (tab không active không hiện X ngay trên vòng tròn — bấm vào
     * để chuyển tới rồi đóng, giữ giao diện gọn như ảnh gốc).
     */
    private fun createTabChip(tab: com.colablive.keeper.core.BrowserTab, isActive: Boolean): View {
        val circleSize = dp(44)
        // BUG THẬT (người dùng báo icon vẫn xanh lè, favicon vẫn có thể
        // thất bại tuỳ trang) — khôi phục TÊN TAB hiện dưới vòng tròn,
        // đúng như bản GeckoView gốc của project — không chỉ dựa mỗi vào
        // favicon (có thể lỗi/không có) để phân biệt tab. Đổi wrapper
        // thành cột dọc (vòng tròn + tên rút gọn bên dưới) thay vì chỉ có
        // 1 vòng tròn trơ trọi.
        val wrapper = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(dp(60), ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(4, 4, 4, 4) }
        }

        val circleFrame = android.widget.FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(52), dp(52))
        }

        val circle = android.widget.FrameLayout(this).apply {
            layoutParams = android.widget.FrameLayout.LayoutParams(circleSize, circleSize).apply {
                gravity = Gravity.CENTER
            }
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL
                setColor(if (tab.isPrivate) Color.parseColor("#3C4043") else Color.WHITE)
                if (isActive) setStroke(dp(3), Color.parseColor("#1A73E8"))
            }
            isClickable = true
            foreground = androidx.core.content.ContextCompat.getDrawable(this@MainActivity, android.util.TypedValue().also {
                theme.resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, it, true)
            }.resourceId)
            setOnClickListener {
                if (tab.id != engine.getActiveTab()?.id) {
                    engine.switchToTab(tab.id)
                }
            }
            clipToOutline = false
        }

        val icon = ImageView(this).apply {
            layoutParams = android.widget.FrameLayout.LayoutParams(dp(24), dp(24)).apply { gravity = Gravity.CENTER }
            val favicon = tab.favicon
            if (favicon != null) {
                setImageBitmap(favicon)
            } else if (tab.isPrivate) {
                setImageResource(android.R.drawable.ic_lock_lock)
                setColorFilter(Color.WHITE)
            } else {
                // Chưa có favicon (đang tải/trang không có icon, hoặc lỗi
                // tải icon) — chấm tròn xanh lá đơn giản thay cho khoảng
                // trắng — TÊN TAB bên dưới mới là cách phân biệt CHÍNH giờ
                // đây, icon chỉ là phụ trợ khi có.
                setImageResource(android.R.drawable.presence_online)
            }
        }
        circle.addView(icon)
        circleFrame.addView(circle)

        if (isActive) {
            circleFrame.addView(ImageButton(this).apply {
                setImageResource(android.R.drawable.ic_menu_close_clear_cancel)
                setBackgroundColor(Color.parseColor("#1A73E8"))
                layoutParams = android.widget.FrameLayout.LayoutParams(dp(20), dp(20)).apply {
                    gravity = Gravity.TOP or Gravity.END
                }
                setColorFilter(Color.WHITE)
                setOnClickListener {
                    if (engine.getTabs().size <= 1) {
                        Toast.makeText(this@MainActivity, "Không thể đóng tab cuối cùng", Toast.LENGTH_SHORT).show()
                        return@setOnClickListener
                    }
                    engine.closeTab(tab.id)
                    refreshTabBar()
                }
            })
        }
        wrapper.addView(circleFrame)

        wrapper.addView(TextView(this).apply {
            val displayName = tab.title.takeIf { it.isNotBlank() }
                ?: (try { Uri.parse(tab.url).host } catch (e: Exception) { null })
                ?: tab.url
            text = displayName
            textSize = 9f
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            gravity = Gravity.CENTER
            setTextColor(if (tab.isPrivate) Color.LTGRAY else Color.DKGRAY)
            layoutParams = LinearLayout.LayoutParams(dp(58), ViewGroup.LayoutParams.WRAP_CONTENT)
        })

        return wrapper
    }

    /**
     * Lưới xem/chuyển/đóng tab kiểu Chrome (bấm nút "N" cạnh nút + trên
     * thanh công cụ) — thay vì phải dò dải chip ngang khi có nhiều tab.
     */
    private fun showTabSwitcher() {
        val dialog = Dialog(this, android.R.style.Theme_Black_NoTitleBar)
        val activeId = engine.getActiveTab()?.id
        val tabs = engine.getTabs()

        val grid = GridLayout(this).apply {
            columnCount = 2
            setPadding(24, 24, 24, 24)
        }
        tabs.forEach { tab ->
            grid.addView(createTabCard(tab, tab.id == activeId, dialog))
        }
        grid.addView(createNewTabCard(dialog))

        val scroll = ScrollView(this).apply { addView(grid) }

        val titleBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(24, 16, 24, 16)
            addView(TextView(this@MainActivity).apply {
                text = "${tabs.size} tab đang mở"
                textSize = 16f
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            })
            addView(Button(this@MainActivity).apply {
                text = "Đóng"
                setOnClickListener { dialog.dismiss() }
            })
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
            addView(titleBar)
            addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        }
        dialog.setContentView(root)
        dialog.show()
    }

    private fun createTabCard(tab: com.colablive.keeper.core.BrowserTab, isActive: Boolean, dialog: Dialog): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 16, 20, 16)
            // Chrome dùng VIỀN XANH quanh card cho tab đang active, không
            // chỉ đổi màu nền — dễ nhận ra hơn giữa lưới nhiều card giống
            // nhau. Bo góc (trước đây vuông cạnh, không giống Material/Chrome).
            background = android.graphics.drawable.GradientDrawable().apply {
                cornerRadius = dp(12).toFloat()
                setColor(when {
                    tab.isPrivate -> Color.parseColor("#3C4043") // tối, đúng tông ẩn danh Chrome — phân biệt ngay cả khi không active
                    isActive -> Color.parseColor("#D2E3FC")
                    else -> Color.parseColor("#F1F3F4")
                })
                if (isActive) setStroke(dp(2), Color.parseColor("#1A73E8"))
            }
            elevation = dp(1).toFloat()
            layoutParams = GridLayout.LayoutParams().apply {
                width = 0
                height = ViewGroup.LayoutParams.WRAP_CONTENT
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(8, 8, 8, 8)
            }
            isClickable = true
            foreground = androidx.core.content.ContextCompat.getDrawable(this@MainActivity, android.util.TypedValue().also {
                theme.resolveAttribute(android.R.attr.selectableItemBackground, it, true)
            }.resourceId)
            setOnClickListener {
                engine.switchToTab(tab.id)
                dialog.dismiss()
            }
        }

        val titleRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        titleRow.addView(TextView(this).apply {
            text = (if (tab.isPrivate) "🕶 " else "") + (tab.title.takeIf { it.isNotEmpty() } ?: tab.url)
            textSize = 14f
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            if (tab.isPrivate) setTextColor(Color.WHITE)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        })
        titleRow.addView(ImageButton(this).apply {
            setImageResource(android.R.drawable.ic_menu_close_clear_cancel)
            setBackgroundColor(Color.TRANSPARENT)
            layoutParams = LinearLayout.LayoutParams(36, 36)
            setOnClickListener {
                if (engine.getTabs().size <= 1) {
                    Toast.makeText(this@MainActivity, "Không thể đóng tab cuối cùng", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                engine.closeTab(tab.id)
                refreshTabBar()
                dialog.dismiss()
                showTabSwitcher() // vẽ lại lưới cho khớp danh sách mới
            }
        })
        card.addView(titleRow)

        card.addView(TextView(this).apply {
            text = tab.url
            textSize = 11f
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            setTextColor(Color.GRAY)
        })
        return card
    }

    private fun createNewTabCard(dialog: Dialog): View {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(20, 24, 20, 24)
            background = android.graphics.drawable.GradientDrawable().apply {
                cornerRadius = dp(12).toFloat()
                setColor(Color.parseColor("#F1F3F4"))
                setStroke(dp(1), Color.parseColor("#DADCE0"))
            }
            layoutParams = GridLayout.LayoutParams().apply {
                width = 0
                height = ViewGroup.LayoutParams.WRAP_CONTENT
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(8, 8, 8, 8)
            }
            isClickable = true
            foreground = androidx.core.content.ContextCompat.getDrawable(this@MainActivity, android.util.TypedValue().also {
                theme.resolveAttribute(android.R.attr.selectableItemBackground, it, true)
            }.resourceId)
            addView(TextView(this@MainActivity).apply {
                text = "+"
                textSize = 28f
                setTextColor(Color.parseColor("#1A73E8"))
                gravity = Gravity.CENTER
            })
            addView(TextView(this@MainActivity).apply {
                text = "Tab mới"
                textSize = 13f
                setTextColor(Color.parseColor("#1A73E8"))
                gravity = Gravity.CENTER
            })
            setOnClickListener {
                engine.createTab("https://www.google.com")
                refreshTabBar()
                dialog.dismiss()
            }
        }
    }

    /**
     * Dialog danh sách có ICON THẬT (không chỉ chữ) — thay cho
     * `AlertDialog.setItems()` cũ (chỉ hỗ trợ text đơn thuần, không gắn
     * được icon riêng cho từng dòng). Dùng chung cho menu chính lẫn menu
     * con "Tải xuống & Media".
     */
    private fun showIconMenu(title: String, items: List<Triple<Int, String, () -> Unit>>) {
        val density = resources.displayMetrics.density
        val listLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val dialog = AlertDialog.Builder(this).setTitle(title).setView(listLayout).create()
        items.forEach { (iconRes, label, action) ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding((16 * density).toInt(), (14 * density).toInt(), (16 * density).toInt(), (14 * density).toInt())
                isClickable = true
                isFocusable = true
                val ripple = android.util.TypedValue().also {
                    theme.resolveAttribute(android.R.attr.selectableItemBackground, it, true)
                }.resourceId
                setBackgroundResource(ripple)
                setOnClickListener {
                    dialog.dismiss()
                    action()
                }
            }
            row.addView(ImageView(this).apply {
                setImageResource(iconRes)
                setColorFilter(Color.DKGRAY)
            }, LinearLayout.LayoutParams((24 * density).toInt(), (24 * density).toInt()).apply {
                marginEnd = (20 * density).toInt()
            })
            row.addView(TextView(this).apply {
                text = label
                textSize = 15f
                setTextColor(Color.BLACK)
            })
            listLayout.addView(row)
        }
        dialog.show()
    }

    private fun showDownloadMediaMenu() {
        val menuItems = mutableListOf(
            Triple(android.R.drawable.stat_sys_download, "IDM Downloads") { showIDMDialog() },
            Triple(android.R.drawable.ic_menu_slideshow, "Sniff Media") { showSniffDialog() }
        )
        // BUG THẬT đã sửa: catchDownload()/downloadYouTube() đã được viết
        // sẵn đầy đủ (dùng NewPipeExtractor, xem
        // NewPipeDownloaderImpl.kt) nhưng KHÔNG CÓ NÚT NÀO trong toàn bộ
        // app gọi tới khi đang xem 1 video/playlist thật — người dùng chỉ
        // có cách dán URL tay vào "Test tải YouTube" trong Settings. Thêm
        // đúng 1 mục lấy URL tab hiện tại, tự nhận diện video/playlist.
        val currentUrl = engine.currentUrl()
        if (currentUrl != null && (currentUrl.contains("youtube.com") || currentUrl.contains("youtu.be"))) {
            // BUG THẬT (người dùng báo "không có lựa chọn tải audio"):
            // trước đây bấm thẳng vào `downloadYouTube()` (chỉ video), hoàn
            // toàn không có cách chọn "chỉ tải âm thanh" cho video ĐƠN LẺ —
            // dù `downloadYouTubeAudio()` đã viết sẵn đầy đủ, chỉ chưa có
            // nút nào gọi tới khi đang xem 1 video (khác playlist, ĐÃ có
            // lựa chọn audio-only trong `showPlaylistSelectionDialog`).
            // Sửa: hỏi Video/Audio trước khi tải, giống hệt cách playlist
            // đã làm — nhất quán trong toàn app.
            menuItems.add(Triple(android.R.drawable.stat_sys_download_done, "⬇️ Tải video YouTube đang xem") {
                AlertDialog.Builder(this)
                    .setTitle("Tải dạng nào?")
                    .setItems(arrayOf("🎬 Video (kèm âm thanh)", "🎵 Chỉ âm thanh")) { _, which ->
                        val downloadFeature = FeatureRegistry.all().filterIsInstance<DownloadManagerFeature>().firstOrNull()
                        // FALLBACK: NewPipeExtractor lỗi thì tự động thử Sniff
                        // Media trên đúng trang đang mở, KHÔNG đảm bảo tìm
                        // được (StreamSniffer chỉ regex tĩnh HTML) — nhưng
                        // còn hơn im lặng.
                        if (which == 0) {
                            downloadFeature?.catchDownload(this, currentUrl, onYouTubeFailure = { showSniffDialog() })
                        } else {
                            downloadFeature?.downloadYouTubeAudio(this, currentUrl)
                        }
                        Toast.makeText(this, "Đang tải...", Toast.LENGTH_SHORT).show()
                    }
                    .show()
            })
        }
        menuItems.add(Triple(android.R.drawable.ic_menu_save, "💾 Lưu Trang Web") { showWebArchiveDialog() })
        menuItems.add(Triple(android.R.drawable.ic_menu_preferences, "⚙️ Cài đặt Download") { showDownloadPolicySettings() })
        showIconMenu("Tải xuống & Media", menuItems)
    }

    private fun showMenu() {
        // BUG THẬT đã sửa: mục "Features" trước đây gọi thẳng
        // FeatureSettingsActivity nhưng KHÔNG truyền "feature_id" (activity
        // đó cần biết đúng 1 feature nào để hiển thị) — bấm vào chỉ hiện
        // Toast "Không tìm thấy feature" rồi tự đóng ngay, không dẫn tới
        // đâu cả. "Settings" (mục đầu) mới là màn hình liệt kê đúng TẤT CẢ
        // feature (kể cả "Phát media nền" mới thêm) rồi mới mở đúng 1 cái
        // khi bấm vào — đã bỏ mục "Features" trùng lặp/hỏng này.
        //
        // THEO YÊU CẦU "gọn gàng giống Chrome": trước đây danh sách PHẲNG
        // 12 mục, trộn lẫn thao tác duyệt web hay dùng (Tiến tới, Tải lại,
        // Lịch sử...) với công cụ debug/dev ít dùng (Debug Log, Test Cookie
        // Leak, Proxy Config, Xem crash gần nhất) — Chrome KHÔNG bao giờ để
        // công cụ nâng cao lẫn vào menu chính, luôn gom riêng. Gom 4 mục
        // debug/dev đó vào 1 submenu "🛠 Công cụ nâng cao" (giống cách đã
        // gom "Tải xuống & Media" ở phiên trước) — menu chính còn 9 mục,
        // toàn thao tác hay dùng khi duyệt web thường ngày.
        showIconMenu("Menu (Slot $slotIndex)", listOf(
            Triple(
                android.R.drawable.ic_menu_zoom,
                if (engine.isDesktopMode()) "🖥 Đang xem máy tính (bấm để về di động)" else "🖥 Xem bằng máy tính"
            ) { engine.toggleDesktopMode() },
            Triple(android.R.drawable.ic_menu_zoom, "🔍 Thu phóng trang này") { showZoomDialog() },
            Triple(android.R.drawable.stat_sys_download, "📥 Tải xuống & Media") { showDownloadMediaMenu() },
            Triple(android.R.drawable.ic_lock_lock, "🕶 Tab ẩn danh mới") {
                val tab = engine.createTab("about:blank", isPrivate = true)
                engine.switchToTab(tab.id) // createTab() chỉ tự chuyển khi CHƯA có tab nào — cần chủ động chuyển ở đây vì thường đã có tab khác đang mở
                refreshTabBar()
                updatePrivateModeUI()
                Toast.makeText(this, "Đã mở tab ẩn danh — không lưu lịch sử, không khôi phục lại sau khi đóng app", Toast.LENGTH_LONG).show()
            },
            Triple(android.R.drawable.ic_menu_recent_history, "🕐 Lịch sử") {
                startActivityForResult(Intent(this, HistoryActivity::class.java).putExtra("slot_index", slotIndex), RC_HISTORY)
            },
            // BUG THẬT tự gây ra, phát hiện khi thêm mục Zoom cạnh đây:
            // `BookmarkActivity`/`RC_BOOKMARKS`/`BrowserBookmarks` đã xây
            // xong hoàn chỉnh ở phiên trước nhưng QUÊN HẲN không có nút/mục
            // menu nào thực sự mở nó — tính năng coi như vô hình với người
            // dùng dù code đã đầy đủ.
            Triple(android.R.drawable.ic_menu_recent_history, "⭐ Bookmark đã lưu") {
                startActivityForResult(Intent(this, BookmarkActivity::class.java).putExtra("slot_index", slotIndex), RC_BOOKMARKS)
            },
            Triple(android.R.drawable.ic_menu_gallery, "Chuyển Khe") { startActivity(Intent(this, ProfilePickerActivity::class.java)) },
            Triple(android.R.drawable.ic_menu_send, "📋 Sao chép URL hiện tại") { copyToClipboard("URL", engine.currentUrl() ?: "") },
            Triple(android.R.drawable.ic_menu_manage, "Settings") {
                startActivity(Intent(this, SettingsActivity::class.java).putExtra("slot_index", slotIndex))
            },
            Triple(android.R.drawable.ic_menu_preferences, "🛠 Công cụ nâng cao") { showAdvancedToolsMenu() }
        ))
    }

    /**
     * Nút "Thu phóng" giống hệt Chrome (ảnh người dùng gửi) — dùng ĐƯỢC
     * CHO BẤT KỲ TRANG NÀO theo ý muốn, khác hẳn zoom TỰ ĐỘNG chỉ áp cho
     * domain trong danh sách ngoại lệ (`applyDesktopLayoutZoomIfNeeded`).
     * Tái dùng ĐÚNG kỹ thuật đã xác nhận hoạt động (CSS `zoom`, GeckoView
     * 145 đã hỗ trợ — xem chú thích ở hàm đó) thay vì đoán 1 API zoom gốc
     * khác của GeckoView chưa từng tra cứu/xác nhận.
     */
    private fun showZoomDialog() {
        val currentUrl = engine.currentUrl() ?: ""
        var currentPercent = com.colablive.keeper.core.ZoomPrefs.getZoomForUrl(this, slotIndex, currentUrl)
        val label = TextView(this).apply {
            text = "$currentPercent%"
            textSize = 20f
            gravity = Gravity.CENTER
        }
        fun applyZoom() {
            com.colablive.keeper.core.ZoomPrefs.setZoomForUrl(this, slotIndex, currentUrl, currentPercent)
            engine.evaluateJs("document.documentElement.style.zoom = ${currentPercent / 100.0}; 'da chinh ' + '$currentPercent%';")
            label.text = "$currentPercent%"
        }
        val minusBtn = Button(this).apply {
            text = "－"
            setOnClickListener {
                if (currentPercent > 50) { currentPercent -= 10; applyZoom() }
            }
        }
        val plusBtn = Button(this).apply {
            text = "＋"
            setOnClickListener {
                if (currentPercent < 200) { currentPercent += 10; applyZoom() }
            }
        }
        val resetBtn = Button(this).apply {
            text = "Đặt lại"
            setOnClickListener { currentPercent = 100; applyZoom() }
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(32, 24, 32, 24)
            addView(minusBtn)
            addView(label, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { gravity = Gravity.CENTER })
            addView(plusBtn)
        }
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(row)
            addView(resetBtn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                gravity = Gravity.CENTER
            })
        }
        AlertDialog.Builder(this)
            .setTitle("Thu phóng trang này")
            .setView(container)
            .setPositiveButton("Xong", null)
            .show()
    }

    /**
     * Gom 4 mục debug/dev trước đây rải rác trong menu chính (chỉ người
     * phát triển mới cần dùng thường xuyên, người dùng thường không đụng
     * tới) — theo đúng cách Chrome KHÔNG bao giờ để công cụ nâng cao lẫn
     * vào menu duyệt web hàng ngày.
     */
    private fun showAdvancedToolsMenu() {
        showIconMenu("Công cụ nâng cao", listOf(
            Triple(android.R.drawable.ic_menu_info_details, "Debug Log") {
                startActivity(Intent(this, DebugLogActivity::class.java).putExtra("slot_index", slotIndex))
            },
            Triple(android.R.drawable.ic_menu_mapmode, "Proxy Config") { showProxyDialog() },
            Triple(android.R.drawable.ic_menu_view, "Test Cookie Leak") { showLeakTestDialog() },
            Triple(android.R.drawable.ic_dialog_alert, "🩹 Xem crash gần nhất") {
                startActivity(Intent(this, CrashReportActivity::class.java).putExtra("slot_index", slotIndex))
            }
        ))
    }

    private fun copyToClipboard(label: String, text: String) {
        val clipboard = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
        clipboard.setPrimaryClip(android.content.ClipData.newPlainText(label, text))
        Toast.makeText(this, "Đã sao chép: $text", Toast.LENGTH_SHORT).show()
    }

    /** Menu hiện ra khi nhấn giữ 1 liên kết trên trang (trước đây không làm gì cả). */
    private fun showLinkContextMenu(uri: String, linkText: String?) {
        val items = arrayOf("Mở trong tab mới", "Mở ở khe khác…", "Sao chép liên kết", "Chia sẻ liên kết")
        AlertDialog.Builder(this)
            .setTitle(linkText?.takeIf { it.isNotBlank() } ?: uri)
            .setItems(items) { _, which ->
                when (which) {
                    0 -> {
                        engine.createTab(uri)
                        refreshTabBar()
                    }
                    1 -> showOpenInSlotDialog(uri)
                    2 -> copyToClipboard("link", uri)
                    3 -> {
                        val shareIntent = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, uri)
                        }
                        startActivity(Intent.createChooser(shareIntent, "Chia sẻ liên kết"))
                    }
                }
            }
            .show()
    }

    /** Mở 1 URL cụ thể ở 1 khe KHÁC (không phải khe đang đứng) — mở tiến trình khe đó kèm URL qua extra "open_url". */
    private fun showOpenInSlotDialog(uri: String) {
        val slotOptions = (0..ProfileSlots.SLOT_COUNT).filter { it != slotIndex }
        val labels = slotOptions.map { ProfileSlots.getSlotName(it) }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Mở liên kết ở khe nào?")
            .setItems(labels) { _, which ->
                val targetSlot = slotOptions[which]
                val className = ProfileSlots.componentClassNameForSlot(targetSlot)
                val intent = Intent().apply {
                    component = ComponentName(packageName, className)
                    putExtra("open_url", uri)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                startActivity(intent)
            }
            .show()
    }

    private fun showProxyDialog() {
        val proxyType = AppPrefs.getInt(this, slotIndex, "proxy_type", 0)
        val host = AppPrefs.getString(this, slotIndex, "proxy_host", "")
        val port = AppPrefs.getString(this, slotIndex, "proxy_port", "")
        val user = AppPrefs.getString(this, slotIndex, "proxy_user", "")

        val msg = """
            ✅ Áp dụng qua WebExtension Proxy API (browser.proxy.onRequest) —
            đăng ký khi khe khởi động (GeckoRuntimeProvider). Đổi cấu hình bên
            dưới cần ĐÓNG VÀ MỞ LẠI khe này để có tác dụng.

            Proxy Type: ${if (proxyType == 0) "Direct" else if (proxyType == 1) "HTTP" else "SOCKS5"}
            Host: $host
            Port: $port
            User: $user

            ⚠️ Với proxy miễn phí (nút "Tự động tìm proxy"): rủi ro thật là bị
            log traffic hoặc honeypot — không dùng để đăng nhập tài khoản quan
            trọng.

            Vào Settings > Fingerprint Spoof để thay đổi.
        """.trimIndent()

        AlertDialog.Builder(this)
            .setTitle("Proxy Config (Slot $slotIndex)")
            .setMessage(msg)
            .setPositiveButton("OK", null)
            .show()
    }

    private fun showLeakTestDialog() {
        val downloadFeature = FeatureRegistry.all().filterIsInstance<com.colablive.keeper.features.downloads.DownloadManagerFeature>().firstOrNull()
        downloadFeature?.showLeakTestDialog(this, slotIndex, engine)
    }

    private fun showIDMDialog() {
        val downloadFeature = FeatureRegistry.all().filterIsInstance<com.colablive.keeper.features.downloads.DownloadManagerFeature>().firstOrNull()
        downloadFeature?.showIDMDialog(this)
    }

    private fun showSniffDialog() {
        val downloadFeature = FeatureRegistry.all().filterIsInstance<com.colablive.keeper.features.downloads.DownloadManagerFeature>().firstOrNull()
        // Lấy HTML từ trang hiện tại
        engine.evaluateJs("document.documentElement.outerHTML") { html ->
            html?.let {
                val links = downloadFeature?.sniffPage(this, it, engine.currentUrl() ?: "")
                links?.let { list ->
                    runOnUiThread {
                        downloadFeature?.showSniffedLinksDialog(this, list)
                    }
                }
            }
        }
    }

    private fun showWebArchiveDialog() {
        val currentUrl = engine.currentUrl() ?: return
        val currentTitle = engine.getActiveTab()?.title ?: "page"
        val downloadFeature = FeatureRegistry.all().filterIsInstance<com.colablive.keeper.features.downloads.DownloadManagerFeature>().firstOrNull()
        downloadFeature?.showWebArchiveDialog(this, currentUrl, currentTitle, geckoView)
    }

    private fun showDownloadPolicySettings() {
        val downloadFeature = FeatureRegistry.all().filterIsInstance<com.colablive.keeper.features.downloads.DownloadManagerFeature>().firstOrNull()
        downloadFeature?.showPolicySettings(this)
    }



    private fun showDownloadDialog(url: String, fileName: String) {
        AlertDialog.Builder(this)
            .setTitle("Tải xuống")
            .setMessage("$fileName\n$url")
            .setPositiveButton("Tải") { _, _ ->
                val downloadFeature = FeatureRegistry.all().filterIsInstance<DownloadManagerFeature>().firstOrNull()
                downloadFeature?.startDownload(this, url, fileName)
            }
            .setNegativeButton("Hủy", null)
            .show()
    }

    private fun showFilePicker(mimeTypes: Array<String>?) {
        /**
         * ĐỔI HẲN CƠ CHẾ (không phải thử lại "copy vs không copy" — đây là
         * hướng khác hẳn, nhắm đúng vào THỜI GIAN SỐNG của quyền đọc URI,
         * chưa từng thử):
         *
         * `ACTION_GET_CONTENT` (cách cũ) cấp quyền đọc URI kết quả THƯỜNG
         * CHỈ CÓ HIỆU LỰC TRONG PHẠM VI/THỜI GIAN GẮN VỚI LƯỢT GỌI
         * ACTIVITY đó — không đảm bảo còn hiệu lực nếu việc đọc byte thật
         * xảy ra hơi trễ (bất đồng bộ, dù chỉ vài trăm mili-giây). Đây khớp
         * CHÍNH XÁC với triệu chứng đã thấy: `confirm()` (giao URI cho
         * Gecko) chạy được ngay lập tức — nhưng việc ĐỌC BYTE THẬT của
         * Gecko (bên trong tiến trình render riêng, chắc chắn có độ trễ dù
         * nhỏ) có thể xảy ra SAU KHI quyền đã hết hạn.
         *
         * `ACTION_OPEN_DOCUMENT` (Storage Access Framework) + cờ
         * `FLAG_GRANT_PERSISTABLE_URI_PERMISSION` + gọi
         * `takePersistableUriPermission()` cho quyền đọc SỐNG LÂU DÀI,
         * không phụ thuộc thời điểm đọc — đây là cơ chế CHUẨN, được tài
         * liệu Android khuyến nghị rõ ràng cho đúng tình huống "cần đọc
         * file được chọn ở 1 thời điểm sau đó, không phải ngay lập tức".
         * Nếu đúng nguyên nhân là hết hạn quyền (chưa từng thử hướng này
         * trước đây, luôn chỉ đổi qua lại data.data/clipData/copy), đây mới
         * là hướng thật sự khác, không phải lặp lại.
         */
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = mimeTypes?.firstOrNull() ?: "*/*"
            addCategory(Intent.CATEGORY_OPENABLE)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(Intent.createChooser(intent, "Chọn file"), RC_FILE_PICKER)
    }

    /**
     * BUG THẬT đã sửa — "kéo thả file từ Files app không hoạt động như
     * Chrome": code cũ ở đây gắn `setOnDragListener` riêng, và khi có file
     * thả vào thì gọi `engine.handleDropUri()` — hàm đó lại chỉ COPY file
     * vào cache rồi bắn ra 1 `CustomEvent('livebrowser:filedrop', ...)` tự
     * chế trên `window`. KHÔNG TRANG WEB THẬT NÀO lắng nghe sự kiện tự chế
     * này cả — trang web chuẩn dùng sự kiện `drop` HTML5 chuẩn với
     * `event.dataTransfer.files`, không phải sự kiện app tự đặt tên. Nghĩa
     * là kéo thả file trước giờ hoàn toàn KHÔNG hoạt động với bất kỳ trang
     * thật nào, kể cả khi copy file "thành công".
     *
     * Nghiêm trọng hơn: `View.setOnDragListener()` khi được gắn sẽ THAY THẾ
     * HẲN cơ chế xử lý kéo thả nội bộ mặc định của chính View đó (GeckoView
     * đã tự cài sẵn `onDragEvent()` để dịch `DragEvent` gốc của Android
     * thành đúng sự kiện `drop` chuẩn HTML5 cho trang web, y hệt cách Chrome
     * làm) — gắn listener tự chế ở đây đã CHE MẤT cơ chế đúng có sẵn của
     * GeckoView, không chỉ đơn thuần "thêm 1 cách kéo thả không hoạt động"
     * mà còn "chặn mất cách đã hoạt động sẵn".
     *
     * Sửa: bỏ hẳn listener tự chế — để GeckoView tự xử lý kéo thả theo đúng
     * cơ chế chuẩn nó đã có sẵn (giống Chrome/Firefox thật), không can
     * thiệp gì thêm ở tầng app nữa.
     */
    private fun setupDragDrop() {
        // SỬA LẠI (đã tra cứu lại tài liệu chính thức developer.android.com,
        // xác nhận bản sửa trước dùng API BỊA — `Window.addDragDropListener()`
        // / `DragAndDropListener` KHÔNG TỒN TẠI trong Android SDK, không có
        // trong trang tham chiếu android.view.Window chính thức).
        //
        // Sự thật đã xác nhận: drag event CHỈ có 2 cách nhận — override
        // `View.onDragEvent()` hoặc `View.OnDragListener` qua
        // `setOnDragListener()` — cả hai đều chỉ tồn tại ở cấp View, KHÔNG có
        // ở cấp Activity/Window. Không có "điểm quan sát riêng ở cấp Activity"
        // như comment gốc phía trên kỳ vọng.
        //
        // Thêm nữa: theo tài liệu concepts (Key concepts | Views | Android
        // Developers), khi 1 View con (GeckoView) nhận `ACTION_DROP` và trả về
        // true (đã xử lý), hệ thống KHÔNG gửi tiếp event đó lên listener của
        // View cha nữa — nên kể cả gắn `setOnDragListener` ở root layout (cha
        // của geckoView) thay vì ở geckoView cũng KHÔNG đảm bảo nhận được
        // ACTION_DROP một khi GeckoView đã tiêu thụ nó trước.
        //
        // Vì vậy: không có cách "quan sát riêng, không đụng gì đến GeckoView"
        // để tự gọi requestDragAndDropPermissions() ở tầng app. Quay lại đúng
        // hướng đã có ở mục 8r — để trống, tin tưởng hoàn toàn vào GeckoView
        // 145 (đã xác nhận qua Bugzilla Mozilla #1586471: nsDragService xử lý
        // nội bộ, bao gồm cả phần cấp quyền URI xuyên app).
        //
        // NHƯNG: người dùng đã test thật — kéo thả VẪN không hoạt động sau
        // khi để trống như trên. Nghĩa là giả thuyết "GeckoView tự lo hết"
        // SAI, hoặc đúng nhưng có điều kiện khác chưa rõ. Không đoán thêm
        // nữa — gắn listener THUẦN CHẨN ĐOÁN dưới đây để xem THỰC SỰ có
        // DragEvent nào tới geckoView hay không, và tới action nào (STARTED/
        // ENTERED/LOCATION/DROP/EXITED/ENDED). LUÔN return false — không tiêu
        // thụ event, không thay đổi hành vi thật, chỉ quan sát qua log.
        //
        // Đọc log sau khi thử kéo 1 file vào geckoView:
        //   - KHÔNG thấy dòng "DragEvent nhận được" nào cả → hệ thống/launcher
        //     không gửi event tới app này (vấn đề ở tầng ngoài GeckoView,
        //     ví dụ: launcher không hỗ trợ kéo file vào app khác, hoặc app
        //     không được khai báo nhận drag trong manifest/theme).
        //   - Thấy STARTED nhưng KHÔNG thấy DROP → GeckoView (hoặc View nào
        //     đó) đã từ chối/không accept drag ngay từ đầu (trả false cho
        //     ACTION_DRAG_STARTED), nên hệ thống không gửi tiếp DROP.
        //   - Thấy tới DROP → event có tới, vấn đề nằm ở việc GeckoView xử lý
        //     nội dung sau DROP (có thể thật sự cần requestDragAndDropPermissions
        //     hoặc cần can thiệp thêm) — lúc đó mới có cơ sở sửa tiếp, không
        //     phải đoán.
        geckoView.setOnDragListener { _, event ->
            val actionName = when (event.action) {
                android.view.DragEvent.ACTION_DRAG_STARTED -> "ACTION_DRAG_STARTED"
                android.view.DragEvent.ACTION_DRAG_ENTERED -> "ACTION_DRAG_ENTERED"
                android.view.DragEvent.ACTION_DRAG_LOCATION -> "ACTION_DRAG_LOCATION"
                android.view.DragEvent.ACTION_DRAG_EXITED -> "ACTION_DRAG_EXITED"
                android.view.DragEvent.ACTION_DROP -> "ACTION_DROP"
                android.view.DragEvent.ACTION_DRAG_ENDED -> "ACTION_DRAG_ENDED"
                else -> "UNKNOWN(${event.action})"
            }
            // Bỏ log riêng cho ACTION_DRAG_LOCATION — đây là action bắn ra
            // LIÊN TỤC (hàng chục lần/giây) suốt lúc kéo, chiếm gần hết log,
            // che mất mọi thứ khác. Đã xác nhận đủ (log trước) rằng chuỗi
            // event đi trọn qua LOCATION bình thường — không cần log lặp lại
            // action này nữa, chỉ log các mốc quan trọng (STARTED/ENTERED/
            // EXITED/DROP/ENDED).
            if (event.action != android.view.DragEvent.ACTION_DRAG_LOCATION) {
                DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN kéo-thả] DragEvent nhận được tại geckoView — action=$actionName, clipDescription=${event.clipDescription}")
            }

            // CẬP NHẬT — đã tra ra: log lần trước cho thấy chuỗi event đi trọn
            // tới DROP/ENDED, nghĩa là GeckoView NỘI BỘ đã tự chấp nhận drag
            // (nếu từ chối ACTION_DRAG_STARTED thì Android đã ngừng gửi tiếp).
            // Xác nhận qua tra cứu: GeckoView 145 (bản project đang dùng) CÓ
            // thật `PanZoomController.onDragEvent()` — API thêm từ v124, đúng
            // bug #1586471 mà code gốc trích dẫn — không phải bịa. Vậy việc
            // "return false, để GeckoView tự xử lý qua fallback" trước đây
            // VỀ MẶT LÝ THUYẾT đã đúng hướng — nhưng ta chưa từng THẤY được
            // GeckoView thực sự trả về gì (chấp nhận hay từ chối nội dung),
            // vì đó là fallback nội bộ, không quan sát được qua log.
            //
            // Sửa: gọi THẲNG `panZoomController.onDragEvent()` ở đây — vừa
            // cấp quyền đọc URI (`requestDragAndDropPermissions`) TRƯỚC khi
            // Gecko cố đọc nội dung ở ACTION_DROP, vừa lấy được giá trị trả
            // về THẬT (true/false) để biết chính xác Gecko có chấp nhận nội
            // dung hay không — thay vì đoán qua 1 lớp fallback vô hình.
            if (event.action == android.view.DragEvent.ACTION_DROP) {
                try {
                    requestDragAndDropPermissions(event)
                    DebugLog.log("Khe $slotIndex: đã requestDragAndDropPermissions() cho ACTION_DROP")
                } catch (e: Exception) {
                    DebugLog.log("Khe $slotIndex: requestDragAndDropPermissions() lỗi: ${e.message}")
                }
            }

            val pzc = geckoView.session?.panZoomController
            val accepted = try {
                pzc?.onDragEvent(event) ?: false
            } catch (e: Exception) {
                DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN kéo-thả] panZoomController.onDragEvent() NÉM LỖI: ${e.message}")
                false
            }
            if (event.action != android.view.DragEvent.ACTION_DRAG_LOCATION) {
                DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN kéo-thả] panZoomController.onDragEvent($actionName) trả về = $accepted")
            }

            // Trả THẲNG kết quả thật từ panZoomController — không trả `false`
            // cố định nữa. Lý do: nếu vẫn trả `false`, Android sẽ RƠI TIẾP
            // xuống `onDragEvent()` nội bộ của GeckoView (theo đúng cơ chế
            // OnDragListener→fallback đã xác nhận) — và nội bộ đó (nếu có)
            // NHIỀU KHẢ NĂNG cũng gọi lại `panZoomController.onDragEvent()`
            // giống hệt như mình vừa gọi ở trên → xử lý event 2 LẦN. Với
            // ACTION_DROP, xử lý 2 lần có thể gây đọc file 2 lần/lỗi tranh
            // chấp — rủi ro hơn là lợi. Trả `accepted` (kết quả thật) khiến
            // lệnh gọi trực tiếp của mình trở thành nguồn xử lý DUY NHẤT.
            accepted
        }
    }

    private fun requestPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, PERMISSION_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, arrayOf(PERMISSION_NOTIFICATIONS), RC_NOTIFICATIONS)
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (com.colablive.keeper.core.FolderPickerBridge.handleActivityResult(this, requestCode, resultCode, data)) {
            return
        }
        if (requestCode == RC_HISTORY) {
            if (resultCode == RESULT_OK) {
                data?.getStringExtra("open_url")?.let { engine.loadUrl(it) }
            }
            return
        }
        if (requestCode == RC_BOOKMARKS) {
            if (resultCode == RESULT_OK) {
                data?.getStringExtra("open_url")?.let { engine.loadUrl(it) }
            }
            return
        }
        if (requestCode == RC_FILE_PICKER) {
            /**
             * QUAY LẠI COPY FILE — LẦN NÀY CÓ BẰNG CHỨNG THẬT, KHÔNG PHẢI
             * ĐOÁN. Log thật gửi lên xác nhận: đưa thẳng URI (bản trước,
             * mục 8z) → `resolveFilePrompt` báo "confirm prompt thành
             * công" (không hề có exception phía Kotlin) → nhưng trang VẪN
             * báo "Unable to read file", với CẢ 2 provider khác nhau (SAF
             * Downloads lẫn 1 app quản lý file khác). Tức là `confirm()`
             * chạy được, nhưng việc ĐỌC BYTE THẬT xảy ra ở tầng SÂU HƠN bên
             * trong Gecko (rất có thể ở tiến trình render riêng) và tầng đó
             * không đọc được URI ngoài — CHỨNG MINH giả thuyết "vấn đề
             * quyền truy cập cross-process" ban đầu là ĐÚNG, không phải chỉ
             * là 1 khả năng.
             *
             * Copy file vào bộ nhớ RIÊNG của app này (qua FileProvider) né
             * được đúng vấn đề này vì không còn phụ thuộc provider ngoài —
             * mọi tiến trình của app đều có quyền đọc file trong bộ nhớ
             * riêng của chính app. Đưa lại cách này, giữ nguyên các phần đã
             * sửa trước đó (chạy nền tránh treo UI — mục 8t, tự dọn cache
             * cũ — mục 8s, đọc thêm clipData — mục 8x), chỉ thêm log rõ hơn
             * ở bước cuối để biết chắc chắn có tới `resolveFilePrompt`
             * không.
             */
            DebugLog.log("onActivityResult(RC_FILE_PICKER): resultCode=$resultCode, data.data=${data?.data}, data.clipData=${data?.clipData}")
            val pickedUri = if (resultCode == RESULT_OK) {
                data?.data ?: data?.clipData?.let { if (it.itemCount > 0) it.getItemAt(0).uri else null }
            } else null
            if (pickedUri == null) {
                DebugLog.log("onActivityResult(RC_FILE_PICKER): pickedUri null (huỷ chọn file, hoặc resultCode != OK) — dismiss() prompt")
                engine.resolveFilePrompt(this, null)
                return
            }
            // Lấy quyền đọc DÀI HẠN ngay lập tức (rẻ, đồng bộ) — xem giải
            // thích lớn ở `showFilePicker()`. Không để lỡ khoảng thời gian
            // nào giữa lúc nhận URI và lúc thật sự đọc nó.
            try {
                contentResolver.takePersistableUriPermission(pickedUri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e: Exception) {
                DebugLog.log("takePersistableUriPermission lỗi (không chặn luồng, vẫn thử đọc tiếp): ${e.message}")
            }
            DebugLog.log("onActivityResult(RC_FILE_PICKER): pickedUri=$pickedUri — bắt đầu copy nền vào bộ nhớ riêng của app")
            val progressToast = Toast.makeText(this, "Đang xử lý file...", Toast.LENGTH_LONG)
            progressToast.show()
            Thread {
                val safeUri = copyToAppStorageAsFileProviderUri(pickedUri)
                DebugLog.log("onActivityResult(RC_FILE_PICKER): copy xong, safeUri=$safeUri (null nghĩa là copy lỗi, xem log ngay phía trên dòng này)")
                runOnUiThread {
                    progressToast.cancel()
                    if (safeUri == null) {
                        Toast.makeText(this, "Không đọc được file đã chọn", Toast.LENGTH_SHORT).show()
                    }
                    DebugLog.log("onActivityResult(RC_FILE_PICKER): gọi engine.resolveFilePrompt(safeUri=$safeUri)")
                    engine.resolveFilePrompt(this, safeUri)
                }
            }.start()
        }
    }

    /**
     * Copy file được chọn vào bộ nhớ RIÊNG của app này rồi cấp quyền qua
     * `FileProvider` chuẩn (đã khai báo sẵn trong AndroidManifest.xml từ
     * trước, không cần thêm gì) — xem giải thích đầy đủ lý do ở
     * `onActivityResult` phía trên.
     */
    private fun cleanupOldUploadCache() {
        try {
            val dir = File(cacheDir, "uploads")
            val cutoff = System.currentTimeMillis() - 10 * 60 * 1000L
            dir.listFiles()?.forEach { f ->
                if (f.lastModified() < cutoff) f.delete()
            }
        } catch (e: Exception) {
            DebugLog.log("cleanupOldUploadCache lỗi: ${e.message}")
        }
    }

    /**
     * NGUYÊN NHÂN THẬT — đã TRA ĐƯỢC, không còn đoán: tra Bugzilla của
     * chính Mozilla (bug #1515440, "PromptDelegate.FileCallback.confirm
     * not handling URIs from content://...") xác nhận GeckoView's
     * `FilePrompt.confirm(Context, Uri)` CHỈ hỗ trợ URI dạng `file://` —
     * TỪ CHỐI mọi URI `content://`, KỂ CẢ từ `FileProvider` CỦA CHÍNH APP
     * NÀY (không phân biệt content:// đến từ provider ngoài hay provider
     * riêng — đều bị từ chối như nhau, lỗi log gốc bên phía Gecko là
     * "Only file URI is supported"). Đây là lý do CẢ 2 lần thử trước đều
     * thất bại: lần đưa thẳng URI ngoài (content://, mục 8z) VÀ lần copy
     * qua FileProvider (vẫn ra content://, mục 8za) — cả 2 đều dùng SAI
     * LOẠI URI, không liên quan gì đến việc có copy hay không, hay quyền
     * đọc dài/ngắn hạn.
     *
     * Cách khắc phục ĐÚNG kỹ sư Mozilla xác nhận trong bug đó: app tự đọc
     * dữ liệu content:// rồi đưa lại — nghĩa là copy file (đã làm đúng),
     * NHƯNG bước cuối phải dùng `Uri.fromFile(destFile)` (file://) thay vì
     * bọc qua FileProvider (content://) như trước. `Uri.fromFile()` không
     * kích hoạt `FileUriExposedException` ở đây vì đó chỉ áp dụng khi đưa
     * URI file:// vào 1 `Intent` gửi SANG APP KHÁC — còn `confirm()` là gọi
     * hàm Java trực tiếp trong tiến trình mình, không phải Intent.
     */
    private fun copyToAppStorageAsFileProviderUri(sourceUri: Uri): Uri? {
        return try {
            cleanupOldUploadCache()
            val fileName = getFileNameFromUriPublic(sourceUri) ?: "upload_${System.currentTimeMillis()}"
            val dir = File(cacheDir, "uploads").apply { mkdirs() }
            val destFile = File(dir, "${System.currentTimeMillis()}_$fileName")
            val bytesCopied = contentResolver.openInputStream(sourceUri)?.use { input ->
                destFile.outputStream().use { output -> input.copyTo(output) }
            }
            if (bytesCopied == null) {
                DebugLog.log("copyToAppStorageAsFileProviderUri: openInputStream trả về null cho $sourceUri — CHÍNH tiến trình app này cũng không đọc được nguồn (không phải vấn đề riêng của Gecko)")
                return null
            }
            DebugLog.log("copyToAppStorageAsFileProviderUri: copy xong $bytesCopied byte vào ${destFile.path} — dùng Uri.fromFile() (file://), KHÔNG dùng FileProvider (content://) vì GeckoView từ chối content://")
            Uri.fromFile(destFile)
        } catch (e: Exception) {
            DebugLog.log("copyToAppStorageAsFileProviderUri lỗi: ${e.javaClass.simpleName}: ${e.message}")
            null
        }
    }

    private fun getFileNameFromUriPublic(uri: Uri): String? {
        var result: String? = null
        if (uri.scheme == "content") {
            contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val idx = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0) result = cursor.getString(idx)
                }
            }
        }
        return result ?: uri.lastPathSegment
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        // Khe này (singleTask) ĐÃ ĐANG CHẠY SẴN — Android gọi đây thay vì
        // onCreate() lại. Trước đây không xử lý gì cả, nên "Mở ở khe khác"
        // im lặng KHÔNG mở link nếu khe đích đã mở sẵn từ trước (chỉ đưa
        // khe đó lên foreground, giữ nguyên trang đang xem).
        val openUrl = intent.getStringExtra("open_url")
        if (openUrl != null) {
            engine.createTab(openUrl)
            refreshTabBar()
        }
    }

    /**
     * CHẨN ĐOÁN cho vụ "YouTube tắt tiếng khi khoá màn hình/chuyển app" —
     * bản visibility-spoof JS (BackgroundMediaFeature, mục 8b-8d) đã xác
     * nhận KHÔNG đủ (người dùng test bản mới nhất vẫn còn lỗi). Nguyên
     * nhân còn lại nhiều khả năng nằm ở tầng GeckoView/Android — ví dụ
     * GeckoView có thể tự huỷ Surface render (và có thể cả audio) khi
     * Activity mất hiển thị — nhưng đây là hành vi NỘI BỘ của thư viện
     * GeckoView, không có API public để đọc thẳng, và đoán mò API
     * (`GeckoSession.MediaSession.Delegate` chẳng hạn) mà không có mạng để
     * tra đúng chữ ký hàm RẤT dễ đoán sai → gãy build (đã từng xảy ra với
     * `element.linkText`, không muốn lặp lại).
     *
     * Nên thay vì đoán tiếp, ghi log các mốc vòng đời Activity — CHỈ dùng
     * API Android chuẩn, không đụng gì tới GeckoView. Sau khi bạn build
     * bản này, tái hiện lỗi (mở YouTube, khoá màn hình vài giây, mở lại),
     * vào Menu ⋮ → Debug Log, copy đoạn quanh lúc đó gửi lại — sẽ biết
     * chính xác Activity có bị onStop() không, cách nhau bao lâu, từ đó
     * mới sửa đúng chỗ thay vì đoán mò.
     */
    override fun onPause() {
        super.onPause()
        DebugLog.log("Khe $slotIndex: MainActivity.onPause() — Activity mất foreground")
        // Lưu danh sách tab mỗi lần mất foreground — mốc lưu đáng tin cậy,
        // xem giải thích lớn ở `GeckoViewEngine.saveTabsState()`.
        engine.saveTabsState()
    }

    override fun onStop() {
        super.onStop()
        DebugLog.log("Khe $slotIndex: MainActivity.onStop() — Activity không còn hiển thị (surface có thể bị huỷ ở đây)")
    }

    override fun onResume() {
        super.onResume()
        DebugLog.log("Khe $slotIndex: MainActivity.onResume() — Activity quay lại foreground")
        updateTaskDescription() // đề phòng người dùng đổi tên hồ sơ qua ProfilePickerActivity rồi quay lại (không tự khởi động lại tiến trình trong mọi trường hợp)
    }

    /**
     * BUG THẬT (người dùng chụp ảnh Recent Apps — mọi thẻ khe đều hiện
     * cùng 1 icon/tên app mặc định, không phân biệt được khe nào là khe
     * nào): `taskAffinity` khai báo đúng trong Manifest (mỗi khe ĐÃ LÀ 1
     * thẻ Recent Apps riêng biệt thật) nhưng CHƯA TỪNG gọi
     * `setTaskDescription()` — API Android CHUYÊN DÙNG để đặt tên/icon
     * riêng cho từng thẻ Recent Apps, khác hẳn tên app chung khai báo tĩnh
     * trong Manifest (`android:label` ở mức <application>, giống nhau cho
     * mọi activity/task theo mặc định).
     */
    private fun updateTaskDescription() {
        val profileName = ProfileSlots.getSlotAssignment(this, slotIndex)
        val label = "Khe $slotIndex — $profileName"
        try {
            // BUG THẬT (người dùng báo Recent Apps vẫn không phân biệt được
            // khe nào là khe nào): setLabel() đúng là đã gọi từ trước, NHƯNG
            // label chỉ hiện thành DÒNG CHỮ NHỎ dưới ảnh thu nhỏ trong thẻ —
            // thứ đập vào mắt đầu tiên khi lướt Recent Apps là ICON app ở
            // góc thẻ, và trước giờ mọi khe dùng CHUNG icon mặc định của
            // app (không đổi theo TaskDescription) — nhìn thoáng qua 4 thẻ
            // vẫn giống hệt nhau dù label có đúng. Sửa: tự vẽ 1 icon tròn
            // MÀU RIÊNG cho từng khe (0=xanh dương, 1=xanh lá, 2=cam,
            // 3=tím) kèm số khe lớn ở giữa — nhận diện được ngay từ xa,
            // không cần đọc chữ nhỏ.
            val icon = buildSlotTaskIcon(slotIndex)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                setTaskDescription(
                    android.app.ActivityManager.TaskDescription.Builder()
                        .setLabel(label)
                        .setIcon(android.graphics.drawable.Icon.createWithBitmap(icon))
                        .build()
                )
            } else {
                @Suppress("DEPRECATION")
                setTaskDescription(android.app.ActivityManager.TaskDescription(label, icon))
            }
        } catch (e: Exception) {
            DebugLog.log("updateTaskDescription lỗi: ${e.message}")
        }
    }

    /** Vẽ icon tròn MÀU RIÊNG theo khe + số khe lớn ở giữa — dùng cho thẻ
     * Recent Apps (xem `updateTaskDescription()`). Vẽ bằng Canvas thuần,
     * không cần asset ảnh nào — luôn khớp đúng SLOT_COUNT dù thêm/bớt khe
     * sau này (màu lặp lại theo chu kỳ nếu vượt quá danh sách màu). */
    private fun buildSlotTaskIcon(slotIndex: Int): android.graphics.Bitmap {
        val colors = intArrayOf(
            Color.parseColor("#1A73E8"), // Khe 0 — xanh dương
            Color.parseColor("#0F9D58"), // Khe 1 — xanh lá
            Color.parseColor("#F4511E"), // Khe 2 — cam
            Color.parseColor("#8E24AA")  // Khe 3 — tím
        )
        val bgColor = colors[slotIndex % colors.size]
        val size = dp(72)
        val bitmap = android.graphics.Bitmap.createBitmap(size, size, android.graphics.Bitmap.Config.ARGB_8888)
        val canvas = android.graphics.Canvas(bitmap)
        val circlePaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            color = bgColor
            style = android.graphics.Paint.Style.FILL
        }
        val radius = size / 2f
        canvas.drawCircle(radius, radius, radius, circlePaint)
        val textPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = size * 0.5f
            textAlign = android.graphics.Paint.Align.CENTER
            isFakeBoldText = true
        }
        val textY = radius - (textPaint.descent() + textPaint.ascent()) / 2f
        canvas.drawText(slotIndex.toString(), radius, textY, textPaint)
        return bitmap
    }

    override fun onDestroy() {
        handler.removeCallbacks(featureTickRunnable)
        gracefulCloseReceiver?.let {
            try { unregisterReceiver(it) } catch (e: Exception) { /* đã bị gỡ trước đó, bỏ qua */ }
        }
        // LIÊN QUAN TRỰC TIẾP tới ColabLiveKeeperFeature (giữ phiên Colab
        // "sống" khi nền) + BackgroundMediaFeature: `onDestroy()` KHÔNG chỉ
        // xảy ra khi người dùng THẬT SỰ đóng khe — Android cũng gọi
        // `onDestroy()` khi tự thu hồi bộ nhớ của 1 Activity đang ở nền
        // (trong khi TIẾN TRÌNH + task vẫn còn, đúng như tình huống gây
        // crash ở mục 8g). TRƯỚC ĐÂY `engine.release()` (đóng TẤT CẢ tab,
        // gồm cả tab Colab/YouTube đang chạy nền) chạy VÔ ĐIỀU KIỆN mỗi lần
        // `onDestroy()` — nghĩa là mỗi lần Android âm thầm thu hồi Activity
        // nền, tab Colab/YouTube bị ĐÓNG THẬT (không phải chỉ tạm ẩn), làm
        // mất hết tác dụng của việc "giữ chạy nền" dù GeckoRuntime bên dưới
        // vẫn còn sống. Dùng `isFinishing` để phân biệt: đúng là đang đóng
        // hẳn khe (người dùng bấm back/thoát hẳn) thì mới đóng tab; còn
        // Android tự thu hồi Activity để dọn RAM (task/tiến trình vẫn còn)
        // thì GIỮ NGUYÊN tab, không đóng gì cả — lần sau `onCreate()` mở lại
        // (cùng tiến trình, xem 8g) sẽ tự thấy engine/tab cũ vẫn còn.
        if (isFinishing) {
            DebugLog.log("Khe $slotIndex: MainActivity.onDestroy() — isFinishing=true, đóng hẳn khe, đóng tab")
            // engine.release() ở đây vẫn cần cho trường hợp người dùng thoát
            // khe theo cách THÔNG THƯỜNG (bấm Back, không qua
            // ProfilePickerActivity) — trường hợp gán lại hồ sơ thì
            // `gracefulCloseReceiver` (xem `onCreate()`) đã tự gọi
            // `engine.release()` + `GeckoRuntimeProvider.shutdown()` +
            // gửi ACK từ TRƯỚC khi gọi `finish()` rồi, nên gọi lại ở đây vô
            // hại (tabs đã rỗng sẵn, `forEach` không làm gì).
            engine.release()
        } else {
            DebugLog.log("Khe $slotIndex: MainActivity.onDestroy() — isFinishing=false (Android tự thu hồi Activity nền), GIỮ tab đang chạy")
        }
        // BUG THẬT ĐÃ SỬA (nguyên nhân THẬT SỰ của crash "Only one
        // GeckoRuntime instance is allowed" — 2 lượt crash log gửi lên đều
        // do CHÍNH XÁC dòng này, không phải race condition ở restartSlot()
        // như suy đoán trước): GeckoRuntime BẮT BUỘC phải sống suốt vòng đời
        // TIẾN TRÌNH (process) — đây là giới hạn cứng của Gecko, không phải
        // của app này: tạo được ĐÚNG 1 lần cho cả đời tiến trình, "release"
        // bao nhiêu lần cũng không cho phép tạo lại lần 2 trong CÙNG process.
        //
        // Dòng `GeckoRuntimeProvider.release(slotIndex)` trước đây gọi ở
        // ĐÂY — trong `onDestroy()` của Activity — nhưng `onDestroy()` KHÔNG
        // đồng nghĩa với "tiến trình sắp chết"! Android có thể huỷ Activity
        // (thu hồi bộ nhớ nền, xoay màn hình, v.v.) trong khi TIẾN TRÌNH vẫn
        // sống — mà `KeepAliveService` lại đang CỐ Ý giữ tiến trình sống
        // (đúng mục đích của service đó). Kết quả: `release()` chỉ xoá khỏi
        // map trong bộ nhớ (`runtimes.remove()`) — KHÔNG hề gọi
        // `runtime.shutdown()` — nên GeckoRuntime native cũ vẫn còn sống
        // nguyên trong tiến trình. Lần sau mở lại Khe này (vẫn CÙNG tiến
        // trình vì chưa từng chết), code tưởng map trống nên cố tạo runtime
        // MỚI → Gecko từ chối thẳng vì tiến trình đã "dùng" 1 lần rồi → crash
        // NGAY LẬP TỨC, không phải hiếm — gần như CHẮC CHẮN xảy ra mỗi lần
        // Android tự dọn Activity nền trong khi KeepAliveService còn giữ
        // tiến trình sống.
        //
        // Sửa: KHÔNG gọi `GeckoRuntimeProvider.release()` ở đây nữa.
        // GeckoRuntime cứ để sống trong map suốt đời tiến trình — mở lại
        // Activity (dù trong cùng tiến trình) sẽ tự tìm thấy runtime đã có
        // sẵn qua `getOrPut`, dùng lại đúng cách GeckoView được thiết kế để
        // dùng (tạo runtime 1 lần, dùng suốt đời process — giống Firefox
        // thật làm), không cần tạo lại.
        super.onDestroy()
    }

    override fun onBackPressed() {
        if (engine.canGoBack()) {
            engine.goBack()
        } else {
            super.onBackPressed()
        }
    }

}
