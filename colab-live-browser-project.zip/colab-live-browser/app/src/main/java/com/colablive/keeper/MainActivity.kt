package com.colablive.keeper

import android.Manifest
import android.content.ClipData
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.DragEvent
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.colablive.keeper.core.*
import com.colablive.keeper.features.colablive.ColabLiveKeeperFeature
import com.colablive.keeper.features.downloads.DownloadManagerFeature
import com.colablive.keeper.features.fingerprint.FingerprintSpoofFeature
import org.mozilla.geckoview.GeckoView
import java.net.URLEncoder

class MainActivity : AppCompatActivity() {

    private lateinit var geckoView: GeckoView
    private lateinit var engine: GeckoViewEngine
    private lateinit var urlBar: EditText
    private lateinit var tabBar: HorizontalScrollView
    private lateinit var tabContainer: LinearLayout
    private lateinit var progressBar: ProgressBar
    private lateinit var backButton: ImageButton
    private lateinit var forwardButton: ImageButton
    private lateinit var refreshButton: ImageButton
    private lateinit var menuButton: ImageButton
    private lateinit var newTabButton: ImageButton
    private lateinit var toolbarContainer: LinearLayout

    private val handler = Handler(Looper.getMainLooper())
    private var slotIndex = 0
    private val tabViews = mutableMapOf<String, View>()

    companion object {
        private const val RC_FILE_PICKER = 1001
        private const val RC_NOTIFICATIONS = 1002
        private const val PERMISSION_NOTIFICATIONS = Manifest.permission.POST_NOTIFICATIONS
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        slotIndex = intent.getIntExtra("slot_index", 0)
        ForegroundState.broadcastActiveSlot(this, slotIndex)

        setupUI()
        setupEngine()
        setupDragDrop()
        initServices()
        requestPermissions()
    }

    private fun initServices() {
        KeepAliveService.start(this)
        val downloadFeature = FeatureRegistry.all().filterIsInstance<DownloadManagerFeature>().firstOrNull()
    // REMOVED: downloadFeature?.// initEngine - removed(this)

        // Setup proxy cho slot này
        setupProxyForSlot()

        // Load trang mặc định
        val homeUrl = AppPrefs.getString(this, slotIndex, "home_url", "https://www.google.com")
        engine.createTab(homeUrl)
    }

    private fun setupProxyForSlot() {
        val proxyType = AppPrefs.getInt(this, slotIndex, "proxy_type", 0)
        if (proxyType > 0) {
            val host = AppPrefs.getString(this, slotIndex, "proxy_host", "")
            val port = AppPrefs.getString(this, slotIndex, "proxy_port", "").toIntOrNull() ?: 0
            val user = AppPrefs.getString(this, slotIndex, "proxy_user", "")
            val pass = AppPrefs.getString(this, slotIndex, "proxy_pass", "")

            if (host.isNotEmpty() && port > 0) {
                engine.setupProxy(host, port, user, pass)
                DebugLog.log("Slot $slotIndex proxy: $host:$port")
            }
        }
    }

    // ===== UI Setup =====

    private fun setupUI() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
        }

        // Toolbar container
        toolbarContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#F8F9FA"))
        }

        // Tab bar
        tabBar = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            val tabLayout = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(8, 8, 8, 8)
            }
            tabContainer = tabLayout
            addView(tabLayout, ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        toolbarContainer.addView(tabBar, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // URL + Navigation bar
        val navBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(16, 8, 16, 8)
            gravity = Gravity.CENTER_VERTICAL
        }

        backButton = ImageButton(this).apply {
            setImageResource(android.R.drawable.ic_media_previous)
            setBackgroundColor(Color.TRANSPARENT)
            setOnClickListener { engine.goBack() }
        }
        navBar.addView(backButton, ViewGroup.LayoutParams(48, 48))

        forwardButton = ImageButton(this).apply {
            setImageResource(android.R.drawable.ic_media_next)
            setBackgroundColor(Color.TRANSPARENT)
            setOnClickListener { engine.goForward() }
        }
        navBar.addView(forwardButton, ViewGroup.LayoutParams(48, 48))

        refreshButton = ImageButton(this).apply {
            setImageResource(android.R.drawable.ic_menu_rotate)
            setBackgroundColor(Color.TRANSPARENT)
            setOnClickListener { engine.reload() }
        }
        navBar.addView(refreshButton, ViewGroup.LayoutParams(48, 48))

        urlBar = EditText(this).apply {
            hint = "Nhập URL hoặc tìm kiếm..."
            setBackgroundResource(android.R.drawable.edit_text)
            setPadding(16, 12, 16, 12)
            setSingleLine(true)
            inputType = EditorInfo.TYPE_TEXT_VARIATION_URI
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_GO) {
                    navigateToUrl(text.toString())
                    true
                } else false
            }
        }
        navBar.addView(urlBar, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        newTabButton = ImageButton(this).apply {
            setImageResource(android.R.drawable.ic_input_add)
            setBackgroundColor(Color.TRANSPARENT)
            setOnClickListener {
                engine.createTab("https://www.google.com")
            }
        }
        navBar.addView(newTabButton, ViewGroup.LayoutParams(48, 48))

        menuButton = ImageButton(this).apply {
            setImageResource(android.R.drawable.ic_menu_more)
            setBackgroundColor(Color.TRANSPARENT)
            setOnClickListener { showMenu() }
        }
        navBar.addView(menuButton, ViewGroup.LayoutParams(48, 48))

        toolbarContainer.addView(navBar, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // Progress bar
        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            visibility = View.GONE
        }
        toolbarContainer.addView(progressBar, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 4))

        root.addView(toolbarContainer, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // GeckoView
        geckoView = GeckoView(this)
        root.addView(geckoView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        setContentView(root)
    }

    private fun setupEngine() {
        engine = GeckoViewEngine(this, geckoView, slotIndex)

        engine.onPageLoadedListener = { url ->
            urlBar.setText(url)
            updateNavButtons()
        }

        engine.onPageErrorListener = { url, code ->
            DebugLog.log("Page error: $url code=$code")
        }

        engine.onTitleChangedListener = { title ->
            updateTabTitle(title)
        }

        engine.onProgressChangedListener = { progress ->
            progressBar.progress = progress
            progressBar.visibility = if (progress in 1..99) View.VISIBLE else View.GONE
        }

        engine.onNewTabRequestedListener = { url ->
            engine.createTab(url)
        }

        engine.onDownloadRequestedListener = { url, fileName ->
            val downloadFeature = FeatureRegistry.all().filterIsInstance<com.colablive.keeper.features.downloads.DownloadManagerFeature>().firstOrNull()
    // REMOVED: downloadFeature?.// startDownloadWithPolicy - removed(this, url, fileName)
        }

        engine.onFilePromptListener = { mimeTypes ->
            showFilePicker(mimeTypes)
        }
    }

    private fun navigateToUrl(input: String) {
        val url = when {
            input.startsWith("http://") || input.startsWith("https://") -> input
            input.contains(".") && !input.contains(" ") -> "https://$input"
            else -> "https://www.google.com/search?q=${URLEncoder.encode(input, "UTF-8")}"
        }
        engine.loadUrl(url)
    }

    private fun updateNavButtons() {
        backButton.isEnabled = engine.canGoBack()
        backButton.alpha = if (engine.canGoBack()) 1f else 0.3f
        forwardButton.isEnabled = engine.canGoForward()
        forwardButton.alpha = if (engine.canGoForward()) 1f else 0.3f
    }

    private fun updateTabTitle(title: String) {
        val activeTab = engine.getActiveTab() ?: return
        val view = tabViews[activeTab.id]
        (view as? TextView)?.text = title.take(20)
    }

    private fun showMenu() {
        val items = arrayOf("Settings", "Features", "Debug Log", "Chuyển Khe", "Proxy Config", "Test Cookie Leak", "IDM Downloads", "Sniff Media", "💾 Lưu Trang Web", "⚙️ Cài đặt Download")
        AlertDialog.Builder(this)
            .setTitle("Menu (Slot $slotIndex)")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> startActivity(Intent(this, SettingsActivity::class.java).putExtra("slot_index", slotIndex))
                    1 -> startActivity(Intent(this, FeatureSettingsActivity::class.java).putExtra("slot_index", slotIndex))
                    2 -> startActivity(Intent(this, DebugLogActivity::class.java))
                    3 -> startActivity(Intent(this, ProfilePickerActivity::class.java))
                    4 -> showProxyDialog()
    // REMOVED: 5 -> // showLeakTestDialog - removed()
    // REMOVED: 6 -> // showIDMDialog - removed()
                    7 -> showSniffDialog()
    // REMOVED: 8 -> // showWebArchiveDialog - removed()
    // REMOVED: 9 -> // showDownloadPolicySettings - removed()
                }
            }
            .show()
    }

    private fun showProxyDialog() {
        val proxyType = AppPrefs.getInt(this, slotIndex, "proxy_type", 0)
        val host = AppPrefs.getString(this, slotIndex, "proxy_host", "")
        val port = AppPrefs.getString(this, slotIndex, "proxy_port", "")
        val user = AppPrefs.getString(this, slotIndex, "proxy_user", "")

        val msg = """
            Proxy Type: ${if (proxyType == 0) "Direct" else if (proxyType == 1) "HTTP" else "SOCKS5"}
            Host: $host
            Port: $port
            User: $user

            Vào Settings > Fingerprint Spoof để thay đổi.
        """.trimIndent()

        AlertDialog.Builder(this)
            .setTitle("Proxy Config (Slot $slotIndex)")
            .setMessage(msg)
            .setPositiveButton("OK", null)
            .show()
    }

    // REMOVED: private fun // showLeakTestDialog - removed() {
        val downloadFeature = FeatureRegistry.all().filterIsInstance<com.colablive.keeper.features.downloads.DownloadManagerFeature>().firstOrNull()
    // REMOVED: downloadFeature?.// showLeakTestDialog - removed(this, slotIndex, engine)
    }

    // REMOVED: private fun // showIDMDialog - removed() {
        val downloadFeature = FeatureRegistry.all().filterIsInstance<com.colablive.keeper.features.downloads.DownloadManagerFeature>().firstOrNull()
    // REMOVED: downloadFeature?.// showIDMDialog - removed(this)
    }

    private fun showSniffDialog() {
        val downloadFeature = FeatureRegistry.all().filterIsInstance<com.colablive.keeper.features.downloads.DownloadManagerFeature>().firstOrNull()
        // Lấy HTML từ trang hiện tại
        engine.evaluateJs("document.documentElement.outerHTML") { html ->
            html?.let {
    // REMOVED: val links = downloadFeature?.// sniffPage - removed(this, it, engine.currentUrl() ?: "")
                links?.let { list ->
                    runOnUiThread {
    // REMOVED: downloadFeature.// showSniffedLinksDialog - removed(this, list)
                    }

    // REMOVED: private fun // showWebArchiveDialog - removed() {
        val currentUrl = engine.currentUrl() ?: return
        val currentTitle = engine.getActiveTab()?.title ?: "page"
        val downloadFeature = FeatureRegistry.all().filterIsInstance<com.colablive.keeper.features.downloads.DownloadManagerFeature>().firstOrNull()
    // REMOVED: downloadFeature?.// showWebArchiveDialog - removed(this, currentUrl, currentTitle, geckoView)
    }

    // REMOVED: private fun // showDownloadPolicySettings - removed() {
        val downloadFeature = FeatureRegistry.all().filterIsInstance<com.colablive.keeper.features.downloads.DownloadManagerFeature>().firstOrNull()
        downloadFeature?.showPolicySettings(this)
    }


                }
            }
        }
    }



    private fun showDownloadDialog(url: String, fileName: String) {
        AlertDialog.Builder(this)
            .setTitle("Tải xuống")
            .setMessage("$fileName\n$url")
            .setPositiveButton("Tải") { _, _ ->
                val downloadFeature = FeatureRegistry.all().filterIsInstance<DownloadManagerFeature>().firstOrNull()
                downloadFeature?.startDownload(this, url, fileName)
            }
            .setNegativeButton("Hủy", null)
            .show()
    }

    private fun showFilePicker(mimeTypes: Array<String>?) {
        val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
            type = mimeTypes?.firstOrNull() ?: "*/*"
            addCategory(Intent.CATEGORY_OPENABLE)
        }
        startActivityForResult(Intent.createChooser(intent, "Chọn file"), RC_FILE_PICKER)
    }

    private fun setupDragDrop() {
        geckoView.setOnDragListener { _, event ->
            when (event.action) {
                DragEvent.ACTION_DROP -> {
                    val clipData: ClipData? = event.clipData
                    if (clipData != null) {
                        for (i in 0 until clipData.itemCount) {
                            val item = clipData.getItemAt(i)
                            item.uri?.let { uri ->
                                engine.handleDropUri(uri, null)
                            }
                        }
                    }
                    true
                }
                else -> true
            }
        }
    }

    private fun requestPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, PERMISSION_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, arrayOf(PERMISSION_NOTIFICATIONS), RC_NOTIFICATIONS)
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == RC_FILE_PICKER && resultCode == RESULT_OK) {
            data?.data?.let { uri ->
                engine.handleDropUri(uri, null)
            }
        }
    }

    override fun onDestroy() {
        engine.release()
        GeckoRuntimeProvider.release(slotIndex)
        super.onDestroy()
    }

    override fun onBackPressed() {
        if (engine.canGoBack()) {
            engine.goBack()
        } else {
            super.onBackPressed()
        }
    }
}
