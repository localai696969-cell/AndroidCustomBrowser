package com.colablive.keeper

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import com.colablive.keeper.core.FeatureRegistry
import com.colablive.keeper.core.ForegroundState
import com.colablive.keeper.core.GeckoRuntimeProvider
import com.colablive.keeper.core.GeckoViewEngine
import com.colablive.keeper.core.ProfileSlots
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.GeckoView

/**
 * ĐÃ CHUYỂN sang GeckoView (trước đây dùng android.webkit.WebView) — bước
 * đầu tiên để có thể load addon WebExtension thật sau này. Theo đúng yêu cầu
 * ưu tiên: chỉ tập trung cho ColabLiveKeeperFeature chạy được trên engine
 * mới trước; setDownloadListener kiểu WebView (bắt link tải file tự động)
 * CHƯA có tương đương GeckoView được nối ở bước này — DownloadManagerFeature
 * vẫn quét được thẻ <video> qua evaluateJs (đã hoạt động), chỉ phần bắt
 * download tự động là tạm chưa hoạt động, sẽ nối lại ở bước sau.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var geckoView: GeckoView
    private lateinit var session: GeckoSession
    private lateinit var engine: GeckoViewEngine
    private val handler = Handler(Looper.getMainLooper())
    private val defaultUrl = "https://www.google.com/"

    private var mySlotIndex: Int = 0
    private lateinit var urlBar: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mySlotIndex = ProfileSlots.currentProcessSlotIndex(this)

        window.addFlags(
            WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
        )

        val runtime = GeckoRuntimeProvider.get(this)
        session = GeckoSession()
        session.open(runtime)

        geckoView = GeckoView(this).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }
        geckoView.setSession(session)

        engine = GeckoViewEngine(geckoView, session) { url ->
            handler.post { onUrlChanged(url) }
        }

        urlBar = EditText(this).apply {
            inputType = InputType.TYPE_TEXT_VARIATION_URI
            setText(defaultUrl)
        }
        val goButton = Button(this).apply {
            text = "Đi"
            setOnClickListener {
                var url = urlBar.text.toString().trim()
                if (!url.startsWith("http")) url = "https://$url"
                engine.loadUrl(url)
            }
        }
        val settingsButton = Button(this).apply {
            text = "⚙ Tiện ích"
            setOnClickListener {
                startActivity(
                    Intent(this@MainActivity, SettingsActivity::class.java)
                        .putExtra("slot_index", mySlotIndex)
                )
            }
        }
        val profileButton = Button(this).apply {
            text = "👤 Trình duyệt con"
            setOnClickListener {
                startActivity(Intent(this@MainActivity, ProfilePickerActivity::class.java))
            }
        }

        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(urlBar, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(goButton)
            addView(settingsButton)
            addView(profileButton)
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.TOP
            addView(topBar)
            addView(geckoView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0))
            (geckoView.layoutParams as LinearLayout.LayoutParams).weight = 1f
        }
        setContentView(root)

        val startUrl = intent.getStringExtra("start_url") ?: defaultUrl
        engine.loadUrl(startUrl)

        startForegroundService(Intent(this, KeepAliveService::class.java))
        handler.post(featureTickRunnable)
    }

    private fun onUrlChanged(url: String?) {
        urlBar.setText(url)
        broadcastForegroundState(url)
        for (feature in FeatureRegistry.enabledFeatures(this, mySlotIndex)) {
            if (feature.matchesUrl(url)) {
                feature.onPageFinished(this, mySlotIndex, engine, url)
            }
        }
    }

    private val featureTickRunnable = object : Runnable {
        override fun run() {
            val url = engine.currentUrl()
            for (feature in FeatureRegistry.enabledFeatures(this@MainActivity, mySlotIndex)) {
                if (feature.matchesUrl(url)) {
                    feature.onTick(this@MainActivity, mySlotIndex, engine, url)
                }
            }
            handler.postDelayed(this, 60_000L)
        }
    }

    override fun onResume() {
        super.onResume()
        if (::engine.isInitialized) broadcastForegroundState(engine.currentUrl())
    }

    private fun broadcastForegroundState(url: String?) {
        sendBroadcast(
            Intent(ForegroundState.ACTION_UPDATED).apply {
                setPackage(packageName)
                putExtra(ForegroundState.EXTRA_URL, url)
                putExtra(ForegroundState.EXTRA_SLOT_INDEX, mySlotIndex)
            }
        )
    }

    override fun onDestroy() {
        handler.removeCallbacks(featureTickRunnable)
        super.onDestroy()
    }
}
