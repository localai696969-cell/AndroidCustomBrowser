package com.colablive.keeper

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.colablive.keeper.core.FeatureRegistry
import com.colablive.keeper.core.ForegroundState
import com.colablive.keeper.core.GeckoRuntimeProvider
import com.colablive.keeper.core.GeckoViewEngine
import com.colablive.keeper.core.ProfileSlots
import org.mozilla.geckoview.GeckoResult
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.GeckoSessionSettings
import org.mozilla.geckoview.GeckoView
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var geckoView: GeckoView
    private lateinit var session: GeckoSession
    private lateinit var engine: GeckoViewEngine
    private val handler = Handler(Looper.getMainLooper())
    private val defaultUrl = "https://www.google.com/"

    private var mySlotIndex: Int = 0
    private lateinit var urlBar: EditText
    private lateinit var backButton: ImageButton
    private lateinit var forwardButton: ImageButton

    // File upload: GeckoView bắt buộc trả PromptResponse qua GeckoResult,
    // nhưng việc chọn file (system picker) là async — nên phải giữ lại cả
    // prompt lẫn GeckoResult để hoàn tất SAU KHI onActivityResult trả về.
    private var pendingFilePrompt: GeckoSession.PromptDelegate.FilePrompt? = null
    private var pendingFilePromptResult: GeckoResult<GeckoSession.PromptDelegate.PromptResponse>? = null
    private val FILE_PICK_REQUEST_CODE = 4242

    // Theo dõi trạng thái để nút Back của Android lùi trong lịch sử trang web
    // trước, chỉ thoát app khi không còn trang nào để lùi nữa (giống Chrome).
    // Trước đây KHÔNG có override này — Back hệ thống đóng thẳng app luôn,
    // mất trang đang xem.
    private var canGoBackState: Boolean = false

    override fun onBackPressed() {
        if (canGoBackState) {
            engine.goBack()
        } else {
            super.onBackPressed()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mySlotIndex = ProfileSlots.currentProcessSlotIndex(this)

        // Trước đây khai báo quyền này trong Manifest nhưng CHƯA xin runtime —
        // trên Android 13+ (API 33+), POST_NOTIFICATIONS là quyền nguy hiểm,
        // bắt buộc phải xin lúc chạy mới hiện hộp thoại, khai Manifest thôi
        // không đủ. Đây là lý do trước giờ bạn không thấy app hỏi gì cả.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1001)
            }
        }

        window.addFlags(
            WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
        )

        val runtime = GeckoRuntimeProvider.get(this, mySlotIndex)
        session = GeckoSession()
        session.open(runtime)

        session.promptDelegate = object : GeckoSession.PromptDelegate {
            override fun onFilePrompt(
                session: GeckoSession,
                prompt: GeckoSession.PromptDelegate.FilePrompt
            ): GeckoResult<GeckoSession.PromptDelegate.PromptResponse> {
                // Cách "chứng minh" dễ nhất: nếu bấm "Duyệt qua" mà KHÔNG thấy
                // Toast này hiện ra, nghĩa là onFilePrompt không được gọi —
                // vấn đề nằm ở việc trang không kích hoạt được file input,
                // không phải lỗi ở phần code xử lý phía sau (Intent/copy file).
                Toast.makeText(this@MainActivity, "onFilePrompt được gọi — đang mở picker...", Toast.LENGTH_SHORT).show()
                pendingFilePrompt = prompt
                val result = GeckoResult<GeckoSession.PromptDelegate.PromptResponse>()
                pendingFilePromptResult = result

                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    type = prompt.mimeTypes?.firstOrNull()?.takeIf { it.isNotBlank() } ?: "*/*"
                    addCategory(Intent.CATEGORY_OPENABLE)
                    if (prompt.type == GeckoSession.PromptDelegate.FilePrompt.Type.MULTIPLE) {
                        putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                    }
                }
                runCatching {
                    startActivityForResult(intent, FILE_PICK_REQUEST_CODE)
                }.onFailure {
                    result.complete(prompt.dismiss())
                    pendingFilePrompt = null
                    pendingFilePromptResult = null
                }
                return result
            }
        }

        geckoView = GeckoView(this).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }
        geckoView.setSession(session)

        engine = GeckoViewEngine(
            geckoView = geckoView,
            session = session,
            onLocationChanged = { url -> handler.post { onUrlChanged(url) } },
            onCanGoBackChanged = { canGoBack -> handler.post {
                backButton.isEnabled = canGoBack
                canGoBackState = canGoBack
            } },
            onCanGoForwardChanged = { canGoForward -> handler.post { forwardButton.isEnabled = canGoForward } },
            onLoadError = { message -> handler.post { Toast.makeText(this, message, Toast.LENGTH_LONG).show() } },
            onPopupRequested = { uri -> handler.post {
                Toast.makeText(this, "Đang mở: $uri", Toast.LENGTH_SHORT).show()
                engine.loadUrl(uri)
            } },
            onNavigationAttempt = { info -> handler.post {
                Toast.makeText(this, info, Toast.LENGTH_SHORT).show()
            } }
        )

        val density = resources.displayMetrics.density
        fun dp(v: Int) = (v * density).toInt()

        urlBar = EditText(this).apply {
            inputType = InputType.TYPE_TEXT_VARIATION_URI
            imeOptions = EditorInfo.IME_ACTION_GO
            setText(defaultUrl)
            setBackgroundResource(R.drawable.rounded_search_bg)
            setPadding(dp(16), dp(8), dp(16), dp(8))
            setSingleLine(true)
            textSize = 15f
        }
        backButton = ImageButton(this).apply {
            setImageResource(R.drawable.ic_arrow_back)
            background = null
            isEnabled = false
            contentDescription = "Quay lại"
            setOnClickListener { engine.goBack() }
        }
        forwardButton = ImageButton(this).apply {
            setImageResource(R.drawable.ic_arrow_forward)
            background = null
            isEnabled = false
            contentDescription = "Tiến tới"
            setOnClickListener { engine.goForward() }
        }
        val reloadButton = ImageButton(this).apply {
            setImageResource(R.drawable.ic_refresh)
            background = null
            contentDescription = "Tải lại"
            setOnClickListener { engine.loadUrl(engine.currentUrl() ?: defaultUrl) }
        }
        val menuButton = ImageButton(this).apply {
            setImageResource(R.drawable.ic_more_vert)
            background = null
            contentDescription = "Menu"
            setOnClickListener { view -> showOverflowMenu(view) }
        }

        val iconSize = dp(48)
        val iconLayoutParams = LinearLayout.LayoutParams(iconSize, iconSize)

        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), dp(6), dp(4), dp(6))
            setBackgroundColor(Color.WHITE)
            elevation = dp(4).toFloat()
            addView(backButton, iconLayoutParams)
            addView(forwardButton, iconLayoutParams)
            addView(reloadButton, iconLayoutParams)
            addView(
                urlBar,
                LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                    marginStart = dp(4)
                    marginEnd = dp(4)
                }
            )
            addView(menuButton, iconLayoutParams)
        }

        urlBar.setOnEditorActionListener { _, _, _ ->
            submitUrlFromBar()
            true
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.TOP
            addView(topBar)
            addView(geckoView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0))
            (geckoView.layoutParams as LinearLayout.LayoutParams).weight = 1f
        }
        setContentView(root)

        val startUrl = intent.getStringExtra("start_url") ?: defaultUrl
        engine.loadUrl(startUrl)

        startForegroundService(Intent(this, KeepAliveService::class.java))
        handler.post(featureTickRunnable)
    }

    private fun submitUrlFromBar() {
        var url = urlBar.text.toString().trim()
        if (url.isEmpty()) return
        if (!url.startsWith("http://") && !url.startsWith("https://")) {
            url = "https://$url"
        }
        engine.loadUrl(url)
    }

    private fun showOverflowMenu(anchor: View) {
        PopupMenu(this, anchor).apply {
            menu.add("Tiện ích")
            menu.add("Trình duyệt con")
            menu.add(if (desktopModeEnabled) "Tắt chế độ máy tính" else "Chế độ máy tính")
            setOnMenuItemClickListener { item ->
                when (item.title) {
                    "Tiện ích" -> startActivity(
                        Intent(this@MainActivity, SettingsActivity::class.java)
                            .putExtra("slot_index", mySlotIndex)
                    )
                    "Trình duyệt con" -> startActivity(
                        Intent(this@MainActivity, ProfilePickerActivity::class.java)
                    )
                    "Chế độ máy tính", "Tắt chế độ máy tính" -> toggleDesktopMode()
                }
                true
            }
            show()
        }
    }

    // Desktop mode: giả User-Agent + viewport như máy tính để trang web trả
    // về giao diện desktop. LƯU Ý quan trọng: đây CHỈ đổi User-Agent string +
    // cách tính layout viewport — KHÔNG giả các dấu vân tay phần cứng khác
    // (WebGL renderer, hardwareConcurrency, deviceMemory, canvas fingerprint...).
    // Việc giả toàn bộ dấu vân tay phần cứng là 1 tính năng chống fingerprinting
    // quy mô lớn hơn nhiều (kiểu Tor Browser/Brave làm), không nằm trong phạm
    // vi đợt này — nếu bạn cần cụ thể để né phát hiện gì, nói rõ mục đích để
    // biết cần giả tới mức nào.
    private var desktopModeEnabled = false

    private fun toggleDesktopMode() {
        desktopModeEnabled = !desktopModeEnabled
        if (desktopModeEnabled) {
            session.settings.userAgentMode = GeckoSessionSettings.USER_AGENT_MODE_DESKTOP
            session.settings.viewportMode = GeckoSessionSettings.VIEWPORT_MODE_DESKTOP
        } else {
            session.settings.userAgentMode = GeckoSessionSettings.USER_AGENT_MODE_MOBILE
            session.settings.viewportMode = GeckoSessionSettings.VIEWPORT_MODE_MOBILE
        }
        engine.loadUrl(engine.currentUrl() ?: defaultUrl)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != FILE_PICK_REQUEST_CODE) return

        val prompt = pendingFilePrompt
        val result = pendingFilePromptResult
        pendingFilePrompt = null
        pendingFilePromptResult = null
        if (prompt == null || result == null) return

        val pickedUri = data?.data
        if (resultCode != RESULT_OK || pickedUri == null) {
            result.complete(prompt.dismiss())
            return
        }

        // GIỚI HẠN CÓ THẬT của GeckoView (đã xác nhận qua báo cáo lỗi công
        // khai của Mozilla): FilePrompt.confirm() chỉ chấp nhận URI dạng
        // "file://", KHÔNG chấp nhận "content://" mà Android trả về từ Google
        // Photos/Drive/Downloads qua Storage Access Framework. Cách né: tự
        // copy nội dung file vào bộ nhớ riêng của app, tạo URI file:// thật từ
        // bản copy đó rồi mới xác nhận prompt.
        val fileUri = copyToAppCacheAsFileUri(pickedUri)
        if (fileUri == null) {
            Toast.makeText(this, "Không đọc được file đã chọn", Toast.LENGTH_SHORT).show()
            result.complete(prompt.dismiss())
            return
        }
        result.complete(prompt.confirm(this, fileUri))
    }

    private fun copyToAppCacheAsFileUri(sourceUri: Uri): Uri? {
        return try {
            contentResolver.openInputStream(sourceUri)?.use { input ->
                val outFile = File(cacheDir, "upload_${System.currentTimeMillis()}")
                outFile.outputStream().use { output -> input.copyTo(output) }
                Uri.fromFile(outFile)
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun onUrlChanged(url: String?) {
        urlBar.setText(url)
        broadcastForegroundState(url)
        for (feature in FeatureRegistry.enabledFeatures(this, mySlotIndex)) {
            if (feature.matchesUrl(url)) {
                feature.onPageFinished(this, mySlotIndex, engine, url)
            }
        }
    }

    private val featureTickRunnable = object : Runnable {
        override fun run() {
            val url = engine.currentUrl()
            for (feature in FeatureRegistry.enabledFeatures(this@MainActivity, mySlotIndex)) {
                if (feature.matchesUrl(url)) {
                    feature.onTick(this@MainActivity, mySlotIndex, engine, url)
                }
            }
            handler.postDelayed(this, 60_000L)
        }
    }

    override fun onResume() {
        super.onResume()
        if (::engine.isInitialized) broadcastForegroundState(engine.currentUrl())
    }

    private fun broadcastForegroundState(url: String?) {
        sendBroadcast(
            Intent(ForegroundState.ACTION_UPDATED).apply {
                setPackage(packageName)
                putExtra(ForegroundState.EXTRA_URL, url)
                putExtra(ForegroundState.EXTRA_SLOT_INDEX, mySlotIndex)
            }
        )
    }

    override fun onDestroy() {
        handler.removeCallbacks(featureTickRunnable)
        super.onDestroy()
    }
}
