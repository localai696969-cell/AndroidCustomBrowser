package com.colablive.keeper

import android.Manifest
import android.content.ClipData
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.DragEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.colablive.keeper.core.*
import com.colablive.keeper.features.colablive.ColabLiveKeeperFeature
import com.colablive.keeper.features.downloads.DownloadManagerFeature
import com.colablive.keeper.features.fingerprint.FingerprintSpoofFeature
import org.mozilla.geckoview.GeckoView
import java.net.URLEncoder

class MainActivity : AppCompatActivity() {

    private lateinit var geckoView: GeckoView
    private lateinit var engine: GeckoViewEngine
    private lateinit var urlBar: EditText
    private lateinit var tabBar: HorizontalScrollView
    private lateinit var tabContainer: LinearLayout
    private lateinit var progressBar: ProgressBar
    private lateinit var backButton: ImageButton
    private lateinit var forwardButton: ImageButton
    private lateinit var refreshButton: ImageButton
    private lateinit var menuButton: ImageButton
    private lateinit var newTabButton: ImageButton

    private val handler = Handler(Looper.getMainLooper())
    private var slotIndex = 0
    private val tabViews = mutableMapOf<String, View>()

    companion object {
        private const val RC_NOTIFICATIONS = 1002
        private const val PERMISSION_NOTIFICATIONS = Manifest.permission.POST_NOTIFICATIONS
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        slotIndex = intent.getIntExtra("slot_index", 0)
        ForegroundState.broadcastActiveSlot(this, slotIndex)

        setupUI()
        setupEngine()
        setupDragDrop()
        initServices()
        requestPermissions()
    }

    private fun initServices() {
        KeepAliveService.start(this)
        setupProxyForSlot()
        val homeUrl = AppPrefs.getString(this, slotIndex, "home_url", "https://www.google.com")
        engine.createTab(homeUrl)
    }

    private fun setupProxyForSlot() {
        val proxyType = AppPrefs.getInt(this, slotIndex, "proxy_type", 0)
        if (proxyType == 1) {
            val host = AppPrefs.getString(this, slotIndex, "proxy_host", "")
            val port = AppPrefs.getInt(this, slotIndex, "proxy_port", 0)
            if (host.isNotEmpty() && port > 0) {
                engine.setupProxy(host, port)
            }
        }
    }

    private fun setupUI() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
        }

        val toolbarContainer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(8, 8, 8, 8)
            setBackgroundColor(Color.parseColor("#F5F5F5"))
        }

        backButton = ImageButton(this).apply {
            setImageResource(R.drawable.ic_arrow_back)
            setBackgroundResource(android.R.drawable.btn_default_small)
            setOnClickListener { engine.goBack(); updateButtons() }
        }

        forwardButton = ImageButton(this).apply {
            setImageResource(R.drawable.ic_arrow_forward)
            setBackgroundResource(android.R.drawable.btn_default_small)
            setOnClickListener { engine.goForward(); updateButtons() }
        }

        refreshButton = ImageButton(this).apply {
            setImageResource(R.drawable.ic_refresh)
            setBackgroundResource(android.R.drawable.btn_default_small)
            setOnClickListener { engine.reload() }
        }

        urlBar = EditText(this).apply {
            hint = "Nhập URL..."
            setBackgroundResource(R.drawable.rounded_search_bg)
            setPadding(16, 12, 16, 12)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            imeOptions = EditorInfo.IME_ACTION_GO
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_GO) {
                    loadUrlFromBar()
                    true
                } else false
            }
        }

        menuButton = ImageButton(this).apply {
            setImageResource(R.drawable.ic_more_vert)
            setBackgroundResource(android.R.drawable.btn_default_small)
            setOnClickListener { showMenu() }
        }

        toolbarContainer.addView(backButton)
        toolbarContainer.addView(forwardButton)
        toolbarContainer.addView(refreshButton)
        toolbarContainer.addView(urlBar)
        toolbarContainer.addView(menuButton)

        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 4)
            visibility = View.GONE
        }

        tabContainer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(8, 4, 8, 4)
        }
        tabBar = HorizontalScrollView(this).apply {
            addView(tabContainer)
            setBackgroundColor(Color.parseColor("#EEEEEE"))
        }

        newTabButton = ImageButton(this).apply {
            setImageResource(android.R.drawable.ic_input_add)
            setBackgroundResource(android.R.drawable.btn_default_small)
            setOnClickListener {
                val url = urlBar.text.toString().ifEmpty { "https://www.google.com" }
                engine.createTab(url)
            }
        }
        tabContainer.addView(newTabButton)

        geckoView = GeckoView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }

        root.addView(toolbarContainer)
        root.addView(progressBar)
        root.addView(tabBar)
        root.addView(geckoView)

        setContentView(root)
    }

    private fun setupEngine() {
        engine = GeckoViewEngine(this, geckoView, slotIndex)

        engine.onPageLoadedListener = { url ->
            runOnUiThread {
                urlBar.setText(url)
                updateButtons()
                notifyFeaturesPageLoaded(url)
            }
        }

        engine.onPageErrorListener = { url, code ->
            DebugLog.log("Page error: $url code=$code")
        }

        engine.onTitleChangedListener = { title ->
            updateTabTitle(engine.getActiveTab()?.id ?: "", title)
        }

        engine.onProgressChangedListener = { progress ->
            runOnUiThread {
                progressBar.progress = progress
                progressBar.visibility = if (progress in 1..99) View.VISIBLE else View.GONE
            }
        }

        engine.onNewTabRequestedListener = { url ->
            runOnUiThread { engine.createTab(url) }
        }

        engine.onDownloadRequestedListener = { url, fileName ->
            runOnUiThread { handleDownload(url, fileName) }
        }
    }

    private fun setupDragDrop() {
        geckoView.setOnDragListener { _, event ->
            when (event.action) {
                DragEvent.ACTION_DROP -> {
                    val clipData: ClipData? = event.clipData
                    if (clipData != null) {
                        for (i in 0 until clipData.itemCount) {
                            val item = clipData.getItemAt(i)
                            item.uri?.let { uri ->
                                engine.handleDropUri(uri, null)
                            }
                        }
                    }
                    true
                }
                else -> true
            }
        }
    }

    private fun loadUrlFromBar() {
        val input = urlBar.text.toString().trim()
        if (input.isEmpty()) return
        val url = when {
            input.startsWith("http://") || input.startsWith("https://") -> input
            input.contains(".") -> "https://$input"
            else -> "https://www.google.com/search?q=${URLEncoder.encode(input, "UTF-8")}"
        }
        engine.loadUrl(url)
    }

    private fun updateButtons() {
        backButton.isEnabled = engine.canGoBack()
        backButton.alpha = if (backButton.isEnabled) 1.0f else 0.5f
        forwardButton.isEnabled = engine.canGoForward()
        forwardButton.alpha = if (forwardButton.isEnabled) 1.0f else 0.5f
    }

    private fun updateTabTitle(tabId: String, title: String) {
        tabViews[tabId]?.findViewById<TextView>(android.R.id.text1)?.text = title
    }

    private fun addTabView(tab: BrowserTab) {
        val tabView = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(12, 8, 12, 8)
            setBackgroundResource(android.R.drawable.btn_default_small)
            setOnClickListener { engine.switchToTab(tab.id) }

            addView(TextView(this@MainActivity).apply {
                id = android.R.id.text1
                text = tab.url.substringAfterLast("/").take(20)
                maxLines = 1
            })

            addView(ImageButton(this@MainActivity).apply {
                setImageResource(android.R.drawable.ic_delete)
                setBackgroundResource(android.R.drawable.btn_default_small)
                setOnClickListener {
                    engine.closeTab(tab.id)
                    tabViews.remove(tab.id)?.let { tabContainer.removeView(it) }
                }
            })
        }
        tabViews[tab.id] = tabView
        tabContainer.addView(tabView, tabContainer.childCount - 1)
    }

    private fun notifyFeaturesPageLoaded(url: String) {
        FeatureRegistry.enabledFeatures(this, slotIndex).forEach { feature ->
            feature.onPageLoaded(this, slotIndex, url)
        }
    }

    private fun handleDownload(url: String, fileName: String) {
        val downloadFeature = FeatureRegistry.all()
            .filterIsInstance<DownloadManagerFeature>()
            .firstOrNull()
        downloadFeature?.catchDownload(this, url, fileName)
    }

    private fun showMenu() {
        val items = arrayOf(
            "📑 Chọn Khe (Profile)",
            "⚙️ Cài đặt",
            "🔧 Tính năng",
            "📋 Debug Log",
            "🔄 Đổi User Agent"
        )
        AlertDialog.Builder(this)
            .setTitle("Menu")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> startActivity(Intent(this, ProfilePickerActivity::class.java))
                    1 -> startActivity(Intent(this, SettingsActivity::class.java))
                    2 -> startActivity(Intent(this, FeatureSettingsActivity::class.java))
                    3 -> startActivity(Intent(this, DebugLogActivity::class.java))
                    4 -> showUserAgentDialog()
                }
            }
            .show()
    }

    private fun showUserAgentDialog() {
        val uas = arrayOf(
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.0",
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.0",
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.0"
        )
        AlertDialog.Builder(this)
            .setTitle("User Agent")
            .setItems(uas) { _, which ->
                // Apply UA
            }
            .show()
    }

    private fun requestPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, PERMISSION_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, arrayOf(PERMISSION_NOTIFICATIONS), RC_NOTIFICATIONS)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        ForegroundState.broadcastActiveSlot(this, slotIndex)
    }

    override fun onDestroy() {
        super.onDestroy()
        engine.release()
    }
}
