package com.colablive.keeper

import android.app.Dialog

import android.Manifest
import android.content.ClipData
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.DragEvent
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.colablive.keeper.core.*
import com.colablive.keeper.features.colablive.ColabLiveKeeperFeature
import java.io.File
import com.colablive.keeper.features.downloads.DownloadManagerFeature
import com.colablive.keeper.features.fingerprint.FingerprintSpoofFeature
import org.mozilla.geckoview.GeckoView
import java.net.URLEncoder

open class MainActivity : AppCompatActivity() {

    private lateinit var geckoView: GeckoView
    private lateinit var engine: GeckoViewEngine
    private lateinit var urlBar: EditText
    private lateinit var tabBar: HorizontalScrollView
    private lateinit var tabContainer: LinearLayout
    private lateinit var progressBar: ProgressBar
    private lateinit var backButton: ImageButton
    private lateinit var forwardButton: ImageButton
    private lateinit var refreshButton: ImageButton
    private lateinit var menuButton: ImageButton
    private lateinit var newTabButton: ImageButton
    private lateinit var tabSwitcherButton: TextView
    private lateinit var toolbarContainer: LinearLayout

    private val handler = Handler(Looper.getMainLooper())
    private var slotIndex = 0
    private val tabViews = mutableMapOf<String, View>()
    private var gracefulCloseReceiver: android.content.BroadcastReceiver? = null

    companion object {
        private const val RC_FILE_PICKER = 1001
        private const val RC_NOTIFICATIONS = 1002
        private const val RC_HISTORY = 1003
        private const val PERMISSION_NOTIFICATIONS = Manifest.permission.POST_NOTIFICATIONS
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // QUAN TRỌNG: launcher (bấm icon màn hình chính) KHÔNG gửi kèm extra
        // tuỳ ý — "slot_index" chỉ có khi CHÍNH APP tự mở 1 khe khác. Bấm
        // thẳng icon "Khe 1/2/3" (activity-alias, chạy process ":slot1/2/3"
        // riêng) sẽ không có extra này — nếu chỉ dựa extra, mọi khe sẽ luôn
        // nghĩ mình là khe 0, khiến 2 tiến trình khác nhau cùng cố mở CHUNG 1
        // thư mục hồ sơ Gecko (`gecko_profile_slot_0`) cùng lúc — Gecko có
        // khoá hồ sơ, việc này có thể khiến GeckoRuntime khởi tạo lỗi/crash ở
        // tiến trình mở sau. Nguồn đáng tin cậy thật là TÊN TIẾN TRÌNH đang chạy.
        slotIndex = if (intent.hasExtra("slot_index")) {
            intent.getIntExtra("slot_index", 0)
        } else {
            ProfileSlots.getCurrentSlotIndex(this)
        }
        ForegroundState.broadcastActiveSlot(this, slotIndex)

        /**
         * BUG CỰC KỲ NGHIÊM TRỌNG — lần sửa TRƯỚC (chỉ `engine.release()` +
         * đợi ack) người dùng test lại VẪN mất dữ liệu. Nghĩ lại kỹ hơn:
         * `engine.release()` chỉ đóng CÁC TAB (`GeckoSession.close()`) — đây
         * KHÔNG đồng nghĩa với việc Gecko đã ghi xong cookie/phiên đăng nhập
         * xuống đĩa! Kho lưu cookie trong Gecko chạy như 1 dịch vụ RIÊNG,
         * độc lập với việc đóng tab — đóng tab không tự động ép dịch vụ đó
         * flush ngay. Cách THẬT SỰ đảm bảo Gecko ghi hết dữ liệu là tắt hẳn
         * `GeckoRuntime` (`runtime.shutdown()`) — đây mới đúng là điểm Gecko
         * dọn dẹp/flush toàn bộ trước khi thoát.
         *
         * Trước đây KHÔNG dám gọi `shutdown()` vì sợ lặp lại đúng bug đã sửa
         * ở mục 8g (gọi `release()`/quên khỏi map mà KHÔNG shutdown khiến
         * tạo runtime lần 2 trong process còn sống bị Gecko từ chối). Nhưng
         * ở ĐÂY khác: broadcast này CHỈ được gửi từ đúng 1 chỗ duy nhất —
         * `ProfilePickerActivity.restartSlot()` — và ngay sau khi nhận được,
         * process này CHẮC CHẮN bị kill/exit ngay sau đó (xem
         * `doRestartSlot()`), không bao giờ còn cơ hội tạo GeckoRuntime nào
         * khác trong CHÍNH process này nữa — nên `shutdown()` ở đây an toàn,
         * không tái diễn bug 8g.
         */
        gracefulCloseReceiver = object : android.content.BroadcastReceiver() {
            override fun onReceive(context: android.content.Context?, intent: Intent?) {
                DebugLog.log("Khe $slotIndex: nhận broadcast đóng đàng hoàng — đóng tab + TẮT HẲN GeckoRuntime (đảm bảo flush thật) trước khi finish()")
                engine.release()
                GeckoRuntimeProvider.shutdown(slotIndex)
                DebugLog.log("Khe $slotIndex: đã shutdown xong — gửi ACK")
                sendBroadcast(Intent(ProfileSlots.gracefulCloseAckAction(slotIndex)).apply { setPackage(packageName) })
                finish()
            }
        }
        // ContextCompat.registerReceiver (không phải registerReceiver() thẳng)
        // vì cờ RECEIVER_NOT_EXPORTED + overload 3 tham số chỉ có từ API 33 —
        // app này minSdk 26, gọi thẳng sẽ crash NoSuchMethodError trên máy cũ.
        ContextCompat.registerReceiver(
            this,
            gracefulCloseReceiver,
            android.content.IntentFilter(ProfileSlots.gracefulCloseAction(slotIndex)),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )

        DebugLog.log("MainActivity.onCreate: slot=$slotIndex, bắt đầu setupUI()")
        setupUI()
        DebugLog.log("MainActivity.onCreate: setupUI xong, bắt đầu setupEngine() (tạo GeckoRuntime — điểm nghi ngờ crash native cao nhất)")
        setupEngine()
        DebugLog.log("MainActivity.onCreate: setupEngine xong, bắt đầu setupDragDrop()")
        setupDragDrop()
        DebugLog.log("MainActivity.onCreate: setupDragDrop xong, bắt đầu initServices()")
        initServices()
        DebugLog.log("MainActivity.onCreate: initServices xong, bắt đầu requestPermissions()")
        requestPermissions()
        DebugLog.log("MainActivity.onCreate: HOÀN TẤT")
    }

    private fun initServices() {
        KeepAliveService.start(this)
        val downloadFeature = FeatureRegistry.all().filterIsInstance<DownloadManagerFeature>().firstOrNull()
        downloadFeature?.initEngine(this)

        // Setup proxy cho slot này
        setupProxyForSlot()

        // Load trang mặc định — hoặc URL được truyền vào từ "Mở ở khe khác"
        // (nhấn giữ link ở khe khác, chọn mở link này ở khe này)
        //
        // THEO YÊU CẦU: khôi phục lại các tab đang mở từ lần trước (giống
        // Chrome/Firefox thật) thay vì luôn mở trang chủ trắng — xem
        // `GeckoViewEngine.restoreTabsIfAny()`. Nếu người dùng đang cố mở 1
        // URL cụ thể (`openUrl` != null, từ "Mở ở khe khác") thì ưu tiên mở
        // đúng URL đó trước, không khôi phục (tránh gây nhầm lẫn "tôi bấm mở
        // link này mà sao lại ra tab cũ").
        val openUrl = intent.getStringExtra("open_url")
        if (openUrl != null) {
            engine.createTab(openUrl)
        } else if (!engine.restoreTabsIfAny()) {
            val homeUrl = AppPrefs.getString(this, slotIndex, "home_url", "https://www.google.com")
            engine.createTab(homeUrl)
        }
        refreshTabBar()
    }

    private fun setupProxyForSlot() {
        val proxyType = AppPrefs.getInt(this, slotIndex, "proxy_type", 0)
        if (proxyType > 0) {
            val host = AppPrefs.getString(this, slotIndex, "proxy_host", "")
            val port = AppPrefs.getString(this, slotIndex, "proxy_port", "").toIntOrNull() ?: 0
            val user = AppPrefs.getString(this, slotIndex, "proxy_user", "")
            val pass = AppPrefs.getString(this, slotIndex, "proxy_pass", "")

            if (host.isNotEmpty() && port > 0) {
                engine.setupProxy(host, port, user, pass)
                DebugLog.log("Slot $slotIndex proxy: $host:$port")
            }
        }
    }

    // ===== UI Setup =====

    /** Quy đổi dp -> pixel thật theo mật độ màn hình — dùng để tránh lặp lại
     * bug "48 PIXEL THÔ tưởng là 48dp" (xem giải thích lớn ở `setupUI()`). */
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun setupUI() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
        }

        // Toolbar container
        toolbarContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#F8F9FA"))
        }

        // Tab bar
        tabBar = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            val tabLayout = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(8, 8, 8, 8)
            }
            tabContainer = tabLayout
            addView(tabLayout, ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        toolbarContainer.addView(tabBar, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // Nhãn LUÔN HIỂN THỊ "đang ở Khe nào / hồ sơ nào" — trước đây thông
        // tin này chỉ hiện trong tiêu đề 1 vài dialog (vd "Menu (Slot 1)"),
        // không có gì hiển thị thường trực trong lúc duyệt web, dễ nhầm
        // đang ở khe nào khi mở nhiều khe cùng lúc. Chỉ cần đọc 1 lần lúc
        // tạo UI vì việc đổi gán hồ sơ luôn khởi động lại khe (xem
        // `ProfilePickerActivity.restartSlot`), nên giá trị không đổi trong
        // suốt vòng đời Activity này.
        val slotLabel = TextView(this).apply {
            text = "Khe $slotIndex — ${ProfileSlots.getSlotAssignmentDisplay(this@MainActivity, slotIndex)}"
            textSize = 11f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#616161"))
            setPadding(16, 4, 16, 4)
        }
        toolbarContainer.addView(slotLabel, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // URL + Navigation bar
        //
        // BUG THẬT đã sửa (người dùng phản ánh "icon nhí nhí khó nhấn"): các
        // nút back/forward/refresh/tab/menu trước đây có kích thước
        // `ViewGroup.LayoutParams(48, 48)` — đây là 48 PIXEL THÔ, không phải
        // 48dp! Trên màn hình mật độ điểm ảnh cao (3x, rất phổ biến) thì 48px
        // chỉ tương đương ~16dp thật — thấp hơn NHIỀU so với khuyến nghị tối
        // thiểu 48dp của Material Design cho vùng chạm ngón tay, nên khó
        // bấm trúng là đúng, không phải cảm giác. Sửa: đổi hết sang `dp(48)`
        // (hàm quy đổi theo mật độ màn hình thật), thêm đệm bên trong icon +
        // hiệu ứng gợn sóng khi chạm (giống Material/Chrome) cho dễ bấm và
        // có phản hồi rõ ràng khi chạm trúng.
        //
        // THEO YÊU CẦU: gom back/forward/refresh vào menu 3 chấm thay vì để
        // cố định trên thanh công cụ — đúng như Chrome thật làm (Chrome
        // KHÔNG có nút Back riêng trên thanh công cụ, dùng nút/vuốt Back của
        // hệ thống — app này đã tự làm đúng việc đó từ trước, xem
        // `onBackPressed()` phía dưới gọi `engine.goBack()`). Forward/Reload
        // chuyển vào `showMenu()`. Vẫn giữ nguyên các biến `backButton`/
        // `forwardButton`/`refreshButton` (không xoá) vì vài chỗ khác trong
        // file còn cập nhật trạng thái enable/alpha của chúng — chỉ không
        // gắn vào `navBar` để không chiếm chỗ trên màn hình nữa.
        val navBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(4), dp(6), dp(4), dp(6))
            gravity = Gravity.CENTER_VERTICAL
        }

        val rippleBg = android.util.TypedValue().also {
            theme.resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, it, true)
        }.resourceId

        backButton = ImageButton(this).apply {
            setImageResource(android.R.drawable.ic_media_previous)
            setBackgroundResource(rippleBg)
            setPadding(dp(10), dp(10), dp(10), dp(10))
            setOnClickListener { engine.goBack() }
        }
        forwardButton = ImageButton(this).apply {
            setImageResource(android.R.drawable.ic_media_next)
            setBackgroundResource(rippleBg)
            setPadding(dp(10), dp(10), dp(10), dp(10))
            setOnClickListener { engine.goForward() }
        }
        refreshButton = ImageButton(this).apply {
            setImageResource(android.R.drawable.ic_menu_rotate)
            setBackgroundResource(rippleBg)
            setPadding(dp(10), dp(10), dp(10), dp(10))
            setOnClickListener { engine.reload() }
        }

        // Omnibox kiểu Chrome: bo tròn viên thuốc, nền xám nhạt, không viền —
        // thay vì ô nhập viền vuông mặc định trước đây. Giờ rộng hơn nhiều
        // vì không còn phải chia chỗ với 3 nút back/forward/refresh nữa.
        urlBar = EditText(this).apply {
            hint = "Tìm kiếm hoặc nhập URL"
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.parseColor("#F1F3F4"))
                cornerRadius = dp(24).toFloat()
            }
            setPadding(dp(16), dp(10), dp(16), dp(10))
            setSingleLine(true)
            textSize = 15f
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            imeOptions = EditorInfo.IME_ACTION_GO
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_GO) {
                    navigateToUrl(text.toString())
                    true
                } else false
            }
        }
        navBar.addView(urlBar, LinearLayout.LayoutParams(0, dp(44), 1f).apply {
            marginStart = dp(4); marginEnd = dp(4)
        })

        newTabButton = ImageButton(this).apply {
            setImageResource(android.R.drawable.ic_input_add)
            setBackgroundResource(rippleBg)
            setPadding(dp(10), dp(10), dp(10), dp(10))
            setOnClickListener {
                engine.createTab("https://www.google.com")
                refreshTabBar()
            }
        }
        navBar.addView(newTabButton, ViewGroup.LayoutParams(dp(48), dp(48)))

        // Nút "N tab" kiểu Chrome — bấm mở lưới xem/chuyển/đóng tab, thay
        // vì phải cuộn dải chip ngang khi có nhiều tab.
        tabSwitcherButton = TextView(this).apply {
            text = "1"
            textSize = 13f
            gravity = Gravity.CENTER
            setTextColor(Color.DKGRAY)
            background = android.graphics.drawable.GradientDrawable().apply {
                setStroke(dp(2), Color.DKGRAY)
                cornerRadius = dp(6).toFloat()
            }
            foreground = androidx.core.content.ContextCompat.getDrawable(this@MainActivity, rippleBg)
            setOnClickListener { showTabSwitcher() }
        }
        // BUG BUILD đã sửa: `ViewGroup.LayoutParams` (lớp cha) KHÔNG có
        // marginStart/marginEnd — chỉ `ViewGroup.MarginLayoutParams` (và các
        // lớp con như `LinearLayout.LayoutParams`) mới có. Trước đây viết
        // nhầm `ViewGroup.LayoutParams` ở đây → "Unresolved reference" lúc
        // build. navBar là LinearLayout nên đổi đúng sang `LinearLayout.LayoutParams`.
        navBar.addView(tabSwitcherButton, LinearLayout.LayoutParams(dp(40), dp(40)).apply {
            marginStart = dp(4); marginEnd = dp(4)
        })

        menuButton = ImageButton(this).apply {
            setImageResource(android.R.drawable.ic_menu_more)
            setBackgroundResource(rippleBg)
            setPadding(dp(10), dp(10), dp(10), dp(10))
            setOnClickListener { showMenu() }
        }
        navBar.addView(menuButton, ViewGroup.LayoutParams(dp(48), dp(48)))

        toolbarContainer.addView(navBar, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // Progress bar
        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            visibility = View.GONE
        }
        toolbarContainer.addView(progressBar, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 4))

        root.addView(toolbarContainer, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // GeckoView
        geckoView = GeckoView(this)
        root.addView(geckoView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        setContentView(root)
    }

    private fun setupEngine() {
        engine = GeckoViewEngine(this, geckoView, slotIndex)

        engine.onPageLoadedListener = { url ->
            urlBar.setText(url)
            updateNavButtons()
            ForegroundState.broadcastActiveSlot(this, slotIndex, url)
            engine.recordHistoryVisit(url)
            FeatureRegistry.enabledFeatures(this, slotIndex).forEach {
                it.onPageFinished(this, slotIndex, engine, url)
            }
        }

        engine.onPageErrorListener = { url, code ->
            DebugLog.log("Page error: $url code=$code")
        }

        engine.onTitleChangedListener = { title ->
            updateTabTitle(title)
            engine.currentUrl()?.let { engine.updateLastHistoryTitle(it, title) }
        }

        engine.onProgressChangedListener = { progress ->
            progressBar.progress = progress
            progressBar.visibility = if (progress in 1..99) View.VISIBLE else View.GONE
        }

        engine.onNewTabRequestedListener = { url ->
            engine.createTab(url)
            refreshTabBar()
        }

        engine.onTabSwitchedListener = {
            urlBar.setText(engine.currentUrl() ?: "")
            updateNavButtons()
            refreshTabBar()
        }

        engine.onLongPressLinkListener = { uri, text ->
            runOnUiThread { showLinkContextMenu(uri, text) }
        }

        engine.onDownloadRequestedListener = { url, fileName ->
            val downloadFeature = FeatureRegistry.all().filterIsInstance<com.colablive.keeper.features.downloads.DownloadManagerFeature>().firstOrNull()
            downloadFeature?.startDownloadWithPolicy(this, url, fileName)
        }

        engine.onFilePromptListener = { mimeTypes ->
            showFilePicker(mimeTypes)
        }

        startFeatureTickLoop()
    }

    /**
     * Vòng lặp tick 60s/lần cho các feature cần hành vi định kỳ (vd Colab Live
     * Keeper chế độ DOM — bấm nút Connect lại). Trước đây `onTick` được viết
     * đầy đủ trong ColabLiveKeeperFeature nhưng KHÔNG CÓ GÌ GỌI TỚI NÓ, nên
     * chế độ DOM (mặc định) không có tác dụng gì dù đã bật switch trong Settings.
     */
    private val featureTickRunnable = object : Runnable {
        override fun run() {
            FeatureRegistry.enabledFeatures(this@MainActivity, slotIndex).forEach {
                it.onTick(this@MainActivity, slotIndex, engine, engine.currentUrl())
            }
            handler.postDelayed(this, 60_000L)
        }
    }

    private fun startFeatureTickLoop() {
        handler.removeCallbacks(featureTickRunnable)
        handler.postDelayed(featureTickRunnable, 60_000L)
    }

    private fun navigateToUrl(input: String) {
        val url = when {
            input.startsWith("http://") || input.startsWith("https://") -> input
            input.contains(".") && !input.contains(" ") -> "https://$input"
            else -> "https://www.google.com/search?q=${URLEncoder.encode(input, "UTF-8")}"
        }
        engine.loadUrl(url)
    }

    private fun updateNavButtons() {
        backButton.isEnabled = engine.canGoBack()
        backButton.alpha = if (engine.canGoBack()) 1f else 0.3f
        forwardButton.isEnabled = engine.canGoForward()
        forwardButton.alpha = if (engine.canGoForward()) 1f else 0.3f
    }

    private fun updateTabTitle(title: String) {
        // Tiêu đề chỉ đổi cho tab đang active — vẽ lại cả thanh tab cho đơn giản
        // và luôn nhất quán (số lượng tab thường nhỏ, chi phí không đáng kể).
        refreshTabBar()
    }

    /**
     * Vẽ lại toàn bộ thanh tab từ danh sách tab thật của engine.
     * Trước đây thanh tab được khai báo nhưng KHÔNG BAO GIỜ có view nào được
     * thêm vào `tabContainer` — tạo tab mới không hiện gì, không bấm chuyển
     * được. Đây là hàm khắc phục, gọi lại mỗi khi danh sách/tab active/tiêu
     * đề thay đổi.
     */
    private fun refreshTabBar() {
        tabContainer.removeAllViews()
        tabViews.clear()
        val activeId = engine.getActiveTab()?.id
        val tabs = engine.getTabs()
        tabs.forEach { tab ->
            val chip = createTabChip(tab, tab.id == activeId)
            tabViews[tab.id] = chip
            tabContainer.addView(chip)
        }
        if (::tabSwitcherButton.isInitialized) {
            tabSwitcherButton.text = tabs.size.toString()
        }
    }

    private fun createTabChip(tab: com.colablive.keeper.core.BrowserTab, isActive: Boolean): View {
        val chip = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(20, 10, 8, 10)
            setBackgroundColor(if (isActive) Color.WHITE else Color.parseColor("#E0E0E0"))
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                setMargins(4, 4, 4, 4)
            }
            isClickable = true
            setOnClickListener {
                if (tab.id != engine.getActiveTab()?.id) {
                    engine.switchToTab(tab.id)
                }
            }
        }

        chip.addView(TextView(this).apply {
            text = (tab.title.takeIf { it.isNotEmpty() } ?: tab.url).take(16)
            textSize = 13f
            setTextColor(Color.DKGRAY)
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(160, ViewGroup.LayoutParams.WRAP_CONTENT)
        })

        chip.addView(ImageButton(this).apply {
            setImageResource(android.R.drawable.ic_menu_close_clear_cancel)
            setBackgroundColor(Color.TRANSPARENT)
            layoutParams = LinearLayout.LayoutParams(40, 40)
            setOnClickListener {
                if (engine.getTabs().size <= 1) {
                    Toast.makeText(this@MainActivity, "Không thể đóng tab cuối cùng", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                engine.closeTab(tab.id)
                refreshTabBar()
            }
        })

        return chip
    }

    /**
     * Lưới xem/chuyển/đóng tab kiểu Chrome (bấm nút "N" cạnh nút + trên
     * thanh công cụ) — thay vì phải dò dải chip ngang khi có nhiều tab.
     */
    private fun showTabSwitcher() {
        val dialog = Dialog(this, android.R.style.Theme_Black_NoTitleBar)
        val activeId = engine.getActiveTab()?.id
        val tabs = engine.getTabs()

        val grid = GridLayout(this).apply {
            columnCount = 2
            setPadding(24, 24, 24, 24)
        }
        tabs.forEach { tab ->
            grid.addView(createTabCard(tab, tab.id == activeId, dialog))
        }
        grid.addView(createNewTabCard(dialog))

        val scroll = ScrollView(this).apply { addView(grid) }

        val titleBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(24, 16, 24, 16)
            addView(TextView(this@MainActivity).apply {
                text = "${tabs.size} tab đang mở"
                textSize = 16f
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            })
            addView(Button(this@MainActivity).apply {
                text = "Đóng"
                setOnClickListener { dialog.dismiss() }
            })
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
            addView(titleBar)
            addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        }
        dialog.setContentView(root)
        dialog.show()
    }

    private fun createTabCard(tab: com.colablive.keeper.core.BrowserTab, isActive: Boolean, dialog: Dialog): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 16, 20, 16)
            setBackgroundColor(if (isActive) Color.parseColor("#D2E3FC") else Color.parseColor("#F1F3F4"))
            layoutParams = GridLayout.LayoutParams().apply {
                width = 0
                height = ViewGroup.LayoutParams.WRAP_CONTENT
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(8, 8, 8, 8)
            }
            isClickable = true
            setOnClickListener {
                engine.switchToTab(tab.id)
                dialog.dismiss()
            }
        }

        val titleRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        titleRow.addView(TextView(this).apply {
            text = tab.title.takeIf { it.isNotEmpty() } ?: tab.url
            textSize = 14f
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        })
        titleRow.addView(ImageButton(this).apply {
            setImageResource(android.R.drawable.ic_menu_close_clear_cancel)
            setBackgroundColor(Color.TRANSPARENT)
            layoutParams = LinearLayout.LayoutParams(36, 36)
            setOnClickListener {
                if (engine.getTabs().size <= 1) {
                    Toast.makeText(this@MainActivity, "Không thể đóng tab cuối cùng", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                engine.closeTab(tab.id)
                refreshTabBar()
                dialog.dismiss()
                showTabSwitcher() // vẽ lại lưới cho khớp danh sách mới
            }
        })
        card.addView(titleRow)

        card.addView(TextView(this).apply {
            text = tab.url
            textSize = 11f
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            setTextColor(Color.GRAY)
        })
        return card
    }

    private fun createNewTabCard(dialog: Dialog): View {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(20, 24, 20, 24)
            setBackgroundColor(Color.parseColor("#F1F3F4"))
            layoutParams = GridLayout.LayoutParams().apply {
                width = 0
                height = ViewGroup.LayoutParams.WRAP_CONTENT
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(8, 8, 8, 8)
            }
            isClickable = true
            addView(TextView(this@MainActivity).apply {
                text = "+  Tab mới"
                textSize = 14f
                gravity = Gravity.CENTER
            })
            setOnClickListener {
                engine.createTab("https://www.google.com")
                refreshTabBar()
                dialog.dismiss()
            }
        }
    }

    /**
     * Dialog danh sách có ICON THẬT (không chỉ chữ) — thay cho
     * `AlertDialog.setItems()` cũ (chỉ hỗ trợ text đơn thuần, không gắn
     * được icon riêng cho từng dòng). Dùng chung cho menu chính lẫn menu
     * con "Tải xuống & Media".
     */
    private fun showIconMenu(title: String, items: List<Triple<Int, String, () -> Unit>>) {
        val density = resources.displayMetrics.density
        val listLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val dialog = AlertDialog.Builder(this).setTitle(title).setView(listLayout).create()
        items.forEach { (iconRes, label, action) ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding((16 * density).toInt(), (14 * density).toInt(), (16 * density).toInt(), (14 * density).toInt())
                isClickable = true
                isFocusable = true
                val ripple = android.util.TypedValue().also {
                    theme.resolveAttribute(android.R.attr.selectableItemBackground, it, true)
                }.resourceId
                setBackgroundResource(ripple)
                setOnClickListener {
                    dialog.dismiss()
                    action()
                }
            }
            row.addView(ImageView(this).apply {
                setImageResource(iconRes)
                setColorFilter(Color.DKGRAY)
            }, LinearLayout.LayoutParams((24 * density).toInt(), (24 * density).toInt()).apply {
                marginEnd = (20 * density).toInt()
            })
            row.addView(TextView(this).apply {
                text = label
                textSize = 15f
                setTextColor(Color.BLACK)
            })
            listLayout.addView(row)
        }
        dialog.show()
    }

    private fun showDownloadMediaMenu() {
        showIconMenu("Tải xuống & Media", listOf(
            Triple(android.R.drawable.stat_sys_download, "IDM Downloads") { showIDMDialog() },
            Triple(android.R.drawable.ic_menu_slideshow, "Sniff Media") { showSniffDialog() },
            Triple(android.R.drawable.ic_menu_save, "💾 Lưu Trang Web") { showWebArchiveDialog() },
            Triple(android.R.drawable.ic_menu_preferences, "⚙️ Cài đặt Download") { showDownloadPolicySettings() }
        ))
    }

    private fun showMenu() {
        // BUG THẬT đã sửa: mục "Features" trước đây gọi thẳng
        // FeatureSettingsActivity nhưng KHÔNG truyền "feature_id" (activity
        // đó cần biết đúng 1 feature nào để hiển thị) — bấm vào chỉ hiện
        // Toast "Không tìm thấy feature" rồi tự đóng ngay, không dẫn tới
        // đâu cả. "Settings" (mục đầu) mới là màn hình liệt kê đúng TẤT CẢ
        // feature (kể cả "Phát media nền" mới thêm) rồi mới mở đúng 1 cái
        // khi bấm vào — đã bỏ mục "Features" trùng lặp/hỏng này.
        //
        // THEO YÊU CẦU: icon thật cho Tiến tới/Tải lại (giống Chrome) thay
        // vì chỉ chữ + emoji; gom IDM/Sniff Media/Lưu Trang Web/Cài đặt
        // Download (4 mục rời rạc trước đây) vào chung 1 mục "Tải xuống &
        // Media" cho gọn, đỡ phải cuộn dài. "Quay lại" KHÔNG cần thêm ở đây
        // vì nút/vuốt Back của hệ thống Android đã tự làm đúng việc đó rồi
        // (xem `onBackPressed()`).
        showIconMenu("Menu (Slot $slotIndex)", listOf(
            Triple(android.R.drawable.ic_media_next, "Tiến tới") {
                if (engine.canGoForward()) engine.goForward() else Toast.makeText(this, "Không có trang để tiến tới", Toast.LENGTH_SHORT).show()
            },
            Triple(android.R.drawable.ic_menu_rotate, "Tải lại trang") { engine.reload() },
            Triple(android.R.drawable.ic_menu_manage, "Settings") {
                startActivity(Intent(this, SettingsActivity::class.java).putExtra("slot_index", slotIndex))
            },
            Triple(android.R.drawable.ic_menu_info_details, "Debug Log") { startActivity(Intent(this, DebugLogActivity::class.java)) },
            Triple(android.R.drawable.ic_menu_gallery, "Chuyển Khe") { startActivity(Intent(this, ProfilePickerActivity::class.java)) },
            Triple(android.R.drawable.ic_menu_recent_history, "🕐 Lịch sử") {
                startActivityForResult(Intent(this, HistoryActivity::class.java).putExtra("slot_index", slotIndex), RC_HISTORY)
            },
            Triple(android.R.drawable.ic_menu_mapmode, "Proxy Config") { showProxyDialog() },
            Triple(android.R.drawable.ic_menu_view, "Test Cookie Leak") { showLeakTestDialog() },
            Triple(android.R.drawable.stat_sys_download, "📥 Tải xuống & Media") { showDownloadMediaMenu() },
            Triple(android.R.drawable.ic_dialog_alert, "🩹 Xem crash gần nhất") { startActivity(Intent(this, CrashReportActivity::class.java)) },
            Triple(android.R.drawable.ic_menu_send, "📋 Sao chép URL hiện tại") { copyToClipboard("URL", engine.currentUrl() ?: "") }
        ))
    }

    private fun copyToClipboard(label: String, text: String) {
        val clipboard = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
        clipboard.setPrimaryClip(android.content.ClipData.newPlainText(label, text))
        Toast.makeText(this, "Đã sao chép: $text", Toast.LENGTH_SHORT).show()
    }

    /** Menu hiện ra khi nhấn giữ 1 liên kết trên trang (trước đây không làm gì cả). */
    private fun showLinkContextMenu(uri: String, linkText: String?) {
        val items = arrayOf("Mở trong tab mới", "Mở ở khe khác…", "Sao chép liên kết", "Chia sẻ liên kết")
        AlertDialog.Builder(this)
            .setTitle(linkText?.takeIf { it.isNotBlank() } ?: uri)
            .setItems(items) { _, which ->
                when (which) {
                    0 -> {
                        engine.createTab(uri)
                        refreshTabBar()
                    }
                    1 -> showOpenInSlotDialog(uri)
                    2 -> copyToClipboard("link", uri)
                    3 -> {
                        val shareIntent = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, uri)
                        }
                        startActivity(Intent.createChooser(shareIntent, "Chia sẻ liên kết"))
                    }
                }
            }
            .show()
    }

    /** Mở 1 URL cụ thể ở 1 khe KHÁC (không phải khe đang đứng) — mở tiến trình khe đó kèm URL qua extra "open_url". */
    private fun showOpenInSlotDialog(uri: String) {
        val slotOptions = (0..ProfileSlots.SLOT_COUNT).filter { it != slotIndex }
        val labels = slotOptions.map { ProfileSlots.getSlotName(it) }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Mở liên kết ở khe nào?")
            .setItems(labels) { _, which ->
                val targetSlot = slotOptions[which]
                val className = ProfileSlots.componentClassNameForSlot(targetSlot)
                val intent = Intent().apply {
                    component = ComponentName(packageName, className)
                    putExtra("open_url", uri)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                startActivity(intent)
            }
            .show()
    }

    private fun showProxyDialog() {
        val proxyType = AppPrefs.getInt(this, slotIndex, "proxy_type", 0)
        val host = AppPrefs.getString(this, slotIndex, "proxy_host", "")
        val port = AppPrefs.getString(this, slotIndex, "proxy_port", "")
        val user = AppPrefs.getString(this, slotIndex, "proxy_user", "")

        val msg = """
            ✅ Áp dụng qua WebExtension Proxy API (browser.proxy.onRequest) —
            đăng ký khi khe khởi động (GeckoRuntimeProvider). Đổi cấu hình bên
            dưới cần ĐÓNG VÀ MỞ LẠI khe này để có tác dụng.

            Proxy Type: ${if (proxyType == 0) "Direct" else if (proxyType == 1) "HTTP" else "SOCKS5"}
            Host: $host
            Port: $port
            User: $user

            ⚠️ Với proxy miễn phí (nút "Tự động tìm proxy"): rủi ro thật là bị
            log traffic hoặc honeypot — không dùng để đăng nhập tài khoản quan
            trọng.

            Vào Settings > Fingerprint Spoof để thay đổi.
        """.trimIndent()

        AlertDialog.Builder(this)
            .setTitle("Proxy Config (Slot $slotIndex)")
            .setMessage(msg)
            .setPositiveButton("OK", null)
            .show()
    }

    private fun showLeakTestDialog() {
        val downloadFeature = FeatureRegistry.all().filterIsInstance<com.colablive.keeper.features.downloads.DownloadManagerFeature>().firstOrNull()
        downloadFeature?.showLeakTestDialog(this, slotIndex, engine)
    }

    private fun showIDMDialog() {
        val downloadFeature = FeatureRegistry.all().filterIsInstance<com.colablive.keeper.features.downloads.DownloadManagerFeature>().firstOrNull()
        downloadFeature?.showIDMDialog(this)
    }

    private fun showSniffDialog() {
        val downloadFeature = FeatureRegistry.all().filterIsInstance<com.colablive.keeper.features.downloads.DownloadManagerFeature>().firstOrNull()
        // Lấy HTML từ trang hiện tại
        engine.evaluateJs("document.documentElement.outerHTML") { html ->
            html?.let {
                val links = downloadFeature?.sniffPage(this, it, engine.currentUrl() ?: "")
                links?.let { list ->
                    runOnUiThread {
                        downloadFeature?.showSniffedLinksDialog(this, list)
                    }
                }
            }
        }
    }

    private fun showWebArchiveDialog() {
        val currentUrl = engine.currentUrl() ?: return
        val currentTitle = engine.getActiveTab()?.title ?: "page"
        val downloadFeature = FeatureRegistry.all().filterIsInstance<com.colablive.keeper.features.downloads.DownloadManagerFeature>().firstOrNull()
        downloadFeature?.showWebArchiveDialog(this, currentUrl, currentTitle, geckoView)
    }

    private fun showDownloadPolicySettings() {
        val downloadFeature = FeatureRegistry.all().filterIsInstance<com.colablive.keeper.features.downloads.DownloadManagerFeature>().firstOrNull()
        downloadFeature?.showPolicySettings(this)
    }



    private fun showDownloadDialog(url: String, fileName: String) {
        AlertDialog.Builder(this)
            .setTitle("Tải xuống")
            .setMessage("$fileName\n$url")
            .setPositiveButton("Tải") { _, _ ->
                val downloadFeature = FeatureRegistry.all().filterIsInstance<DownloadManagerFeature>().firstOrNull()
                downloadFeature?.startDownload(this, url, fileName)
            }
            .setNegativeButton("Hủy", null)
            .show()
    }

    private fun showFilePicker(mimeTypes: Array<String>?) {
        val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
            type = mimeTypes?.firstOrNull() ?: "*/*"
            addCategory(Intent.CATEGORY_OPENABLE)
        }
        startActivityForResult(Intent.createChooser(intent, "Chọn file"), RC_FILE_PICKER)
    }

    /**
     * BUG THẬT đã sửa — "kéo thả file từ Files app không hoạt động như
     * Chrome": code cũ ở đây gắn `setOnDragListener` riêng, và khi có file
     * thả vào thì gọi `engine.handleDropUri()` — hàm đó lại chỉ COPY file
     * vào cache rồi bắn ra 1 `CustomEvent('livebrowser:filedrop', ...)` tự
     * chế trên `window`. KHÔNG TRANG WEB THẬT NÀO lắng nghe sự kiện tự chế
     * này cả — trang web chuẩn dùng sự kiện `drop` HTML5 chuẩn với
     * `event.dataTransfer.files`, không phải sự kiện app tự đặt tên. Nghĩa
     * là kéo thả file trước giờ hoàn toàn KHÔNG hoạt động với bất kỳ trang
     * thật nào, kể cả khi copy file "thành công".
     *
     * Nghiêm trọng hơn: `View.setOnDragListener()` khi được gắn sẽ THAY THẾ
     * HẲN cơ chế xử lý kéo thả nội bộ mặc định của chính View đó (GeckoView
     * đã tự cài sẵn `onDragEvent()` để dịch `DragEvent` gốc của Android
     * thành đúng sự kiện `drop` chuẩn HTML5 cho trang web, y hệt cách Chrome
     * làm) — gắn listener tự chế ở đây đã CHE MẤT cơ chế đúng có sẵn của
     * GeckoView, không chỉ đơn thuần "thêm 1 cách kéo thả không hoạt động"
     * mà còn "chặn mất cách đã hoạt động sẵn".
     *
     * Sửa: bỏ hẳn listener tự chế — để GeckoView tự xử lý kéo thả theo đúng
     * cơ chế chuẩn nó đã có sẵn (giống Chrome/Firefox thật), không can
     * thiệp gì thêm ở tầng app nữa.
     */
    private fun setupDragDrop() {
        // Cố tình để trống — xem giải thích lớn phía trên hàm.
    }

    private fun requestPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, PERMISSION_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, arrayOf(PERMISSION_NOTIFICATIONS), RC_NOTIFICATIONS)
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == RC_HISTORY) {
            if (resultCode == RESULT_OK) {
                data?.getStringExtra("open_url")?.let { engine.loadUrl(it) }
            }
            return
        }
        if (requestCode == RC_FILE_PICKER) {
            val pickedUri = if (resultCode == RESULT_OK) data?.data else null
            if (pickedUri == null) {
                engine.resolveFilePrompt(this, null)
                return
            }
            /**
             * BUG THẬT đã sửa (người dùng phát hiện — cực kỳ đúng trọng
             * tâm): bản sửa "Unable to read file" (8r) copy file NGAY TRÊN
             * LUỒNG CHÍNH (UI thread) — file nhỏ (ảnh, vài MB) thì không
             * để ý, nhưng file LỚN (video, file nén nhiều trăm MB/vài GB)
             * copy mất VÀI GIÂY ĐẾN VÀI PHÚT tuỳ dung lượng + tốc độ đọc —
             * chặn luồng chính suốt thời gian đó nghĩa là TOÀN BỘ app đứng
             * hình (không vuốt được, không bấm được gì), và nếu chặn quá
             * ~5 giây, Android tự phát hiện "app không phản hồi" và hỏi
             * người dùng có muốn ĐÓNG APP không (ANR — Application Not
             * Responding), tệ hơn hẳn cả lỗi "Unable to read file" ban đầu.
             *
             * Sửa: copy chạy trên luồng NỀN (`Thread`, không phải UI
             * thread) — UI vẫn mượt, không đứng hình, không bị Android hỏi
             * đóng app. Chỉ có bước cuối (`engine.resolveFilePrompt`, cần
             * tương tác với GeckoSession — API này cần chạy đúng luồng
             * chính) mới quay lại UI thread qua `runOnUiThread`.
             */
            val progressToast = Toast.makeText(this, "Đang xử lý file...", Toast.LENGTH_LONG)
            progressToast.show()
            Thread {
                val safeUri = copyToAppStorageAsFileProviderUri(pickedUri)
                runOnUiThread {
                    progressToast.cancel()
                    if (safeUri == null) {
                        Toast.makeText(this, "Không đọc được file đã chọn", Toast.LENGTH_SHORT).show()
                    }
                    engine.resolveFilePrompt(this, safeUri)
                }
            }.start()
        }
    }

    /**
     * BUG THẬT đã sửa — lỗi "Unable to read file" khi upload (Colab và có
     * thể nhiều trang khác): GeckoView render trang trong 1 tiến trình
     * RIÊNG (không phải tiến trình app này) — content:// URI từ app khác
     * (Files, Drive, Photos...) app này ĐỌC ĐƯỢC không có nghĩa tiến trình
     * render riêng đó cũng đọc được, tuỳ provider gốc có chia sẻ quyền đúng
     * cách cho tiến trình con hay không (tuỳ từng provider, không nhất
     * quán). Sửa AN TOÀN, không cần đoán API GeckoView nội bộ: copy hẳn
     * nội dung file vào bộ nhớ RIÊNG của app này rồi cấp quyền qua
     * `FileProvider` chuẩn (xem AndroidManifest.xml) — Gecko chắc chắn đọc
     * được vì đây là file thuộc về CHÍNH app này, có quyền rõ ràng, không
     * còn phụ thuộc provider ngoài nào nữa.
     *
     * BUG THẬT #2 đã sửa (người dùng hỏi đúng trọng tâm — cảm ơn): copy
     * xong KHÔNG hề tự xoá — upload càng nhiều lần, `cacheDir/uploads/`
     * càng phình, không có giới hạn. `cacheDir` VỀ LÝ THUYẾT Android có thể
     * tự dọn khi máy thiếu bộ nhớ, nhưng KHÔNG đảm bảo dọn kịp thời/đúng
     * lúc — không nên trông cậy vào đó. Sửa: mỗi lần upload MỚI, dọn hết
     * file CŨ hơn 10 phút trong thư mục này trước khi copy file mới (không
     * xoá NGAY file vừa copy phiên trước — Gecko đọc file bất đồng bộ, xoá
     * quá sớm có thể làm hỏng upload đang xử lý dở; 10 phút là khoảng đệm
     * an toàn, dư sức cho Gecko đọc xong dù file lớn/máy chậm).
     */
    private fun cleanupOldUploadCache() {
        try {
            val dir = File(cacheDir, "uploads")
            val cutoff = System.currentTimeMillis() - 10 * 60 * 1000L
            dir.listFiles()?.forEach { f ->
                if (f.lastModified() < cutoff) f.delete()
            }
        } catch (e: Exception) {
            DebugLog.log("cleanupOldUploadCache lỗi: ${e.message}")
        }
    }

    private fun copyToAppStorageAsFileProviderUri(sourceUri: Uri): Uri? {
        return try {
            cleanupOldUploadCache()
            val fileName = getFileNameFromUriPublic(sourceUri) ?: "upload_${System.currentTimeMillis()}"
            val dir = File(cacheDir, "uploads").apply { mkdirs() }
            // Thêm timestamp vào tên file THẬT trên đĩa (khác tên hiển thị) để
            // 2 lần upload trùng tên (vd cùng chọn "anh.jpg" 2 lần) không ghi
            // đè lên nhau khi lần đầu chưa kịp bị dọn.
            val destFile = File(dir, "${System.currentTimeMillis()}_$fileName")
            contentResolver.openInputStream(sourceUri)?.use { input ->
                destFile.outputStream().use { output -> input.copyTo(output) }
            } ?: return null
            val providerUri = androidx.core.content.FileProvider.getUriForFile(this, "$packageName.fileprovider", destFile)
            grantUriPermission(packageName, providerUri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            providerUri
        } catch (e: Exception) {
            DebugLog.log("copyToAppStorageAsFileProviderUri lỗi: ${e.javaClass.simpleName}: ${e.message}")
            null
        }
    }

    private fun getFileNameFromUriPublic(uri: Uri): String? {
        var result: String? = null
        if (uri.scheme == "content") {
            contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val idx = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0) result = cursor.getString(idx)
                }
            }
        }
        return result ?: uri.lastPathSegment
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        // Khe này (singleTask) ĐÃ ĐANG CHẠY SẴN — Android gọi đây thay vì
        // onCreate() lại. Trước đây không xử lý gì cả, nên "Mở ở khe khác"
        // im lặng KHÔNG mở link nếu khe đích đã mở sẵn từ trước (chỉ đưa
        // khe đó lên foreground, giữ nguyên trang đang xem).
        val openUrl = intent.getStringExtra("open_url")
        if (openUrl != null) {
            engine.createTab(openUrl)
            refreshTabBar()
        }
    }

    /**
     * CHẨN ĐOÁN cho vụ "YouTube tắt tiếng khi khoá màn hình/chuyển app" —
     * bản visibility-spoof JS (BackgroundMediaFeature, mục 8b-8d) đã xác
     * nhận KHÔNG đủ (người dùng test bản mới nhất vẫn còn lỗi). Nguyên
     * nhân còn lại nhiều khả năng nằm ở tầng GeckoView/Android — ví dụ
     * GeckoView có thể tự huỷ Surface render (và có thể cả audio) khi
     * Activity mất hiển thị — nhưng đây là hành vi NỘI BỘ của thư viện
     * GeckoView, không có API public để đọc thẳng, và đoán mò API
     * (`GeckoSession.MediaSession.Delegate` chẳng hạn) mà không có mạng để
     * tra đúng chữ ký hàm RẤT dễ đoán sai → gãy build (đã từng xảy ra với
     * `element.linkText`, không muốn lặp lại).
     *
     * Nên thay vì đoán tiếp, ghi log các mốc vòng đời Activity — CHỈ dùng
     * API Android chuẩn, không đụng gì tới GeckoView. Sau khi bạn build
     * bản này, tái hiện lỗi (mở YouTube, khoá màn hình vài giây, mở lại),
     * vào Menu ⋮ → Debug Log, copy đoạn quanh lúc đó gửi lại — sẽ biết
     * chính xác Activity có bị onStop() không, cách nhau bao lâu, từ đó
     * mới sửa đúng chỗ thay vì đoán mò.
     */
    override fun onPause() {
        super.onPause()
        DebugLog.log("Khe $slotIndex: MainActivity.onPause() — Activity mất foreground")
        // Lưu danh sách tab mỗi lần mất foreground — mốc lưu đáng tin cậy,
        // xem giải thích lớn ở `GeckoViewEngine.saveTabsState()`.
        engine.saveTabsState()
    }

    override fun onStop() {
        super.onStop()
        DebugLog.log("Khe $slotIndex: MainActivity.onStop() — Activity không còn hiển thị (surface có thể bị huỷ ở đây)")
    }

    override fun onResume() {
        super.onResume()
        DebugLog.log("Khe $slotIndex: MainActivity.onResume() — Activity quay lại foreground")
    }

    override fun onDestroy() {
        handler.removeCallbacks(featureTickRunnable)
        gracefulCloseReceiver?.let {
            try { unregisterReceiver(it) } catch (e: Exception) { /* đã bị gỡ trước đó, bỏ qua */ }
        }
        // LIÊN QUAN TRỰC TIẾP tới ColabLiveKeeperFeature (giữ phiên Colab
        // "sống" khi nền) + BackgroundMediaFeature: `onDestroy()` KHÔNG chỉ
        // xảy ra khi người dùng THẬT SỰ đóng khe — Android cũng gọi
        // `onDestroy()` khi tự thu hồi bộ nhớ của 1 Activity đang ở nền
        // (trong khi TIẾN TRÌNH + task vẫn còn, đúng như tình huống gây
        // crash ở mục 8g). TRƯỚC ĐÂY `engine.release()` (đóng TẤT CẢ tab,
        // gồm cả tab Colab/YouTube đang chạy nền) chạy VÔ ĐIỀU KIỆN mỗi lần
        // `onDestroy()` — nghĩa là mỗi lần Android âm thầm thu hồi Activity
        // nền, tab Colab/YouTube bị ĐÓNG THẬT (không phải chỉ tạm ẩn), làm
        // mất hết tác dụng của việc "giữ chạy nền" dù GeckoRuntime bên dưới
        // vẫn còn sống. Dùng `isFinishing` để phân biệt: đúng là đang đóng
        // hẳn khe (người dùng bấm back/thoát hẳn) thì mới đóng tab; còn
        // Android tự thu hồi Activity để dọn RAM (task/tiến trình vẫn còn)
        // thì GIỮ NGUYÊN tab, không đóng gì cả — lần sau `onCreate()` mở lại
        // (cùng tiến trình, xem 8g) sẽ tự thấy engine/tab cũ vẫn còn.
        if (isFinishing) {
            DebugLog.log("Khe $slotIndex: MainActivity.onDestroy() — isFinishing=true, đóng hẳn khe, đóng tab")
            // engine.release() ở đây vẫn cần cho trường hợp người dùng thoát
            // khe theo cách THÔNG THƯỜNG (bấm Back, không qua
            // ProfilePickerActivity) — trường hợp gán lại hồ sơ thì
            // `gracefulCloseReceiver` (xem `onCreate()`) đã tự gọi
            // `engine.release()` + `GeckoRuntimeProvider.shutdown()` +
            // gửi ACK từ TRƯỚC khi gọi `finish()` rồi, nên gọi lại ở đây vô
            // hại (tabs đã rỗng sẵn, `forEach` không làm gì).
            engine.release()
        } else {
            DebugLog.log("Khe $slotIndex: MainActivity.onDestroy() — isFinishing=false (Android tự thu hồi Activity nền), GIỮ tab đang chạy")
        }
        // BUG THẬT ĐÃ SỬA (nguyên nhân THẬT SỰ của crash "Only one
        // GeckoRuntime instance is allowed" — 2 lượt crash log gửi lên đều
        // do CHÍNH XÁC dòng này, không phải race condition ở restartSlot()
        // như suy đoán trước): GeckoRuntime BẮT BUỘC phải sống suốt vòng đời
        // TIẾN TRÌNH (process) — đây là giới hạn cứng của Gecko, không phải
        // của app này: tạo được ĐÚNG 1 lần cho cả đời tiến trình, "release"
        // bao nhiêu lần cũng không cho phép tạo lại lần 2 trong CÙNG process.
        //
        // Dòng `GeckoRuntimeProvider.release(slotIndex)` trước đây gọi ở
        // ĐÂY — trong `onDestroy()` của Activity — nhưng `onDestroy()` KHÔNG
        // đồng nghĩa với "tiến trình sắp chết"! Android có thể huỷ Activity
        // (thu hồi bộ nhớ nền, xoay màn hình, v.v.) trong khi TIẾN TRÌNH vẫn
        // sống — mà `KeepAliveService` lại đang CỐ Ý giữ tiến trình sống
        // (đúng mục đích của service đó). Kết quả: `release()` chỉ xoá khỏi
        // map trong bộ nhớ (`runtimes.remove()`) — KHÔNG hề gọi
        // `runtime.shutdown()` — nên GeckoRuntime native cũ vẫn còn sống
        // nguyên trong tiến trình. Lần sau mở lại Khe này (vẫn CÙNG tiến
        // trình vì chưa từng chết), code tưởng map trống nên cố tạo runtime
        // MỚI → Gecko từ chối thẳng vì tiến trình đã "dùng" 1 lần rồi → crash
        // NGAY LẬP TỨC, không phải hiếm — gần như CHẮC CHẮN xảy ra mỗi lần
        // Android tự dọn Activity nền trong khi KeepAliveService còn giữ
        // tiến trình sống.
        //
        // Sửa: KHÔNG gọi `GeckoRuntimeProvider.release()` ở đây nữa.
        // GeckoRuntime cứ để sống trong map suốt đời tiến trình — mở lại
        // Activity (dù trong cùng tiến trình) sẽ tự tìm thấy runtime đã có
        // sẵn qua `getOrPut`, dùng lại đúng cách GeckoView được thiết kế để
        // dùng (tạo runtime 1 lần, dùng suốt đời process — giống Firefox
        // thật làm), không cần tạo lại.
        super.onDestroy()
    }

    override fun onBackPressed() {
        if (engine.canGoBack()) {
            engine.goBack()
        } else {
            super.onBackPressed()
        }
    }
}
