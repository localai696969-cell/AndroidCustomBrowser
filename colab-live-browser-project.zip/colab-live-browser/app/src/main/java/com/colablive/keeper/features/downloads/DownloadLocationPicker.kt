package com.colablive.keeper.features.downloads

import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.os.Environment
import android.view.*
import android.widget.*
import java.io.File

/**
 * Dialog chọn thư mục lưu file trước khi download.
 */
class DownloadLocationPicker(private val context: Context) {

    interface LocationPickerCallback {
        fun onLocationSelected(path: String, rememberForSite: Boolean)
        fun onCancelled()
    }

    fun showPicker(
        fileName: String,
        fileSize: String,
        url: String,
        defaultPath: String,
        callback: LocationPickerCallback
    ) {
        val scrollView = ScrollView(context)
        val container = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
        }

        // File info
        container.addView(TextView(context).apply {
            text = "⬇️ Tải xuống"
            textSize = 20f
            setTextColor(Color.BLACK)
            setPadding(0, 0, 0, 8)
        })

        container.addView(TextView(context).apply {
            text = "Tên: $fileName"
            textSize = 14f
            setTextColor(Color.DKGRAY)
        })

        if (fileSize.isNotEmpty()) {
            container.addView(TextView(context).apply {
                text = "Kích thước: $fileSize"
                textSize = 14f
                setTextColor(Color.DKGRAY)
                setPadding(0, 0, 0, 16)
            })
        }

        // Current location
        container.addView(TextView(context).apply {
            text = "📁 Thư mục lưu:"
            textSize = 16f
            setTextColor(Color.BLACK)
            setPadding(0, 8, 0, 8)
        })

        val pathInput = EditText(context).apply {
            setText(defaultPath)
            setSingleLine(true)
            isFocusable = false
            isClickable = true
            setOnClickListener {
                showFolderBrowser(defaultPath) { selectedPath ->
                    setText(selectedPath)
                }
            }
        }
        container.addView(pathInput)

        // Quick locations
        container.addView(TextView(context).apply {
            text = "📍 Nhanh:"
            textSize = 14f
            setTextColor(Color.DKGRAY)
            setPadding(0, 16, 0, 8)
        })

        val quickPaths = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
        }

        val quickLocations = listOf(
            "📥 Downloads" to (context.getExternalFilesDir(null)?.absolutePath + "/downloads"),
            "🖼️ Images" to (context.getExternalFilesDir(null)?.absolutePath + "/downloads/images"),
            "🎵 Music" to (context.getExternalFilesDir(null)?.absolutePath + "/downloads/music"),
            "🎬 Videos" to (context.getExternalFilesDir(null)?.absolutePath + "/downloads/videos"),
            "📄 Documents" to (context.getExternalFilesDir(null)?.absolutePath + "/downloads/documents"),
        )

        quickLocations.forEach { (label, path) ->
            quickPaths.addView(Button(context).apply {
                text = label
                textSize = 10f
                setOnClickListener {
                    pathInput.setText(path)
                }
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            })
        }
        container.addView(quickPaths)

        // Remember for this site
        val rememberCheck = CheckBox(context).apply {
            text = "Nhớ thư mục này cho trang ${DownloadPolicyManager.extractDomain(url)}"
            isChecked = false
            setPadding(0, 16, 0, 0)
        }
        container.addView(rememberCheck)

        scrollView.addView(container)

        AlertDialog.Builder(context)
            .setView(scrollView)
            .setPositiveButton("⬇️ Tải") { _, _ ->
                callback.onLocationSelected(pathInput.text.toString(), rememberCheck.isChecked)
            }
            .setNegativeButton("❌ Huỷ") { _, _ ->
                callback.onCancelled()
            }
            .setOnCancelListener {
                callback.onCancelled()
            }
            .show()
    }

    private fun showFolderBrowser(currentPath: String, callback: (String) -> Unit) {
        // Tạm thời: Chỉ cho phép chọn từ quick locations
        // Thực tế cần FilePicker hoặc Storage Access Framework
        callback(currentPath)
    }

    companion object {
        fun extractDomain(url: String): String {
            return try {
                android.net.Uri.parse(url).host ?: url
            } catch (e: Exception) {
                url
            }
        }
    }
}
