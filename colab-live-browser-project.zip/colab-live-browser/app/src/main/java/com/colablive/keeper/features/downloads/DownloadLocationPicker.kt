package com.colablive.keeper.features.downloads

import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.os.Environment
import android.view.*
import android.widget.*
import java.io.File

/**
 * Dialog chọn thư mục lưu file trước khi download.
 */
class DownloadLocationPicker(private val context: Context) {

    interface LocationPickerCallback {
        fun onLocationSelected(path: String, rememberForSite: Boolean)
        fun onCancelled()
    }

    fun showPicker(
        fileName: String,
        fileSize: String,
        url: String,
        defaultPath: String,
        callback: LocationPickerCallback
    ) {
        val scrollView = ScrollView(context)
        val container = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
        }

        container.addView(TextView(context).apply {
            text = "⬇️ Tải xuống"
            textSize = 20f
            setTextColor(Color.BLACK)
            setPadding(0, 0, 0, 8)
        })

        container.addView(TextView(context).apply {
            text = "Tên: $fileName"
            textSize = 14f
            setTextColor(Color.DKGRAY)
        })

        if (fileSize.isNotEmpty()) {
            container.addView(TextView(context).apply {
                text = "Kích thước: $fileSize"
                textSize = 14f
                setTextColor(Color.DKGRAY)
                setPadding(0, 0, 0, 16)
            })
        }

        container.addView(TextView(context).apply {
            text = "📁 Thư mục lưu:"
            textSize = 16f
            setTextColor(Color.BLACK)
            setPadding(0, 8, 0, 8)
        })

        val pathInput = EditText(context).apply {
            setText(defaultPath)
            setSingleLine(true)
            isFocusable = false
            isClickable = true
            setOnClickListener {
                showFolderBrowser(defaultPath) { selectedPath ->
                    setText(selectedPath)
                }
            }
        }
        container.addView(pathInput)

        container.addView(TextView(context).apply {
            text = "📍 Nhanh:"
            textSize = 14f
            setTextColor(Color.DKGRAY)
            setPadding(0, 16, 0, 8)
        })

        val quickPaths = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
        }

        val quickLocations = listOf(
            "📥 Downloads" to (context.getExternalFilesDir(null)?.absolutePath + "/downloads"),
            "🖼️ Images" to (context.getExternalFilesDir(null)?.absolutePath + "/downloads/images"),
            "🎵 Music" to (context.getExternalFilesDir(null)?.absolutePath + "/downloads/music"),
            "🎬 Videos" to (context.getExternalFilesDir(null)?.absolutePath + "/downloads/videos"),
            "📄 Documents" to (context.getExternalFilesDir(null)?.absolutePath + "/downloads/documents"),
        )

        quickLocations.forEach { (label, path) ->
            quickPaths.addView(Button(context).apply {
                text = label
                setOnClickListener { pathInput.setText(path) }
            })
        }
        container.addView(quickPaths)

        val rememberCheck = CheckBox(context).apply {
            text = "Nhớ vị trí này cho site này"
        }
        container.addView(rememberCheck)

        scrollView.addView(container)

        AlertDialog.Builder(context)
            .setTitle("Chọn vị trí lưu")
            .setView(scrollView)
            .setPositiveButton("Tải") { _, _ ->
                callback.onLocationSelected(pathInput.text.toString(), rememberCheck.isChecked)
            }
            .setNegativeButton("Hủy") { _, _ -> callback.onCancelled() }
            .show()
    }

    private fun showFolderBrowser(currentPath: String, onSelected: (String) -> Unit) {
        val dir = File(currentPath)
        val parent = dir.parentFile
        val dirs = dir.listFiles { file -> file.isDirectory }?.toList() ?: emptyList()

        val items = mutableListOf<String>()
        if (parent != null) items.add("📁 .. (lên)")
        dirs.forEach { items.add("📁 ${it.name}") }

        AlertDialog.Builder(context)
            .setTitle(dir.absolutePath)
            .setItems(items.toTypedArray()) { _, which ->
                when {
                    which == 0 && parent != null -> showFolderBrowser(parent.absolutePath, onSelected)
                    which == 0 && parent == null -> showFolderBrowser(currentPath, onSelected)
                    else -> {
                        val selectedDir = if (parent != null) dirs[which - 1] else dirs[which]
                        showFolderBrowser(selectedDir.absolutePath, onSelected)
                    }
                }
            }
            .setPositiveButton("Chọn") { _, _ -> onSelected(dir.absolutePath) }
            .setNegativeButton("Hủy", null)
            .show()
    }

    companion object {
        @JvmStatic
        fun show(context: Context, callback: (String) -> Unit) {
            val picker = DownloadLocationPicker(context)
            val defaultPath = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)?.absolutePath
                ?: (Environment.getExternalStorageDirectory().absolutePath + "/Download")
            picker.showPicker("", "", "", defaultPath, object : LocationPickerCallback {
                override fun onLocationSelected(path: String, rememberForSite: Boolean) {
                    callback(path)
                }
                override fun onCancelled() {}
            })
        }
    }
}
