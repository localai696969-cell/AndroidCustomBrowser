package com.colablive.keeper.core

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri

/**
 * Cầu nối chọn thư mục THẬT qua Storage Access Framework — thay cho việc
 * bắt gõ tay đường dẫn ở mục "Tuỳ chọn" trong `SaveLocationDialog` (người
 * dùng phản ánh 2 lần, xác nhận là giới hạn thật của Scoped Storage Android
 * 10+, cần SAF mới làm đúng — xem PROJECT_STATUS.md mục 8zzb/8zzi).
 *
 * `SaveLocationDialog` là 1 class thường (không phải Activity), không thể
 * tự `startActivityForResult()`/nhận kết quả — cần 1 điểm trung gian dùng
 * chung cho MỌI Activity trong app (`MainActivity`, và bất kỳ Activity nào
 * khác gọi `SaveLocationDialog` sau này) tự đăng ký nhận kết quả rồi
 * chuyển tiếp qua đây.
 */
object FolderPickerBridge {
    const val RC_FOLDER_PICKER = 9101

    private var pendingCallback: ((Uri?) -> Unit)? = null

    /** Gọi từ `SaveLocationDialog` khi bấm "📁 Chọn thư mục". `activity`
     * PHẢI là Activity thật đang hiển thị (ép kiểu từ Context) — nếu
     * không phải Activity (hiếm, context lạ), gọi callback với `null`
     * ngay, không crash. */
    fun requestFolder(context: Context, callback: (Uri?) -> Unit) {
        val activity = context as? Activity
        if (activity == null) {
            DebugLog.log("FolderPickerBridge: context không phải Activity, không mở được trình chọn thư mục")
            callback(null)
            return
        }
        pendingCallback = callback
        try {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
                addFlags(
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or
                        Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                        Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
                )
            }
            activity.startActivityForResult(intent, RC_FOLDER_PICKER)
        } catch (e: Exception) {
            DebugLog.log("FolderPickerBridge.requestFolder lỗi: ${e.message}")
            pendingCallback = null
            callback(null)
        }
    }

    /** Gọi từ `onActivityResult()` của Activity — trả về `true` nếu ĐÚNG
     * là kết quả của trình chọn thư mục này (Activity tự biết để `return`
     * sớm, không xử lý tiếp như request code khác). */
    fun handleActivityResult(context: Context, requestCode: Int, resultCode: Int, data: Intent?): Boolean {
        if (requestCode != RC_FOLDER_PICKER) return false
        val callback = pendingCallback
        pendingCallback = null
        if (resultCode == Activity.RESULT_OK) {
            val uri = data?.data
            if (uri != null) {
                try {
                    // BẮT BUỘC — không xin quyền bền vững (persistable) thì
                    // quyền ghi vào thư mục này MẤT NGAY khi app bị kill,
                    // lần tải sau sẽ lỗi âm thầm dù người dùng tưởng đã chọn
                    // xong từ trước.
                    context.contentResolver.takePersistableUriPermission(
                        uri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                    )
                } catch (e: Exception) {
                    DebugLog.log("takePersistableUriPermission lỗi: ${e.message}")
                }
            }
            callback?.invoke(uri)
        } else {
            callback?.invoke(null)
        }
        return true
    }
}
