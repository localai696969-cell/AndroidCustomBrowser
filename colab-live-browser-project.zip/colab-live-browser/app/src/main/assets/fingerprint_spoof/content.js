// Ap dung bao ve MAC DINH ngay lap tuc (document_start, truoc khi trang kip
// doc gia tri that), SAU DO co dieu chinh lai theo cau hinh THAT (rieng tung
// khe, do nguoi dung chon) neu native gui kip qua port — trong da so truong
// hop se rat nhanh (cung process, khong qua mang) nen thuong thang truoc ca
// luc trang kip doc gia tri.
(function () {
  var originalToDataURL = HTMLCanvasElement.prototype.toDataURL;
  var originalGetParameter = window.WebGLRenderingContext
    ? WebGLRenderingContext.prototype.getParameter
    : null;

  function applySpoof(cfg) {
    try {
      if (cfg.canvas) {
        HTMLCanvasElement.prototype.toDataURL = function () {
          var ctx = this.getContext('2d');
          if (ctx) {
            try {
              var imageData = ctx.getImageData(0, 0, this.width, this.height);
              for (var i = 0; i < imageData.data.length; i += 4) {
                imageData.data[i] = imageData.data[i] ^ (Math.random() < 0.5 ? 0 : 1);
              }
              ctx.putImageData(imageData, 0, 0);
            } catch (e) {}
          }
          return originalToDataURL.apply(this, arguments);
        };
      }
      if (cfg.webgl && originalGetParameter) {
        WebGLRenderingContext.prototype.getParameter = function (param) {
          if (param === 37445) return cfg.webglVendor;
          if (param === 37446) return cfg.webglRenderer;
          return originalGetParameter.apply(this, arguments);
        };
      }
      if (cfg.hardwareConcurrency) {
        Object.defineProperty(navigator, 'hardwareConcurrency', {
          configurable: true,
          get: function () { return cfg.hardwareConcurrencyValue; }
        });
      }
      if (cfg.deviceMemory && 'deviceMemory' in navigator) {
        Object.defineProperty(navigator, 'deviceMemory', {
          configurable: true,
          get: function () { return cfg.deviceMemoryValue; }
        });
      }
    } catch (e) {}
  }

  applySpoof({
    canvas: true, webgl: true,
    webglVendor: "Intel Inc.", webglRenderer: "Intel Iris OpenGL Engine",
    hardwareConcurrency: true, hardwareConcurrencyValue: 4,
    deviceMemory: true, deviceMemoryValue: 8
  });

  try {
    var port = browser.runtime.connectNative("browser");
    port.onMessage.addListener(function (msg) {
      if (msg && msg.type === "fp_config" && msg.config) {
        applySpoof(msg.config);
      }
    });
  } catch (e) {}
})();
