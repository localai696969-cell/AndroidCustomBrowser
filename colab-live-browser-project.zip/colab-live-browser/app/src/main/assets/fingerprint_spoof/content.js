// Fingerprint Spoof Content Script v4.0
// Chạy ở document_start để giả tín hiệu TRƯỚC KHI trang web kịp đọc.

(function() {
    'use strict';

    /**
     * BUG THẬT tìm được qua đọc code (không suy đoán — grep xác nhận KHÔNG
     * có bất kỳ cơ chế seed/RNG ổn định nào trong toàn file trước đây):
     * mọi nhiễu (canvas, đo chữ, WebGL pixel, audio, timing) đều dùng
     * `Math.random()` THUẦN TÚY — ra giá trị KHÁC NHAU mỗi lần gọi, kể cả
     * đọc cùng 1 API 2 lần liên tiếp trong CÙNG 1 lần tải trang. Đây đúng
     * là kiểu bất ổn định mà các hệ thống chống gian lận như của Google cố
     * ý phát hiện: script bảo mật thật của Google thường tự đọc lại
     * fingerprint API 2-3 lần trong 1 trang để kiểm tra có nhất quán không
     * — nhiễu đổi mỗi lần đọc là dấu hiệu rất giống giả mạo/tự động hoá,
     * có thể là 1 phần nguyên nhân khiến phiên đăng nhập Google bị coi là
     * đáng ngờ và bị đăng xuất. (Chưa thể khẳng định CHẮC CHẮN 100% đây là
     * NGUYÊN NHÂN DUY NHẤT gây "gg bị out" — cần test thật để xác nhận —
     * nhưng đây LÀ MỘT lỗ hổng thật, đáng sửa bất kể có phải nguyên nhân
     * chính hay không.)
     *
     * Sửa: seed 1 PRNG ổn định (mulberry32) NGAY LÚC SCRIPT NÀY CHẠY (1
     * lần cho mỗi lần tải trang) — mọi nhiễu trong CÙNG 1 lần tải trang
     * giờ NHẤT QUÁN (đọc lại nhiều lần ra cùng 1 kiểu nhiễu), giống hành vi
     * 1 thiết bị thật. Đây CHƯA PHẢI ổn định xuyên suốt nhiều lần tải
     * trang/nhiều ngày (cần đồng bộ qua storage mới đạt được, phạm vi lớn
     * hơn, chưa làm ở đây) — chỉ sửa phần bất ổn NGHIÊM TRỌNG NHẤT: nhiễu
     * đổi ngay trong cùng 1 lần tải trang.
     */
    function mulberry32(seed) {
        return function() {
            seed |= 0; seed = (seed + 0x6D2B79F5) | 0;
            let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
            t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
            return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
        };
    }
    // Seed từ Date.now() + 1 lần Math.random() thật — CHỈ dùng Math.random()
    // ĐÚNG 1 LẦN ở đây để khởi tạo seed, không dùng trực tiếp cho nhiễu nữa.
    const pageRandom = mulberry32((Date.now() ^ (Math.random() * 0xFFFFFFFF)) | 0);

    let config = {
        enabled: false,
        canvas: false,
        hardware: false,
        spoofLocale: false,
        audio: false,
        font: false,
        webrtc: false,
        uaSync: false,
        platform: navigator.platform,
        hardwareConcurrency: navigator.hardwareConcurrency || 4,
        deviceMemory: navigator.deviceMemory || 8,
        maxTouchPoints: navigator.maxTouchPoints || 1,
        screenWidth: screen.width,
        screenHeight: screen.height,
        colorDepth: screen.colorDepth,
        pixelRatio: window.devicePixelRatio || 1,
        webglVendor: null,
        webglRenderer: null,
        userAgent: navigator.userAgent,
        timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
        language: navigator.language,
        languages: Array.from(navigator.languages || [navigator.language]),
        locale: navigator.language
    };

    // ===== Apply spoof ngay lập tức =====
    function applySpoof() {
        if (!config.enabled) return;

        const proto = {
            navigator: Object.getPrototypeOf(navigator),
            screen: Object.getPrototypeOf(screen),
            window: window
        };

        // --- Hardware Profile ---
        if (config.hardware) {
            Object.defineProperty(proto.navigator, 'platform', {
                get: () => config.platform,
                configurable: true
            });
            Object.defineProperty(proto.navigator, 'hardwareConcurrency', {
                get: () => config.hardwareConcurrency,
                configurable: true
            });
            Object.defineProperty(proto.navigator, 'deviceMemory', {
                get: () => config.deviceMemory,
                configurable: true
            });
            Object.defineProperty(proto.navigator, 'maxTouchPoints', {
                get: () => config.maxTouchPoints,
                configurable: true
            });
            if (config.uaSync && config.userAgent) {
                Object.defineProperty(proto.navigator, 'userAgent', {
                    get: () => config.userAgent,
                    configurable: true
                });
            }
            Object.defineProperty(proto.screen, 'width', {
                get: () => config.screenWidth,
                configurable: true
            });
            Object.defineProperty(proto.screen, 'height', {
                get: () => config.screenHeight,
                configurable: true
            });
            Object.defineProperty(proto.screen, 'availWidth', {
                get: () => config.screenWidth,
                configurable: true
            });
            Object.defineProperty(proto.screen, 'availHeight', {
                get: () => config.screenHeight - 40,
                configurable: true
            });
            Object.defineProperty(proto.screen, 'colorDepth', {
                get: () => config.colorDepth,
                configurable: true
            });
            Object.defineProperty(proto.screen, 'pixelDepth', {
                get: () => config.colorDepth,
                configurable: true
            });
            Object.defineProperty(proto.window, 'devicePixelRatio', {
                get: () => config.pixelRatio,
                configurable: true
            });
            // Spoof innerWidth/innerHeight
            Object.defineProperty(proto.window, 'innerWidth', {
                get: () => config.screenWidth,
                configurable: true
            });
            Object.defineProperty(proto.window, 'innerHeight', {
                get: () => config.screenHeight,
                configurable: true
            });
            Object.defineProperty(proto.window, 'outerWidth', {
                get: () => config.screenWidth,
                configurable: true
            });
            Object.defineProperty(proto.window, 'outerHeight', {
                get: () => config.screenHeight,
                configurable: true
            });
        }

        // --- Locale Profile ---
        if (config.spoofLocale) {
            const origDate = window.Date;
            const fakeOffset = (() => {
                try {
                    const now = new origDate();
                    const tzDate = new origDate(now.toLocaleString('en-US', { timeZone: config.timezone }));
                    const localDate = new origDate(now.toLocaleString('en-US', { timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone }));
                    return (localDate - tzDate) / 60000;
                } catch (e) { return 0; }
            })();

            Object.defineProperty(proto.window, 'Date', {
                value: class extends origDate {
                    constructor(...args) { super(...args); }
                    getTimezoneOffset() { return fakeOffset; }
                },
                configurable: true
            });

            Object.defineProperty(proto.navigator, 'language', {
                get: () => config.language,
                configurable: true
            });
            Object.defineProperty(proto.navigator, 'languages', {
                get: () => config.languages,
                configurable: true
            });

            const origIntl = window.Intl;
            Object.defineProperty(proto.window, 'Intl', {
                value: new Proxy(origIntl, {
                    construct(target, args) {
                        if (args[0] === 'DateTimeFormat') {
                            return new origIntl.DateTimeFormat(config.locale, args[1]);
                        }
                        return new target(...args);
                    }
                }),
                configurable: true
            });
        }

        // --- Canvas Fingerprint ---
        if (config.canvas) {
            const origToDataURL = HTMLCanvasElement.prototype.toDataURL;
            const origGetImageData = CanvasRenderingContext2D.prototype.getImageData;
            const origGetContext = HTMLCanvasElement.prototype.getContext;

            /**
             * BUG THẬT đã sửa: hàm này TRƯỚC ĐÂY chỉ gọi lại hàm gốc và trả
             * y nguyên kết quả — KHÔNG hề thêm nhiễu gì cả! Trong khi
             * `toDataURL()` mới chính là cách canvas fingerprint PHỔ BIẾN
             * NHẤT (hầu hết thư viện fingerprint, kể cả FingerprintJS, dùng
             * đúng hàm này) — bật toggle "Canvas fingerprint" tưởng đã bảo
             * vệ nhưng thực ra hình ảnh canvas thật vẫn lộ nguyên vẹn qua
             * đường này. Chỉ có `getImageData()` (ít trang gọi trực tiếp
             * hơn) là có nhiễu thật.
             *
             * Sửa: vẽ canvas gốc sang 1 canvas TẠM (không đụng canvas thật
             * đang hiển thị trên trang — tránh làm sai hình ảnh người dùng
             * thấy), thêm nhiễu vào bản sao đó, rồi mới encode base64 từ bản
             * sao. Dùng `drawImage()` để sao chép nên hoạt động ĐÚNG cho cả
             * canvas có context WebGL (không chỉ context 2D) — drawImage lấy
             * đúng ảnh đã render ra, không quan tâm loại context nguồn.
             */
            HTMLCanvasElement.prototype.toDataURL = function(...args) {
                try {
                    const tmp = document.createElement('canvas');
                    tmp.width = this.width || 1;
                    tmp.height = this.height || 1;
                    const tmpCtx = tmp.getContext('2d');
                    tmpCtx.drawImage(this, 0, 0);
                    const imageData = tmpCtx.getImageData(0, 0, tmp.width, tmp.height);
                    for (let i = 0; i < imageData.data.length; i += 4) {
                        if (pageRandom() < 0.01) {
                            imageData.data[i] = (imageData.data[i] + 1) % 256;
                        }
                    }
                    tmpCtx.putImageData(imageData, 0, 0);
                    return origToDataURL.apply(tmp, args);
                } catch (e) {
                    // Canvas rỗng/kích thước 0/lỗi cross-origin taint — trả về
                    // kết quả gốc thay vì crash trang.
                    return origToDataURL.apply(this, args);
                }
            };

            CanvasRenderingContext2D.prototype.getImageData = function(...args) {
                const imageData = origGetImageData.apply(this, args);
                for (let i = 0; i < imageData.data.length; i += 4) {
                    if (pageRandom() < 0.01) {
                        imageData.data[i] = (imageData.data[i] + 1) % 256;
                    }
                }
                return imageData;
            };

            // CanvasRenderingContext2D — spoof text metrics
            const origMeasureText = CanvasRenderingContext2D.prototype.measureText;
            CanvasRenderingContext2D.prototype.measureText = function(text) {
                const metrics = origMeasureText.call(this, text);
                // Thêm nhiễu nhẹ vào width
                if (metrics.width) {
                    Object.defineProperty(metrics, 'width', {
                        value: metrics.width + (pageRandom() - 0.5) * 0.02,
                        configurable: true
                    });
                }
                return metrics;
            };
        }

        // --- WebGL Spoof ---
        if (config.hardware && config.webglVendor) {
            const origGetParameter = WebGLRenderingContext.prototype.getParameter;
            WebGLRenderingContext.prototype.getParameter = function(parameter) {
                if (parameter === 0x1F00) return config.webglVendor;
                if (parameter === 0x1F01) return config.webglRenderer;
                return origGetParameter.call(this, parameter);
            };

            // WebGL2
            if (window.WebGL2RenderingContext) {
                const origGetParameter2 = WebGL2RenderingContext.prototype.getParameter;
                WebGL2RenderingContext.prototype.getParameter = function(parameter) {
                    if (parameter === 0x1F00) return config.webglVendor;
                    if (parameter === 0x1F01) return config.webglRenderer;
                    return origGetParameter2.call(this, parameter);
                };
            }

            // Spoof getSupportedExtensions
            const origGetSupportedExtensions = WebGLRenderingContext.prototype.getSupportedExtensions;
            WebGLRenderingContext.prototype.getSupportedExtensions = function() {
                const extensions = origGetSupportedExtensions.call(this) || [];
                // Trả về danh sách chuẩn, không để lộ GPU thật
                return extensions.filter(ext => !ext.includes('WEBGL_debug'));
            };

            /**
             * LỖ HỔNG THẬT đã vá: fingerprint qua WebGL không chỉ đọc chuỗi
             * vendor/renderer (đã spoof ở trên) mà còn có thể đọc THẲNG pixel
             * đã render ra qua `gl.readPixels()` — cách này KHÔNG đi qua
             * `canvas.toDataURL()` nên hoàn toàn lọt qua noise đã thêm ở phần
             * Canvas Fingerprint phía trên. Vì pixel render ra phụ thuộc GPU
             * thật (driver, làm tròn số thực khác nhau giữa các GPU), đây là
             * 1 trong những cách fingerprint khó giả nhất — cùng hướng thêm
             * nhiễu nhẹ vào buffer pixel đọc được, giống cách đã làm với
             * `getImageData()`.
             */
            const addPixelNoise = (pixels) => {
                if (!pixels || typeof pixels.length !== 'number') return; // biến thể ghi vào PIXEL_PACK_BUFFER (offset số, không phải TypedArray) — bỏ qua, không có gì để thêm nhiễu
                for (let i = 0; i < pixels.length; i += 4) {
                    if (pageRandom() < 0.01) {
                        pixels[i] = (pixels[i] + 1) % 256;
                    }
                }
            };
            const origReadPixels = WebGLRenderingContext.prototype.readPixels;
            WebGLRenderingContext.prototype.readPixels = function(...args) {
                origReadPixels.apply(this, args);
                addPixelNoise(args[6]);
            };
            if (window.WebGL2RenderingContext) {
                const origReadPixels2 = WebGL2RenderingContext.prototype.readPixels;
                WebGL2RenderingContext.prototype.readPixels = function(...args) {
                    origReadPixels2.apply(this, args);
                    addPixelNoise(args[6]);
                };
            }
        }

        // --- Audio Fingerprint ---
        if (config.audio) {
            const origCreateAnalyser = AudioContext.prototype.createAnalyser;
            AudioContext.prototype.createAnalyser = function(...args) {
                const analyser = origCreateAnalyser.apply(this, args);
                const origGetFloatFrequencyData = analyser.getFloatFrequencyData;
                analyser.getFloatFrequencyData = function(array) {
                    origGetFloatFrequencyData.call(this, array);
                    for (let i = 0; i < array.length; i++) {
                        if (pageRandom() < 0.005) {
                            array[i] += (pageRandom() - 0.5) * 0.1;
                        }
                    }
                };
                return analyser;
            };

            const origCreateOscillator = AudioContext.prototype.createOscillator;
            AudioContext.prototype.createOscillator = function(...args) {
                const osc = origCreateOscillator.apply(this, args);
                return osc;
            };

            // OfflineAudioContext — giả sample rate
            const origOfflineAudioContext = window.OfflineAudioContext;
            if (origOfflineAudioContext) {
                Object.defineProperty(proto.window, 'OfflineAudioContext', {
                    value: class extends origOfflineAudioContext {
                        constructor(...args) {
                            super(...args);
                        }
                    },
                    configurable: true
                });
            }
        }

        // --- Font Enumeration ---
        if (config.font) {
            const commonFonts = [
                'Arial', 'Arial Black', 'Arial Narrow', 'Calibri', 'Cambria',
                'Comic Sans MS', 'Courier New', 'Georgia', 'Helvetica', 'Impact',
                'Lucida Console', 'Lucida Sans Unicode', 'Microsoft Sans Serif',
                'Palatino Linotype', 'Segoe UI', 'Tahoma', 'Times New Roman',
                'Trebuchet MS', 'Verdana', 'Wingdings'
            ];

            if (window.queryLocalFonts) {
                window.queryLocalFonts = async function() {
                    return commonFonts.map(name => ({
                        family: name,
                        fullName: name,
                        postscriptName: name.replace(/\s/g, ''),
                        style: 'Regular'
                    }));
                };
            }

            if (document.fonts && document.fonts.check) {
                const origCheck = document.fonts.check;
                document.fonts.check = function(font, text) {
                    const fontName = font.toLowerCase();
                    for (const common of commonFonts) {
                        if (fontName.includes(common.toLowerCase())) {
                            return true;
                        }
                    }
                    return origCheck.call(this, font, text);
                };
            }

            // Spoof FontFaceSet
            if (document.fonts && document.fonts.values) {
                const origValues = document.fonts.values;
                document.fonts.values = function() {
                    return commonFonts.map(name => ({
                        family: name,
                        status: 'loaded'
                    }))[Symbol.iterator]();
                };
            }
        }

        // --- WebRTC Block ---
        if (config.webrtc) {
            const props = ['RTCPeerConnection', 'webkitRTCPeerConnection', 'RTCDataChannel',
                'RTCSessionDescription', 'RTCIceCandidate', 'RTCSctpTransport',
                'RTCDtlsTransport', 'RTCIceTransport', 'RTCRtpSender', 'RTCRtpReceiver'];
            props.forEach(prop => {
                Object.defineProperty(proto.window, prop, {
                    get: () => undefined,
                    configurable: true
                });
            });
        }

        // --- Performance Spoof ---
        if (config.hardware) {
            const origNow = performance.now.bind(performance);
            performance.now = function() {
                return origNow() + (pageRandom() - 0.5) * 0.5;
            };
        }
    }

    // ===== Nhận config từ native =====
    function setupPort() {
        try {
            const port = browser.runtime.connectNative("browser");
            port.onMessage.addListener((msg) => {
                if (msg && msg.config) {
                    config = { ...config, ...msg.config };
                    applySpoof();
                }
            });
            port.postMessage({ action: "getConfig" });
        } catch (e) {
            console.log("Fingerprint spoof: cannot connect to native port");
        }
    }

    // ===== Chạy ngay =====
    applySpoof();
    if (typeof browser !== 'undefined') {
        setupPort();
    }

})();
