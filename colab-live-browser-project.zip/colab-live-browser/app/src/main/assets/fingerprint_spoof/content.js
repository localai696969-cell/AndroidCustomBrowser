// Fingerprint Spoof Content Script v4.0
// Chạy ở document_start để giả tín hiệu TRƯỚC KHI trang web kịp đọc.

(function() {
    'use strict';

    let config = {
        enabled: false,
        canvas: false,
        hardware: false,
        spoofLocale: false,
        audio: false,
        font: false,
        webrtc: false,
        uaSync: false,
        platform: navigator.platform,
        hardwareConcurrency: navigator.hardwareConcurrency || 4,
        deviceMemory: navigator.deviceMemory || 8,
        maxTouchPoints: navigator.maxTouchPoints || 1,
        screenWidth: screen.width,
        screenHeight: screen.height,
        colorDepth: screen.colorDepth,
        pixelRatio: window.devicePixelRatio || 1,
        webglVendor: null,
        webglRenderer: null,
        userAgent: navigator.userAgent,
        timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
        language: navigator.language,
        languages: Array.from(navigator.languages || [navigator.language]),
        locale: navigator.language
    };

    // ===== Apply spoof ngay lập tức =====
    function applySpoof() {
        if (!config.enabled) return;

        const proto = {
            navigator: Object.getPrototypeOf(navigator),
            screen: Object.getPrototypeOf(screen),
            window: window
        };

        // --- Hardware Profile ---
        if (config.hardware) {
            Object.defineProperty(proto.navigator, 'platform', {
                get: () => config.platform,
                configurable: true
            });
            Object.defineProperty(proto.navigator, 'hardwareConcurrency', {
                get: () => config.hardwareConcurrency,
                configurable: true
            });
            Object.defineProperty(proto.navigator, 'deviceMemory', {
                get: () => config.deviceMemory,
                configurable: true
            });
            Object.defineProperty(proto.navigator, 'maxTouchPoints', {
                get: () => config.maxTouchPoints,
                configurable: true
            });
            if (config.uaSync && config.userAgent) {
                Object.defineProperty(proto.navigator, 'userAgent', {
                    get: () => config.userAgent,
                    configurable: true
                });
            }
            Object.defineProperty(proto.screen, 'width', {
                get: () => config.screenWidth,
                configurable: true
            });
            Object.defineProperty(proto.screen, 'height', {
                get: () => config.screenHeight,
                configurable: true
            });
            Object.defineProperty(proto.screen, 'availWidth', {
                get: () => config.screenWidth,
                configurable: true
            });
            Object.defineProperty(proto.screen, 'availHeight', {
                get: () => config.screenHeight - 40,
                configurable: true
            });
            Object.defineProperty(proto.screen, 'colorDepth', {
                get: () => config.colorDepth,
                configurable: true
            });
            Object.defineProperty(proto.screen, 'pixelDepth', {
                get: () => config.colorDepth,
                configurable: true
            });
            Object.defineProperty(proto.window, 'devicePixelRatio', {
                get: () => config.pixelRatio,
                configurable: true
            });
            // Spoof innerWidth/innerHeight
            Object.defineProperty(proto.window, 'innerWidth', {
                get: () => config.screenWidth,
                configurable: true
            });
            Object.defineProperty(proto.window, 'innerHeight', {
                get: () => config.screenHeight,
                configurable: true
            });
            Object.defineProperty(proto.window, 'outerWidth', {
                get: () => config.screenWidth,
                configurable: true
            });
            Object.defineProperty(proto.window, 'outerHeight', {
                get: () => config.screenHeight,
                configurable: true
            });
        }

        // --- Locale Profile ---
        if (config.spoofLocale) {
            const origDate = window.Date;
            const fakeOffset = (() => {
                try {
                    const now = new origDate();
                    const tzDate = new origDate(now.toLocaleString('en-US', { timeZone: config.timezone }));
                    const localDate = new origDate(now.toLocaleString('en-US', { timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone }));
                    return (localDate - tzDate) / 60000;
                } catch (e) { return 0; }
            })();

            Object.defineProperty(proto.window, 'Date', {
                value: class extends origDate {
                    constructor(...args) { super(...args); }
                    getTimezoneOffset() { return fakeOffset; }
                },
                configurable: true
            });

            Object.defineProperty(proto.navigator, 'language', {
                get: () => config.language,
                configurable: true
            });
            Object.defineProperty(proto.navigator, 'languages', {
                get: () => config.languages,
                configurable: true
            });

            const origIntl = window.Intl;
            Object.defineProperty(proto.window, 'Intl', {
                value: new Proxy(origIntl, {
                    construct(target, args) {
                        if (args[0] === 'DateTimeFormat') {
                            return new origIntl.DateTimeFormat(config.locale, args[1]);
                        }
                        return new target(...args);
                    }
                }),
                configurable: true
            });
        }

        // --- Canvas Fingerprint ---
        if (config.canvas) {
            const origToDataURL = HTMLCanvasElement.prototype.toDataURL;
            const origGetImageData = CanvasRenderingContext2D.prototype.getImageData;
            const origGetContext = HTMLCanvasElement.prototype.getContext;

            HTMLCanvasElement.prototype.toDataURL = function(...args) {
                const result = origToDataURL.apply(this, args);
                return result;
            };

            CanvasRenderingContext2D.prototype.getImageData = function(...args) {
                const imageData = origGetImageData.apply(this, args);
                for (let i = 0; i < imageData.data.length; i += 4) {
                    if (Math.random() < 0.01) {
                        imageData.data[i] = (imageData.data[i] + 1) % 256;
                    }
                }
                return imageData;
            };

            // CanvasRenderingContext2D — spoof text metrics
            const origMeasureText = CanvasRenderingContext2D.prototype.measureText;
            CanvasRenderingContext2D.prototype.measureText = function(text) {
                const metrics = origMeasureText.call(this, text);
                // Thêm nhiễu nhẹ vào width
                if (metrics.width) {
                    Object.defineProperty(metrics, 'width', {
                        value: metrics.width + (Math.random() - 0.5) * 0.02,
                        configurable: true
                    });
                }
                return metrics;
            };
        }

        // --- WebGL Spoof ---
        if (config.hardware && config.webglVendor) {
            const origGetParameter = WebGLRenderingContext.prototype.getParameter;
            WebGLRenderingContext.prototype.getParameter = function(parameter) {
                if (parameter === 0x1F00) return config.webglVendor;
                if (parameter === 0x1F01) return config.webglRenderer;
                return origGetParameter.call(this, parameter);
            };

            // WebGL2
            if (window.WebGL2RenderingContext) {
                const origGetParameter2 = WebGL2RenderingContext.prototype.getParameter;
                WebGL2RenderingContext.prototype.getParameter = function(parameter) {
                    if (parameter === 0x1F00) return config.webglVendor;
                    if (parameter === 0x1F01) return config.webglRenderer;
                    return origGetParameter2.call(this, parameter);
                };
            }

            // Spoof getSupportedExtensions
            const origGetSupportedExtensions = WebGLRenderingContext.prototype.getSupportedExtensions;
            WebGLRenderingContext.prototype.getSupportedExtensions = function() {
                const extensions = origGetSupportedExtensions.call(this) || [];
                // Trả về danh sách chuẩn, không để lộ GPU thật
                return extensions.filter(ext => !ext.includes('WEBGL_debug'));
            };
        }

        // --- Audio Fingerprint ---
        if (config.audio) {
            const origCreateAnalyser = AudioContext.prototype.createAnalyser;
            AudioContext.prototype.createAnalyser = function(...args) {
                const analyser = origCreateAnalyser.apply(this, args);
                const origGetFloatFrequencyData = analyser.getFloatFrequencyData;
                analyser.getFloatFrequencyData = function(array) {
                    origGetFloatFrequencyData.call(this, array);
                    for (let i = 0; i < array.length; i++) {
                        if (Math.random() < 0.005) {
                            array[i] += (Math.random() - 0.5) * 0.1;
                        }
                    }
                };
                return analyser;
            };

            const origCreateOscillator = AudioContext.prototype.createOscillator;
            AudioContext.prototype.createOscillator = function(...args) {
                const osc = origCreateOscillator.apply(this, args);
                return osc;
            };

            // OfflineAudioContext — giả sample rate
            const origOfflineAudioContext = window.OfflineAudioContext;
            if (origOfflineAudioContext) {
                Object.defineProperty(proto.window, 'OfflineAudioContext', {
                    value: class extends origOfflineAudioContext {
                        constructor(...args) {
                            super(...args);
                        }
                    },
                    configurable: true
                });
            }
        }

        // --- Font Enumeration ---
        if (config.font) {
            const commonFonts = [
                'Arial', 'Arial Black', 'Arial Narrow', 'Calibri', 'Cambria',
                'Comic Sans MS', 'Courier New', 'Georgia', 'Helvetica', 'Impact',
                'Lucida Console', 'Lucida Sans Unicode', 'Microsoft Sans Serif',
                'Palatino Linotype', 'Segoe UI', 'Tahoma', 'Times New Roman',
                'Trebuchet MS', 'Verdana', 'Wingdings'
            ];

            if (window.queryLocalFonts) {
                window.queryLocalFonts = async function() {
                    return commonFonts.map(name => ({
                        family: name,
                        fullName: name,
                        postscriptName: name.replace(/\s/g, ''),
                        style: 'Regular'
                    }));
                };
            }

            if (document.fonts && document.fonts.check) {
                const origCheck = document.fonts.check;
                document.fonts.check = function(font, text) {
                    const fontName = font.toLowerCase();
                    for (const common of commonFonts) {
                        if (fontName.includes(common.toLowerCase())) {
                            return true;
                        }
                    }
                    return origCheck.call(this, font, text);
                };
            }

            // Spoof FontFaceSet
            if (document.fonts && document.fonts.values) {
                const origValues = document.fonts.values;
                document.fonts.values = function() {
                    return commonFonts.map(name => ({
                        family: name,
                        status: 'loaded'
                    }))[Symbol.iterator]();
                };
            }
        }

        // --- WebRTC Block ---
        if (config.webrtc) {
            const props = ['RTCPeerConnection', 'webkitRTCPeerConnection', 'RTCDataChannel',
                'RTCSessionDescription', 'RTCIceCandidate', 'RTCSctpTransport',
                'RTCDtlsTransport', 'RTCIceTransport', 'RTCRtpSender', 'RTCRtpReceiver'];
            props.forEach(prop => {
                Object.defineProperty(proto.window, prop, {
                    get: () => undefined,
                    configurable: true
                });
            });
        }

        // --- Performance Spoof ---
        if (config.hardware) {
            const origNow = performance.now.bind(performance);
            performance.now = function() {
                return origNow() + (Math.random() - 0.5) * 0.5;
            };
        }
    }

    // ===== Nhận config từ native =====
    function setupPort() {
        try {
            const port = browser.runtime.connectNative("browser");
            port.onMessage.addListener((msg) => {
                if (msg && msg.config) {
                    config = { ...config, ...msg.config };
                    applySpoof();
                }
            });
            port.postMessage({ action: "getConfig" });
        } catch (e) {
            console.log("Fingerprint spoof: cannot connect to native port");
        }
    }

    // ===== Chạy ngay =====
    applySpoof();
    if (typeof browser !== 'undefined') {
        setupPort();
    }

})();
