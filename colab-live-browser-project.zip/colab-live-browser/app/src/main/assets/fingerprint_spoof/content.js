// Giả fingerprint — chạy NGAY (document_start), TRƯỚC khi script của trang
// kịp đọc các giá trị này. Tách riêng khỏi eval_bridge để feature này bật/tắt
// độc lập được (đăng ký/không đăng ký cả extension này lúc khởi động
// GeckoRuntime, xem GeckoRuntimeProvider.kt) mà không ảnh hưởng eval bridge.
//
// CHỈ che được: canvas fingerprint, WebGL vendor/renderer,
// hardwareConcurrency, deviceMemory.
// CHƯA che: rò IP thật qua WebRTC, audio fingerprint, liệt kê font cài sẵn,
// timezone/locale, User-Agent chi tiết (dùng "Chế độ máy tính" trong app
// cho phần đó — khác cơ chế này).
// CHƯA làm: giá trị giả hiện tại CỐ ĐỊNH GIỐNG NHAU cho mọi khe/profile —
// muốn mỗi profile có 1 fingerprint riêng biệt (đúng bài toán multi-account),
// cần thêm seed ngẫu nhiên theo slotIndex, chưa triển khai.
(function () {
  try {
    var origToDataURL = HTMLCanvasElement.prototype.toDataURL;
    HTMLCanvasElement.prototype.toDataURL = function () {
      var ctx = this.getContext('2d');
      if (ctx) {
        try {
          var imageData = ctx.getImageData(0, 0, this.width, this.height);
          for (var i = 0; i < imageData.data.length; i += 4) {
            imageData.data[i] = imageData.data[i] ^ (Math.random() < 0.5 ? 0 : 1);
          }
          ctx.putImageData(imageData, 0, 0);
        } catch (e) {}
      }
      return origToDataURL.apply(this, arguments);
    };

    if (window.WebGLRenderingContext) {
      var origGetParameter = WebGLRenderingContext.prototype.getParameter;
      WebGLRenderingContext.prototype.getParameter = function (param) {
        if (param === 37445) return "Intel Inc.";
        if (param === 37446) return "Intel Iris OpenGL Engine";
        return origGetParameter.apply(this, arguments);
      };
    }

    Object.defineProperty(navigator, 'hardwareConcurrency', {
      get: function () { return 4; }
    });
    if ('deviceMemory' in navigator) {
      Object.defineProperty(navigator, 'deviceMemory', {
        get: function () { return 8; }
      });
    }
  } catch (e) {}
})();
