// Ap dung bao ve MAC DINH ngay lap tuc (document_start), SAU DO doi lai theo
// cau hinh THAT (ho so tron goi, rieng tung khe) neu native gui kip qua port.
(function () {
  var originalToDataURL = HTMLCanvasElement.prototype.toDataURL;
  var originalGetParameter = window.WebGLRenderingContext
    ? WebGLRenderingContext.prototype.getParameter
    : null;
  var originalDateTimeFormat = Intl.DateTimeFormat;
  var originalGetTimezoneOffset = Date.prototype.getTimezoneOffset;

  function applySpoof(cfg) {
    try {
      if (cfg.canvas) {
        HTMLCanvasElement.prototype.toDataURL = function () {
          var ctx = this.getContext('2d');
          if (ctx) {
            try {
              var imageData = ctx.getImageData(0, 0, this.width, this.height);
              for (var i = 0; i < imageData.data.length; i += 4) {
                imageData.data[i] = imageData.data[i] ^ (Math.random() < 0.5 ? 0 : 1);
              }
              ctx.putImageData(imageData, 0, 0);
            } catch (e) {}
          }
          return originalToDataURL.apply(this, arguments);
        };
      }

      if (cfg.hwProfile) {
        if (originalGetParameter) {
          WebGLRenderingContext.prototype.getParameter = function (param) {
            if (param === 37445) return cfg.webglVendor;
            if (param === 37446) return cfg.webglRenderer;
            return originalGetParameter.apply(this, arguments);
          };
        }
        Object.defineProperty(navigator, 'hardwareConcurrency', {
          configurable: true, get: function () { return cfg.hardwareConcurrencyValue; }
        });
        if ('deviceMemory' in navigator) {
          Object.defineProperty(navigator, 'deviceMemory', {
            configurable: true, get: function () { return cfg.deviceMemoryValue; }
          });
        }
        Object.defineProperty(navigator, 'platform', {
          configurable: true, get: function () { return cfg.platform; }
        });
      }

      if (cfg.locale) {
        Date.prototype.getTimezoneOffset = function () { return -cfg.timezoneOffsetMinutes; };
        var FakeDateTimeFormat = function (locales, options) {
          options = options || {};
          if (!options.timeZone) options.timeZone = cfg.timezoneName;
          return new originalDateTimeFormat(locales, options);
        };
        FakeDateTimeFormat.prototype = originalDateTimeFormat.prototype;
        Intl.DateTimeFormat = FakeDateTimeFormat;

        Object.defineProperty(navigator, 'language', {
          configurable: true, get: function () { return cfg.languageValue; }
        });
        Object.defineProperty(navigator, 'languages', {
          configurable: true, get: function () { return [cfg.languageValue]; }
        });
      }

      if (cfg.blockWebrtc) {
        try {
          Object.defineProperty(window, 'RTCPeerConnection', { get: function () { return undefined; } });
          Object.defineProperty(window, 'webkitRTCPeerConnection', { get: function () { return undefined; } });
          Object.defineProperty(window, 'RTCDataChannel', { get: function () { return undefined; } });
        } catch (e) {}
      }
    } catch (e) {}
  }

  // Bảo vệ mặc định (an toàn khi config thật tới trễ)
  applySpoof({
    canvas: true,
    hwProfile: true, platform: "Win32",
    webglVendor: "Intel Inc.", webglRenderer: "Intel Iris OpenGL Engine",
    hardwareConcurrencyValue: 4, deviceMemoryValue: 8,
    locale: true, timezoneName: "Asia/Ho_Chi_Minh", timezoneOffsetMinutes: 420, languageValue: "vi-VN",
    blockWebrtc: true
  });

  try {
    var port = browser.runtime.connectNative("browser");
    port.onMessage.addListener(function (msg) {
      if (msg && msg.type === "fp_config" && msg.config) {
        applySpoof(msg.config);
      }
    });
  } catch (e) {}
})();
