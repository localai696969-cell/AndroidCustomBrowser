// Fingerprint Spoof Content Script v4.0
// Chạy ở document_start để giả tín hiệu TRƯỚC KHI trang web kịp đọc.

(function() {
    'use strict';

    /**
     * TỰ SỬA LẠI (người dùng chỉ ra đúng — bản vá trước chỉ seed ổn định
     * TRONG 1 lần tải trang, KHÔNG cố định theo hồ sơ, khiến nhiễu vẫn đổi
     * khác nhau mỗi lần đăng nhập/mỗi lần tải trang mới — đúng như người
     * dùng phản ánh, không phải như hardware/locale vốn đã cố định đúng
     * theo hồ sơ từ trước). Giờ dùng seed THẬT nhận từ Kotlin
     * (`config.noiseSeed`, sinh 1 lần duy nhất, lưu bền qua AppPrefs theo
     * đúng hồ sơ — xem `GeckoViewEngine.getOrCreateNoiseSeedForSlot()`) —
     * `pageRandom` bên dưới chỉ là giá trị TẠM dùng cho khoảng thời gian
     * ngắn TRƯỚC KHI config từ native kịp tới (document_start chạy trước
     * cả khi có thể connect port xong) — ngay khi nhận được config thật,
     * `pageRandom` được GÁN LẠI (reseed) bằng seed cố định theo hồ sơ ở
     * `setupPort()` bên dưới, TRƯỚC khi `applySpoof()` thật sự có tác dụng
     * (lần gọi applySpoof() đầu tiên ở cuối file luôn no-op vì
     * config.enabled=false lúc đó — chỉ lần gọi lại BÊN TRONG
     * port.onMessage mới thật sự áp dụng, nên reseed kịp trước khi cần).
     */
    function mulberry32(seed) {
        return function() {
            seed |= 0; seed = (seed + 0x6D2B79F5) | 0;
            let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
            t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
            return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
        };
    }
    // Seed TẠM (fallback) — chỉ dùng trong khoảng ngắn trước khi config
    // thật từ native tới. `let` (không phải `const`) vì sẽ bị GÁN LẠI khi
    // nhận noiseSeed thật — mọi closure dùng pageRandom() bên dưới đọc lại
    // biến này MỖI LẦN GỌI (JS closure theo binding, không theo giá trị
    // tại thời điểm định nghĩa), nên gán lại sớm là đủ, không cần sửa các
    // chỗ gọi pageRandom() khác.
    let pageRandom = mulberry32((Date.now() ^ (Math.random() * 0xFFFFFFFF)) | 0);

    let config = {
        enabled: false,
        canvas: false,
        hardware: false,
        spoofLocale: false,
        audio: false,
        font: false,
        webrtc: false,
        uaSync: false,
        platform: navigator.platform,
        hardwareConcurrency: navigator.hardwareConcurrency || 4,
        deviceMemory: navigator.deviceMemory || 8,
        maxTouchPoints: navigator.maxTouchPoints || 1,
        screenWidth: screen.width,
        screenHeight: screen.height,
        colorDepth: screen.colorDepth,
        pixelRatio: window.devicePixelRatio || 1,
        webglVendor: null,
        webglRenderer: null,
        userAgent: navigator.userAgent,
        timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
        language: navigator.language,
        languages: Array.from(navigator.languages || [navigator.language]),
        locale: navigator.language
    };

    // ===== Apply spoof ngay lập tức =====
    function applySpoof() {
        if (!config.enabled) return;

        const proto = {
            navigator: Object.getPrototypeOf(navigator),
            screen: Object.getPrototypeOf(screen),
            window: window
        };

        // --- Hardware Profile ---
        if (config.hardware) {
            Object.defineProperty(proto.navigator, 'platform', {
                get: () => config.platform,
                configurable: true
            });
            Object.defineProperty(proto.navigator, 'hardwareConcurrency', {
                get: () => config.hardwareConcurrency,
                configurable: true
            });
            Object.defineProperty(proto.navigator, 'deviceMemory', {
                get: () => config.deviceMemory,
                configurable: true
            });
            Object.defineProperty(proto.navigator, 'maxTouchPoints', {
                get: () => config.maxTouchPoints,
                configurable: true
            });
            if (config.uaSync && config.userAgent) {
                Object.defineProperty(proto.navigator, 'userAgent', {
                    get: () => config.userAgent,
                    configurable: true
                });
            }
            Object.defineProperty(proto.screen, 'width', {
                get: () => config.screenWidth,
                configurable: true
            });
            Object.defineProperty(proto.screen, 'height', {
                get: () => config.screenHeight,
                configurable: true
            });
            Object.defineProperty(proto.screen, 'availWidth', {
                get: () => config.screenWidth,
                configurable: true
            });
            Object.defineProperty(proto.screen, 'availHeight', {
                get: () => config.screenHeight - 40,
                configurable: true
            });
            Object.defineProperty(proto.screen, 'colorDepth', {
                get: () => config.colorDepth,
                configurable: true
            });
            Object.defineProperty(proto.screen, 'pixelDepth', {
                get: () => config.colorDepth,
                configurable: true
            });
            Object.defineProperty(proto.window, 'devicePixelRatio', {
                get: () => config.pixelRatio,
                configurable: true
            });
            // Spoof innerWidth/innerHeight
            Object.defineProperty(proto.window, 'innerWidth', {
                get: () => config.screenWidth,
                configurable: true
            });
            Object.defineProperty(proto.window, 'innerHeight', {
                get: () => config.screenHeight,
                configurable: true
            });
            Object.defineProperty(proto.window, 'outerWidth', {
                get: () => config.screenWidth,
                configurable: true
            });
            Object.defineProperty(proto.window, 'outerHeight', {
                get: () => config.screenHeight,
                configurable: true
            });
        }

        // --- Locale Profile ---
        if (config.spoofLocale) {
            const origDate = window.Date;
            const fakeOffset = (() => {
                try {
                    const now = new origDate();
                    const tzDate = new origDate(now.toLocaleString('en-US', { timeZone: config.timezone }));
                    const localDate = new origDate(now.toLocaleString('en-US', { timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone }));
                    return (localDate - tzDate) / 60000;
                } catch (e) { return 0; }
            })();

            Object.defineProperty(proto.window, 'Date', {
                value: class extends origDate {
                    constructor(...args) { super(...args); }
                    getTimezoneOffset() { return fakeOffset; }
                },
                configurable: true
            });

            Object.defineProperty(proto.navigator, 'language', {
                get: () => config.language,
                configurable: true
            });
            Object.defineProperty(proto.navigator, 'languages', {
                get: () => config.languages,
                configurable: true
            });

            const origIntl = window.Intl;
            Object.defineProperty(proto.window, 'Intl', {
                value: new Proxy(origIntl, {
                    construct(target, args) {
                        if (args[0] === 'DateTimeFormat') {
                            return new origIntl.DateTimeFormat(config.locale, args[1]);
                        }
                        return new target(...args);
                    }
                }),
                configurable: true
            });
        }

        // --- Canvas Fingerprint ---
        if (config.canvas) {
            const origToDataURL = HTMLCanvasElement.prototype.toDataURL;
            const origGetImageData = CanvasRenderingContext2D.prototype.getImageData;
            const origGetContext = HTMLCanvasElement.prototype.getContext;

            /**
             * BUG THẬT đã sửa: hàm này TRƯỚC ĐÂY chỉ gọi lại hàm gốc và trả
             * y nguyên kết quả — KHÔNG hề thêm nhiễu gì cả! Trong khi
             * `toDataURL()` mới chính là cách canvas fingerprint PHỔ BIẾN
             * NHẤT (hầu hết thư viện fingerprint, kể cả FingerprintJS, dùng
             * đúng hàm này) — bật toggle "Canvas fingerprint" tưởng đã bảo
             * vệ nhưng thực ra hình ảnh canvas thật vẫn lộ nguyên vẹn qua
             * đường này. Chỉ có `getImageData()` (ít trang gọi trực tiếp
             * hơn) là có nhiễu thật.
             *
             * Sửa: vẽ canvas gốc sang 1 canvas TẠM (không đụng canvas thật
             * đang hiển thị trên trang — tránh làm sai hình ảnh người dùng
             * thấy), thêm nhiễu vào bản sao đó, rồi mới encode base64 từ bản
             * sao. Dùng `drawImage()` để sao chép nên hoạt động ĐÚNG cho cả
             * canvas có context WebGL (không chỉ context 2D) — drawImage lấy
             * đúng ảnh đã render ra, không quan tâm loại context nguồn.
             */
            HTMLCanvasElement.prototype.toDataURL = function(...args) {
                try {
                    const tmp = document.createElement('canvas');
                    tmp.width = this.width || 1;
                    tmp.height = this.height || 1;
                    const tmpCtx = tmp.getContext('2d');
                    tmpCtx.drawImage(this, 0, 0);
                    const imageData = tmpCtx.getImageData(0, 0, tmp.width, tmp.height);
                    for (let i = 0; i < imageData.data.length; i += 4) {
                        if (pageRandom() < 0.01) {
                            imageData.data[i] = (imageData.data[i] + 1) % 256;
                        }
                    }
                    tmpCtx.putImageData(imageData, 0, 0);
                    return origToDataURL.apply(tmp, args);
                } catch (e) {
                    // Canvas rỗng/kích thước 0/lỗi cross-origin taint — trả về
                    // kết quả gốc thay vì crash trang.
                    return origToDataURL.apply(this, args);
                }
            };

            CanvasRenderingContext2D.prototype.getImageData = function(...args) {
                const imageData = origGetImageData.apply(this, args);
                for (let i = 0; i < imageData.data.length; i += 4) {
                    if (pageRandom() < 0.01) {
                        imageData.data[i] = (imageData.data[i] + 1) % 256;
                    }
                }
                return imageData;
            };

            // CanvasRenderingContext2D — spoof text metrics
            const origMeasureText = CanvasRenderingContext2D.prototype.measureText;
            CanvasRenderingContext2D.prototype.measureText = function(text) {
                const metrics = origMeasureText.call(this, text);
                // Thêm nhiễu nhẹ vào width
                if (metrics.width) {
                    Object.defineProperty(metrics, 'width', {
                        value: metrics.width + (pageRandom() - 0.5) * 0.02,
                        configurable: true
                    });
                }
                return metrics;
            };
        }

        // --- WebGL Spoof ---
        if (config.hardware && config.webglVendor) {
            const origGetParameter = WebGLRenderingContext.prototype.getParameter;
            WebGLRenderingContext.prototype.getParameter = function(parameter) {
                if (parameter === 0x1F00) return config.webglVendor;
                if (parameter === 0x1F01) return config.webglRenderer;
                return origGetParameter.call(this, parameter);
            };

            // WebGL2
            if (window.WebGL2RenderingContext) {
                const origGetParameter2 = WebGL2RenderingContext.prototype.getParameter;
                WebGL2RenderingContext.prototype.getParameter = function(parameter) {
                    if (parameter === 0x1F00) return config.webglVendor;
                    if (parameter === 0x1F01) return config.webglRenderer;
                    return origGetParameter2.call(this, parameter);
                };
            }

            // Spoof getSupportedExtensions
            const origGetSupportedExtensions = WebGLRenderingContext.prototype.getSupportedExtensions;
            WebGLRenderingContext.prototype.getSupportedExtensions = function() {
                const extensions = origGetSupportedExtensions.call(this) || [];
                // Trả về danh sách chuẩn, không để lộ GPU thật
                return extensions.filter(ext => !ext.includes('WEBGL_debug'));
            };

            /**
             * LỖ HỔNG THẬT đã vá: fingerprint qua WebGL không chỉ đọc chuỗi
             * vendor/renderer (đã spoof ở trên) mà còn có thể đọc THẲNG pixel
             * đã render ra qua `gl.readPixels()` — cách này KHÔNG đi qua
             * `canvas.toDataURL()` nên hoàn toàn lọt qua noise đã thêm ở phần
             * Canvas Fingerprint phía trên. Vì pixel render ra phụ thuộc GPU
             * thật (driver, làm tròn số thực khác nhau giữa các GPU), đây là
             * 1 trong những cách fingerprint khó giả nhất — cùng hướng thêm
             * nhiễu nhẹ vào buffer pixel đọc được, giống cách đã làm với
             * `getImageData()`.
             */
            const addPixelNoise = (pixels) => {
                if (!pixels || typeof pixels.length !== 'number') return; // biến thể ghi vào PIXEL_PACK_BUFFER (offset số, không phải TypedArray) — bỏ qua, không có gì để thêm nhiễu
                for (let i = 0; i < pixels.length; i += 4) {
                    if (pageRandom() < 0.01) {
                        pixels[i] = (pixels[i] + 1) % 256;
                    }
                }
            };
            const origReadPixels = WebGLRenderingContext.prototype.readPixels;
            WebGLRenderingContext.prototype.readPixels = function(...args) {
                origReadPixels.apply(this, args);
                addPixelNoise(args[6]);
            };
            if (window.WebGL2RenderingContext) {
                const origReadPixels2 = WebGL2RenderingContext.prototype.readPixels;
                WebGL2RenderingContext.prototype.readPixels = function(...args) {
                    origReadPixels2.apply(this, args);
                    addPixelNoise(args[6]);
                };
            }
        }

        // --- Audio Fingerprint ---
        if (config.audio) {
            const origCreateAnalyser = AudioContext.prototype.createAnalyser;
            AudioContext.prototype.createAnalyser = function(...args) {
                const analyser = origCreateAnalyser.apply(this, args);
                const origGetFloatFrequencyData = analyser.getFloatFrequencyData;
                analyser.getFloatFrequencyData = function(array) {
                    origGetFloatFrequencyData.call(this, array);
                    for (let i = 0; i < array.length; i++) {
                        if (pageRandom() < 0.005) {
                            array[i] += (pageRandom() - 0.5) * 0.1;
                        }
                    }
                };
                return analyser;
            };

            const origCreateOscillator = AudioContext.prototype.createOscillator;
            AudioContext.prototype.createOscillator = function(...args) {
                const osc = origCreateOscillator.apply(this, args);
                return osc;
            };

            // OfflineAudioContext — giả sample rate
            const origOfflineAudioContext = window.OfflineAudioContext;
            if (origOfflineAudioContext) {
                Object.defineProperty(proto.window, 'OfflineAudioContext', {
                    value: class extends origOfflineAudioContext {
                        constructor(...args) {
                            super(...args);
                        }
                    },
                    configurable: true
                });
            }
        }

        // --- Font Enumeration ---
        if (config.font) {
            const commonFonts = [
                'Arial', 'Arial Black', 'Arial Narrow', 'Calibri', 'Cambria',
                'Comic Sans MS', 'Courier New', 'Georgia', 'Helvetica', 'Impact',
                'Lucida Console', 'Lucida Sans Unicode', 'Microsoft Sans Serif',
                'Palatino Linotype', 'Segoe UI', 'Tahoma', 'Times New Roman',
                'Trebuchet MS', 'Verdana', 'Wingdings'
            ];

            if (window.queryLocalFonts) {
                window.queryLocalFonts = async function() {
                    return commonFonts.map(name => ({
                        family: name,
                        fullName: name,
                        postscriptName: name.replace(/\s/g, ''),
                        style: 'Regular'
                    }));
                };
            }

            if (document.fonts && document.fonts.check) {
                const origCheck = document.fonts.check;
                document.fonts.check = function(font, text) {
                    const fontName = font.toLowerCase();
                    for (const common of commonFonts) {
                        if (fontName.includes(common.toLowerCase())) {
                            return true;
                        }
                    }
                    return origCheck.call(this, font, text);
                };
            }

            // Spoof FontFaceSet
            if (document.fonts && document.fonts.values) {
                const origValues = document.fonts.values;
                document.fonts.values = function() {
                    return commonFonts.map(name => ({
                        family: name,
                        status: 'loaded'
                    }))[Symbol.iterator]();
                };
            }
        }

        // --- WebRTC Block ---
        if (config.webrtc) {
            const props = ['RTCPeerConnection', 'webkitRTCPeerConnection', 'RTCDataChannel',
                'RTCSessionDescription', 'RTCIceCandidate', 'RTCSctpTransport',
                'RTCDtlsTransport', 'RTCIceTransport', 'RTCRtpSender', 'RTCRtpReceiver'];
            props.forEach(prop => {
                Object.defineProperty(proto.window, prop, {
                    get: () => undefined,
                    configurable: true
                });
            });
        }

        // --- Performance Spoof ---
        if (config.hardware) {
            const origNow = performance.now.bind(performance);
            performance.now = function() {
                return origNow() + (pageRandom() - 0.5) * 0.5;
            };
        }
    }

    // ===== Nhận config từ native =====
    function setupPort() {
        try {
            const port = browser.runtime.connectNative("browser");
            port.onMessage.addListener((msg) => {
                if (msg && msg.config) {
                    config = { ...config, ...msg.config };
                    // Reseed bằng seed CỐ ĐỊNH THEO HỒ SƠ nhận từ Kotlin —
                    // thay cho seed tạm theo Date.now() lúc script mới
                    // chạy. `| 0` ép về số nguyên 32-bit — an toàn dù
                    // `noiseSeed` (Long ở Kotlin) mất độ chính xác khi
                    // serialize qua JSON/JS number, vì mulberry32 chỉ cần
                    // 32 bit thấp làm seed.
                    if (typeof config.noiseSeed === 'number' && config.noiseSeed) {
                        pageRandom = mulberry32(config.noiseSeed | 0);
                    }
                    applySpoof();
                }
            });
            port.postMessage({ action: "getConfig" });
        } catch (e) {
            console.log("Fingerprint spoof: cannot connect to native port");
        }
    }

    // ===== Chạy ngay =====
    applySpoof();
    if (typeof browser !== 'undefined') {
        setupPort();
    }

    /**
     * FIX BUG THẬT (mục 75 PROJECT_STATUS.md — người dùng chỉ ra đúng chỗ
     * sai trong suy luận trước đó): "dán text lớn vào Colab làm đơ hoàn
     * toàn, nhưng Chrome dán y hệt không sao". Nếu đây là giới hạn CHUNG
     * của việc dán text lớn (mục 61.2/70.4 cũ), Chrome PHẢI đơ y hệt vì
     * chạy CHÍNH file `editor.main.js` này — Monaco tải từ CDN của Colab,
     * không phải code app tự viết, giống hệt nhau trên mọi trình duyệt.
     * Chrome không đơ chứng minh bản thân đoạn JS đó không chậm cố hữu —
     * nó chỉ chậm BẤT THƯỜNG khi chạy trên động cơ JS của Gecko
     * (SpiderMonkey) với ĐÚNG kiểu input này. Bằng chứng trực tiếp: log
     * `onSlowScript` chỉ đích danh CHÍNH XÁC `editor.main.js` (mã của
     * Monaco) đang giữ CPU quá lâu — không phải mã nội bộ nào của Gecko
     * (spellchecker...) — nên fix tắt spellcheck (mục 70.5) nhiều khả
     * năng KHÔNG PHẢI nguyên nhân thật (dù vẫn giữ lại vì vô hại). Đây là
     * hiện tượng CÓ THẬT, đã biết trong giới viết engine JS: bộ tokenizer/
     * tô màu cú pháp dùng regex nặng (chính là việc Monaco làm mỗi khi
     * nội dung đổi) có thể nhanh/chậm khác nhau RẤT NHIỀU giữa các bộ máy
     * regex khác nhau (V8 so với SpiderMonkey) với CÙNG 1 input.
     *
     * SỬA ĐÚNG CHỖ GÂY CHẬM (không phải huỷ dán giữa chừng như mục 70.4 —
     * đúng như người dùng phê bình, huỷ giữa chừng không giải quyết gì,
     * chỉ che dấu hiệu và còn làm mất chữ đang dán): tắt TẠM THỜI việc
     * tokenize/tô màu cú pháp của Monaco (đổi ngôn ngữ model sang
     * 'plaintext' — Monaco bỏ hẳn bước tokenize cho plaintext) NGAY TRƯỚC
     * khi nội dung dán lớn được chèn vào, khôi phục lại ngôn ngữ gốc NGAY
     * SAU KHI chèn xong. Lúc đó Monaco chỉ tokenize lại 1 lần cho toàn bộ
     * nội dung (quy trình nền đã được Monaco tối ưu sẵn cho trường hợp
     * này), thay vì phải chạy tokenize đồng bộ ngay trong lúc xử lý sự
     * kiện paste — đây chính là chỗ tốn CPU bất thường trên Gecko.
     */
    (function setupLargePasteMonacoBypass() {
        const LARGE_PASTE_THRESHOLD = 20000; // ~20k ký tự — đủ nhỏ để không ảnh hưởng paste bình thường, đủ lớn để bắt đúng trường hợp gây đơ đã quan sát được

        /**
         * MỞ RỘNG (mục 80 PROJECT_STATUS.md — người dùng báo "dùng bộ nhớ
         * tạm của bàn phím dán vào VẪN đơ" dù mục 75 đã chặn sự kiện
         * `paste`). Nguyên nhân rất có thể: bảng nhớ tạm CỦA BÀN PHÍM ẢO
         * (GBoard...) khi người dùng chạm để chèn 1 mục đã copy trước đó,
         * KHÔNG LUÔN bắn ra sự kiện `paste` chuẩn của trình duyệt — nhiều
         * bàn phím ảo chèn text qua cơ chế IME (`InputConnection.
         * commitText()` ở tầng Android), Gecko dịch việc này thành sự kiện
         * `beforeinput`/`input` với `inputType: 'insertFromPaste'` (đúng
         * chuẩn Input Events Level 2 — trình duyệt DÙNG inputType này
         * chính xác cho trường hợp "chèn giống như dán nhưng không qua
         * đường clipboard event truyền thống") — KHÔNG bắn `paste` — nên
         * listener ở mục 75 không hề được gọi tới, giải thích đúng khớp
         * triệu chứng "mục 75 không có tác dụng cho đúng trường hợp này".
         *
         * Đã tách logic tắt/bật tokenize dùng chung thành `applyBypass()`,
         * gọi từ CẢ 2 nơi: sự kiện `paste` (giữ nguyên, bắt Ctrl+V/menu dán
         * hệ thống thật) VÀ sự kiện `beforeinput` với
         * `inputType === 'insertFromPaste'` (bắt thêm trường hợp bảng nhớ
         * tạm bàn phím ảo/IME). `beforeinput` cho `text` qua `event.data`
         * (chuỗi, không phải `clipboardData`) — chỉ có sẵn TRỰC TIẾP kích
         * thước qua `event.data.length`, không cần đọc `clipboardData`.
         */
        function applyBypass(text) {
            try {
                if (typeof window.monaco === 'undefined' || !window.monaco.editor || !window.monaco.editor.getEditors) return;
                if (!text || text.length < LARGE_PASTE_THRESHOLD) return;

                const editors = window.monaco.editor.getEditors();
                let target = null;
                for (const ed of editors) {
                    const domNode = ed.getDomNode && ed.getDomNode();
                    if (domNode && domNode.contains(document.activeElement)) { target = ed; break; }
                }
                if (!target) return;
                const model = target.getModel && target.getModel();
                if (!model) return;

                const originalLanguage = model.getLanguageId ? model.getLanguageId() : (model.getModeId ? model.getModeId() : null);
                if (!originalLanguage || originalLanguage === 'plaintext') return; // đã plaintext sẵn thì không có gì để tắt

                window.monaco.editor.setModelLanguage(model, 'plaintext');
                console.log('[colablive] tạm tắt tokenize Monaco (chèn ' + text.length + ' ký tự) để tránh đơ trên Gecko');

                // Khôi phục ngôn ngữ gốc SAU KHI nội dung đã chèn xong —
                // dùng onDidChangeContent (1 lần) thay vì setTimeout cố
                // định, vì thời điểm insertion thật sự hoàn tất phụ thuộc
                // độ dài text, không đoán trước được 1 con số cố định đủ
                // an toàn cho mọi trường hợp.
                const disposable = model.onDidChangeContent(function() {
                    disposable.dispose();
                    // Đợi thêm 1 khung hình để Monaco xử lý xong đợt render
                    // đầu (không tokenize) trước khi bật lại tokenize —
                    // tránh 2 việc nặng chồng lên nhau cùng lúc.
                    requestAnimationFrame(function() {
                        try {
                            window.monaco.editor.setModelLanguage(model, originalLanguage);
                            console.log('[colablive] đã khôi phục ngôn ngữ Monaco: ' + originalLanguage);
                        } catch (e) { /* model có thể đã bị dispose nếu người dùng đổi cell rất nhanh — bỏ qua */ }
                    });
                });
                // Lưới an toàn: nếu onDidChangeContent vì lý do gì đó không
                // bao giờ bắn (paste bị chặn giữa chừng, lỗi khác...), vẫn
                // tự khôi phục ngôn ngữ sau 15s để không kẹt vĩnh viễn ở
                // plaintext (mất tô màu cú pháp) chỉ vì 1 lần lỗi.
                setTimeout(function() {
                    try { disposable.dispose(); } catch (e) {}
                    try {
                        if (model.getLanguageId && model.getLanguageId() === 'plaintext' && originalLanguage !== 'plaintext') {
                            window.monaco.editor.setModelLanguage(model, originalLanguage);
                        }
                    } catch (e) {}
                }, 15000);
            } catch (e) {
                console.log('[colablive] largePasteMonacoBypass lỗi (bỏ qua, không chặn paste bình thường): ' + e.message);
            }
        }

        document.addEventListener('paste', function(event) {
            const text = event.clipboardData ? event.clipboardData.getData('text/plain') : '';
            applyBypass(text);
        }, true); // capture=true — chạy TRƯỚC listener 'paste' riêng của Monaco, kịp đổi ngôn ngữ trước khi Monaco bắt đầu tokenize nội dung vừa chèn

        document.addEventListener('beforeinput', function(event) {
            if (event.inputType !== 'insertFromPaste' && event.inputType !== 'insertFromPasteAsQuotation') return;
            applyBypass(event.data || '');
        }, true);
    })();

})();
