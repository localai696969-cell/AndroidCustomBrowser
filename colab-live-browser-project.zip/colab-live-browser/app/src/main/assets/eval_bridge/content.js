// Cau noi 1 chieu: native (Kotlin) -> content script -> eval trong trang.
// KHONG phai addon that, chi la ha tang de BrowserEngine.evaluateJs() hoat
// dong tren GeckoView giong het WebView.evaluateJavascript().
(function () {
  try {
    var port = browser.runtime.connectNative("browser");
    port.onMessage.addListener(function (msg) {
      if (msg && msg.type === "eval" && typeof msg.script === "string") {
        try {
          (new Function(msg.script))();
        } catch (e) {
          // Nuot loi - script tu feature chon, khong de crash content script
        }
      }
    });
  } catch (e) {
    // Truong hop hiem trang chan native messaging - bo qua an toan
  }
})();
