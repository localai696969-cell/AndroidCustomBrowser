// Cau noi 1 chieu -> 2 chieu: native (Kotlin) -> content script -> eval trong
// trang -> GUI KET QUA THAT (hoac loi that) VE LAI qua port.postMessage().
// TRUOC DAY: loi bi NUOT AM THAM (catch rong), khong bao gio bao ve Kotlin -
// nghia la port connect duoc KHONG co nghia la script chay dung, chi la co
// ket noi thoi. Sua de biet chac chan.
(function () {
  try {
    var port = browser.runtime.connectNative("browser");
    port.onMessage.addListener(function (msg) {
      if (msg && msg.type === "eval" && typeof msg.script === "string") {
        try {
          var value = (new Function(msg.script))();
          port.postMessage({ result: "OK" + (value !== undefined ? (": " + String(value)) : "") });
        } catch (e) {
          port.postMessage({ result: "LOI: " + (e && e.message ? e.message : String(e)) });
        }
      }
    });
  } catch (e) {
    // Truong hop hiem trang chan native messaging - bo qua an toan
  }
})();
