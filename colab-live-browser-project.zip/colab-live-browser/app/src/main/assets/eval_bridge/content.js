// Cau noi 1 chieu -> 2 chieu: native (Kotlin) -> content script -> eval trong
// trang -> GUI KET QUA THAT (hoac loi that) VE LAI qua port.postMessage().
// TRUOC DAY: loi bi NUOT AM THAM (catch rong), khong bao gio bao ve Kotlin -
// nghia la port connect duoc KHONG co nghia la script chay dung, chi la co
// ket noi thoi. Sua de biet chac chan.
//
// BUG NGHIEM TRONG DA SUA (phat hien khi doi chieu truc tiep code Kotlin):
// Kotlin gui field "type": "eval" nhung ban JS truoc day kiem tra sai ten
// field - dieu kien if KHONG BAO GIO dung, script CHUA TUNG duoc thuc thi
// qua cau noi nay tu truoc den gio (ke ca keepPlayingScript chong YouTube
// tu pause). Sua dung "msg.type". Them echo lai "requestId" trong ket qua
// tra ve - phia Kotlin gio dung nhieu callback dong thoi (khac 1 bien
// callback dung chung truoc day, de bi ghi de mat nhau khi co nhieu lenh
// goi evaluateJs() gan nhau).
(function () {
  try {
    var port = browser.runtime.connectNative("browser");
    port.onMessage.addListener(function (msg) {
      if (msg && msg.type === "eval" && typeof msg.script === "string") {
        try {
          // FIX: new Function(script)() chỉ trả về giá trị nếu script có
          // "return" ở cấp cao nhất. Script dạng (function(){...return x;})()
          // là expression-statement — kết quả IIFE tính ra nhưng không được
          // return ra ngoài new Function() → value luôn undefined → log "OK".
          // Sửa: bọc "return <expr>" — nhưng phải trim dấu ";" trailing
          // trước (script Kotlin thường kết thúc bằng ";") để tránh lỗi
          // cú pháp "return (expr;)" không hợp lệ.
          var trimmed = msg.script.trim().replace(/;+$/, "");
          var value = (new Function("return (" + trimmed + ")"))();
          port.postMessage({
            result: "OK" + (value !== undefined ? (": " + String(value)) : ""),
            requestId: msg.requestId
          });
        } catch (e) {
          port.postMessage({
            result: "LOI: " + (e && e.message ? e.message : String(e)),
            requestId: msg.requestId
          });
        }
      }
    });
  } catch (e) {
    // Truong hop hiem trang chan native messaging - bo qua an toan
  }
})();
