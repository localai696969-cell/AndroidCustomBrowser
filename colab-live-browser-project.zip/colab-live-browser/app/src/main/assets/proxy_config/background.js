// Proxy rieng theo tung khe qua browser.proxy.onRequest — API CHUAN cua
// WebExtension (khong phai GeckoRuntimeSettings.arguments(), cach do da xac
// nhan KHONG hoat dong qua bao cao loi cong khai). Xac nhan huong nay dung
// qua Mozilla bug 1525486 (Secure Proxy team): "co the lam duoc bang chinh
// Proxy API san co trong WebExtension".
var proxyConfig = null;

try {
  var port = browser.runtime.connectNative("browser");
  port.onMessage.addListener(function (msg) {
    if (msg && msg.type === "proxy_config") {
      proxyConfig = msg.config;
    }
  });
} catch (e) {}

browser.proxy.onRequest.addListener(function (details) {
  if (!proxyConfig || !proxyConfig.enabled || !proxyConfig.host) {
    return { type: "direct" };
  }
  return {
    type: proxyConfig.type,  // "http" hoac "socks" (SOCKS5)
    host: proxyConfig.host,
    port: proxyConfig.port
  };
}, { urls: ["<all_urls>"] });

// Xac thuc user/pass cho proxy (neu co) — proxy thuong (residential/mobile)
// yeu cau dang nhap, khong xu ly se bi tu choi ket noi qua proxy.
browser.webRequest.onAuthRequired.addListener(function (details) {
  if (details.isProxy && proxyConfig && proxyConfig.username) {
    return {
      authCredentials: {
        username: proxyConfig.username,
        password: proxyConfig.password
      }
    };
  }
}, { urls: ["<all_urls>"] }, ["blocking"]);
