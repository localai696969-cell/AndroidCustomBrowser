# LICH SU LOI BUILD - Cap nhat lien tuc

## Build #81
- Loi: `Could not find geckoview-nightly-arm64-v8a:150.0.20260511200624`
- Nguyen nhan: Version khong ton tai
- Fix: Doi sang `154.0.20260718090721`
- Nguon tra cuu: Maven repository search

## Build #90
- Loi: `compileSdk 36` + `core-ktx:1.19.0`
- Nguyen nhan: SDK qua cu, dependency tu resolve len cao
- Fix: Tang `compileSdk 37`, giu `core-ktx:1.13.1`

## Build #93
- Loi: `plugin already on classpath with unknown version`
- Nguyen nhan: Kotlin plugin conflict
- Fix: Bo `version '2.0.21'`

## Build #96
- Loi: `Cannot add extension with name 'kotlin'`
- Nguyen nhan: AGP 9.1.1 co built-in Kotlin
- Fix: Bo `apply plugin: 'org.jetbrains.kotlin.android'`

## Build #102
- Loi: `Could not find method kotlinOptions()`
- Nguyen nhan: Khong co Kotlin plugin -> khong co `kotlinOptions`
- Fix: Bo `kotlinOptions` block

## Build #105
- Loi: `kotlin-stdlib:2.4.10` incompatible voi compiler 2.2.0
- Nguyen nhan: AGP 9.1.1 built-in Kotlin ~2.2.0, nhung dependencies resolve ra 2.4.10
- Fix: `resolutionStrategy` force `kotlin-stdlib:2.2.10`

## Build #108
- Loi: `org.jetbrains.kotlin.android` plugin khong tuong thich voi AGP 9.1.1 new DSL
- Nguyen nhan: KGP external khong tuong thich voi built-in Kotlin cua AGP 9.1.1
- Fix: Bo KGP external, dung built-in Kotlin
- Nguon tra cuu: https://kotl.in/gradle/agp-built-in-kotlin

## Build #111
- Loi: `AppPrefs.getString` too many arguments + `string/accessibility_service_description` not found
- Nguyen nhan: AppPrefs signature 4 params nhung goi 5 params (thieu featureId); strings.xml thieu resource
- Fix: Them overloaded methods trong AppPrefs; them string resource

## Build #114
- Loi: Nhieu loi syntax Kotlin:
  1. `const val` trong class (khong phai object/companion)
  2. `DeviceProfiles.hardwareProfiles.keys` - List khong co `keys`
  3. `GeckoViewEngine.kt` - `canGoBack`/`canGoForward` la callback, khong phai property; `currentUri` khong ton tai
  4. `ProfilePickerActivity.kt` - Thieu import `View`; `onItemSelected` signature
  5. `PageConverter.kt` + `StreamSniffer.kt` - Regex escape loi
- Fix: 
  - Chuyen `const val` vao `companion object`
  - Dung `map { it.name }` thay vi `.keys` cho List
  - Dung `onCanGoBack`/`onCanGoForward` callbacks + `_canGoBack`/`_canGoForward` fields
  - Dung `onLocationChange` de track `_currentUrl`
  - Them import `android.view.View`; fix `onItemSelected` signature
  - Fix regex escape

## Build #117
- Loi: `onExternalResponse` overrides nothing + `WebResponse` unresolved + `FileCallback` unresolved + `Uri` vs `String`
- Nguyen nhan: API GeckoView khong chinh xac:
  - `WebResponse` la class rieng `org.mozilla.geckoview.WebResponse`, khong phai inner class
  - `onFilePrompt` can 6 params: `(session, title, type, mimeTypes, capture, callback)`
  - `FileCallback` = `GeckoSession.PromptDelegate.FileCallback`
  - `loadUri(String)` nhan **String**, khong phai Uri
- Nguon tra cuu: Mozilla GeckoView CHANGELOG (searchfox.org)
- Fix: Them import `WebResponse`, sua signature `onFilePrompt`, dung `loadUri(String)`

## Build #120
- Loi: 
  1. `ProfilePickerActivity.kt:53` - `Syntax error: Unexpected token` - dung `AdapterView<*>!` (Java annotation) trong Kotlin
  2. `GeckoViewEngine.kt` - `WebResponse` van unresolved (import chua dung)
  3. `PageConverter.kt:31` - `Unsupported escape sequence` - regex escape chua fix
  4. `StreamSniffer.kt` - `invoke` + `Unsupported escape sequence` - code bi hong hoan toan
- Fix:
  1. Dung `AdapterView<*>` thay vi `AdapterView<*>!` trong Kotlin
  2. Import `org.mozilla.geckoview.WebResponse` (class rieng)
  3. Dung raw string `Regex("""...""")` thay vi escape
  4. Rewrite StreamSniffer.kt dung `java.util.regex.Pattern`

## CAC FILE DA THEM MOI
- `DownloadModels.kt` - Data classes cho Download Manager
- `DownloadPolicy.kt` - Quan ly chinh sach download
- `DownloadLocationPicker.kt` - Dialog chon thu muc luu
- `KeepAliveJobService` trong AndroidManifest.xml

## CAC FILE DA SUA
- `build.gradle` (root) - Force kotlin-stdlib version
- `app/build.gradle` - Dung `kotlin.compilerOptions`
- `gradle.properties` - Clean up
- `AndroidManifest.xml` - Them services
- `AppPrefs.kt` - Overloaded methods
- `strings.xml` - Them accessibility_service_description
- `GeckoViewEngine.kt` - Fix API calls (canGoBack/Forward callbacks, onLocationChange, WebResponse, onFilePrompt 6 params)
- `ProfilePickerActivity.kt` - Fix imports + signature
- `AutoBehaviorFeature.kt` - `const val` vao companion
- `ColabLiveKeeperFeature.kt` - `const val` vao companion + import GeckoViewEngine
- `FingerprintSpoofFeature.kt` - Fix List access + const val
- `WebArchiver.kt` - Xoa duplicate ArchiveResult
- `PageConverter.kt` - Fix regex escape
- `StreamSniffer.kt` - Rewrite dung Pattern

## Build #123
- Loi: `unzip` interactive prompt EOF error + `compileSdk 37` khong ton tai + artifact name sai + kotlin block khong hop le
- Nguyen nhan: 
  1. ZIP chua 2 entry trung ten `BUILD_FIX_HISTORY.md` -> unzip hoi overwrite -> EOF tren Actions -> exit code 1
  2. `compileSdk 37` - Android SDK chi co toi da 35
  3. `geckoview-nightly-arm64-v8a` khong ton tai tren Maven
  4. `kotlin` block khong co KGP external -> DSL khong nhan dien
- Fix: 
  1. Them flag `-o` vao lenh unzip trong workflow
  2. Doi `compileSdk 37` -> `compileSdk 35`
  3. Doi artifact name -> `geckoview:${geckoviewVersion}`
  4. Bo block `kotlin`, giu `compileOptions`
- Nguon tra cuu: Maven Central, Android SDK docs, unzip man page

## Build #124
- Loi: `Switch` deprecated + `activity-alias` thieu dong tag + `startAutoBehavior()` sai scope
- Nguyen nhan:
  1. `android.widget.Switch` deprecated tu API 29
  2. XML thieu `>` va `</activity-alias>`
  3. Goi method trong anonymous class khong dung `this@OuterClass`
- Fix:
  1. Doi -> `androidx.appcompat.widget.SwitchCompat`
  2. Them dong tag day du
  3. Them `this@GeckoViewEngine.startAutoBehavior()`

## Build #125
- Loi: `List` khong co `.keys` + `const val` trong class + strings.xml thieu resource
- Nguyen nhan:
  1. `hardwareProfiles` la `List` khong phai `Map`
  2. `const val` chi duoc trong `object`/`companion object`
  3. `AndroidManifest.xml` tham chieu string khong ton tai
- Fix:
  1. Dung `.map { it.name }` thay `.keys`
  2. Chuyen vao `companion object`
  3. Them `accessibility_service_description` vao strings.xml

## Build #126
- Loi: `AppPrefs` key format sai + `RandomAccessFile` leak + `WebView` import trong app GeckoView
- Nguyen nhan:
  1. Truyen `"$id:enabled"` thay vi dung overload 5 params
  2. Khong dung `.use` block cho `RandomAccessFile`
  3. `PageConverter.kt` import `android.webkit.WebView`
- Fix:
  1. Dung `AppPrefs.getBoolean(context, slotIndex, id, "enabled", true)`
  2. Wrap trong `.use { }`
  3. Can xem lai thiet ke - khong dung WebView trong app GeckoView


## Build #126
- Loi: `Could not find org.mozilla.geckoview:geckoview:154.0.20260718090721`
- Nguyen nhan: 
  - Version `154.0.20260718090721` KHONG TON TAI tren Maven
  - Tra cuu Maven Repository: version moi nhat la `150.0.20260511200624` (May 12, 2026)
  - Mozilla khong publish version 154.0, chi co toi da 150.0.x
  - Loi nay da xay ra tu build #81, fix o build #90 nhung lai bi sua sai thanh version khong ton tai
- Fix: 
  - Doi version: `154.0.20260718090721` -> `150.0.20260511200624`
  - Artifact name dung: `geckoview-nightly-arm64-v8a`
- Nguon tra cuu: https://mvnrepository.com/artifact/org.mozilla.geckoview/geckoview
- BAI HOC: KHONG BAO GIO tu nghi version. Phai tra Maven Repository truoc khi viet version vao build.gradle.
