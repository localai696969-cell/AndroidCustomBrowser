# LỊCH SỬ FIX LỖI BUILD

## Build #81
- **Lỗi:** `Could not find geckoview-nightly-arm64-v8a:150.0.20260511200624`
- **Nguyên nhân:** Version không tồn tại
- **Fix:** Đổi sang `154.0.20260718090721`

## Build #90
- **Lỗi:** `compileSdk 36` + `core-ktx:1.19.0`
- **Nguyên nhân:** SDK quá cũ, dependency tự resolve lên cao
- **Fix:** Tăng `compileSdk 37`, giữ `core-ktx:1.13.1`

## Build #93
- **Lỗi:** `plugin already on classpath with unknown version`
- **Nguyên nhân:** Kotlin plugin conflict
- **Fix:** Bỏ `version '2.0.21'`

## Build #96
- **Lỗi:** `Cannot add extension with name 'kotlin'`
- **Nguyên nhân:** AGP 9.1.1 có built-in Kotlin
- **Fix:** Bỏ `apply plugin: 'org.jetbrains.kotlin.android'`

## Build #102
- **Lỗi:** `Could not find method kotlinOptions()`
- **Nguyên nhân:** Không có Kotlin plugin -> không có `kotlinOptions`
- **Fix:** Bỏ `kotlinOptions` block

## Build #105
- **Lỗi:** `kotlin-stdlib:2.4.10` incompatible với compiler 2.2.0
- **Nguyên nhân:** AGP 9.1.1 built-in Kotlin ~2.2.0, nhưng dependencies resolve ra 2.4.10
- **Fix:** Dùng `resolutionStrategy` force `kotlin-stdlib:2.2.10`

## Build #108
- **Lỗi:** `org.jetbrains.kotlin.android` plugin không tương thích với AGP 9.1.1 new DSL
- **Nguyên nhân:** KGP external không tương thích với built-in Kotlin của AGP 9.1.1
- **Fix:** Bỏ KGP external, dùng built-in Kotlin + `android.builtInKotlin=false` -> bỏ luôn, dùng default `true`

## Build #111
- **Lỗi:** `AppPrefs.getString` too many arguments + `string/accessibility_service_description` not found
- **Nguyên nhân:** AppPrefs signature 4 params nhưng gọi 5 params (thiếu featureId); strings.xml thiếu resource
- **Fix:** Thêm overloaded methods trong AppPrefs; thêm string resource

## Build #114
- **Lỗi:** Nhiều lỗi syntax Kotlin:
  1. `const val` trong class (không phải object/companion)
  2. `DeviceProfiles.hardwareProfiles.keys` - List không có `keys`
  3. `GeckoViewEngine.kt` - `canGoBack`/`canGoForward` là callback, không phải property; `currentUri` không tồn tại
  4. `ProfilePickerActivity.kt` - Thiếu import `View`; `onItemSelected` signature
  5. `PageConverter.kt` + `StreamSniffer.kt` - Regex escape lỗi
- **Fix:** 
  - Chuyển `const val` vào `companion object`
  - Dùng `map { it.name }` thay vì `.keys` cho List
  - Dùng `onCanGoBack`/`onCanGoForward` callbacks + `_canGoBack`/`_canGoForward` fields
  - Dùng `onLocationChange` để track `_currentUrl`
  - Thêm import `android.view.View`; fix `onItemSelected` signature nullable
  - Fix regex escape `"` -> `\"`

## CÁC FILE ĐÃ THÊM MỚI
- `DownloadModels.kt` - Data classes cho Download Manager
- `DownloadPolicy.kt` - Quản lý chính sách download
- `DownloadLocationPicker.kt` - Dialog chọn thư mục lưu
- `KeepAliveJobService` trong AndroidManifest.xml

## CÁC FILE ĐÃ SỬA
- `build.gradle` (root) - Force kotlin-stdlib version
- `app/build.gradle` - Dùng `kotlin.compilerOptions`
- `gradle.properties` - Clean up
- `AndroidManifest.xml` - Thêm services
- `AppPrefs.kt` - Overloaded methods
- `strings.xml` - Thêm accessibility_service_description
- `GeckoViewEngine.kt` - Fix API calls
- `ProfilePickerActivity.kt` - Fix imports + signature
- `AutoBehaviorFeature.kt` - `const val` vào companion
- `ColabLiveKeeperFeature.kt` - `const val` vào companion
- `FingerprintSpoofFeature.kt` - Fix List access + const val
- `WebArchiver.kt` - Xóa duplicate ArchiveResult
- `PageConverter.kt` - Fix regex escape
- `StreamSniffer.kt` - Fix regex escape
